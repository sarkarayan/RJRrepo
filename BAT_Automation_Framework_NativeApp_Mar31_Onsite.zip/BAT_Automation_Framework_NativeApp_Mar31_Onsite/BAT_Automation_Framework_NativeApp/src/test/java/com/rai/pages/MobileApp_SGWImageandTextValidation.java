package com.rai.pages;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.rai.framework.Status;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.framework.RecogniseText;
import com.rai.componentgroups.*;
import com.rai.pageObjects.AppHamburgerMenuPageObjects;
import com.rai.pageObjects.AppLoginPageObjects;
import com.rai.pageObjects.brandWebsitePageObjects;




public class MobileApp_SGWImageandTextValidation extends BaseClass {
	
	String testcaseName;
	
		public MobileApp_SGWImageandTextValidation(String testcaseName) {
			this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(AppLoginPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
			
    public void validatingSGWtext() throws Exception {
        String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
        String path = System.getProperty("user.dir") +  "\\src\\test\\resources\\SGW_Images\\SGW_Image.png";
        //commonFunction.scrollIntoView(getPageElement(AppLoginPageObjects.sgwText_PreLogin));
        //Thread.sleep(5000);
        commonFunction.scrollDown();
        commonFunction.validateImage(path, "Pre Login Footer SGW", "SGW Image Validation");

        String actualImageText = RecogniseText.extractImageText(getPageElement(AppLoginPageObjects.sgwText_PreLogin));
        commonFunction.compareStrings(Expected_SGWtext, actualImageText);
    }
 
    public void validatingSGWtextPallMall() throws Exception {
        String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
        String path = System.getProperty("user.dir") +  "\\src\\test\\resources\\SGW_Images\\SGW_PallMall.gif";
        //commonFunction.scrollIntoView(getPageElement(AppLoginPageObjects.sgwText_PreLogin));
        commonFunction.scrollDown();
        //commonFunction.validateImage(path, "Pre Login Footer SGW", "SGW Image Validation");

        String actualImageText = RecogniseText.extractImageText(getPageElement(AppLoginPageObjects.sgwText_PreLogin));
        commonFunction.compareStrings(Expected_SGWtext, actualImageText);
    }

    
    public void validatingSGWtextGrizzlyFooter() throws Exception {
        String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
        String path = System.getProperty("user.dir") +  "\\src\\test\\resources\\SGW_Images\\SGW_grizzly.png";
       // commonFunction.scrollIntoView(getPageElement(AppLoginPageObjects.sgwText_Footer));
        commonFunction.scrollDown();
        commonFunction.scrollDown();
        commonFunction.scrollDown();
        //commonFunction.validateImage(path, "Pre Login Footer SGW", "SGW Image Validation");
        //String altText = commonFunction.getValueFromAttribute(getPageElement(AppLoginPageObjects.sgwText_Footer),AppLoginPageObjects.sgwText_Footer.getObjectname(), "alt");
        if(isElementPresent(By.xpath("//android.widget.LinearLayout/android.widget.TextView"))) {
            commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.sgwText_PreLoginGrizzly), AppLoginPageObjects.sgwText_PreLoginGrizzly.getObjectname(), Expected_SGWtext);
    		} else if(isElementPresent(By.xpath("//*[@resource-id=\"sgwimg\"]"))) {
    			 String actualImageText = RecogniseText.extractImageTextWithoutResize(getPageElement(AppLoginPageObjects.sgwText_snus));
    			 commonFunction.compareStrings(Expected_SGWtext, actualImageText);
    		}
    }
    
    public void validatingSGWtextFooter() throws Exception {
        String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
        String path = System.getProperty("user.dir") +  "\\src\\test\\resources\\SGW_Images\\SGW_Image.png";
       // commonFunction.scrollIntoView(getPageElement(AppLoginPageObjects.sgwText_Footer));
        commonFunction.scrollDown();
        commonFunction.scrollDownFromMid();
       // commonFunction.validateImage(path, "Pre Login Footer SGW", "SGW Image Validation");
        //String altText = commonFunction.getValueFromAttribute(getPageElement(AppLoginPageObjects.sgwText_Footer),AppLoginPageObjects.sgwText_Footer.getObjectname(), "alt");
        String actualImageText = RecogniseText.extractImageText(getPageElement(AppLoginPageObjects.sgwText_Hamburger));
        commonFunction.compareStrings(Expected_SGWtext, actualImageText);
        //commonFunction.compareStrings(Expected_SGWtext, altText);
    }
    
    public void validatingSGWtextFooterNewport() throws Exception {
        String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
        String path = System.getProperty("user.dir") +  "\\src\\test\\resources\\SGW_Images\\SGW_Image.png";
       // commonFunction.scrollIntoView(getPageElement(AppLoginPageObjects.sgwText_Footer));
        commonFunction.scrollDown();
        commonFunction.scrollDownFromMid();
       // commonFunction.validateImage(path, "Pre Login Footer SGW", "SGW Image Validation");
        //String altText = commonFunction.getValueFromAttribute(getPageElement(AppLoginPageObjects.sgwText_Footer),AppLoginPageObjects.sgwText_Footer.getObjectname(), "alt");
        String actualImageText = RecogniseText.extractImageTextUsingScreenShotUsingScreenSize(getPageElement(AppLoginPageObjects.sgwText_Hamburger));
        commonFunction.compareStrings(Expected_SGWtext, actualImageText);
        //commonFunction.compareStrings(Expected_SGWtext, altText);
    }
    
    public void validatingSGWtextFooterPallMall() throws Exception {
        String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
        String path = System.getProperty("user.dir") +  "\\src\\test\\resources\\SGW_Images\\SGW_PallMall.gif";
       // commonFunction.scrollIntoView(getPageElement(AppLoginPageObjects.sgwText_Footer));
        commonFunction.scrollDown();
        commonFunction.scrollDownFromMid();
       // commonFunction.validateImage(path, "Pre Login Footer SGW", "SGW Image Validation");
        //String altText = commonFunction.getValueFromAttribute(getPageElement(AppLoginPageObjects.sgwText_Footer),AppLoginPageObjects.sgwText_Footer.getObjectname(), "alt");
        String actualImageText = RecogniseText.extractImageText(getPageElement(AppLoginPageObjects.sgwText_Hamburger));
        commonFunction.compareStrings(Expected_SGWtext, actualImageText);
        //commonFunction.compareStrings(Expected_SGWtext, altText);
    }
    
    public void validatingSnusSGWtext() throws Exception {
        String Expected_SGWtext = dataTable.getData("General_Data", "NascigsSGWText1");
        String path = System.getProperty("user.dir") +  "\\src\\test\\resources\\SGW_Images\\SGW_snusImage.png";
        commonFunction.scrollDown();
        commonFunction.scrollDownFromMid();
        String actualImageText = RecogniseText.extractImageText(getPageElement(AppLoginPageObjects.sgwText_snus));
        commonFunction.compareStrings(Expected_SGWtext, actualImageText);
    }
    
    public void validatingSGWtextGrizzly() throws Exception {
        String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
		commonFunction.scrollDown();
		commonFunction.scrollDown();
		commonFunction.scrollDown();
		if(isElementPresent(By.xpath("//android.widget.LinearLayout/android.widget.TextView"))) {
        commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.sgwText_PreLoginGrizzly), AppLoginPageObjects.sgwText_PreLoginGrizzly.getObjectname(), Expected_SGWtext);
		} else if(isElementPresent(By.xpath("//*[@resource-id=\"sgwimg\"]"))) {
			 String actualImageText = RecogniseText.extractImageText(getPageElement(AppLoginPageObjects.sgwText_snus));
			 commonFunction.compareStrings(Expected_SGWtext, actualImageText);
		}
    }

    public void validateAppisLaunched() {
    	try {
			commonFunction.isElementPresentVerification(getPageElement(AppLoginPageObjects.menu_AltHomePage),AppHamburgerMenuPageObjects.menu_AltHomePage.getObjectname());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
 
}



