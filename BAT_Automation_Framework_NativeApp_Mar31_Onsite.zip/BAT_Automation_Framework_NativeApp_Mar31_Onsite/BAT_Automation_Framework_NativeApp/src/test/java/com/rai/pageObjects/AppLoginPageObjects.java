package com.rai.pageObjects;

import static com.rai.pageObjects.ObjectLocator.*;

public enum AppLoginPageObjects implements PageObjects {
	
	//AllowPermission
	btn_AppAllowPermission("//*[@resource-id='android:id/switch_widget']",XPATH,"APP Permission Allow"),
	btn_navigateUp("//*[@content-desc=\"Navigate up\"]",XPATH,"Navigate back to App button"),
	//Login Page
	txt_GrizzlyAPPLoginUsername("//android.widget.EditText[@text='Username / Email Address']",XPATH,"Input - APP LoginUsername"),
	txt_GrizzlyAPPLoginPassword("//android.widget.EditText[@text='Password']",XPATH,"Input - APP LoginPassword"),
//	chkbx_RememberMe("//android.widget.Button[@XPath='//hierarchy/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.FrameLayout[1]/android.view.ViewGroup[1]/android.widget.ScrollView[1]/android.view.ViewGroup[1]/android.view.ViewGroup[5]/android.widget.Button[1]']",XPATH,"Checkbox - APP LoginRememberMe"),
//	chkbx_RememberMe("//android.widget.Button[@class='android.widget.ScrollView'/android.view.ViewGroup[1]/android.view.ViewGroup[3]/android.widget.Button[1]]",XPATH,"Checkbox - APP LoginRememberMe"),
	chkbx_RememberMe("//android.widget.Button[@class='android.widget.Button']",XPATH,"Checkbox - APP LoginRememberMe"),

	txt_GrizzlyAPPLoginRememberMe("//android.widget.TextView[@text='Remember Me']",XPATH,"Text - APP Login Remember me checkbox text"),
	btn_GrizzlyAPPLogin("//android.widget.TextView[@text='LOG IN']",XPATH,"Button - APP Login"),
	lnk_GrizzlyAPPLoginForgotUsername("//android.widget.Button[@text='Forgot Username?']",XPATH,"Link - APP Login ForgotUsername"),
	lnk_GrizzlyAPPLoginForgotPassword("//android.widget.Button[@text='Forgot Password?']",XPATH,"Link - APP Login ForgotPassword"),
	btn_GrizzlyAPPRegister("//android.widget.Button[@text='REGISTER']",XPATH,"Button - Register"),
	lnk_PreloginPrivacyPolicy("//android.widget.Button[@text='Privacy Policy']",XPATH,"Link - PreLoginPrivacyPolicy"),
	lnk_PreLoginTermsOfUse("//android.widget.Button[@text='Terms of Use']",XPATH,"Link - PreLoginTermsOfUse"),
	lnk_PreLoginFAQs("//android.widget.Button[@text='FAQs']",XPATH,"Link - PreLoginFAQs"),
	lnk_PreLoginContactUs("//android.widget.Button[@text='Contact Us']",XPATH,"Link - PreLoginContactUs"),
	lnk_PreLoginAppReqs("//android.widget.Button[@text='App Requirements']",XPATH,"Link - PreLoginAppReqs"),
	btn_NotNowEasyLogIn("//android.widget.Button[@text='NOT NOW']",XPATH,"Button - Not Now"),
	
	errormsg_LoginwithoutanyData("//android.widget.TextView[@text='PLEASE FILL IN ALL REQUIRED INFORMATION.']",XPATH,"Error - PLEASE FILL IN ALL REQUIRED INFORMATION."),
	btn_OK_LoginwithoutanyData("//android.widget.Button[@text='OK' or @text='Close']",XPATH,"Button - OK/Close"),
	errormsg_LoginwithNonExistingUserId("//android.widget.TextView[@text='USERNAME OR PASSWORD INCORRECT.']",XPATH,"Error - USERNAME OR PASSWORD INCORRECT."),
	btn_Close_LoginwithWrongData("//android.widget.Button[@text='Close']",XPATH,"Button - Close"),
	errormsg_Usernamefieldformaterror("//android.widget.TextView[@text='USERNAME MUST BE A COMBINATION OF 8-30 LETTERS AND NUMBERS.']",XPATH,"Error - USERNAME MUST BE A COMBINATION OF 8-30 LETTERS AND NUMBERS."),
	
	errormsg_WrongPasswrd("//android.widget.TextView[@text='USERNAME OR PASSWORD INCORRECT.  YOU HAVE 2 ATTEMPTS LEFT.']",XPATH,"Error - USERNAME OR PASSWORD INCORRECT.  YOU HAVE 2 ATTEMPTS LEFT."),
	errormsg_WrongPasswrd2ndattempt("//android.widget.TextView[@text='USERNAME OR PASSWORD INCORRECT.  YOU HAVE 1 ATTEMPT LEFT.']",XPATH,"Error - USERNAME OR PASSWORD INCORRECT.  YOU HAVE 1 ATTEMPT LEFT."),
	errormsg_WrongPasswrd3rdattempt("//android.widget.TextView[@text='USERNAME OR PASSWORD INCORRECT.  ACCOUNT IS LOCKED.  TAP OK TO UNLOCK YOUR ACCOUNT.']",XPATH,"Error - USERNAME OR PASSWORD INCORRECT.  ACCOUNT IS LOCKED.  TAP OK TO UNLOCK YOUR ACCOUNT."),
	
	drpdwn_ForgotUsernameBirthMonth("//android.widget.Spinner[@resource-id='BirthMonth']",XPATH,"Dropdown - BirthMonth"),
	drpdwn_ForgotUsernameBirthDay("//android.widget.Spinner[@resource-id='BirthDay']",XPATH,"Dropdown - BirthDay"),
	drpdwn_ForgotUsernameBirthYear("//android.widget.Spinner[@resource-id='BirthYear']",XPATH,"Dropdown - BirthYear"),
	tooltip_ForgotUsername("//android.view.View[@text='i']",XPATH,"Tooltip -  AcctInformation"),
	txt_ForgotUsernameFirstName("//android.widget.EditText[@resource-id='FirstName']",XPATH,"Input - FirstName"),
	txt_ForgotUsernameLastName("//android.widget.EditText[@resource-id='LastName']",XPATH,"Input -  LastName"),
	txt_ForgotUsernameAddress("//android.widget.EditText[@resource-id='AddressLine1']",XPATH,"Input -  AddressLine"),
	txt_ForgotUsernameZipcode("//android.widget.EditText[@resource-id='ZipCode']",XPATH,"Input -  Zipcode"),
	txt_ForgotUsernameCity("//android.widget.EditText[@resource-id='City']",XPATH,"Input -  City"),
	drpdwn_ForgotUsernameState("//android.widget.Spinner[@resource-id='State']",XPATH,"Dropdown -  State"),
	Continuebtn_LoginResetviaLoginonGeneralInfo("//android.widget.Button[@resource-id='edit-submit']",XPATH,"Button -  AcctInfo Continue"),
	Continuebtn("//android.view.View[@resource-id='next_UserInformation']",XPATH,"Button -  AcctInfo Continue"),
	txt_RegistrationStep1Email("//android.widget.EditText[@resource-id='UserInformation_EmailAddress']",XPATH,"Input - Email"),
	chkbox_RegistrationStep1("//android.widget.CheckBox[@resource-id='UserInformation_IsCertified']",XPATH,"Checkbox - RegistrationStep1Certified"),
	btn_RegistrationStep1Next("//android.widget.Button[@resource-id='next-intro']",XPATH,"Button - RegistrationStep1 Next"),

	
	errmsg_AlreadyRegistered("//android.view.View[@text='It looks like you are already registered with another Reynolds American operating company�s brand website. Please use your CAMEL.COM Username Camelwebsite@tcs.com and password.']",XPATH,"Already Registered Page"),
	btn_AlreadyRegisteredLogin("//android.widget.Button[@text='RETURN TO LOGIN']",XPATH,"Login - AlreadyRegistered"),
	
	txt_ForgotPasswordChallengeAnswer("//android.widget.EditText[@resource-id='ChallengeAnswer']",XPATH,"Input - Challenge Answer"),
	txt_ChallengeAnswer("//android.widget.EditText[@resource-id='UserInformation_ChallengeAnswer']",XPATH,"Input - Challenge Answer"),
	
	//btn_ForgotUsernameVerifyIdentityContinue("//android.view.View[@resource-id='next_AnswerChallengeQuestion']",XPATH,"Button - ForgotUsernameVerifyIdentity Continue"),
	btn_ForgotPasswordVerifyIdentity("//android.widget.Button[@resource-id='edit-submit']",XPATH,"Button - ForgotPassword VerifyIdentity Continue"),

	txt_ForgotPasswordUsername("//android.widget.EditText[@resource-id='userId']",XPATH,"Input - Forgot password Username"),
	btn_ForgotPasswordUsernameContinue("//android.widget.Button[@resource-id='edit-submit']",XPATH,"Forgot password Continue"),
	
	txt_LoginResetAccntInfoEmail("//android.widget.EditText[@resource-id='UserInformation_EmailAddress']",XPATH,"Input - Email"),
	drpdnw_LoginResetAccntInfoChallengeQuestion("//android.widget.Spinner[@resource-id='UserInformation_ChallengeQuestionId']",XPATH,"Dropdown - Challenge Question"),
			
	txt_ForgotPasswordPassword("//android.widget.EditText[@resource-id='inputPassword']",XPATH,"Input - ForgotPassword ResetPassword Passwordfield"),
	txt_Password("//android.widget.EditText[@resource-id='UserInformation_Password']",XPATH,"Input - ForgotPassword ResetPassword Passwordfield"),
	
	txt_ForgotPasswordConfirmPassword("//android.widget.EditText[@resource-id='inputPasswordConfirm']",XPATH,"Input - ForgotPassword ResetPassword ConfirmPasswordfield"),
	txt_ConfirmPassword("//android.widget.EditText[@resource-id='UserInformation_ConfirmPassword']",XPATH,"Input - ForgotPassword ResetPassword ConfirmPasswordfield"),
	
	btn_ForgotPasswordResetPassword("//android.widget.Button[@resource-id='edit-submit']",XPATH,"Button - ForgotPassword ResetPassword Next"),
	txt_CongratsPageUsername("//android.widget.EditText[@resource-id='username']",XPATH,"Input - Username"),
	txt_CongratsPagePassword("//android.widget.EditText[@resource-id='password']",XPATH,"Input - Password"),
	btn_CongratsPageLoginbutton("//android.widget.Button[@resource-id='edit-submit']",XPATH,"Button - Login"),
	
	txt_CongratsPage("///android.view.View[@text='Congratulations!']",XPATH,"Text - Congratulations!"),
	btn_CongratsPageReturnToLogin("//android.view.View[@text='RETURN TO LOGIN']",XPATH,"Button - Return To Login"),
		  
	errormsg_LoginResetAccntInfoNoDataEntered("//android.view.View[@text='Please fix the errors above']",XPATH,"ErrorMessage - Please fix the errors above"),
	errormsg_LoginResetAccntInfoNoPassword("//android.view.View[@text='Please provide a password']",XPATH,"ErrorMessage - password"),
	errormsg_LoginResetAccntInfoNoChallengeQuestion("//android.view.View[@text='Please select a account recovery question']",XPATH,"ErrorMessage - question"),
	errormsg_LoginResetAccntInfoNoChallengeAnswer("//android.view.View[@text='Please provide an answer to account recovery question']",XPATH,"ErrorMessage - answer"),
	errormsg_LoginResetAccntInfoInvalidPasswordFormat("//android.view.View[@text='Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.']",XPATH,"ErrorMessage - IncorrectPasswordformat"),
	errormsg_LoginResetAccntInfoDifferentPasswordEntered("//android.view.View[@text='Passwords did not match']",XPATH,"ErrorMessage - Passwords did not match"),
	errormsg_LoginResetAcctInfoNoEmailEntered("//android.view.View[@text='Please enter a valid email address']",XPATH,"ErrorMessage - Please enter a valid email address"),
	errormsg_LoginResetAccntInfoInvalidEmail("//android.view.View[@text='Please enter a valid email address']",XPATH,"ErrorMessage - Please enter a valid email address"),
	errormsg_LoginResetAccntInfoInactiveEmail("//android.view.View[@text='This is not an active email address. Please provide an active email address.']",XPATH,"ErrorMessage - Please provide an active email address"),
	
	errormsg_LoginResetAccntInfoExistingEmail("//android.view.View[@text='Username already taken. Please try a different one.']",XPATH,"ErrorMessage - Username already taken. Please try a different one."),
	
		
	//SGW
	 sgwText_PreLoginGrizzly("//android.widget.LinearLayout/android.widget.TextView",XPATH,"App Login page - SGW Image text"),
	 //sgwText_PreLogin("//hierarchy/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.FrameLayout[1]/android.view.ViewGroup[1]/android.widget.ScrollView[1]/android.view.ViewGroup[1]/android.view.ViewGroup[7]/android.view.ViewGroup[1]/android.widget.ImageView[1]",XPATH,"App Login page - SGW Image text"),
	 sgwText_PreLogin("//android.widget.ImageView[@class='android.widget.ImageView']",XPATH,"Prelogin footer section - SGW Image text"),   
	 sgwText_Footer("//android.widget.Image[@resource-id='sgwimg']",XPATH,"footerlink section - SGW Image text"),
	 sgwText_Hamburger("//*[@text='CIGARETTES']/following-sibling::*",XPATH,"Hamburger section - SGW Image text"),
	 sgwText_snus("//android.widget.Image[@resource-id=\"sgwimg\"]",XPATH,"SNUS SGW Image text"),
	 
	 //Footer
	 btn_FooterPrivacyPolicy("//android.widget.Button[@text='Privacy Policy']",XPATH,"Footer Button - Privacy Policy"),
	 btn_FooterTermsofUse("//android.widget.Button[@text='Terms of Use']",XPATH,"Footer Button - Terms of Use"),
	 btn_FooterFAQs("//android.widget.Button[@text='FAQs']",XPATH,"Footer Button - FAQs"),
	 btn_FooterContactUs("//android.widget.Button[@text='Contact Us']",XPATH,"Footer Button - Contact Us"),
	 btn_FooterAppRequirements("//android.widget.Button[@text='App Requirements']",XPATH,"Footer Button - App Requirements"),
	 btn_FooterAppVersionpreLogin("//android.widget.Button[@index=1 and @instance=9]",XPATH,"Footer Button - App Version: QA 3.2.3"),
	 btn_FooterAppVersionPostLogin("//android.widget.Button[@index=1 and @instance=5]",XPATH,"Footer Button - App Version "),
	 txt_FAQS("//android.view.View[@text='FAQS']",XPATH,"Text - FAQS"),
	 txt_ContactUs("//android.view.View[@text='CONTACT US']",XPATH,"Text - CONTACT US"),
	 txt_TermsOfUse("//android.view.View[@text='TERMS AND CONDITIONS OF USE']",XPATH,"Text - Terms Of Use"),
	 txt_PrivacyPolicy("//android.view.View[@text='PRIVACY POLICY AND YOUR CALIFORNIA PRIVACY RIGHTS']",XPATH,"Text - Privacy Policy"),
	 txt_AppRequirements("//android.view.View[@text='APP REQUIREMENTS']",XPATH,"Text - App Requirements"),
	 txt_Back("//android.widget.TextView[@text='Back']",XPATH,"Text - Back"),
	 

	//HamburgerMenu
	menu_AltHomePage("//android.view.ViewGroup[@index=1 and @instance=2]",XPATH,"Hamburger Menu - AltHomePage"),
	//menu_AltHomePageBack("//android.view.ViewGroup[@index=0 and @instance=0]",XPATH,"Hamburger Menu - AltHomePage"),
	menu_AltHomePageBack("//hierarchy/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.view.ViewGroup[1]/android.widget.ImageView[1]",XPATH,"Hamburger Menu - AltHomePage"),
	menu_LogoutLink("//android.widget.TextView[@text='LOG OUT']",XPATH,"Hamburger Menu - LogoutLink"),
	;

	
	String strProperty = "";
   	ObjectLocator locatorType = null;
   	String strObjName = "";
   	
	@Override
	public String getProperty() {
		// TODO Auto-generated method stub
		return strProperty;
	}

	@Override
	public ObjectLocator getLocatorType() {
		// TODO Auto-generated method stub
		return locatorType;
	}

	@Override
	public String getObjectname() {
		// TODO Auto-generated method stub
		return strObjName;
	}
	
	private AppLoginPageObjects (String strPropertyValue, ObjectLocator locatorType, String strObjName) {
		// TODO Auto-generated method stub
		this.strProperty = strPropertyValue;
   		this.locatorType = locatorType;
   		this.strObjName = strObjName;
		
	}

}
