package com.rai.pageObjects;

import static com.rai.pageObjects.ObjectLocator.*;

public enum AppLoginPageObjects implements PageObjects {
	
	//AllowPermission
	btn_AppAllowPermission("//android.widget.Switch[@resource-id='android:id/switch_widget']",XPATH,"APP Permission Allow"),
	//Login Page
	txt_GrizzlyAPPLoginUsername("//android.widget.EditText[@text='Username / Email Address']",XPATH,"Input - APP LoginUsername"),
	txt_GrizzlyAPPLoginPassword("//android.widget.EditText[@text='Password']",XPATH,"Input - APP LoginPassword"),
	//chkbox_GrizzlyAPPLoginRememberMe("//android.widget.Button['@class='android.widget.ScrollView[1]/android.view.ViewGroup[1]/android.view.ViewGroup[3]/android.widget.Button[1]']",XPATH,"Checkbox - APP LoginRememberMe"),
	txt_GrizzlyAPPLoginRememberMe("//android.widget.TextView[@text='Remember Me']",XPATH,"Text - APP Login Remember me checkbox text"),
	btn_GrizzlyAPPLogin("//android.widget.TextView[@text='LOG IN']",XPATH,"Button - APP Login"),
	lnk_GrizzlyAPPLoginForgotUsername("//android.widget.Button[@text='Forgot Username?']",XPATH,"Link - APP Login ForgotUsername"),
	lnk_GrizzlyAPPLoginForgotPassword("//android.widget.Button[@text='Forgot Password?']",XPATH,"Link - APP Login ForgotPassword"),
	btn_GrizzlyAPPRegister("//android.widget.Button[@text='REGISTER']",XPATH,"Button - Register"),
	lnk_PreloginPrivacyPolicy("//android.widget.Button[@text='Privacy Policy']",XPATH,"Link - PreLoginPrivacyPolicy"),
	lnk_PreLoginTermsOfUse("//android.widget.Button[@text='Terms of Use']",XPATH,"Link - PreLoginTermsOfUse"),
	lnk_PreLoginFAQs("//android.widget.Button[@text='FAQs']",XPATH,"Link - PreLoginFAQs"),
	lnk_PreLoginContactUs("//android.widget.Button[@text='Contact Us']",XPATH,"Link - PreLoginContactUs"),
	lnk_PreLoginAppReqs("//android.widget.Button[@text='App Requirements']",XPATH,"Link - PreLoginAppReqs"),
	
	
	;

	
	String strProperty = "";
   	ObjectLocator locatorType = null;
   	String strObjName = "";
   	
	@Override
	public String getProperty() {
		// TODO Auto-generated method stub
		return strProperty;
	}

	@Override
	public ObjectLocator getLocatorType() {
		// TODO Auto-generated method stub
		return locatorType;
	}

	@Override
	public String getObjectname() {
		// TODO Auto-generated method stub
		return strObjName;
	}
	
	private AppLoginPageObjects (String strPropertyValue, ObjectLocator locatorType, String strObjName) {
		// TODO Auto-generated method stub
		this.strProperty = strPropertyValue;
   		this.locatorType = locatorType;
   		this.strObjName = strObjName;
		
	}

}
