package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_ContactUs {
	
	
	
	public static By weContactUs= By.xpath(".//*[@id='unbranded']");
	public static By lnkSubmit= By.xpath(".//*[@id='edit-submit']");
	public static By lnkDropDown=By.xpath(".//*[@class='default ng-pristine ng-untouched ng-invalid ng-invalid-required form-select required']");
	public static By lnkDropitem=By.xpath(".//*[text()='Technical Help']");
	public static By weComment=By.xpath(".//*[@id='email-content']");
	public static By weAfter=By.xpath("//*[@id='unbranded']");
}
