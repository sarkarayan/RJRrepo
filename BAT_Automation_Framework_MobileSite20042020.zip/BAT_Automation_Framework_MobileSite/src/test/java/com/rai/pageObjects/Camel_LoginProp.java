package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_LoginProp {
	public static By txtUsername = By.id("username");
	public static By txtPassword = By.id("password");
	public static By lnkLogin = By.id("edit-submit");
	public static By weUsername=By.xpath(".//*[@id='usernameError']");
	public static By wePassword=By.xpath(".//*[@id='passwordError']");
	public static By weCheckboxRememberme =By.id("IsRememberUserChecked");
	//public static By checkboxTakemetoEmailPreferences =By.id("IsPreferenceScanChecked");
	public static By btnRegister = By.xpath(".//*[text()='Sign me up!']");
	public static By lnkForgotUserId =By.xpath(".//a[.='Forgot Username?']");
	public static By lnkForgotPassword=By.xpath(".//a[.='Forgot Password?']");
	public static By pgforgotPsw = By.xpath(".//*[text()='Forgot Your Password?']");
	public static By pgForgotuserId = By.xpath(".//*[text()='Forgot Your Username?']");

	//Forgot Password
	public static By weUserName = By.xpath(".//*[@id='userId']");
	public static By btnContinueGeneral = By.id("edit-submit");
	public static By pgVerifyYourIdentity = By.xpath(".//*[text()='Verify Your Identity']");
	public static By weChallengeAnswer = By.xpath(".//*[@id='ChallengeAnswer']");
	public static By btnContinue = By.xpath(".//*[@id='edit-submit']");
	public static By pgResetPassword = By.xpath(".//*[text()='Reset Your Password']");
	public static By wePasswordFP = By.id("inputPassword");
	public static By weConfirmPassword = By.id("inputPasswordConfirm");
	public static By pgCongratulations = By.xpath(".//*[text()='Congratulations!']");

	//Forget UserID
	public static By weBirthmonth = By.id("BirthMonth");
	public static By weBirthDay = By.id("BirthDay");
	public static By weBirthYear = By.id("BirthYear");
	public static By weFirstName = By.id("FirstName");
	public static By weLaseName = By.id("LastName");
	public static By weAddress = By.id("AddressLine1");
	public static By weZipCode = By.id("ZipCode");
	public static By btnContinueForgotUserId= By.id("next_UserInformation");
	public static By weCity = By.id("City");
	public static By btnContinueChallengeAns = By.id("next_AnswerChallengeQuestion");
	public static By pgWelcomeBack = By.xpath(".//*[text()='Welcome Back!']");
	public static By wePasswordUserID = By.id("password");
	public static By weuserID = By.id("userId");
	public static By btnLogin = By.xpath(".//*[@id='edit-submit']");




}
