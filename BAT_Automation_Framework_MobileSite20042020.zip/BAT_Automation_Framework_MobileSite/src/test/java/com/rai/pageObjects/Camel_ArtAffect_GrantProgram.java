package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_ArtAffect_GrantProgram {
	public static By weGrantProgramHeroTile=By.xpath(".//*[contains(@class,'sc-bdVaJa sc-bwzfXH hWeXcz')]");//Prathisha
	public static By btnVideoGrantProgramHeroTile=By.xpath("(//*[text()='Play Video'])[1]");//Prathisha
	public static By weHeroTileVideoOverlay=By.xpath(".//*[@id='Video-5840554795001_html5_api']");
	public static By btnHeroTileVideoOverlayClose=By.xpath("(.//*[@class='styles__CloseButton-sc-1uvfz74-2 eofSUE styles__StyledButton-sc-4qcnu1-0 cVrrfY'])[1]");
	//Prathisha
	public static By weSectionGrantProgram=By.xpath(".//*[@class='sc-bdVaJa sc-bwzfXH sc-bxivhb gqmXXq']");//Prathisha
	public static By weGranteeSection1 = By.xpath(".//*[@class='sc-bdVaJa sc-bwzfXH sc-bxivhb ifwZMk']");//Prathisha 
	public static By weGranteeSection2 = By.xpath(".//*[@class='sc-bdVaJa sc-bwzfXH sc-bxivhb kiMTMj']");//Prathisha
	public static By btnArtistAric = By.xpath(".//*[text()='Meet Aric']");
	public static By btnArtistChris = By.xpath(".//*[text()='Meet Chris']");
	public static By btnArtistJeromie = By.xpath(".//*[text()='Meet Jeromie']");
	public static By btnArtistKatie = By.xpath(".//*[text()='Meet Katie']");
	public static By btnArtistBob = By.xpath(".//*[text()='Meet Bob']");
	public static By btnArtistThem = By.xpath(".//*[text()='Meet Them']");
	public static By btnArtistDB = By.xpath(".//*[text()='Meet DB']");
	public static By weLatestBuild = By.xpath("(.//*[@class='Box-yh4gdj-0 giYeqr'])[3]");
	public static By btnSeeBuild = By.xpath(".//*[@href='/art-affect/detroit']");
	public static By weArtistModel=By.xpath(".//*[@class='Box-yh4gdj-0 hmLyeY']");
    public static By btnArtistModelClose=By.xpath("(.//*[@class='styles__CloseButton-sc-1uvfz74-2 eofSUE styles__StyledButton-sc-4qcnu1-0 cVrrfY'])[2]");
   //end Prathisha
	
	
	//images of project collaborators
	public static By weImgProjectCollabaorator1GrantProgram=By.xpath("(.//*[@class='headline-block artist-bio'])[1]");
	public static By weImgProjectCollabaorator2GrantProgram=By.xpath("(.//*[@class='headline-block artist-bio'])[2]");
	public static By weImgProjectCollabaorator3GrantProgram=By.xpath("(.//*[@class='headline-block artist-bio'])[3]");
	public static By weImgProjectCollabaorator4GrantProgram=By.xpath("(.//*[@class='headline-block artist-bio'])[4]");
	
	//names of project collaborators in Grant program page
	public static By weTxtProjectCollabaorator1GrantProgram=By.xpath(".//*[text()='MATT SHULTZ']");
	public static By weTxtProjectCollabaorator2GrantProgram=By.xpath(".//*[text()='ARIC SHAPIRO']");
	public static By weTxtProjectCollabaorator3GrantProgram=By.xpath(".//*[text()='DAVE AIAZZI']");
	public static By weTxtProjectCollabaorator4GrantProgram=By.xpath(".//*[text()='HILLARY L. SCHIEVE']");
	
	public static By weImgGrantProgramCollaborators=By.xpath("(.//*[@class='container-inner'])[6]");
	public static By btnGrantProgramMeetTheArtist=By.xpath(".//*[text()='Meet The Artists']");
	public static By btnPoppsEmporium=By.xpath("(.//*[@class='btn btn--transparent'])[1]");
	public static By btnConfluence=By.xpath("(.//*[@class='btn btn--transparent'])[3]");
	public static By btnPaperMachine=By.xpath("(.//*[@class='btn btn--transparent'])[2]");

	// content of project collaborators in Grant Program collaborators page
	public static By weTxtProjectCollabaorator1=By.xpath("(.//*[@class='container-inner'])[3]");
	public static By weTxtProjectCollabaorator2=By.xpath("(.//*[@class='container-inner'])[5]");
	public static By weTxtProjectCollabaorator3=By.xpath("(.//*[@class='container-inner'])[7]");
	public static By weTxtProjectCollabaorator4=By.xpath("(.//*[@class='container-inner'])[9]");
	
	public static By weArtAffectProjectCollaboratorTitle=By.xpath("(.//*[@class='container-inner'])[1]");

//Images of the Collaborators in Grant Program Collaborators page
	public static By weImgGrantProgramProjectCollabaorator1=By.xpath(".//*[@class='hero-artist grant-program-one']");
	public static By weImgGrantProgramProjectCollabaorator2=By.xpath(".//*[@class='hero-artist grant-program-two']");                                                                                  
    public static By weImgGrantProgramProjectCollabaorator3=By.xpath(".//*[@class='hero-artist grant-program-three']");
    public static By weImgGrantProgramProjectCollabaorator4=By.xpath(".//*[@class='hero-artist grant-program-four']");


//View project button of DB Burkeman and Public shelter of the featured grantees
    public static By btnViewProjectDBBurkeman=By.xpath("(.//*[text()='View Project'])[1]");
    public static By btnViewProjectPublicShelter=By.xpath("(.//*[text()='View Project'])[2]");
//Featured grantees
    public static By weTxtFeaturedGrantees=By.xpath("(.//*[text()='Featured Grantees'])[1]");
    public static By weTxtAbout=By.xpath(".//*[text()='About']");
    public static By weImgArtistDB1=By.xpath("(.//*[@alt='City Map'])[1]");
    public static By weImgArtistDB2=By.xpath("(.//*[@alt='Home Exterior'])[1]");
    public static By weImgArtistDB3=By.xpath("(.//*[@alt='House Frame'])[1]");
    
    public static By weImgArtistChris1=By.xpath("(.//*[@alt='City Map'])[2]");
    public static By weImgArtistChris2=By.xpath("(.//*[@alt='Home Exterior'])[2]");
    public static By weImgArtistChris3=By.xpath("(.//*[@alt='House Frame'])[2]");
    
    public static By weTxtFeaturedGrantees1=By.xpath("(.//*[@class='Box-yh4gdj-0 giYeqr'])[1]");
    public static By weTxtFeaturedGrantees2=By.xpath("(.//*[@class='Box-yh4gdj-0 giYeqr'])[2]");


}
	
	