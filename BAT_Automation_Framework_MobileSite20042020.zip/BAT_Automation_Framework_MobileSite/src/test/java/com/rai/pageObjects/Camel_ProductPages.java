package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_ProductPages {
	//crush product page
	public static By weTxtCrush=By.xpath("(.//*[@id='home-content'])[1]");
	public static By weCrushPack=By.xpath(".//*[@id='crush-canvas']");
	public static By weCrushTitle=By.xpath(".//*[@id='crushing']");
	//classics product page
	public static By weTxtClassics=By.xpath("(.//*[@class='clipper'])[1]");
	public static By weImgClassicsTitle=By.xpath("(//span[text()='Classics'])[1]");
	//wides product page
	public static By weTxtWides=By.xpath("(.//*[@id='wides'])[1]");
	public static By weImgWidesPack=By.xpath("(.//*[@class='Product-hero-content'])[4]");
	//Red Kamel
	public static By weTxtRedKamel =By.xpath("(.//*[@id='red-kamel'])[1]");
	public static By weImgRedKamel =By.xpath("(.//*[@class='Product-hero-content'])[6]");
	//No 9
	public static By weImgNo9 =By.xpath("(.//*[@class='Product-hero-content'])[5]");
	public static By weNo9 =By.xpath("(.//*[@id='no9'])[1]");
	//snus
	public static By weImgSnus =By.xpath("(.//*[text()='SNUS'])[1]");
	public static By weSnus =By.xpath("(.//*[@id='snus'])[1]");
	//Suneel menu navigation
	//Products page text
		public static By weProductsPage = By.xpath(".//*[text()='Camel Products']");
		public static By weCreationsPage = By.xpath("(.//*[text()='Camel Creations'])[2]");
		//Snus
		public static By weSnusFrost = By.xpath(".//*[text()='CAMEL ' and 'SNUS FROST']");
		public static By weLargestrobost = By.xpath(".//*[text()='CAMEL SNUS ' and 'LARGE ROBUST']");
		public static By weSnussMellow = By.xpath(".//*[text()='CAMEL ' and 'SNUS MELLOW']");
		public static By weSnusMint = By.xpath(".//*[text()='CAMEL ' and 'SNUS MINT']");
		public static By weSnusLargeFrost = By.xpath(".//*[text()='CAMEL SNUS ' and 'LARGE FROST']");
		public static By weSnusLargeWinterchill = By.xpath(".//*[text()='CAMEL SNUS ' and 'LARGE WINTERCHILL']");
		public static By lnkBacktoAll = By.xpath("(.//*[contains(@class,'styles__BackArrow-u1fekm-6 cIoKCn')])[1]");
		public static By lnkClicktoOpen = By.xpath(".//*[text()='Click' and 'Open']");	
		public static By weRightArrow = By.xpath("(.//*[@viewBox='0 0 100 100'])[1]");
		public static By weLeftArrow = By.xpath("(.//*[@viewBox='0 0 100 100'])[2]");
		public static By weExperiencemyFlavor = By.xpath("(.//*[contains(@class,'styles__OfferDetails-sc')])");
		public static By weSecondSection = By.xpath("((.//*[contains(@class,'styles__Container-sc')]))[2]");	
		public static By btnViewCoupon = By.xpath("(.//*[text()='View Coupon'])[1]");
		public static By weSnusWarning = By.xpath(".//*[@class='SGW u-display-large-up']");
		public static By lnkClickClose = By.xpath(".//*[text()='Click' and 'Close']");
		public static By weFooter = By.id("footer");
		public static By pgCrush = By.xpath("(.//*[@id='crush-canvas'])[1]");
		
}
