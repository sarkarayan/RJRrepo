package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_ArtAffect_Builds {
	
	//Camel Login Page
		public static By lgnPgSgnIn = By.xpath(".//*[@class='headline'and contains(text(),'Sign In')]");
	
	//link for builds
		public static By lnkArtAffect = By.xpath(".//a[text()='artAffect']");
		public static By lnkBuilds=By.xpath("//*[text()='Builds']");
		
	//Elements of Header section of ArtAffect Builds page
		public static By imgTxtArtAffect = By.xpath(".//*[@id='ArtAffect']");
		public static By imgTxtBuilds = By.xpath("(//*[text()='Builds'])[2]");
		public static By imgTxtHeader = By.xpath("(//*[@class='Text-sc-1n4wa1f-0 gAmqUn'])[1]");
	
	// Elements of Popps emporium section of ArtAffect Builds page
		public static By txtPoppsEmprm = By.xpath("//p[text()='Popps Emporium']");
		public static By txtDtrtMI = By.xpath("(//p[text()='Detroit, MI'])");
		public static By txtFllwng = By.xpath("//p[contains(text(),'Following')]");
		public static By seeBuildsBtn = By.xpath("//*[@data-ca-tracking='Builds Landing Page - Popps Emporium Build: See Build']");
		public static By txtLatstBlds = By.xpath(".//*[text()= 'Latest Build']");
		public static By img1CityMap = By.xpath(".//*[@alt='City Map']");
		public static By img2PpsEmprm = By.xpath(".//*[@alt='Home Exterior']");
		public static By img3PpsEmprm = By.xpath(".//*[@alt='House Frame']");
	
	//Element of Popps Emporium Page
		public static By popsEmprmPageElmnt = By.xpath("(//*[text()='Popps Emporium'])[1]");
	
	//Elements of Paper Machine section of ArtAffect builds page
		public static By img1NewOrlns = By.xpath(".//*[@alt='New Orleans']");
		public static By img2PprMchne = By.xpath(".//*[@alt='Paper Machine Printing Hub']");
		public static By img3PprMchne = By.xpath(".//*[@alt='Painting Wall']");
		public static By txtPprMachne = By.xpath("//p[contains(text(),'Paper Machine')]");
		public static By txtNewOrlns = By.xpath("//p[contains(text(),'New Orleans, LA')]");
		public static By txtForDcds = By.xpath(".//p[contains(text(),'For decades')]");
		public static By pprMchnSeeBld = By.xpath(".//*[contains(@href,'new-orleans')]");
		
	//Element of page Paper Machine
		public static By pprMchnPageElmnt = By.xpath(".//h1[contains(text(),'Paper Machine')]");
		
	// Elements of Confluence section of Art Affect Builds page
		public static By txtConflunce = By.xpath(".//p[contains(text(),'Confluence')]");
		public static By txtKnsasCity = By.xpath(".//p[contains(text(),'Kansas City, MO')]");
		public static By txtMsgCnflnc = By.xpath(".//p[contains(text(),'project: Confluence')]");
		public static By img1Cnflnce = By.xpath(".//*[@alt='Out Door Canopy']");
		public static By img2Cnflnce = By.xpath(".//*[@alt='Canopy Close Up']");
		public static By img3Cnflnce = By.xpath(".//*[@alt='Canopy Wall']");
		public static By cnflnceSeeBld = By.xpath(".//*[contains(@href,'kansas-city')]");
		
	//Element of Confluence page
		public static By cnflncePgElmnt = By.xpath(".//h1[contains(text(),'Confluence')]");
	
	//Elements of Grant Program section
		public static By txtGrntPgm = By.xpath(".//h2[contains(text(),'Grant Program')]");
		public static By txtMsgGrntPgm = By.xpath(".//*[contains(text(),'Our grants support')]");
		public static By learnMoreBtn = By.xpath(".//*[contains(@href,'grant-program')"
				+ "and contains(text(),'Learn More')]");
	
	//Element of Grant Program page
		public static By grntPgmPgElmnt = By.xpath(".//h2[contains(text(),'Grant Program')]");
		
		
		
		
		
		
		
}
