package com.rai.pageObjects;

import static com.rai.pageObjects.ObjectLocator.*;

public enum AppForgotUsernamePageObjects implements PageObjects {
	
	//AllowPermission
		btn_AppAllowPermission("//android.widget.Switch[@resource-id='android:id/switch_widget']",XPATH,"APP Permission Allow"),

	//ForgotUsername
	    lnk_GrizzlyAPPLoginForgotUsername("//android.widget.Button[@text='Forgot Username?']",XPATH,"Link - APP Login ForgotUsername"),
		lnk_ForgotUsernameAcctInfoBacktoLogin("//android.widget.TextView[@text='Back to Login']",XPATH,"Link - ForgotUsernameAcctInfo BacktoLogin text"),
		drpdwn_ForgotUsernameBirthMonth("//android.widget.Spinner[@resource-id='BirthMonth']",XPATH,"Dropdown - ForgotUsernameBirthMonth"),
		drpdwn_ForgotUsernameBirthDay("//android.widget.Spinner[@resource-id='BirthDay']",XPATH,"Dropdown - ForgotUsernameBirthDay"),
		drpdwn_ForgotUsernameBirthYear("//android.widget.Spinner[@resource-id='BirthYear']",XPATH,"Dropdown - ForgotUsernameBirthYear"),
		tooltip_ForgotUsername("//android.view.View[@text='i']",XPATH,"Tooltip - ForgotUsername AcctInformation"),
		txt_ForgotUsernameFirstName("//android.widget.EditText[@resource-id='FirstName']",XPATH,"Input - ForgotUsername FirstName"),
		txt_ForgotUsernameLastName("//android.widget.EditText[@resource-id='LastName']",XPATH,"Input - ForgotUsername LastName"),
		txt_ForgotUsernameAddressLine("//android.widget.EditText[@resource-id='AddressLine1']",XPATH,"Input - ForgotUsername AddressLine"),
		txt_ForgotUsernameZipcode("//android.widget.EditText[@resource-id='ZipCode']",XPATH,"Input - ForgotUsername Zipcode"),
		txt_ForgotUsernameCity("//android.widget.EditText[@resource-id='City']",XPATH,"Input - ForgotUsername City"),
		Drpdwn_ForgotUsernameState("//android.widget.Spinner[@resource-id='State']",XPATH,"Dropdown - ForgotUsername State"),
		btn_ForgotUsernameAcctInfoConitnue("//android.view.View[@resource-id='next_UserInformation' or @text='CONTINUE']",XPATH,"Button - ForgotUsername AcctInfo Continue"),
		
		lnk_ForgotUsernameVerifyIdentityBacktoLogin("//android.widget.TextView[@text='Back to Login']",XPATH,"Link - ForgotUsernameVerifyIdenity BacktoLogin text"),
		txt_ForgotUsernameVerifyIdentityChallengeAnswer("//android.widget.EditText[@resource-id='ChallengeAnswer']",XPATH,"Input - ForgotUsernameVerifyIdentity ChallengeAnswer"),
		btn_ForgotUsernameVerifyIdentityContinue("//android.view.View[@resource-id='next_AnswerChallengeQuestion']",XPATH,"Button - ForgotUsernameVerifyIdentity Continue"),
		
		lnk_ForgotUsernameWelcomeBackBacktoLogin("//android.widget.TextView[@text='Back to Login']",XPATH,"Link - ForgotUsernameWelcomeBack BacktoLogin text"),
		txt_ForgotUsernameUserIdDetails("//android.view.View[@resource-id='userId']",XPATH,"UserId - ForgotUsername WelcomeBack page"),
		btn_ForgotUsernameReturntoLogin("//android.widget.Button[@text='RETURN TO LOGIN']",XPATH,"ReturnToLogin button - WelcomeBack page"),
		
		//Errormessages AcctInformationPage
		errormsg_AcctInfowithoutanydata("//android.view.View[@text='Please fix the errors above']",XPATH,"Errormsg - Please fix the errors above"),
		errormsg_AcctInforwithoutState("//android.view.View[@resource-id='stateError']",XPATH,"Errormsg - Please provide State"),
		errormsg_AcctInfowithoutCity("//android.view.View[@resource-id='cityError']",XPATH,"Errormsg - Please provide City"),
		errormsg_AcctInfowithoutZipcode("//android.view.View[@resource-id='zipCodeError']",XPATH,"Errormsg - Please provide a Zipcode"),
		errormsg_AcctInfowihtoutDOB("//android.view.View[@resource-id='dobError']",XPATH,"Errormsg - Please provide a DateOfBirth"),
		errormsg_AcctInfowihtoutLegalName("//android.view.View[@resource-id='nameError']",XPATH,"Errormsg - Please enter your legalname"),
		errormsg_AcctInfowithoutAddress("//android.view.View[@resource-id='streetAddressError']",XPATH,"Errormsg - Please provide a street Address"),
		
		
		//Errormessages VerifyIdentityPage
		errormsg_VerifyIdenityChallengeAnswer("//android.view.View[@resource-id='answerError']",XPATH,"Errormsg - Please provide an answer to account recovery question"),
		errormsg_VerifyIdentitywithoutanydata("//android.view.View[@text='Please fix the errors above']",XPATH,"Errormsg - Please fix the errors above"),
	
	;
	

	
	String strProperty = "";
   	ObjectLocator locatorType = null;
   	String strObjName = "";
   	
	@Override
	public String getProperty() {
		// TODO Auto-generated method stub
		return strProperty;
	}

	@Override
	public ObjectLocator getLocatorType() {
		// TODO Auto-generated method stub
		return locatorType;
	}

	@Override
	public String getObjectname() {
		// TODO Auto-generated method stub
		return strObjName;
	}
	
	private AppForgotUsernamePageObjects (String strPropertyValue, ObjectLocator locatorType, String strObjName) {
		// TODO Auto-generated method stub
		this.strProperty = strPropertyValue;
   		this.locatorType = locatorType;
   		this.strObjName = strObjName;
		
	}
	
}
