package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_ArtAffect_PublicShelter {
	
	public static By wePgPublicShelter=By.xpath("(.//*[text()='The Public Shelter Project'])[1]");
	public static By weArtAffectLogo=By.xpath("(.//*[@class='styles__Svg-sc-12jbcao-0 iJTrZf'])[1]");
	public static By weTxtChrisWyattScott=By.xpath("(.//*[text()='Chris Wyatt Scott'])[1]");
	public static By weTxtBuildingAnOasis=By.xpath("(.//*[text()='Building an oasis for those who need it most.'])[1]");

	public static By weTxtTheProject=By.xpath("(.//*[text()='The Project'])[1]");

	public static By weImgTheProject1=By.xpath("(.//*[@alt='New Orleans'])[1]");
	public static By weImgTheProject2=By.xpath("(.//*[@alt='Paper Machine Printing Hub'])[1]");
	public static By weImgTheProject3=By.xpath("(.//*[@alt='Painting Wall'])[1]");
	
	public static By weTxtTheProjectContent=By.xpath("(.//*[@class='sc-bdVaJa sc-bwzfXH sc-bxivhb hoZBar'])[1]");
	public static By weTxtProjectGallery=By.xpath("(.//*[text()='Project Gallery'])[1]");
	public static By btnRightArrowProjectGallerysection=By.xpath("(.//*[@class='flickity-button flickity-prev-next-button next'])[1]");
	public static By btnLeftArrowProjectGallerysection=By.xpath("(.//*[@class='flickity-button flickity-prev-next-button previous'])[1]");
	public static By btnPaginationDot1=By.xpath("(.//*[@class='dot '])[1]");
	
	
	public static By weImgProjectGallery1=By.xpath("(.//*[@class='Box-yh4gdj-0 lctLFy'])[4]");
	public static By weImgProjectGallery2=By.xpath("(.//*[@class='Box-yh4gdj-0 lctLFy'])[5]");
	public static By weImgProjectGallery3=By.xpath("(.//*[@class='Box-yh4gdj-0 lctLFy'])[6]");
	public static By weImgProjectGallery4=By.xpath("(.//*[@class='Box-yh4gdj-0 lctLFy'])[7]");
	
	public static By weTxtChrisProjectGallery=By.xpath("(.//*[text()='Chris Wyatt Scott'])[2]");
	
	
	public static By weTxtProjectGallery1=By.xpath("(.//*[text()='Two of the three shelters ready to go at The Generator.'])[1]");
	public static By weTxtProjectGallery2=By.xpath("(.//*[text()='The finishing touches.'])[1]");
	public static By weTxtProjectGallery3=By.xpath("(.//*[text()='Inside the cabin-inspired mobile shelter.'])[1]");
	public static By weTxtProjectGallery4=By.xpath("(.//*[text()='A common source of shelter for the homeless in Reno.'])[1]");
	
	public static By WeExploreMoreBuilds=By.xpath("//*[text()='Explore More Builds']");
	
	public static By WePOPPSEMPORIUM=By.xpath("//*[text()='Popps Emporium']");
	public static By WePaperMachine=By.xpath("//*[text()='Paper Machine']");
	public static By WeConfluence=By.xpath("//*[text()='Confluence']");
	
	
	public static By BtnLearnmorePOPPSEMPORIUM=By.xpath("(//*[text()='Learn More'])[1]");
	public static By BtnLearnmorePaperMachine=By.xpath("(//*[text()='Learn More'])[2]");
	public static By BtnLearnmoreConfluence=By.xpath("(//*[text()='Learn More'])[3]");
	
	public static By WePOPPSEMPORIUMPage = By.xpath("(//*[text()='Detroit'])[1]");
	public static By WePaperMachinePage=By.xpath("(//*[text()='New Orleans'])[1]");
	public static By WeConfluencePage=By.xpath("(//*[text()='Kansas City'])[1]");
}
	
	