package com.rai.pageObjects;

import static com.rai.pageObjects.ObjectLocator.ID;
import static com.rai.pageObjects.ObjectLocator.NAME;
import static com.rai.pageObjects.ObjectLocator.XPATH;

public enum MobileSite_MyprofilePageObjects implements PageObjects {

	//Profile 
    //lnk_MyAccount("//*[@id='main']/header/nav/a[6]",XPATH,"MyAccount Link - Homepage"),profileSettings
	ham_menu("//a[@href='#mobileNav']",XPATH,"Menu Link - Americanspirit Homepage"),
	btn_menu("//button[@class='styles__SystemContainer-k0088d-0 styles__Container-k0088d-5 hFvzkK']",XPATH,"MyAccount Link - Pallmall Homepage"),
    lnk_CamelMyAccount("//div/a[@href='/profile/linkout']",XPATH,"MyAccount Link - Camel Homepage"),
    lnk_GrizzlyMyAccount("//span/a[contains(text(),'Profile')]",XPATH,"MyAccount Link - Grizzly Homepage"),
    btn_GrizzlyUpdateInfo("//a/button[contains(text(),'Update Your Contact Information')]",XPATH,"UpdateInformation button - Profile HomePage"),
    lnk_NewportMyAccount("//li/a[@class='nav-link-item']",XPATH,"MyAccount Link - Newport Homepage"),
    link_pallmallprofilee("//nav/a[contains(text(),'Profile')]",XPATH,"PostLogin - NASCIGS Profile footerlink"),
    lnk_NASCIGSProfile("//a[@href='/profile']",XPATH,"PostLogin - NASCIGS Profile footerlink"),
    lnk_PallmallProfile("//div/a[@href='/myprofile']",XPATH,"MyAccount Link - Pallmall profile"),
    btn_pallmallmenu("//a/div[@class='nav-trigger-burg']",XPATH,"MyAccount Link - Pallmall Homepage"),
    btn_profilesetting("//a[@href='/profile/linkout']",XPATH,"MyAccount Link - Pallmall profilesetting"),
    btn_Newportmenu("//div[@class='navigation-mobile-toggle']",XPATH,"MyAccount Link - Newport Menu"),
    
  //div[@class='navigation-mobile-toggle']
    btn_Profilesetting("//a[@href='/settings']",XPATH,"Button - profileSettings"),
    btn_ProfileUserInfo("tabUserInformation",ID,"Button - ProfileUserInformation"),
    btn_ProfileTobaccoPreferences("tabMySmokes",ID,"Button - ProfileTobaccoPreferences"),
    btn_ProfileContentPreferences("tabMyCp",ID,"Button - ProfileContentPreferences"),
    txt_ProfileAddressLine1("UserInformation_AddressLine1",ID,"Input - ProfileAddressLine1"),
    txt_ProfileCity("UserInformation_City",ID,"Input - ProfileCity"),
    txt_ProfileZipcode("UserInformation_ZipCode",ID,"Input - ProfileZipcode"),
    txt_ProfileNewEmail("NewEmailAddress",ID,"Input - NewEmail"),
    txt_ProfileConfirmEmail("ConfirmNewEmailAddress",ID,"Input - ConfirmEmail"),
    btn_ProfileUpdateInfo("btnUpdateUserInfo",ID,"Button - UpdateEmail&Permission"),
    txt_ProfileCurrentPassword("CurrentPassword",ID,"Input - CurrentPassword"),
    txt_ProfileNewPassword("NewPassword",ID,"Input - NewPassword"),
    txt_ProfileConfirmNewPassword("ConfirmNewPassword",ID,"Input - ConfirmNewPassword"),
    btn_ProfileUpdatePassword("btnUpdatePassword",ID,"Button - UpdatePassword"),
    drpdwn_ProfileChallengeQuestion("ChallengeQuestion",ID,"Dropdown - ChallengeQuestion"),
    txt_ProfileChallengeAnswer("ChallengeAnswer",ID,"Input - ChallengeAnswer"),
    btn_ProfileUpdateChallengeQuestion("//input[@id='btnUpdateChallengeQA']",XPATH,"Button - ChallengeQuestion"),
    btn_ProfileBacktoSite("//img[@src='/themes/custom/rjr_theme/images/Btn_BackToSite.jpg']",XPATH,"Button - Backtosite"),
    
    chckbox_TobaccoPreferencesCombustible("//input[@value='10001|aPROD CATEGORY|1000001|10001']",XPATH,"MyProfile - TobaccoPreferences - Combustible"),
    chckbox_TobaccoPreferencesMoistSnuff("//input[@value='10001|aPROD CATEGORY|1000001|10002']",XPATH,"MyProfile - TobaccoPreferences - MoistSnuff"),
    chckbox_TobaccoPreferencesVapor("//input[@value='10001|aPROD CATEGORY|1000001|10003']",XPATH,"MyProfile - TobaccoPreferences - Vapor"),
    chckbox_TobaccoPreferencesSNUS("//input[@value='10001|aPROD CATEGORY|1000001|10004']",XPATH,"MyProfile - TobaccoPreferences - SNUS"),
    chckbox_TobaccoPreferencesDissolvableTobacco("//input[@value='10003|aPROD CATEGORY|1000001|10005']",XPATH,"MyProfile - TobaccoPreferences - DissolvableTobacco"),
    chckbox_TobaccoPreferencesDissolvableTobacco_camel("//input[@value='10001|aPROD CATEGORY|1000001|10005']",XPATH,"MyProfile - TobaccoPreferences - DissolvableTobacco"),
    chckbox_TobaccoPreferencesDissolvableTobacco_NP("//input[@value='10040|aPROD CATEGORY|1000001|10005']",XPATH,"MyProfile - TobaccoPreferences - DissolvableTobacco"),
    chckbox_TobaccoPreferencesDissolvableTobacco_pallmall("//input[@value='10002|aPROD CATEGORY|1000001|10005']",XPATH,"MyProfile - TobaccoPreferences - DissolvableTobacco"),
    drpdwn_TobaccoPreferencesDissolvable1("TobaccoPreferencesSurvey.ScreenerSections[0].1000010UB",NAME,"MyProfile - TobaccoPreferences - DissolvableTobacco - 1"),
    drpdwn_TobaccoPreferencesDissolvable2("TobaccoPreferencesSurvey_ScreenerSections__0_1000011SOR",ID,"MyProfile - TobaccoPreferences - DissolvableTobacco - 2"),
    chckbox_TobaccoPreferencesDissolvable3("//input[@value='10003|DISSOLVABLE|1000015|10060']",XPATH,"MyProfile - TobaccoPreferences - last30daysPurchased"),
    chckbox_TobaccoPreferencesDissolvable3_camel("//input[@value='10001|DISSOLVABLE|1000015|10060']",XPATH,"MyProfile - TobaccoPreferences - last30daysPurchased"),
    chckbox_TobaccoPreferencesDissolvable3_NP("//input[@value='10040|DISSOLVABLE|1000015|10060']",XPATH,"MyProfile - TobaccoPreferences - last30daysPurchased"),
    chckbox_TobaccoPreferencesDissolvable3_Pallmall("//input[@value='10002|DISSOLVABLE|1000015|10060']",XPATH,"MyProfile - TobaccoPreferences - last30daysPurchased"),
    btn_TobaccoPreferencesUpdateText("//span/span[contains(text(),'Answering the question above is required to continue')]",XPATH,"MyProfile - TobaccoPreferences - Update"),
    btn_TobaccoPreferencesUpdate("btnUpdateMySmokes",ID,"My Profile Page - Tobacco Preferences Section - Update Button"),
    errormsg_ProfileNoAddress("//li/span/span[contains(text(),'The Address Line 1 field is required.')]",XPATH,"MyProfile - No Address1"),
    errormsg_ProfileNoCity("//li/span/span[contains(text(),'The City field is required.')]",XPATH,"MyProfile - No City"),
    errormsg_ProfileNoZipcode("//li/span/span[contains(text(),'The Zip Code field is required.')]",XPATH,"MyProfile - No Zipcode"),
    errormsg_ProfileNoTobaccoPreferencesUpdate("//span/span[contains(text(),'Answering the question above is required to continue')]",XPATH,"MyProfile - No TobaccoPreferences"),
    
    errormsg_ProfileNoChallengeAnswer("//li/span/span[contains(text(),'The Challenge Answer field is required.')]",XPATH,"MyProfile - ChallengeAnswer not entered"),
    errormsg_ProfileNoCurrentPassword("//li/span/span[contains(text(),'The Current Password field is required.')]",XPATH,"MyProfile - CurrentPassword not entered"),
    errormsg_ProfileInvalidPasswordformatinNewPassword("//li/span/span[contains(text(),'Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.')]",XPATH,"Invalid Password format in NewPassword field"),
    errormsg_ProfileNoNewPassword("//li/span/span[contains(text(),'The New Password field is required.')]",XPATH,"MyProfile - NewPassword not entered"),
    errormsg_ProfileDifferentPassword("//li/span/span[contains(text(),'The New Password and Confirm New Password fields do not match.')]",XPATH,"MyProfile - Password doesnt match in NewPassword & ConfirmPassword fields"),
    errormsg_ProfileInactiveEmail("//li/span/span[contains(text(),'This is not an active email address. Please provide an active email address.')]",XPATH,"MyProfile - User entered Inactive email"),
    errormsg_ProfileInValidEmail("//li/span/span[contains(text(),'Please enter a valid email address')]",XPATH,"MyProfile - User entered InValid email"),
    errormsg_ProfileEnteredExistingEmail("//li/span/span[contains(text(),'User Name already taken. Please try a different one.')]",XPATH,"MyProfile - User entered Existing email"),

 
	
	//PreLogin - Camel,Pallmall and Newport Footerlinks
    PreLoginfooterlnk_FAQs("//div[@class='footer-mobile']//div[@class='footer-links']/nav/div[@class='links-head1 head']/a[@href='/FooterLinks/Faqs']",XPATH,"PreLogin - FAQs footerlink"),
	//PreLoginfooterlnk_FAQs("//div[@class='footer reg']/div[@class='footer-fullsize']/div/nav/div/a[@href='/FooterLinks/Faqs']",XPATH,"PreLogin - FAQs footerlink"),
	PreLoginfooterlnk_ContactUs("//div[@class='footer-mobile']//div[@class='footer-links']/nav/div[@class='links-head1 head']/a[@href='/FooterLinks/ContactUs']",XPATH,"PreLogin - ContactUs footerlink"),
	PreLoginfooterlnk_TobaccoRights("//div[@class='footer-mobile']/div[@class='footer-links']/nav/div/a[@href='https://ownitvoiceit.com/']",XPATH,"PreLogin - TobaccoRights"),
	PreLoginfooterlnk_SiteRequrmnts("//div[@class='footer-mobile']/div[@class='footer-links']/nav/div/a[@href='/FooterLinks/SiteRequirements']",XPATH,"PreLogin - SiteRequirements"),
	PreLoginfooterlnk_AgeFiltering("//div[@class='footer-mobile']/div[@class='footer-links']/nav/div/a[@href='/FooterLinks/AgeFilteringSoftware']",XPATH,"PreLogin - AgeFiltering"),
	PreLoginfooterlnk_TermsOfUse("//div[@class='footer-mobile']/div[@class='footer-links']/nav/div/a[@href='/FooterLinks/TermsOfUse']",XPATH,"PreLogin - TermsOfUse"),
	PreLoginfooterlnk_PrivacyPolicy("//div[@class='footer-mobile']/div[@class='footer-links']/nav/div/a[@href='/FooterLinks/PrivacyPolicy']",XPATH,"PreLogin - PrivacyPolicy"),
	
//PostLogin - Camel and Newport Footerlinks
	PostLoginfooterlnk_FAQs("//div/a[contains(text(),'FAQs')]",XPATH,"PostLogin - FAQs footerlink"),
	PostLoginfooterlnk_ContactUs("//div/a[contains(text(),'Contact Us')]",XPATH,"PostLogin - ContactUs footerlink"),
	PostLoginfooterlnk_ContactUsQuestion("email-topic",NAME,"PostLogin - ContactUs Question dropdown"),
	PostLoginfooterlnk_ContactUsAnswer("email-content",ID,"PostLogin - ContactUs Answer textbox"),
	PostLoginfooterlnk_ContactUsSubmit("edit-submit",ID,"PostLogin - ContactUs Submit"),
	PostLoginfooterlnk_TobaccoRights("//div/a[contains(text(),'Tobacco Rights')]",XPATH,"PostLogin - TobaccoRights footerlink"),
	PostLoginfooterlnk_SiteRequirements("//div/a[contains(text(),'Site Requirements')]",XPATH,"PostLogin - SiteRequirements footerlink"),
	PostLoginfooterlnk_AgeFiltering("//div/a[contains(text(),'Age')]",XPATH,"PostLogin - AgeFiltering footerlink"),
	PostLoginfooterlnk_TermsOfUse("//div/a[contains(text(),'Terms')]",XPATH,"PostLogin - TermsOfUse footerlink"),
	PostLoginfooterlnk_PrivacyPolicy("//div/a[contains(text(),'Privacy Policy')]",XPATH,"PostLogin - PrivacyPolicy footerlink"),
	
	PostLoginCamelfooterlnk_Logout("(//a[text()='Logout'])[1]",XPATH,"PostLogin - Logout footerlink"),//a[text()='Log Out']
	PostLoginNewportfooterlnk_Logout("//a[text()='Log Out']",XPATH,"PostLogin - Logout footerlink"),
	
//PostLogin - Pallmall Footerlinks
	PostLoginPallmallfooterlnk_FAQs("//footer[@id='site-footer']//div//div//nav[@class='footer-nav-primary']/a[@href='https://qa-pallmall.raimktg.com/FooterLinks/Faqs']",XPATH,"PostLogin - Pallmall FAQs footerlink"),
	PostLoginPallmallfooterlnk_ContactUs("//footer[@id='site-footer']//div//div//nav[@class='footer-nav-primary']/a[contains(text(),'Contact Us')]",XPATH,"PostLogin - Pallmall ContactUs footerlink"),
	PostLoginPallmallfooterlnk_TobaccoRights("//footer[@id='site-footer']//div//div//nav[@class='footer-nav-secondary']/a[contains(text(),'Tobacco Rights')]",XPATH,"PostLogin - Pallmall TobaccoRights footerlink"),
	PostLoginPallmallfooterlnk_SiteRequirements("//footer[@id='site-footer']//div//div//nav[@class='footer-nav-secondary']/a[contains(text(),'Site Requirements')]",XPATH,"PostLogin - Pallmall SiteRequirements footerlink"),
	PostLoginPallmallfooterlnk_AgeFiltering("//footer[@id='site-footer']//div//div//nav[@class='footer-nav-secondary']/a[contains(text(),'Site Requirements')]",XPATH,"PostLogin - Pallmall AgeFiltering footerlink"),
	PostLoginPallmallfooterlnk_TermsOfUse("//footer[@id='site-footer']//div//div//nav[@class='footer-nav-secondary']/a[contains(text(),'Terms of Use')]",XPATH,"PostLogin - Pallmall TermsOfUse footerlink"),
	PostLoginPallmallfooterlnk_PrivacyPolicy("//footer[@id='site-footer']//div//div//nav[@class='footer-nav-secondary']/a[contains(text(),'Privacy Policy and Your California Privacy Rights')]",XPATH,"PostLogin - Pallmall PrivacyPolicy footerlink"),
	
	
	PostLoginPallmallfooterlnk_Logout("//footer[@class='footer mobile-nav-footer']/div/div/nav/a[contains(text(),'Logout')]",XPATH,"PostLogin - Pallmall Logout footerlink"),
	
//PreLogin - Grizzly Footerlinks
	PreLoginfooterlnk_GrizzlyContactUs("//span/a[contains(text(),'Contact Us')]",XPATH,"PreLogin - Grizzly ContactUs footerlink"),
	PreLoginfooterlnk_GrizzlyFAQs("//span/a[contains(text(),'FAQs')]",XPATH,"PreLogin - Grizzly FAQs footerlink"),
	PreLoginfooterlnk_GrizzlyTobaccoRights("//div/a[contains(text(),'Tobacco Rights')]",XPATH,"PreLogin - Grizzly TobaccoRights footerlink"),
	PreLoginfooterlnk_GrizzlySiteRequirements("//div/a[contains(text(),'Site Requirements')]",XPATH,"PreLogin - Grizzly SiteRequirements footerlink"),
	PreLoginfooterlnk_GrizzlyAgeFiltering("//div/a[contains(text(),'Age Filtering')]",XPATH,"PreLogin - Grizzly AgeFiltering footerlink"),
	PreLoginfooterlnk_GrizzlyTermsOfUse("//div/a[contains(text(),'Terms of Use')]",XPATH,"PreLogin - Grizzly TermsOfUse footerlink"),
	PreLoginfooterlnk_GrizzlyPrivacyPolicy("//div/a[contains(text(),'Privacy Policy')]",XPATH,"PreLogin - Grizzly PrivacyPolicy footerlink"),
	
//PostLogin - Grizzly Footerlinks
	PostLoginfooterlnk_GrizzlyContactUs("//span/a[contains(text(),'Contact Us')]",XPATH,"PostLogin - Grizzly ContactUs footerlink"),
	PostLoginfooterlnk_GrizzlyFAQs("//span/a[contains(text(),'FAQs')]",XPATH,"PostLogin - Grizzly FAQs footerlink"),
	PostLoginfooterlnk_GrizzlyTobaccoRights("//span/a[contains(text(),'Tobacco Rights')]",XPATH,"PostLogin - Grizzly TobaccoRights footerlink"),
	PostLoginfooterlnk_GrizzlySiteRequirements("//span/a[contains(text(),'Site Requirements')]",XPATH,"PostLogin - Grizzly SiteRequirements footerlink"),
	PostLoginfooterlnk_GrizzlyAgeFiltering("//span/a[contains(text(),'Age Filtering')]",XPATH,"PostLogin - Grizzly AgeFiltering footerlink"),
	PostLoginfooterlnk_GrizzlyTermsOfUse("//span/a[contains(text(),'Terms of Use')]",XPATH,"PostLogin - Grizzly TermsOfUse footerlink"),
	PostLoginfooterlnk_GrizzlyPrivacyPolicy("//span/a[contains(text(),'Privacy Policy')]",XPATH,"PostLogin - Grizzly PrivacyPolicy footerlink"),
	
	PostLogin_Menu("//div/a/span[contains(text(),'Menu')]",XPATH,"PostLogin - Menu icon"),
	PostLogin_Menu_Logout("//div/a[contains(text(),'Log Out')]",XPATH,"PostLogin - Logout icon"),
	
//PreLogin - AmericanSpirit Footerlinks
    PreLoginNASfooterlnk_FAQs("//nav/nav/div/a[contains(text(),'FAQs')]",XPATH,"PreLogin - NASCIGS FAQs footerlink"),
    PreLoginNASfooterlnk_ContactUs("//nav/nav/div/a[contains(text(),'Contact Us')]",XPATH,"PreLogin - NASCIGS FAQs footerlink"),
    PreLoginNASfooterlnk_TobaccoRights("//nav/nav/div/a[contains(text(),'Tobacco Rights')]",XPATH,"PreLogin - NASCIGS TobaccoRights footerlink"),
    PreLoginNASfooterlnk_SiteRequirements("//nav/nav/div/a[contains(text(),'Site Requirements')]",XPATH,"PreLogin - NASCIGS SiteRequirements footerlink"),
    PreLoginNASfooterlnk_AgeFiltering("//nav/nav/div/a[contains(text(),'Age Filtering')]",XPATH,"PreLogin - NASCIGS AgeFiltering footerlink"),
    PreLoginNASfooterlnk_TermsOfUse("//nav/nav/div/a[contains(text(),'Terms of Use')]",XPATH,"PreLogin - NASCIGS TermsOfUse footerlink"),
    PreLoginNASfooterlnk_PrivacyPolicy("//nav/nav/div/a[contains(text(),'Privacy Policy')]",XPATH,"PreLogin - NASCIGS PrivacyPolicy footerlink"),

//PostLogin - AmericanSpirit Footerlinks
   PostLoginNASfooterlnk_SFNTC("//nav/a[contains(text(),'SFNTC')]",XPATH,"PostLogin - NASCIGS SFNTC footerlink"),
   PostLoginNASfooterlnk_ResponsibleMarketing("//nav/a[contains(text(),'Responsible Marketing')]",XPATH,"PostLogin - NASCIGS ResponsibleMarketing footerlink"),
   PostLoginNASfooterlnk_ContactUs("//nav/a[contains(text(),'Contact Us')]",XPATH,"PostLogin - NASCIGS ContactUs footerlink"), 
   PostLoginNASfooterlnk_TobaccoRights("//nav/a[contains(text(),'Tobacco Rights')]",XPATH,"PostLogin - NASCIGS TobaccoRights footerlink"),
   PostLoginNASfooterlnk_SiteRequirements("//nav/a[contains(text(),'Site Requirements')]",XPATH,"PostLogin - NASCIGS SiteRequirements footerlink"),
   PostLoginNASfooterlnk_AgeFiltering("//nav/a[contains(text(),'Age Filtering')]",XPATH,"PostLogin - NASCIGS AgeFiltering footerlink"),
   PostLoginNASfooterlnk_TermsOfUse("//nav/a[contains(text(),'Terms Of Use')]",XPATH,"PostLogin - NASCIGS TermsOfUse footerlink"),
   PostLoginNASfooterlnk_PrivacyPolicy("//nav/a[contains(text(),'Privacy Policy')]",XPATH,"PostLogin - NASCIGS PrivacyPolicy footerlink"),
   
   PostLoginNASfooterlnk_LogOut("//nav[@class='Nav--mobile']/footer/div/nav/a[contains(text(),'Logout')]",XPATH,"PostLogin - NASCIGS LogOut footerlink"),
   
//PreLogin - Revel Footerlinks
   PreLoginRevelfooterlnk_FAQs("//div/nav/div/a[contains(text(),'FAQs')]",XPATH,"PreLogin - Revel FAQs footerlink"),
   PreLoginRevelfooterlnk_ContactUs("//div/nav/div/a[contains(text(),'Contact Us')]",XPATH,"PreLogin - Revel ContactUs footerlink"),
   PreLoginRevelfooterlnk_TobaccoRights("//div/nav/div/a[contains(text(),'Tobacco Rights')]",XPATH,"PreLogin - Revel TobaccoRights footerlink"),
   PreLoginRevelfooterlnk_SiteRequirements("//div/nav/div/a[contains(text(),'Site Requirements')]",XPATH,"PreLogin - Revel SiteRequirements footerlink"),
   PreLoginRevelfooterlnk_AgeFiltering("//div/nav/div/a[contains(text(),'Age Filtering')]",XPATH,"PreLogin - Revel AgeFiltering footerlink"),
   PreLoginRevelfooterlnk_TermsOfUse("//div/nav/div/a[contains(text(),'Terms of Use')]",XPATH,"PreLogin - Revel TermsOfUse footerlink"),
   PreLoginRevelfooterlnk_PrivacyPolicy("//div/nav/div/a[contains(text(),'Privacy Policy')]",XPATH,"PreLogin - Revel PrivacyPolicy footerlink"),
   PreLoginRevelfooterlnk_TermsOfSale("//div/nav/div/a[contains(text(),'Terms Of Sale')]",XPATH,"PreLogin - Revel TermsOfSale footerlink"),
   
//PostLogin - Revel Footerlinks
   
   
   
   
   
//PreLogin - Velo Footerlinks
   PreLoginVelofooterlnk_FAQs("//nav/div/div/a[contains(text(),'FAQs')]",XPATH,"PreLogin - Velo FAQs footerlink"),
   PreLoginVelofooterlnk_ContactUs("//nav/div/div/a[contains(text(),'Contact Us')]",XPATH,"PreLogin - Velo ContactUs footerlink"),
   PreLoginVelofooterlnk_TobaccoRights("//nav/div/div/a[contains(text(),'Tobacco Rights')]",XPATH,"PreLogin - Velo TobaccoRights footerlink"),
   PreLoginVelofooterlnk_SiteRequirements("//nav/div/div/a[contains(text(),'Site Requirements')]",XPATH,"PreLogin - Velo SiteRequirements footerlink"),
   PreLoginVelofooterlnk_AgeFiltering("//nav/div/div/a[contains(text(),'Age Filtering')]",XPATH,"PreLogin - Revel AgeFiltering footerlink"),
   PreLoginVelofooterlnk_TermsOfUse("//nav/div/div/a[contains(text(),'Terms of Use')]",XPATH,"PreLogin - Velo TermsOfUse footerlink"),
   PreLoginVelofooterlnk_PrivacyPolicy("//nav/div/div/a[contains(text(),'Privacy Policy')]",XPATH,"PreLogin - Velo PrivacyPolicy footerlink"),
   
//PostLogin - Velo Footerlinks
   
    
	;
	String strProperty = "";
   	ObjectLocator locatorType = null;
   	String strObjName = "";
   	
	@Override
	public String getProperty() {
		// TODO Auto-generated method stub
		return strProperty;
	}

	@Override
	public ObjectLocator getLocatorType() {
		// TODO Auto-generated method stub
		return locatorType;
	}

	@Override
	public String getObjectname() {
		// TODO Auto-generated method stub
		return strObjName;
	}
	
	private MobileSite_MyprofilePageObjects (String strPropertyValue, ObjectLocator locatorType, String strObjName) {
		// TODO Auto-generated method stub
		this.strProperty = strPropertyValue;
   		this.locatorType = locatorType;
   		this.strObjName = strObjName;
		
	}
}
