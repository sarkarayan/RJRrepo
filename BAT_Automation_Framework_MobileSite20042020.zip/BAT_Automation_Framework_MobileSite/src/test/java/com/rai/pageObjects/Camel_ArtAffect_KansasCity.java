package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_ArtAffect_KansasCity {
	public static By weImgKansasCityHeroTile=By.xpath(".//*[@class='hero intro']");
	public static By btnKansasCityHeroTile=By.xpath(".//*[@class='CTA CTA--transparent VideoModal-CTA']");
	public static By weHeroTileVideoOverlay=By.xpath(".//*[@id='Video-5596938063001_html5_api']");
	public static By btnHeroTileVideoOverlayClose=By.xpath(".//*[@class='EmptyModal-button Button Button--close-thick']");
	public static By imgKansasCity1=By.xpath(".//*[@src='https://drkb1ue1l1mjg.cloudfront.net/assets/uat2/20181115002838/imgs/art-affect/kansas-city-1.jpg']");
	public static By imgKansasCity2=By.xpath(".//*[@src='https://drkb1ue1l1mjg.cloudfront.net/assets/uat2/20181115002838/imgs/art-affect/kansas-city-2.jpg']");
	public static By imgKansasCity3=By.xpath(".//*[@src='https://drkb1ue1l1mjg.cloudfront.net/assets/uat2/20181115002838/imgs/art-affect/kansas-city-3.jpg']");
	public static By weSectionKansasCity=By.xpath("(.//*[@class='art-affect--wrapper'])[1]");
	public static By weSectionProjectMaterials=By.xpath("(.//*[@class='art-affect--wrapper'])[3]");
	public static By weRightArrowProjectMaterials=By.xpath("(.//*[@class='flickity-prev-next-button next'])[1]");
	public static By weleftArrowProjectMaterials=By.xpath("(.//*[@class='flickity-prev-next-button previous'])[1]");
	public static By wePaginationDot3ProjectMaterials=By.xpath("(.//*[@class='dot'])[2]");
	public static By wePaginationDot4ProjectMaterials=By.xpath("(.//*[@class='dot'])[3]");
	public static By wePaginationDot5ProjectMaterials=By.xpath("(.//*[@class='dot'])[4]");
	public static By weContent1ProjectMaterials=By.xpath("(.//*[@class='flickity-caption'])[1]");
	public static By weContent2ProjectMaterials=By.xpath("(.//*[@class='flickity-caption'])[2]");
	public static By weContent3ProjectMaterials=By.xpath("(.//*[@class='flickity-caption'])[3]");
	public static By weContent4ProjectMaterials=By.xpath("(.//*[@class='flickity-caption'])[4]");
	public static By weContent5ProjectMaterials=By.xpath("(.//*[@class='flickity-caption'])[5]");
	public static By weTxtProjectCollabaorator1KansasCity=By.xpath(".//*[text()='BEN WOLF']");
	public static By weTxtProjectCollabaorator2KansasCity=By.xpath(".//*[text()='ELVIS ACHELPOHL']");
	public static By weTxtProjectCollabaorator3KansasCity=By.xpath(".//*[text()='ADAM JONES']");
	public static By weTxtProjectCollabaorator4KansasCity=By.xpath(".//*[text()='NIKITA GALE']");
	public static By weTxtExploreArtAffectCities=By.xpath(".//*[text()='EXPLORE ARTAFFECT CITIES']");
	
	//29/8/2019 new objects added
	public static By ImgArtafecttext=By.xpath(".//*[@class='Box-sc-1bhjx4h-0 eHyZGY']");
	public static By WeConfluence=By.xpath(".//*[text()='Confluence']");
	public static By WeKansasCityMO=By.xpath(".//*[text()='Kansas City, MO']");
	public static By WeKansasCitySeeBuild=By.xpath("(.//*[text()='See Build'])[3]");
	public static By ImgConfluenceImage=By.xpath(".//*[@class='sc-bdVaJa sc-bwzfXH styles__Hero-enlpq-3 uNlgJ']");
	public static By TxtKansasartAffect=By.xpath(".//*[@id='ARTAFFECT-HEADER']");
	public static By TxtKansasConfluence=By.xpath("(.//*[text()='Confluence'])[1]");
	public static By TxtKansasCITY=By.xpath(".//*[text()='Kansas City']");
	public static By TxtKansasText=By.xpath("(.//*[@class='Text-sc-1n4wa1f-0 knioFl'])[4]");
	public static By BtnPlayVideo=By.xpath("(.//*[text()='Play Video'])[1]");
	public static By VideoOverlay=By.xpath(".//*[@id='Video-5596938063001_html5_api']");
	public static By VideoOverlayClose=By.xpath(".//*[@class='styles__CloseButton-sc-1uvfz74-2 eofSUE styles__StyledButton-sc-4qcnu1-0 cVrrfY']");
	public static By WeHomePage=By.xpath(".//*[@class='styles__CorrectiveStatementsSection-sc-1r3mlbt-0 kKOumN']");
	public static By WeTheProject=By.xpath("//*[text()='The Project']");
	public static By ImgTheProjectImages=By.xpath(".//*[@class='Box-yh4gdj-0 lcfrZs']");
	public static By WeProjectGallery=By.xpath("//*[text()='Project Gallery']");
	public static By WePaginationPG=By.xpath("//*[@class='flickity-page-dots']");
	public static By WeProjectContent=By.xpath("(.//*[@class='Box-yh4gdj-0 hCVAUD'])[1]");
	
	
	
	//Tiles
	public static By WePGTileScaffolding=By.xpath("//*[@alt='Scaffolding']");
	public static By WePGTileBuildingFoundation=By.xpath("//*[@alt='Building Foundation']");
	public static By WePGTileCanopy=By.xpath("//*[@alt='Canopy']");
	public static By WePGTileConfluenceArt=By.xpath("//*[@alt='Confluence Art']");
	public static By WePGTileBackWall=By.xpath("//*[@alt='Back Wall']");
	
	public static By TxtPGConfluenece=By.xpath("//*[@class='Text-sc-1n4wa1f-0 gOSCQF']");
	public static By TxtPGConflurncelongText=By.xpath("//*[@class='sc-bdVaJa sc-bwzfXH sc-htpNat iUGNFe']");
	
	public static By TxtPGBackwall=By.xpath("//*[text()='Back Wall']");
	public static By TxtPGBackwalllongtext=By.xpath("//*[@class='sc-bdVaJa sc-bwzfXH sc-htpNat iUGNFe']");
	
	public static By TxtPGScaffolding=By.xpath("//*[text()='Scaffolding']");
	public static By TxtScaffoldinglongText=By.xpath(".//*[@class='sc-bdVaJa sc-bwzfXH sc-htpNat iUGNFe']");
	
	public static By TxtBuildingFoundation=By.xpath("//*[text()='Foundation']");
	public static By TxtBuildingFoundationlongText=By.xpath(".//*[@class='sc-bdVaJa sc-bwzfXH sc-htpNat iUGNFe']");
	
	public static By TxtCanopy=By.xpath("//*[text()='Canopy']");
	public static By TxtCanopylongText=By.xpath(".//*[@class='sc-bdVaJa sc-bwzfXH sc-htpNat iUGNFe']");
	
	//Pagination dots
	public static By WePaginationDot1=By.xpath("(//*[@class='dot '])[1]");
	public static By WePaginationDot2=By.xpath("//*[@aria-label='Page dot 2']");
	public static By WePaginationDot3=By.xpath("//*[@aria-label='Page dot 3']");
	public static By WePaginationDot4=By.xpath("//*[@aria-label='Page dot 4']");
	public static By WePaginationDot5=By.xpath("//*[@aria-label='Page dot 5']");
	public static By lnkRightArrowProjectGaller = By.xpath("(.//*[@class='arrow'])[2]");
	
	
	
	public static By WeProjctCollaborators=By.xpath("//*[text()='Project Collaborators']");
	public static By WeBenWolf=By.xpath("(//*[@class='sc-bdVaJa sc-ifAKCX Card__AnimatedCard-sc-9u305p-0 kSFZFd'])[1]");
	public static By WeELVISACHELPOHL=By.xpath("(//*[@class='sc-bdVaJa sc-ifAKCX Card__AnimatedCard-sc-9u305p-0 kSFZFd'])[2]");
	public static By WeADAMJONES=By.xpath("(//*[@class='sc-bdVaJa sc-ifAKCX Card__AnimatedCard-sc-9u305p-0 kSFZFd'])[3]");
	public static By WeNIKITAGALE=By.xpath("(//*[@class='sc-bdVaJa sc-ifAKCX Card__AnimatedCard-sc-9u305p-0 kSFZFd'])[4]");
	
	public static By BtnMeetBen=By.xpath(".//*[text()='Meet Ben']");
	public static By BtnMeetElvis=By.xpath(".//*[text()='Meet Elvis']");
	public static By BtnMeetAdam=By.xpath(".//*[text()='Meet Adam']");
	public static By BtnMeetNikita=By.xpath(".//*[text()='Meet Nikita']");
	
	public static By WeSanArtistModel=By.xpath("(.//*[@class='Box-yh4gdj-0 hmLyeY'])[1]");

	public static By btnSanArtistModelClose=By.xpath("(.//*[@class='styles__CloseButton-sc-1uvfz74-2 eofSUE styles__StyledButton-sc-4qcnu1-0 cVrrfY'])[2]");
	
	
	public static By WeExploreMoreBuilds=By.xpath("//*[text()='Explore More Builds']");
	public static By WeGrantProgram=By.xpath("(//*[@class='sc-bdVaJa sc-bwzfXH evXyaC'])[1]");
	public static By WePOPPSEMPORIUM=By.xpath("(//*[@class='sc-bdVaJa sc-bwzfXH evXyaC'])[2]");
	public static By WePaperMachine=By.xpath("(//*[@class='sc-bdVaJa sc-bwzfXH evXyaC'])[3]");
	
	public static By BtnLearnmoreGrantProgram=By.xpath("(.//*[@href='/art-affect/grant-program'])[2]");
	public static By BtnLearnmorePOPPSEMPORIUM=By.xpath(".//*[@href='/art-affect/detroit']");
	public static By BtnLearnmorePaperMachine=By.xpath(".//*[@href='/art-affect/new-orleans']");
	
	
	public static By WeGrantProgramPage=By.xpath(".//*[@class='sc-bdVaJa sc-bwzfXH hWeXcz']");
	public static By WePOPPSEMPORIUMPage=By.xpath(".//*[@class='Box-yh4gdj-0 enAWxa']");
	public static By WePaperMachinePage=By.xpath(".//*[@class='Box-yh4gdj-0 enAWxa']");
	
	public static By imgKansasCityCollaborators=By.xpath("(.//*[@class='container-inner'])[6]");
	public static By btnKansasCityMeetTheArtist=By.xpath(".//*[@class='CTA']");
	
	
	public static By btnGrantProgram=By.xpath("(.//*[@class='btn btn--transparent'])[1]");
	public static By btnPoppsEmporium=By.xpath("(.//*[@class='btn btn--transparent'])[2]");
	public static By btnPaperMachine=By.xpath("(.//*[@class='btn btn--transparent'])[3]");
	
	
	
//KansasCity Collaborators page
	public static By txtKansasCityProjectCollaboratorsTitle=By.xpath("(.//*[@class='container-inner'])[1]");
	public static By imgKansasCityCollaborator1=By.xpath(".//*[@class='hero-artist kansas-one']");
	
	public static By txtKansasCityCollaborator1=By.xpath("(.//*[@class='container-inner'])[3]");
	public static By imgKansasCityCollaborator2=By.xpath(".//*[@class='hero-artist kansas-two']");
	public static By txtKansasCityCollaborator2=By.xpath("(.//*[@class='container-inner'])[5]");
	public static By imgKansasCityCollaborator3=By.xpath(".//*[@class='hero-artist kansas-three']");
	public static By txtKansasCityCollaborator3=By.xpath("(.//*[@class='container-inner'])[7]");
	public static By imgKansasCityCollaborator4=By.xpath(".//*[@class='hero-artist kansas-four']");
	public static By txtKansasCityCollaborator4=By.xpath("(.//*[@class='container-inner'])[9]");
	public static By btnBackToTop=By.xpath(".//*[text()='BACK TO TOP']");
}
