package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_Home{
	public static By lnkLogOut =By.xpath(".//*[@href='/logout']");
	//Suneel menu navigation properties
	//Home page explore crush button
		public static By btnExploreCrush = By.xpath(".//button[text()='Explore Crush']");
		
		public static By weHomePage = By.xpath(".//*[@class='page-content home-page']");
		public static By pghome = By.xpath(".//*[@class='styles__CorrectiveStatementsSection-sc-1jcm2m3-0 iRPXuP']");
		
		//Navigation links
		public static By lnkNavigation = By.xpath("(.//*[@class='styles__Container-sc-1ohzbs6-0 jxskzo'])[1]");
}
