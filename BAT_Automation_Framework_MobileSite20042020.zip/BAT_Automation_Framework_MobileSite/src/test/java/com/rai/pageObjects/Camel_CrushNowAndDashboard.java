package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_CrushNowAndDashboard 
{
	public static By weCrushNowPage = By.xpath(".//*[@id='CrushDashBoardPage']");
}
