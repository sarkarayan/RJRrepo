package com.rai.pageObjects;

import static com.rai.pageObjects.ObjectLocator.*;
public enum MobileSiteHomePageObjects  implements PageObjects {

	btnHamburgerMenu("//button[contains(@class,'SystemContainer')]",XPATH,"Home Page - Hamburer Menu button"),
	menu_Couponslink("//a[contains(text(),'Coupons')]",XPATH,"Menu - Coupons"),
	camel_gotoApp_Close("//button[contains(@class,'CloseButton')]",XPATH,"Home - GotoAPP - Close"),
	newport_Menu("//div[@class='navigation-mobile-toggle']",XPATH,"Newport Menu"),
	newport_Menu_Couponslink("//a[contains(text(),'Coupons')]",XPATH,"Newport Menu - Coupons"),
	newport_CouponsPage_ClaimNow("//a[contains(text(),'CLAIM NOW')]",XPATH,"Newport CouponsPage - ClaimNow"),  ////a[@class='btn offer-btn ng-scope']
	lnkLogout("Logout",LINKTEXT, "Home Page - Logout Link"),
	;
	String strProperty = "";
   	ObjectLocator locatorType = null;
   	String strObjName = "";
   	
	@Override
	public String getProperty() {
		// TODO Auto-generated method stub
		return strProperty;
	}

	@Override
	public ObjectLocator getLocatorType() {
		// TODO Auto-generated method stub
		return locatorType;
	}

	@Override
	public String getObjectname() {
		// TODO Auto-generated method stub
		return strObjName;
	}
	
	private MobileSiteHomePageObjects (String strPropertyValue, ObjectLocator locatorType, String strObjName) {
		// TODO Auto-generated method stub
		this.strProperty = strPropertyValue;
   		this.locatorType = locatorType;
   		this.strObjName = strObjName;
		
	}
}
