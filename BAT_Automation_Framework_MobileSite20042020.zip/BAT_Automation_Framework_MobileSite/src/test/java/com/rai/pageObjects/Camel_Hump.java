package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_Hump {
	//Suneel menu navigation
	//Season logo
		public static By weImgSeasonLogo = By.xpath("(.//*[@class='Season-logo'])[1]");
}
