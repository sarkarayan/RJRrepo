package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_ArtAffect_Detroit {
	 public static By pgDetroit = By.xpath("(.//*[text()='Detroit'])[1]");//Prathisha
	public static By weDetroitHeroTile=By.xpath("(.//*[@class='sc-bdVaJa sc-bwzfXH styles__Hero-enlpq-3 cUEijk'])[1]");//Prathisha
	public static By btnDetroitVideo=By.xpath("(//*[text()='Play Video'])[1]");
	public static By weHeroTileVideoOverlay=By.xpath("(//*[@id='Video-5982642790001_html5_api'])[1]");
	public static By btnHeroTileVideoOverlayClose=By.xpath("(//*[@class='styles__CloseButton-sc-1uvfz74-2 eofSUE styles__StyledButton-sc-4qcnu1-0 cVrrfY'])[1]");
	public static By weImgProjectSection = By.xpath(".//*[@class='sc-bdVaJa sc-bwzfXH sc-htpNat ESwwV']");
	public static By weProjectText = By.xpath(".//*[text()='The Project']");
	public static By weProjectContent = By.xpath(".//*[@class='Box-yh4gdj-0 hCVAUD']");	
	public static By weProjectGallery = By.xpath(".//*[text()='Project Gallery']");
	public static By weimgPoopsProjectgallery = By.xpath(".//*[@alt='Popps Emporium']");
	public static By weimgDesignProjectgallery = By.xpath(".//*[@alt='Design Library']");
	public static By weimgArtistProjectgallery = By.xpath(".//*[@alt='Artist Residency']");
	public static By weimgToolProjectgallery = By.xpath(".//*[@alt='Tool Library']");
	public static By weSubHeadingProjrtGallery = By.xpath(".//*[@class='Text-sc-1n4wa1f-0 gOSCQF']");
	public static By weContentProjrctGallery = By.xpath(".//*[@class='sc-bdVaJa sc-bwzfXH sc-htpNat iUGNFe']");
	public static By lnkRightArrowProjectGaller = By.xpath("(.//*[@class='arrow'])[2]");
	public static By weProjectCollaborators = By.xpath(".//*[text()='Project Collaborators']");
	public static By lnkPaginationDots = By.xpath("(.//*[@class='dot '])[1]");
	public static String weETest1 = "(.//*[@class='dot'])[";
	public static String weETest2 = "]";
	public static By weFainaLermanProjectCollaborators = By.xpath(".//*[contains(text(),'Co-Founder')]/preceding-sibling::h4[normalize-space()='Faina Lerman']");
	public static By weGraemWhyteProjectCollaborators = By.xpath(".//*[contains(text(),'Co-Founder')]/preceding-sibling::h4[normalize-space()='Graem Whyte']");
	
	public static By wesectionExploreMoreBuildsHeading=By.xpath("//*[text()='Explore More Builds']");
    public static By imgGrantProgramExploreMoreSection=By.xpath(".//*[@alt='Grant Program']");
    public static By imgPaperMachineExploreMoreSection=By.xpath(".//*[@alt='Paper Machine']");
    public static By imgConfluenceExploreMoreSection=By.xpath(".//*[@alt='Confluence']");
    public static By btnLearnMoreConfluenceExploreMoreSection=By.xpath("(.//*[text()='Learn More'])[3]");
    public static By btnLearnMoreGrantProgramExploreMoreSection=By.xpath("(.//*[text()='Learn More'])[1]");
    public static By btnLearnMorePoppsEmporiumExploreMoreSection=By.xpath("(.//*[text()='Learn More'])[2]");
    public static By wePoppsEmporiumLogo=By.xpath("(.//*[text()='Popps Emporium'])[1]"); 
    
  //Other pages headings added on 29 August 2019
    public static By pgGrantProgram=By.xpath(".//*[@class='sc-bdVaJa sc-bwzfXH styles__Hero-juncme-3 lospEj']//*[text()='Grant Program']");
    public static By pgPoppsEmporium=By.xpath(".//*[@class='Box-sc-1bhjx4h-0 eAeWeX']//*[text()='Popps Emporium']");
    public static By pgConfluence=By.xpath(".//*[@class='Box-sc-1bhjx4h-0 eAeWeX']//*[text()='Confluence']");
    public static By pgPaperMachine=By.xpath(".//*[@class='Box-sc-1bhjx4h-0 eAeWeX']//*[text()='Paper Machine']");

	
	public static By btnMeetFaina = By.xpath(".//*[text()='Meet Faina']");
	public static By btnMeetGraem = By.xpath(".//*[text()='Meet Graem']");
	public static By weArtistModel=By.xpath("(.//*[@class='Box-yh4gdj-0 hmLyeY'])[1]");
    public static By btnArtistModelClose=By.xpath("(.//*[@class='styles__CloseButton-sc-1uvfz74-2 eofSUE styles__StyledButton-sc-4qcnu1-0 cVrrfY'])[2]");
	
	



}
	
	