package com.rai.pageObjects;

import static com.rai.pageObjects.ObjectLocator.*;

public enum AppHamburgerMenuPageObjects implements PageObjects {
    
	
	//HamburgerMenu
	menu_AltHomePage("//android.view.ViewGroup[@index=1 and @instance=2]",XPATH,"Hamburger Menu - AltHomePage"),
	menu_HomeLink("//android.widget.TextView[@text='HOME']",XPATH,"Hamburger Menu - HomeLink"),
	menu_SavingsLink("//android.widget.TextView[@text='SAVINGS']",XPATH,"Hamburger Menu - SavingsLink"),
	menu_SavingsOKbtn("//android.widget.Button[@text='OK']",XPATH,"Hamburger Menu - SavingsOK button"),
	menu_StoreLocatorLink("//android.widget.TextView[@text='STORE LOCATOR']",XPATH,"Hamburger Menu - StoreLocatorLink"),
	menu_PromoCodeLink("//android.widget.TextView[@text='PROMO CODE']",XPATH,"Hamburger Menu - PromoCodeLink"),
	menu_PromoCodeSubmitbtn("//android.widget.TextView[@text='SUBMIT']",XPATH,"Hamburger Menu - PromoCode SubmitButton"),
	menu_MySettingsLink("//android.widget.TextView[@text='MY SETTINGS']",XPATH,"Hamburger Menu - MySettingsLink"),
	menu_HelpLink("//android.widget.TextView[@text='HELP']",XPATH,"Hamburger Menu - HelpLink"),
	//hierarchy/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.ScrollView[1]/android.view.ViewGroup[1]/android.view.ViewGroup[1]/android.widget.ScrollView[1]/android.view.ViewGroup[1]/android.view.ViewGroup[1]/android.view.ViewGroup[6]/android.widget.TextView[1]
	menu_LogoutLink("//android.widget.TextView[@text='LOG OUT']",XPATH,"Hamburger Menu - LogoutLink"),
	
	//Footerlinks in Menu
	menu_PrivacyPolicylink("//android.widget.Button[@text='Privacy Policy']",XPATH,"Menu - PrivacyPolicyLink"),
	menu_TermsOfUselink("//android.widget.Button[@text='Terms of Use']",XPATH,"Menu - TermsOfUseLink"),
	menu_FAQslink("//android.widget.Button[@text='FAQs']",XPATH,"Menu - FAQsLink"),
	menu_ContactUslink("//android.widget.Button[@text='Contact Us']",XPATH,"Menu - ContactUsLink"),
	menu_AppRequirementslink("//android.widget.Button[@text='App Requirements']",XPATH,"Menu - AppRequirementsLink"),
	
	
	
	
	
	
	
	
	;
	
	
	
	
	String strProperty = "";
   	ObjectLocator locatorType = null;
   	String strObjName = "";
   	
	@Override
	public String getProperty() {
		// TODO Auto-generated method stub
		return strProperty;
	}

	@Override
	public ObjectLocator getLocatorType() {
		// TODO Auto-generated method stub
		return locatorType;
	}

	@Override
	public String getObjectname() {
		// TODO Auto-generated method stub
		return strObjName;
	}
	
	private AppHamburgerMenuPageObjects (String strPropertyValue, ObjectLocator locatorType, String strObjName) {
		// TODO Auto-generated method stub
		this.strProperty = strPropertyValue;
   		this.locatorType = locatorType;
   		this.strObjName = strObjName;
		
	}
}
