package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_TermsOfUse {
	
	//Contents
	public static By weTxtTermsAndConditions = By.xpath(".//*[@class='resp-header-container']");
	public static By weTxtRestriction = By.xpath(".//*[@id='restrictions']");
	public static By weTxtYourAccount = By.xpath(".//*[@id='your_account']");
	public static By weTxtYourStuff = By.xpath(".//*[@id='your_stuff']");
	public static By weTxtYourConduct = By.xpath(".//*[@id='your_conduct']");
	public static By weTxtContentOnSite = By.xpath(".//*[@id='content_on_the_site']");
	public static By weTxtOurPrivacyPolicy = By.xpath(".//*[@id='our_privacy_policy']");
	public static By weTxtIntellectualPropertyIssues = By.xpath(".//*[@id='Intellectual_property_issues']");
	public static By weTxtSiteAvailability = By.xpath(".//*[@id='Site_availability_and_changes']");
	public static By weTxtChoiceOfLaw = By.xpath(".//*[@id='Choice of law']");
	public static By weTxtDisclaimer = By.xpath(".//*[@id='disclaimer']");
	public static By weTxtIndemnity = By.xpath(".//*[@id='indemnity']");
	public static By weTxtResolvingDisputes = By.xpath(".//*[@id='resolving_disputes']");
	public static By weTxtSpecialNotice = By.xpath(".//*[@id='notice']");
	public static By weTxtElectronicSignature = By.xpath(".//*[@id='electronic_signature']");
	public static By weTxtMiscellaneous = By.xpath(".//*[@id='miscellaneous']");
	
	//links
	public static By lnkRestriction = By.xpath("(.//*[@class='restrictions_mobile'])[1]");
	public static By lnkYourAccount = By.xpath("(.//*[@class='your_account_mobile'])[1]");
	public static By lnkYourStuff = By.xpath("(.//*[@class='your_stuff_mobile'])[1]");
	public static By lnkYourConduct = By.xpath("(.//*[@class='your_conduct_mobile'])[1]");
	public static By lnkContentOnSite = By.xpath("(.//*[@class='content_on_the_site_mobile'])[1]");
	public static By lnkOurPrivacyPolicy = By.xpath("(.//*[@class='our_privacy_policy_mobile'])[1]");
	public static By lnkIntellectualPropertyIssues = By.xpath("(.//*[@class='Intellectual_property_issues_mobile'])[1]");
	public static By lnkSiteAvailability = By.xpath("(.//*[@class='Site_availability_and_changes_mobile'])[1]");
	public static By lnkChoiceOfLaw = By.xpath("(.//*[@class='Choice of law_mobile'])[1]");
	public static By lnkDisclaimer = By.xpath("(.//*[@class='disclaimer_mobile'])[1]");
	public static By lnkIndemnity = By.xpath("(.//*[@class='indemnity_mobile'])[1]");
	public static By lnkResolvingDisputes = By.xpath(".//*[@class='resolving_disputes_mobile']");
	public static By lnkSpecialNotice = By.xpath(".//*[@class='notice_mobile']");
	public static By lnkElectronicSignature = By.xpath(".//*[@class='electronic_signature_mobile']");
	public static By lnkMiscellaneous = By.xpath(".//*[@class='miscellaneous_mobile']");
	//sublinks
	public static By lnkContactUs = By.xpath(".//a[.='Contact Us']");
	public static By lnkHere = By.xpath(".//a[.='here']");
	public static By lnkPrivacyPolicy = By.xpath(".//*[@href='/FooterLinks/PrivacyPolicy']");
}
