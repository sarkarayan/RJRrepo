package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_ProductPage_Classics {
	public static final By btnSignintab = By.xpath("(//*[text()='Sign In'])[1]");
	public static final By txtUsername = By.xpath("//*[@id='username']");
	public static final By txtPassword = By.xpath("//*[@id='password']");
	public static final By btnLogin = By.xpath("//*[@id='edit-submit']");
	public static final By pgCamelHome = By.xpath("//*[@class='Nav-beast']");
    public static final By lnkcamelLogout = By.xpath("//*[text()='Logout']");
    public static final By lnkCamelMenu = By.xpath(".//*[@class='Nav-burger']");
    public static final By lnkProducts = By.xpath(".//span[.='Products']");
    public static final By weBluepack=By.xpath("//*[@id='blue']");
    public static final By pgProducts = By.xpath("//*[text()='Our signature blend with a crushable menthol capsule in every filter for on-demand freshness.']");
    public static final By weClassics = By.xpath("(.//*[@class='Product-list']//p[text()='Classics'])");
    public static final By weClassicspack=By.xpath("(.//*[@class='clipper'])[1]");
    public static final By imgPack = By.xpath("(//*[@class='is-selected'])[2]");
    public static final By weFilterpack = By.xpath("(.//*[@class='clipper'])[3]");
    public static final By weplatinumpack = By.xpath("(.//*[@class='clipper'])[4]");
    public static final By we99pack = By.xpath("(.//*[@class='clipper'])[5]");
    public static final By weFirstdot = By.xpath("(//*[@class='dots first-dot'])[1]");
    
    public static final By weSeconddot = By.xpath("(//*[@class='dots second-dot'])[1]");
    public static final By weThirddot = By.xpath("(//*[@class='dots third-dot'])[1]");
    public static final By weFourthdot = By.xpath("(//*[@class='dots fourth-dot'])[1]");
    public static final By weFivthdot = By.xpath("(//*[@class='dots fifth-dot'])[1]");
    public static final By btnExplore = By.xpath("//*[text()='Explore Classics']");
    public static final By weExplore = By.xpath("//*[@id='home']//*[@class='background']");
    //public static final By weBlue = By.xpath("//*[@id='blue']//*[@class='background']");
    public static final By weFilter = By.xpath("//*[@id='filters']//*[@class='background']");
    public static final By weNinenine = By.xpath("//*[@id='ninety-nines']//*[@class='background']");
    public static final By wePlatinum = By.xpath("//*[@id='platinum']//*[@class='background']");
    public static final By btnBacktotop = By.xpath("//*[@id='back-to-top']//img");
    public static final By weClassics1=By.xpath("(//span[@class='list-name'])[1]");
    public static final By weBlue1=By.xpath("(//span[@class='list-name'])[2]");
    public static final By wefilter1=By.xpath("(//span[@class='list-name'])[3]");
    public static final By wePlatinum1=By.xpath("(//span[@class='list-name'])[4]");
    public static final By we99=By.xpath("(//span[@class='list-name'])[5]");

}
