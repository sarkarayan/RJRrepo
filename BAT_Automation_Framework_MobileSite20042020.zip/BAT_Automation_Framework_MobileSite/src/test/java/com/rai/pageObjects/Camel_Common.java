package com.rai.pageObjects;
import org.openqa.selenium.By;
public class Camel_Common {
	
//ArtAffect links
	public static By lnkArtAffect=By.xpath("(.//a[@href='/art-affect'])[1]");
	public static By lnksubmenuArtAffect=By.xpath(".//*[@class='Nav-items Nav-art-affect active']");
	public static By lnkDetroit=By.xpath(".//*[text()='Detroit']");
	public static By lnkNewOrleans=By.xpath(".//*[text()='New Orleans']");
	public static By lnkKansasCity=By.xpath(".//*[text()='Kansas City']");
	public static By lnkGrantProgram=By.xpath(".//*[@href='/art-affect/grant-program']");//Update by prathisha
	public static By pgGrantProgram = By.xpath(".//*[@class='sc-bdVaJa sc-bwzfXH hWeXcz']//*[text()='Grant Program']");
	public static By lnkBuilds=By.xpath(".//*[@href='/art-affect/builds']");

	
	//Offers page links
	public static By lnkCoupons=By.xpath("(.//*[text()='Coupons'])[1]");
		//Soundboard links
	public static By lnkSoundBoard=By.xpath(".//span[.='Soundboard']");
	public static By lnkCreate=By.xpath("(.//*[text()='Create'])[2]");
	public static By lnkTopTracks=By.xpath("(.//*[text()='Top Tracks'])[2]");
	public static By lnkMyBeats=By.xpath("(.//*[text()='My Beats'])[2]");
	public static By lnkBehindTheSounds=By.xpath("(.//*[text()='Behind the Sounds'])[2]");
	public static By lnkFAQs=By.xpath("(.//*[text()='FAQs'])[2]");
	public static By lnkTermsAndConditions=By.xpath("(.//*[text()='Terms and Conditions'])[2]");
	
	//Product page links
	public static By lnkProducts=By.xpath("(.//*[@href='/products'])[1]");////(.//*[text()='Products'])[1]
	public static By lnkTurkish=By.xpath("(.//*[text()='Turkish'])[1]");
	public static By lnkTurkish1=By.xpath("(.//*[text()='Turkish'])");
	public static By lnkCrush=By.xpath("(.//*[text()='Crush'])[1]");
	public static By lnkCrush1=By.xpath("(.//*[text()='Crush'])");
	public static By lnkNo9=By.xpath("(.//*[text()='No. 9'])[1]");
	public static By lnkNo91=By.xpath("(.//*[text()='No. 9'])");
	public static By lnkClassics=By.xpath("(.//*[text()='Classics'])[1]");
	public static By lnkCamelCreations=By.xpath("(.//*[text()='Camel Creations'])");
	public static By lnkCamelCreations1=By.xpath("(.//*[text()='Camel Creations'])[1]");
	public static By lnkClassics1=By.xpath("(.//*[text()='Classics'])");
	public static By lnkRedKamel=By.xpath("(.//*[text()='Red Kamel'])");
	public static By lnkRedKamel1=By.xpath(".//*[text()='Red Kamel']");
	public static By lnkWides=By.xpath("(.//*[text()='Wides'])[1]");
	public static By lnkWides1=By.xpath("(.//*[text()='Wides'])");
	public static By lnkSnus=By.xpath("(.//*[text()='Snus'])[1]");
	public static By lnkSnus1=By.xpath("(.//*[text()='Snus'])");
	
	//Suneel menu navigation link

	//Crush now and dashboard
	public static By lnkCrushNowAndDashboard = By.xpath("(.//*[@href='/crush'])[1]");
	
	//Home page link
	public static By lnkHome = By.xpath(".//*[@href='/'][@class='Nav-beast']");
	public static By PgHome = By.xpath("(.//*[@data-ca-tracking='Nav: Beast-Icon'])");
	//Build Out link
	//public static By lnkBuildOut = By.xpath(".//*[@href='/buildout']");
	
	//Soundboard Link
	//public static By lnkSoundBoard = By.xpath(".//*[@href='/soundboard']");
	//Crush rich link
		public static By lnkCrushRich= By.xpath("(.//*[@href='/crush-rich'])[1]");
	//The Hump link
	public static By lnkTheHump = By.xpath("(.//*[@href='/hump'])[1]");
	
	//The art affect link
	public static By lnkTheArtAffect = By.xpath(".//*[@href='/art-affect']");
	
	//Products Link
	//public static By lnkProducts = By.xpath(".//*[@href='/products']");
	
	//Offers Link
//	public static By lnkOffers = By.xpath(".//*[@href='/offers']");
	
	//Profile link
	public static By lnkProfile = By.xpath(".//*[@href='/profile/linkout']");
	
	//Logout Link
	public static By lnkLogout = By.xpath(".//*[@href='/logout']");
	
	
}
