package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_ArtAffect_NewOrleans {
	
	//Update 28th Aug
	public static By pgBuilds=By.xpath(".//*[@class='Box-sc-1bhjx4h-0 dFHzuc']//*[text()='Builds']");
    public static By weSectionPaperMachine=By.xpath(".//*[text()='Paper Machine']");
    public static By btnSeeBuildPaperMachine=By.xpath(".//*[@href='/art-affect/new-orleans']");
    public static By pgPaperMachine=By.xpath(".//*[text()='Paper Machine']");
    public static By weProjectCollaborators=By.xpath(".//*[text()='Project Collaborators']");
    public static By imgBobSnead=By.xpath(".//*[@alt='Bob Snead']");
    public static By imgJessicaPeterson=By.xpath(".//*[@alt='Jessica  Peterson']");
    public static By imgChristopherDeris=By.xpath(".//*[@alt='Christopher Deris']");
    public static By imgBryanLee=By.xpath(".//*[@alt='Bryan Lee']");
    public static By btnMeetBob=By.xpath(".//*[text()='Meet Bob']");
    public static By btnMeetJessica=By.xpath(".//*[text()='Meet Jessica']");
    public static By btnMeetChristopher=By.xpath(".//*[text()='Meet Christopher']");
    public static By btnMeetBryan=By.xpath(".//*[text()='Meet Bryan']");
    public static By weArtistModel=By.xpath("(.//*[@id='Video-5707887333001_html5_api'])[1]");
    public static By btnArtistModelClose=By.xpath("(.//*[@class='styles__CloseButton-sc-1uvfz74-2 eofSUE styles__StyledButton-sc-4qcnu1-0 cVrrfY'])[1]");

  //Added on 29 August for New Orleans 001 test case
    public static By wesection1PaperMachine=By.xpath(".//*[@class='sc-bdVaJa sc-bwzfXH styles__Hero-enlpq-3 gUlUSu']");
    public static By btnPlayVideoPaperMachine=By.xpath("(//*[text()='Play Video'])[1]");
    public static By img1projectsection=By.xpath(".//*[@alt='New Orleans']");
    public static By img2projectsection=By.xpath(".//*[@alt='Paper Machine Printing Hub']");
    public static By img3projectsection=By.xpath(".//*[@alt='Painting Wall']");
    public static By weProjectsectionPaperMachine=By.xpath("(.//*[@class='Box-yh4gdj-0 hCVAUD'])[1]");
    public static By wesectionProjectGalleryHeading=By.xpath(".//*[@class='sc-bdVaJa sc-bwzfXH sc-htpNat bNyzyz']//*[text()='Project Gallery']");
    public static By wesectionProjectGallerytext=By.xpath(".//*[@class='sc-bdVaJa sc-bwzfXH sc-htpNat iUGNFe']");
    public static By wesubheadingProjectGallerysection=By.xpath("(.//*[@class='Text-sc-1n4wa1f-0 gOSCQF'])[1]");
    public static By img1ProjectGallerysection=By.xpath(".//*[@alt='Exterior Mural']");
    public static By img2ProjectGallerysection=By.xpath(".//*[@alt='Kinetic Sculpture']");
    public static By img3ProjectGallerysection=By.xpath(".//*[@alt='Projection Canal']");
    public static By img4ProjectGallerysection=By.xpath(".//*[@alt='PrintShop']");
    public static By img5ProjectGallerysection=By.xpath(".//*[@alt='Gallery']");
    public static By btnRightArrowProjectGallerysection=By.xpath("(.//*[@class='arrow'])[2]");
    public static By weDot1Gallerysection=By.xpath("(.//*[@class='dot '])[1]");
    public static By weDot2Gallerysection=By.xpath("(.//*[@class='dot '])[2]");
    public static By weDot3Gallerysection=By.xpath("(.//*[@class='dot '])[3]");
    public static By weDot4Gallerysection=By.xpath("(.//*[@class='dot '])[4]");
    public static By weArtistName1=By.xpath("(.//*[@class='sc-bdVaJa sc-bwzfXH FlexGrid__Col-rodgid-0 jisRTv'])[1]");
    public static By weArtistName2=By.xpath("(.//*[@class='sc-bdVaJa sc-bwzfXH FlexGrid__Col-rodgid-0 jisRTv'])[2]");
    public static By weArtistName3=By.xpath("(.//*[@class='sc-bdVaJa sc-bwzfXH FlexGrid__Col-rodgid-0 jisRTv'])[3]");
    public static By weArtistName4=By.xpath("(.//*[@class='sc-bdVaJa sc-bwzfXH FlexGrid__Col-rodgid-0 jisRTv'])[4]");
    public static By wesectionExploreMoreBuildsHeading=By.xpath("//*[text()='Explore More Builds']");
    public static By imgGrantProgramExploreMoreSection=By.xpath(".//*[@alt='Grant Program']");
    public static By imgPoppsEmporiumExploreMoreSection=By.xpath(".//*[@alt='Popps Emporium']");
    public static By imgConfluenceExploreMoreSection=By.xpath(".//*[@alt='Confluence']");
    public static By btnLearnMoreConfluenceExploreMoreSection=By.xpath("(.//*[text()='Learn More'])[3]");
    public static By btnLearnMoreGrantProgramExploreMoreSection=By.xpath("(.//*[text()='Learn More'])[1]");
    public static By btnLearnMorePoppsEmporiumExploreMoreSection=By.xpath("(.//*[text()='Learn More'])[2]");
    
//Other pages headings added on 29 August 2019
    public static By pgGrantProgram=By.xpath(".//*[@class='sc-bdVaJa sc-bwzfXH styles__Hero-juncme-3 lospEj']//*[text()='Grant Program']");
    public static By pgPoppsEmporium=By.xpath(".//*[@class='Box-sc-1bhjx4h-0 eAeWeX']//*[text()='Popps Emporium']");
    public static By pgConfluence=By.xpath(".//*[@class='Box-sc-1bhjx4h-0 eAeWeX']//*[text()='Confluence']");

}
