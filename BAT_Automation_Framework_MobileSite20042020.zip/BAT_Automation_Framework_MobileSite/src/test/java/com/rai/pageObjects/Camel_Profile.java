package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_Profile {
	public static By lnkWelcomeProfileName = By.xpath(".//*[text()='My Account']");
	public static By txtAddress = By.xpath(".//*[@id='UserInformation_AddressLine1']");
	public static By txtCity = By.xpath(".//*[@id='UserInformation_City']");
	public static By txtZipcode = By.xpath(".//*[@id='UserInformation_ZipCode']");
	public static By txtEmail = By.xpath(".//*[@id='UserInformation_EmailAddress']");
	public static By txtNewEmail = By.xpath(".//*[@id='NewEmailAddress']");
	public static By txtConfirmNewEmail = By.xpath(".//*[@id='ConfirmNewEmailAddress']");
	public static By btnUpdate = By.xpath(".//*[@id='btnUpdateUserInfo']");
	public static By txtState = By.xpath(".//*[@id='UserInformation_State']");
	
	public static By txtCurrentPassword = By.xpath(".//*[@id='CurrentPassword']");
	public static By txtNewPassword = By.xpath(".//*[@id='NewPassword']");
	public static By txtConfirmNewPassword = By.xpath(".//*[@id='ConfirmNewPassword']");
	public static By btnPasswordUpdate = By.xpath(".//*[@id='btnUpdatePassword']");
	public static By btnChallengeQUpdate = By.xpath(".//*[@id='btnUpdateChallengeQA']");
	public static By txtChallengeAnswer=By.xpath(".//*[@id='ChallengeAnswer']");
	public static By weDropdownChallengeQuestion=By.xpath(".//*[@id='ChallengeQuestion']");
	public static By txtChallengeQuestion=By.xpath("(.//*[text()='Who was your childhood hero?'])");
	
	//FORGOT PASSWORD PAGE OBJ
	public static By txtUserID=By.xpath(".//*[@id='userId']");
	public static By btnContinue=By.xpath(".//*[@id='edit-submit']");
	
	public static By txtChallengeAnswer1=By.xpath(".//*[@id='ChallengeAnswer']");
	public static By btnContinue1=By.xpath(".//*[@id='edit-submit']");
	public static By weMsgError=By.xpath(".//*[@id='answerMatchError']");
	public static By lnkGoToLogin=By.xpath(".//a[.='Go to Login']");
	public static By weForgotPasswordContent=By.xpath(".//*[@class='page']");
	//Preference tab
	public static By btnTobaccoPreferences=By.xpath(".//*[@id='tabMySmokes']");
	public static By weTPContents=By.xpath(".//*[@id='contentContainer']");
	public static By weChkBoxCombustible=By.xpath("(.//*[@id='TobaccoPreferencesSurvey_ScreenerSections[0]_TobaccoPreference_1000001aPRODCATEGORY'])[1]"); 
	public static By weChkBoxMoistSnuff=By.xpath("(.//*[@id='TobaccoPreferencesSurvey_ScreenerSections[0]_TobaccoPreference_1000001aPRODCATEGORY'])[2]"); 
	public static By weChkBoxVapor=By.xpath("(.//*[@id='TobaccoPreferencesSurvey_ScreenerSections[0]_TobaccoPreference_1000001aPRODCATEGORY'])[3]"); 
	public static By weChkBoxSnus=By.xpath("(.//*[@id='TobaccoPreferencesSurvey_ScreenerSections[0]_TobaccoPreference_1000001aPRODCATEGORY'])[4]"); 
	public static By weChkBoxDissolvableTobacco=By.xpath("(.//*[@id='TobaccoPreferencesSurvey_ScreenerSections[0]_TobaccoPreference_1000001aPRODCATEGORY'])[5]"); 
	public static By weDropdownCigaretteBrand=By.xpath(".//*[@id='TobaccoPreferencesSurvey_ScreenerSections__0_1000002UB']"); 
	public static By weDropdownRegularBrand=By.xpath(".//*[@id='TobaccoPreferencesSurvey_ScreenerSections__0_1000003SOR']"); 
	public static By weDropdownPrefer=By.xpath(".//*[@id='TobaccoPreferencesSurvey_ScreenerSections__0_1000004FLAVOR']");
	public static By weChkBoxPurchased=By.xpath("(.//*[@id='TobaccoPreferencesSurvey_ScreenerSections[0]_TobaccoPreference_100000730D'])[02]");
	public static By btnUpdateTobaccoPreferences=By.xpath("(.//*[@id='btnUpdateMySmokes'])");
	//Suneel menu navigation
	//Address field
		public static By weAddressField = By.xpath(".//*[@id='UserInformation_AddressLine1']");
}
