package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_ProductPage_Turkish {
	public static By weTurkish1=By.xpath("(.//*[@class='fp-tableCell'])[1]");
	public static By weImgTurkish1=By.xpath("(.//*[@class='Panel-packs'])[1]");
	public static By weTileTitle1=By.xpath("(.//*[@alt='Turkish Blends Headline'])[1]");
	
	public static By weTurkish2=By.xpath("(.//*[@class='fp-tableCell'])[2]");
	public static By weImgTurkish2=By.xpath("(.//*[@class='Panel-pack'])[1]");
	public static By weTileTitle2=By.xpath("(.//*[@alt='Turkish Royal'])[1]");
	
	public static By weTurkish3=By.xpath("(.//*[@class='fp-tableCell'])[3]");
	public static By weImgTurkish3=By.xpath("(.//*[@class='Panel-pack'])[2]");
	public static By weTileTitle3=By.xpath("(.//*[@alt='Turkish Gold'])[1]");
	
	public static By weTurkish4=By.xpath("(.//*[@class='fp-tableCell'])[4]");
	public static By weImgTurkish4=By.xpath("(.//*[@class='Panel-pack'])[3]");
	public static By weTileTitle4=By.xpath("(.//*[@alt='Turkish Silver'])[1]");
	
	public static By weTurkish5=By.xpath("(.//*[@class='fp-tableCell'])[5]");
	public static By weImgTurkish5=By.xpath("(.//*[@class='Panel-pack'])[4]");
	public static By weTileTitle5=By.xpath("(.//*[@alt='Turkish Jade'])[1]");
	
	public static By weTurkish6=By.xpath("(.//*[@class='fp-tableCell'])[6]");
	public static By weImgTurkish6=By.xpath("(.//*[@class='Panel-pack'])[5]");
	public static By weTileTitle6=By.xpath("(.//*[@alt='Turkish Jade Silver'])[1]");
	
	public static By weTurkish7=By.xpath("(.//*[@class='fp-tableCell'])[7]");
	public static By weImgTurkish7=By.xpath("(.//*[@class='phone'])[1]");
	
	
	public static By imgPaginationDot1=By.xpath("(.//*[@href='#'])[13]");
	public static By wePaginationDotText=By.xpath("(.//*[text()='Turkish Blends'])");
	
	public static By imgPaginationDot2=By.xpath("(.//*[@href='#royal'])");
	public static By wePaginationDot2=By.xpath("(.//*[text()='Royal'])");
	
	public static By imgPaginationDot3=By.xpath("(.//*[@href='#gold'])");
	public static By wePaginationDot3=By.xpath("(.//*[text()='Gold'])");
	
	public static By imgPaginationDot4=By.xpath("(.//*[@href='#silver'])");
	public static By wePaginationDot4=By.xpath("(.//*[text()='Silver'])");
	
	public static By imgPaginationDot5=By.xpath("(.//*[@href='#jade'])");
	public static By wePaginationDot5=By.xpath("(.//*[text()='Jade'])");
	
	public static By imgPaginationDot6=By.xpath("(.//*[@href='#jade-silver'])");
	public static By wePaginationDot6=By.xpath("(.//*[text()='Jade Silver'])");
	
	public static By imgPaginationDot7=By.xpath("(.//*[@href='#offers'])");
	public static By wePaginationDot7=By.xpath("(.//*[text()='Offers'])[1]");
	
	
	public static By weDownArrow=By.xpath("(.//*[@alt='Down Arrow'])[1]");
	public static By weUpwardArrow=By.xpath("(.//*[@alt='Down Arrow'])[4]");
	public static By btnViewOffers=By.xpath("(.//*[@class='CTA CTA--secondary'])[1]");
	
	
}
