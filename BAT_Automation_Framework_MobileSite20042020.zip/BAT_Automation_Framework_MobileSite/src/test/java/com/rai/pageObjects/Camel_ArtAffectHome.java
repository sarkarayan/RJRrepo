package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_ArtAffectHome {
	public static By weImgArtAffectHeroTile=By.xpath("(.//*[@class='sc-bdVaJa sc-bwzfXH styles__Hero-enlpq-3 bUNquf'])[1]");
	//public static By weTitleHeroTile=By.xpath(".//*[@class='intro-content']");////art-logo-svg
	public static By btnArtAffectHeroTile=By.xpath("(.//*[text()='Play Video'])[1]");
	public static By weHeroTileVideoOverlay=By.xpath(".//*[@id='Video-5596931033001_html5_api']");
	public static By btnHeroTileVideoOverlayClose=By.xpath("(.//*[@class='styles__CloseButton-sc-1uvfz74-2 eofSUE styles__StyledButton-sc-4qcnu1-0 cVrrfY'])[1]");

	public static By weSectionGrantProgramVideoSection=By.xpath("(.//*[@class='art-affect--wrapper'])[3]");
	public static By weBtnPlayGrantProgramVideo=By.xpath(".//*[@class='grant-program-video VideoModal-CTA']");
	public static By weBtnCloseGrantProgramVideo=By.xpath("(.//*[@class='EmptyModal-button Button Button--close-thick'])[1]");
	public static By weBtnLearnMoreGrantProgramVideo=By.xpath("(.//*[text()='Learn More'])[1]");

	public static By weSectionPoppsEmporium=By.xpath("(.//*[@class='art-affect--wrapper'])[7]");
	public static By weSectionPaperMachine=By.xpath("(.//*[@class='art-affect--wrapper'])[9]");
	public static By weSectionConfluence=By.xpath("(.//*[@class='art-affect--wrapper'])[11]");
	public static By btnGrantProgramViewProject=By.xpath("(.//*[@class='CTA CTA--white'])[2]");
	public static By btnPoppsEmporiumViewProject=By.xpath("(.//*[@class='CTA CTA--white'])[3]");
	public static By btnPaperMachineViewProject=By.xpath("(.//*[@class='CTA CTA--white'])[4]");
	public static By btnConfluenceViewProject=By.xpath("(.//*[@class='CTA CTA--white'])[5]");
	public static By btnBackToTop=By.xpath(".//*[text()='BACK TO TOP']");


	public static By imgGrantProgram1=By.xpath(".//*[@src='https://drkb1ue1l1mjg.cloudfront.net/assets/uat2/20181115002838/imgs/art-affect/grant-program/landing-page/GrantProgram-1.jpg']");
	public static By imgGrantProgram2=By.xpath(".//*[@src='https://drkb1ue1l1mjg.cloudfront.net/assets/uat2/20181115002838/imgs/art-affect/grant-program/landing-page/GrantProgram-2.jpg']");
	public static By imgGrantProgram3=By.xpath(".//*[@src='https://drkb1ue1l1mjg.cloudfront.net/assets/uat2/20181115002838/imgs/art-affect/grant-program/landing-page/GrantProgram-3.jpg']");

	public static By imgPoppsEmporium1=By.xpath(".//*[@src='https://drkb1ue1l1mjg.cloudfront.net/assets/uat2/20181115002838/imgs/art-affect/detroit/landing-page/Detroit-1.jpg']");
	public static By imgPoppsEmporium2=By.xpath(".//*[@src='https://drkb1ue1l1mjg.cloudfront.net/assets/uat2/20181115002838/imgs/art-affect/detroit/landing-page/Detroit-2.jpg']");
	public static By imgPoppsEmporium3=By.xpath(".//*[@src='https://drkb1ue1l1mjg.cloudfront.net/assets/uat2/20181115002838/imgs/art-affect/detroit/landing-page/Detroit-3.jpg']");

	public static By imgPaperMachine1=By.xpath(".//*[@src='https://drkb1ue1l1mjg.cloudfront.net/assets/uat2/20181115002838/imgs/art-affect/PaperMachine-1.jpg']");
	public static By imgPaperMachine2=By.xpath(".//*[@src='https://drkb1ue1l1mjg.cloudfront.net/assets/uat2/20181115002838/imgs/art-affect/PaperMachine-2.jpg']");
	public static By imgPaperMachine3=By.xpath(".//*[@src='https://drkb1ue1l1mjg.cloudfront.net/assets/uat2/20181115002838/imgs/art-affect/PaperMachine-3.jpg']");

	public static By imgConfluence1=By.xpath(".//*[@src='https://drkb1ue1l1mjg.cloudfront.net/assets/uat2/20181115002838/imgs/art-affect/kansas-city-4.jpg']");
	public static By imgConfluence2=By.xpath(".//*[@src='https://drkb1ue1l1mjg.cloudfront.net/assets/uat2/20181115002838/imgs/art-affect/kansas-city-5.jpg']");
	public static By imgConfluence3=By.xpath(".//*[@src='https://drkb1ue1l1mjg.cloudfront.net/assets/uat2/20181115002838/imgs/art-affect/kansas-city-6.jpg']");
	//Suneel menu navigation
	//ArtEffect page logo
	public static By imgArtEffectLogo = By.xpath(".//*[@id='ArtAffect']");
	//ArtAffect hero tile text
	public static By weTxtArtAffectHeroTile=By.xpath(".//*[text()='artAffect supports the transformation of ']");
	public static By weTxtArtAffectHeroTile2=By.xpath(".//*[text()='communities through the power of art.']");
	//View latest button from Our builds section of  ArtAffect landing page
	public static By btnViewLatestBuild=By.xpath("(.//*[text()='view latest build'])[1]");
	//See builds button from Our builds section of ArtAffect landing page.
	public static By btnSeeBuilds=By.xpath("(.//*[text()='See Builds'])[1]");
	//Builds page
	public static By wePgBuildsLogo=By.xpath("(.//*[text()='Builds'])[2]");
	//Our Builds section
	public static By weSectionOurBuilds=By.xpath("(.//*[@class='sc-bdVaJa yZMVz'])[1]");
	//Grant program section
	public static By weSectionGrantProgram=By.xpath("(.//*[@class='sc-bdVaJa yZMVz'])[2]");
	//See Grantees button from Grant program section of ArtAffect landing page.
	public static By btnSeeGrantees=By.xpath("(.//*[text()='See Grantees'])[1]");
	//Grant program page
	public static By wePgGrantProgramLogo=By.xpath("(.//*[text()='Grant Program'])[2]");
	//Text explore more builds section of art affect landing page
	public static By weTxtExploreMoreBuilds=By.xpath("(.//*[text()='Explore More Builds'])[1]");
	//Explore more builds tiles
	public static By wePoppsEmporiumTile=By.xpath("(.//*[@class='sc-bdVaJa sc-bwzfXH evXyaC'])[1]");
	public static By wePaperMachineTile=By.xpath("(.//*[@class='sc-bdVaJa sc-bwzfXH evXyaC'])[2]");
	public static By weConfluenceTile=By.xpath("(.//*[@class='sc-bdVaJa sc-bwzfXH evXyaC'])[3]");
	//Explore more builds tiles titles
	public static By wePoppsEmporiumTileTitle=By.xpath("(.//*[text()='Popps Emporium'])[2]");
	public static By wePaperMachineTileTitle=By.xpath("(.//*[text()='Paper Machine'])[1]");
	public static By weConfluenceTileTitle=By.xpath("(.//*[text()='Confluence'])[1]");
	//Learn more button of the respective tiles of the explore more build section
	public static By btnPoppsEmporiumLearMore=By.xpath("(.//*[text()='Learn More'])[1]");
	public static By btnPaperMachineLearnMore=By.xpath("(.//*[text()='Learn More'])[2]");
	public static By btnConfluenceLearnMore=By.xpath("(.//*[text()='Learn More'])[3]");
	//Detroit page
	public static By wePgPoppsEmporiumLogo=By.xpath("(.//*[text()='Popps Emporium'])[1]");
	//Paper machine page
	public static By wePgPaperMachineLogo=By.xpath("(.//*[text()='Paper Machine'])[1]");
	//Confluence page
	public static By wePgConfluenceLogo=By.xpath("(.//*[text()='Confluence'])[1]");
	//Images of the artaffect landing page
	public static By weImgPoppsEmporium=By.xpath("(.//*[@alt='City Map'])[1]");
	public static By weImgPoppsEmporium1=By.xpath("(.//*[@alt='Home Exterior'])[1]");
	public static By weImgPoppsEmporium2=By.xpath("(.//*[@alt='Home Frame'])[1]");
	public static By weImgGrantProgram=By.xpath("(.//*[@alt='City Map'])[2]");
	public static By weImgGrantProgram1=By.xpath("(.//*[@alt='Home Exterior'])[2]");
	public static By weImgGrantProgram2=By.xpath("(.//*[@alt='Home Frame'])[2]");
	//ArtAffect Menu links
	public static By lnkBuilds=By.xpath("(.//*[text()='Builds'])[1]");
	public static By lnkGrantProgram=By.xpath("(.//*[text()='Grant Program'])[1]");
}
