package com.rai.pageObjects;

public interface PageObjects {

	public String getProperty();
	public ObjectLocator getLocatorType();
	public String getObjectname();
}
