package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_Login {
	public static By txtUsername = By.id("username");
	public static By txtPassword = By.id("password");
	public static By lnkLogin = By.id("edit-submit");
	public static By weUsername=By.xpath(".//*[text()='Please Provide a Username / Email Address.']");//.//*[@id='usernameError']
	public static By wePassword=By.xpath(".//*[text()='Please enter your Password.']");//.//*[@id='passwordError']
	public static By weUsernameFormatError=By.xpath(".//*[text()='Username must be a combination of 8-30 letters and numbers.']");
	public static By weCheckboxRememberme =By.id("IsRememberUserChecked");
	//public static By checkboxTakemetoEmailPreferences =By.id("IsPreferenceScanChecked");
	public static By btnRegister = By.xpath(".//*[text()='Sign me up!']");
public static By lnkForgotUserId =By.xpath(".//a[.='Forgot Username?']");
public static By lnkForgotPassword=By.xpath(".//a[.='Forgot Password?']");

public static By txtMicrosoft=By.xpath(".//*[@type='email']");
public static By btnSubmit=By.xpath("(.//*[@type='submit'])[1]");




}
