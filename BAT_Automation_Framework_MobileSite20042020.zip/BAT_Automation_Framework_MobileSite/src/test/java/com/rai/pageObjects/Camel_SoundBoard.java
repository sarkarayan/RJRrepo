package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_SoundBoard {
//create page objects
	public static By btnMakeABeat=By.xpath("(.//*[@class='CTA CTA--blue CTA--small'])[1]");
	//Top Tracks page objects
	public static By btnBehindTheSounds=By.xpath("(.//*[text()='Behind the Sounds'])[15]");
	public static By weTxtNowListening=By.xpath("(.//*[@class='SoundboardLibrary-EmptyCarouselSlideHeader'])[15]");
	public static By btnMakeABeat3=By.xpath("(.//*[@class='CTA CTA--tiny'])[30]");
	public static By btnRightArrow=By.xpath("(.//*[@class='arrow'])[2]");
	public static By btnLeftArrow=By.xpath("(.//*[@class='arrow'])[1]");
			public static By btnPlay1=By.xpath("(.//*[@class='AudioIcon AudioIcon-play'])[1]");
			public static By btnPause1=By.xpath(".//*[@class='AudioIcon AudioIcon-pause']");
			
	//Behind the Sounds page objects
	public static By btnWatchVideo=By.xpath("(.//*[@class='CTA CTA--blue CTA--small VideoModal-CTA'])[1]");
	//FAQ's
	public static By weTxtFAQs=By.xpath("(.//*[text()='FAQs'])[3]");
	//Term's and Condition's
	public static By weTxtTermsAndConditions=By.xpath("(.//*[text()='Terms and Conditions'])[3]");
	
	
	//Soundboard landingpage page objects
	public static By btnListen=By.xpath("(.//*[@class='CTA CTA--blue'])[4]");
	public static By btnHearTheTracks=By.xpath("(.//*[@class='CTA CTA--blue'])[3]");
	//Soundboard my beats page
	public static By btnPlay=By.xpath("(.//*[@class='os-icon-play'])[1]");
	public static By btnPause=By.xpath("(.//*[@class='os-icon-pause'])[1]");
	public static By weVerifyMakeABeat=By.xpath("(.//*[@class='Coach Coach--on Coach--step1'])[1]");
	public static By btnDownload=By.xpath("(.//*[@class='os-icon-download'])[1]");
	//My beats page page objects
		public static By btnMakeABeat1=By.xpath("(.//*[@class='beat-link'])[1]");
		public static By btnMakeABeat2=By.xpath("(.//*[@class='beat-link'])[2]");
		public static By btnCreate=By.xpath("(.//*[text()='CREATE'])[1]");
//Suneel menu navigation
		//Soundboard logo in soundboard page
		public static By weSoundBoardLogoImg = By.xpath(".//*[@class='soundboardLogo']");



}
