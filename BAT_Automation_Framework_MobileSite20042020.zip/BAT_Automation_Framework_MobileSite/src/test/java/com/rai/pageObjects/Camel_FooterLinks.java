package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_FooterLinks {
	
	//Camel Login page footerlinks
	public static By lnkFAQs=By.xpath(".//a[.='FAQs']");
	public static By lnkContactUs=By.xpath(".//a[.='Contact Us']");
	public static By lnkTobaccoRights=By.xpath(".//a[.='Tobacco Rights']");
	public static By lnkSiteRequirements=By.xpath(".//a[.='Site Requirements']");
	public static By lnkAgeFiltering=By.xpath("(.//*[@href='/FooterLinks/AgeFilteringSoftware'])[2]");
	public static By lnkTermsofUse=By.xpath(".//a[.='Terms Of Use']");
	public static By lnkPrivacyPolicyandYourCaliforniaPrivacyRights=By.xpath("(.//*[@href='/FooterLinks/PrivacyPolicy'])[2]");
	public static By lnkPrivacyPolicyPostLogin = By.xpath(".//*[@href='https://qa-camel.raimktg.com/FooterLinks/PrivacyPolicy']");
public static By lnkFAQsiterequirements=By.xpath(".//a[.='https://qa-camel.raimktg.com/FooterLinks/SiteRequirements']");
public static By linkFAQPP1=By.xpath("(.//a[.='https://qa-camel.raimktg.com/FooterLinks/PrivacyPolicy'])[1]");
public static By linkFAQPP2=By.xpath("(.//a[.='https://qa-camel.raimktg.com/FooterLinks/PrivacyPolicy'])[2]");
public static By linkSRPP=By.xpath("(.//a['https://qa-camel.raimktg.com/FooterLinks/PrivacyPolicy'])[1]");
//Camel Home page footerlinks
public static By lnkFAQsHomePage=By.xpath(".//*[@href='https://qa-camel.raimktg.com/FooterLinks/Faqs']");
public static By lnkContactUsHomePage=By.xpath(".//a[.='Contact Us']");
public static By lnkTobaccoRightsHomePage=By.xpath(".//a[.='Tobacco Rights']");
public static By lnkSiteRequirementsHomePage=By.xpath(".//a[.='Site Requirements']");
public static By lnkAgeFilteringHomePage=By.xpath(".//*[@href='https://qa-camel.raimktg.com/FooterLinks/AgeFilteringSoftware']");
public static By lnkTermsofUseHomePage=By.xpath(".//*[@href='https://qa-camel.raimktg.com/FooterLinks/TermsOfUse']");
public static By lnkPrivacyPolicyandYourCaliforniaPrivacyRightsHomePage=By.xpath(".//*[@href='https://qa-camel.raimktg.com/FooterLinks/PrivacyPolicy']");
public static By linkFAQsiterequirementsHomePage=By.xpath(".//a[.='https://qa-camel.raimktg.com/FooterLinks/SiteRequirements']");
public static By linkFAQPP1HomePage=By.xpath("(.//a[.='https://qa-camel.raimktg.com/FooterLinks/PrivacyPolicy'])[1]");
public static By linkFAQPP2HomePage=By.xpath("(.//a[.='https://qa-camel.raimktg.com/FooterLinks/PrivacyPolicy'])[2]");
public static By linkSRPPHomePage=By.xpath("(.//a['https://qa-camel.raimktg.com/FooterLinks/PrivacyPolicy'])[1]");
//Camel footerlinks content
public static By weTxtFAQ=By.xpath(".//*[@id='main-content']");
public static By lnkFAQ1=By.xpath("(.//*[@class='accordion-title accordion-section-title'])[1]");
public static By lnkFAQ2=By.xpath("(.//*[@class='accordion-title accordion-section-title'])[2]");
public static By lnkFAQ3=By.xpath("(.//*[@class='accordion-title accordion-section-title'])[2]");
public static By lnkFAQ4=By.xpath("(.//*[@class='accordion-title accordion-section-title'])[3]");
public static By lnkFAQ5=By.xpath("(.//*[@class='accordion-title accordion-section-title'])[4]");

public static By weFAQ1=By.xpath(".//*[@id='accordion_1']");
public static By weFAQ2=By.xpath(".//*[@id='accordion_2']");
public static By weFAQ3=By.xpath(".//*[@id='accordion_3']");
public static By weFAQ6=By.xpath(".//*[@id='accordion_5']");
public static By weFAQ3sub1=By.xpath(".//*[text()='Verify that the selected retailer accepts mobile coupons']");
public static By weFAQ3sub2=By.xpath(".//*[text()='Ask the retailer to enter the UPC numbers below the UPC code']");
public static By weFAQ3sub3=By.xpath("//*[text()='Refresh the site/app by placing finger on top of screen and pulling down']");
public static By weFAQ3sub4=By.xpath("//*[text()='Check data connection � turn data off and back on']");
public static By weFAQ3sub5=By.xpath("//*[text()='If connected to Wi-Fi , connect to your own data plan']");
public static By weFAQ3sub6=By.xpath("//*[text()='Turn off all location services and turn them back on']");
public static By weFAQ4=By.xpath(".//*[@id='accordion_4']");
public static By weFAQ5=By.xpath(".//*[@class='accordion-content ng-hide accordion-section-content open']");
public static By weContactUs=By.xpath(".//*[@class='container']");
public static By weSiteReq=By.xpath("(.//*[@class='container mainContainer'])");
public static By weAgeFiltering=By.xpath(".//*[@class='container mainContainer']");







}
