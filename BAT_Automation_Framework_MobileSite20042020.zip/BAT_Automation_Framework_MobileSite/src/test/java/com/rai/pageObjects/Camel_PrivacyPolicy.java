package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_PrivacyPolicy {
	public static By weSidebar = By.xpath(".//*[@class='resp-tabs-list']");
		public static By weRestrict = By.xpath(".//*[@id='restrictions']");
			public static By weWhyWeCollect = By.xpath(".//*[@id='Why_We_Collect']");
			public static By weWhatWeCollect = By.xpath(".//*[@id='What_We_Collect']");
			
			public static By weShareInfo	 = By.xpath(".//*[@id='share_information']");
			public static By weWeProtect = By.xpath(".//*[@id='protect_your_privacy']");
			public static By weCanControl = By.xpath(".//*[@id='control_your_privacy']");
			public static By lnkherewwc=By.xpath(".//a[.='here']");
			public static By lnkCanControlPP	 = By.xpath(".//*[@href='http://www.ftc.gov/bcp/edu/microsites/idtheft/']");
			public static By weNoticeToCalifornia = By.xpath(".//*[@id='notice_to_california']");
			public static By weThirdParty = By.xpath(".//*[@id='third_party_websites']");
			public static By weChangesToPP = By.xpath(".//*[@id='privacy_policy']");
			public static By lnkBackToTop = By.xpath("(.//*[@title='Back to Top'])[15]");
			//Slider bar links
			public static By lnkrestrict = By.xpath(".//*[@class='restrictions_mobile']");
			public static By lnkwhyweCollect = By.xpath(".//*[@class='Why_We_Collect_mobile']");
			public static By lnkwhatweCollect = By.xpath(".//*[@class='What_We_Collect_mobile']");
			public static By lnkShareInfo = By.xpath(".//*[@class='share_information_mobile']");
			public static By lnkWeProtect = By.xpath(".//*[@class='protect_your_privacy_mobile']");
			public static By lnkCanControl = By.xpath(".//*[@class='control_your_privacy_mobile']");
			public static By lnkThirdParty = By.xpath(".//*[@class='third_party_websites_mobile']");
			public static By lnkChangesToPP = By.xpath(".//*[@class='privacy_policy_mobile']");
			public static By lnkNoticeToCalifornia = By.xpath(".//*[@href='#notice_to_california']");
			
			//To scroll down
			public static By weScrollFUpg = By.xpath(".//*[@href='javascript://']");
			public static By weScrollFPpg=By.xpath(".//*[@id='edit-submit']");
			public static By weScrollReg = By.xpath(".//*[text()='Next Step']");
					
			
}
