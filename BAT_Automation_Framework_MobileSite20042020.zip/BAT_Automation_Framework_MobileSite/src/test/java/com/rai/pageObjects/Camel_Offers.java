package com.rai.pageObjects;

import org.openqa.selenium.By;

public class Camel_Offers {
	public static By weYourOffers=By.xpath("(.//*[text()='Mobile Coupons'])");
	public static By weBannerTile=By.xpath(".//*[@class='CrushOfferTheme2--copy']");
	
	public static By btnExploreCrush=By.xpath(".//*[@class='CTA CTA--blue']");
	//public static By lnkCrushInstantRules=By.xpath(".//*[@class='CrushOfferTheme1--rules-cta']");
	public static By weMobileCoupons=By.xpath(".//*[text()='Mobile Coupons']");
	public static By weCouponTile=By.xpath("(.//*[@class='Offers-MobileCoupons'])[1]");
	public static By weRules1=By.xpath("(.//*[@class='Box-yh4gdj-0 hQenae'])[1]");
	//public static By weRules2=By.xpath(".//*[text()='Coupon offer is subject to change or termination without notice. Additional restrictions may apply.']");
	
	
	public static By imgHowToUse1=By.xpath("(.//*[@class='col'])[1]");
	public static By imgHowToUse2=By.xpath("(.//*[@class='col'])[2]");
	public static By imgHowToUse3=By.xpath("(.//*[@class='col'])[3]");
	public static By imgHowToUse4=By.xpath("(.//*[@class='col'])[4]");
	public static By weHowToUseTile=By.xpath(".//*[@class='Offers-Tutorial']");
	public static By btnNeedMoreHelp=By.xpath(".//*[text()='Need More Help?']");
	public static By btnGetItOnGooglePlay=By.xpath("(.//*[@alt='Google Play'])[1]");
	//Suneel menu navigation
	//Offers page text
		public static By weOffersPage = By.xpath(".//*[text()='Mobile Coupons']");
}
