package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.brandWebsitePageObjects;

public class BrandWebsite_ForgotPassword_UsernotfoundPage extends BaseClass {

	String testcaseName;

	public BrandWebsite_ForgotPassword_UsernotfoundPage(String testcaseName) {
		this.testcaseName = testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper The {@link ScriptHelper} object passed from the
	 *                     {@link DriverScript}
	 */

	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	private WebElement getPageElement(brandWebsitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("ForgotPassword Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}

	public void invokeApplication_brandwebsite() {
		System.out.println("Invoking application");
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

	}

	public void navigateToForgotPasswordPage() throws IOException {
		  commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.lnktxt_Forgotpassword),brandWebsitePageObjects.lnktxt_Forgotpassword.getObjectname());
	}
	
	public void navigateToRevelVeloForgotPasswordPage() throws IOException 
	{
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.lnktxt_RevelVeloForgotPassword), brandWebsitePageObjects.lnktxt_RevelVeloForgotPassword.getObjectname());
	}
	
	public void navigateToVUSEForgotPasswordPage() throws IOException 
	{
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.loginLnk_VUSECertifyAgePage), brandWebsitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.lnk_VUSELoginForgotPassword), brandWebsitePageObjects.lnk_VUSELoginForgotPassword.getObjectname());
	}

	public void forgotPassword_EnterValidUsername() throws IOException {
		String Email = dataTable.getData("General_Data", "Email");
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordUsername),Email, brandWebsitePageObjects.txt_ForgotPasswordUsername.getObjectname());
		// Thread.sleep(2000);
		commonFunction.clickIfElementPresentJavaScript(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue),brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
		// commonFunction.sendKeyENTER(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue),brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
	}

	public void forgotPassword_ValidDataOnGeneralInformationPage() throws InterruptedException, IOException {
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data", "City");
		String State = dataTable.getData("General_Data", "State");
		String DOB = dataTable.getData("General_Data", "DOB");

		String date = DOB;
		String dateParts[] = date.split("/");
		String month = dateParts[0];
		String day = dateParts[1];
		String year = dateParts[2];

		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordBirthMonth), month, brandWebsitePageObjects.drpdwn_ForgotPasswordBirthMonth.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordBirthDay), day, brandWebsitePageObjects.drpdwn_ForgotPasswordBirthDay.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordBirthYear), year,brandWebsitePageObjects.drpdwn_ForgotPasswordBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordFirstName), FirstName,brandWebsitePageObjects.txt_ForgotPasswordFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordLastName), LastName,brandWebsitePageObjects.txt_ForgotPasswordLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordAddress), Address,brandWebsitePageObjects.txt_ForgotPasswordAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordZipcode),Zipcode, brandWebsitePageObjects.txt_ForgotPasswordZipcode.getObjectname());
		//Thread.sleep(2000);
		if (getPageElement(brandWebsitePageObjects.txt_ForgotPasswordCity).getText().contains("")) {
			commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordCity), City,brandWebsitePageObjects.txt_ForgotPasswordCity.getObjectname());
			commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordState),State, brandWebsitePageObjects.drpdwn_ForgotPasswordState.getObjectname());
		}
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation),brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation.getObjectname());

	}

	public void forgotPassword_InvalidAnsweronVerifyIdentity() throws InterruptedException, IOException
	{
		String InvalidChallengeAnswer = dataTable.getData("General_Data", "InvalidChallengeAnswer");
		String Errormessage_ForgotPasswordIncorrectChallengeAnswer = "The answer does not match our records. Please re-enter your answer to the challenge question";

		// User entered Incorrect ChallengeAnswer on VerifyIdentity page - 1st time
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordChallengeAnswer), InvalidChallengeAnswer,brandWebsitePageObjects.txt_ForgotPasswordChallengeAnswer.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity),brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordInvalidChallengeAnswer),brandWebsitePageObjects.errormsg_ForgotPasswordInvalidChallengeAnswer.getObjectname(),Errormessage_ForgotPasswordIncorrectChallengeAnswer);

		// User entered Incorrect ChallengeAnswer on VerifyIdentity page - 2nd time
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity),brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordInvalidChallengeAnswer),brandWebsitePageObjects.errormsg_ForgotPasswordInvalidChallengeAnswer.getObjectname(),Errormessage_ForgotPasswordIncorrectChallengeAnswer);

		// User entered Incorrect ChallengeAnswer on VerifyIdentity page - 3rd time
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity),brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
	}

	
	public void forgotPassword_UsernotfoundPage() throws Exception
	{
		
		commonFunction.verifyIfElementIsPresent(getPageElement(brandWebsitePageObjects.forgotPassword_UsernotfoundPage), brandWebsitePageObjects.forgotPassword_UsernotfoundPage.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.forgotPassword_UsernotfoundPage_gotoRegistration), brandWebsitePageObjects.forgotPassword_UsernotfoundPage_gotoRegistration.getObjectname());
	}
}
