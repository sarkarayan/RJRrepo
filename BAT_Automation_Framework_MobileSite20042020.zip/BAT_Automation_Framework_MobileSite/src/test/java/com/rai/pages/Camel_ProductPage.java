package com.rai.pages;

import java.util.Properties;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
//import ReportLib.ExtentManager;
import com.rai.pageObjects.*;
import com.rai.framework.GenericLib;

@Listeners(ExtentITestListenerClassAdapter.class)
public class Camel_ProductPage extends BaseClass{

	GenericLib gl = new GenericLib(this.getClass().getSimpleName());
	Properties config = new Properties();
	SoftAssert softAssert=new SoftAssert();


	@BeforeMethod
	public void beforemethod(String TestCaseName,String TestCaseObjective,String TestEnvironmentUrl) {
		gl.start_report(TestCaseName, TestCaseObjective, TestEnvironmentUrl);
		//extent = ExtentManager.GetExtent();	
		//extent = ExtentManager.createTest(test, description)
	}

	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Verify the Turkish Product page Content, images and buttons.
	//Verifies:
	//Offer landing page UI/buttons and images
	//Pre requisites :
	//User should have valid username and password
	//Author : Vikram T Date: 24.11.2018
	public void  Camel_Turkish_ProductPage_014(String UN,String pwd,String url, String browserName,String txtTurkish1 ,String txtTurkish2,String txtTurkish3,String txtTurkish4,String txtTurkish5,String txtTurkish6,String txtTurkish7)throws Exception
	{
		// Launch Application
		gl.launchApplication(browserName, url);
		Thread.sleep(2000);

		//*********************************************************************************************************************      
		//Camel Login page is displayed.
		//gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//*********************************************************************************************************************          
		//Enter valid email id 
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter valid password

		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd) ;
		//Click login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
		Thread.sleep(10000);
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "HomePage");


		//hover the mouse on ArtAffect
		gl.HowerMouse(Camel_Common.lnkProducts,"Products link from main navigation");
		//Click Turkish link from main navigation submenu
		gl.clickbutton(Camel_Common.lnkTurkish, "Turkish from Products");
		Thread.sleep(6000);
		//Verify that Turkish page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("Products - Turkish | Camel","Turkish product page");

		//Verify the tile 1 content
		gl.fnContentValidation( txtTurkish1,Camel_ProductPage_Turkish.weTurkish1); 
		//Verify pack image is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weImgTurkish1, "Turkish pack image");
		//Verify tile title
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weTileTitle1, "Turkish blends");
		//Click the downward button
		gl.clickLink(Camel_ProductPage_Turkish.weDownArrow, "downward Arrow");

		Thread.sleep(4000);
		//Verify the tile 2 content
		gl.fnContentValidation( txtTurkish2,Camel_ProductPage_Turkish.weTurkish2); 
		//Verify pack image is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weImgTurkish2, "Turkish pack image");
		//Verify tile title
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weTileTitle2, "Royal");
		//Click the downward button
		gl.clickLink(Camel_ProductPage_Turkish.weDownArrow, "downward Arrow");
		Thread.sleep(4000);

		//Verify the tile 3 content
		gl.fnContentValidation( txtTurkish3,Camel_ProductPage_Turkish.weTurkish3); 
		//Verify pack image is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weImgTurkish3, "Turkish pack image");
		//Verify tile title
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weTileTitle3, "Gold");
		//Click the downward button
		gl.clickLink(Camel_ProductPage_Turkish.weDownArrow, "downward Arrow");
		Thread.sleep(4000);

		//Verify the tile 4 content
		gl.fnContentValidation( txtTurkish4,Camel_ProductPage_Turkish.weTurkish4); 
		//Verify pack image is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weImgTurkish4, "Turkish pack image");
		//Verify tile title
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weTileTitle4, "Silver");
		//Click the downward button
		gl.clickLink(Camel_ProductPage_Turkish.weDownArrow, "downward Arrow");

		Thread.sleep(4000);

		//Verify the tile 5 content
		gl.fnContentValidation( txtTurkish5,Camel_ProductPage_Turkish.weTurkish5); 
		//Verify pack image is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weImgTurkish5, "Turkish pack image");
		//Verify tile title
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weTileTitle5, "Jade");
		//Click the downward button
		gl.clickLink(Camel_ProductPage_Turkish.weDownArrow, "downward Arrow");
		Thread.sleep(4000);

		//Verify the tile 6 content
		gl.fnContentValidation( txtTurkish6,Camel_ProductPage_Turkish.weTurkish6); 
		//Verify pack image is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weImgTurkish6, "Turkish pack image");
		//Verify tile title
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weTileTitle6, "Jade Silver");
		//Click the downward button
		gl.clickLink(Camel_ProductPage_Turkish.weDownArrow, "downward Arrow");
		Thread.sleep(4000);
		//Verify the tile7 content
		gl.fnContentValidation( txtTurkish7,Camel_ProductPage_Turkish.weTurkish7); 
		//Verify pack image is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weImgTurkish7, "Turkish pack image");
		Thread.sleep(4000);
		//Click upward button
		gl.clickLink(Camel_ProductPage_Turkish.weUpwardArrow,"Upward button");
		//Verify pack image of tile 1 is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weImgTurkish1, "Turkish pack image");
		Thread.sleep(4000);
		//click second pagination dot
		gl.ClickRadioButton(Camel_ProductPage_Turkish.imgPaginationDot2, "pagination dot 2");
		Thread.sleep(4000);
		//Verify pack image of tile 2 is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weImgTurkish2, "Turkish pack image");

		Thread.sleep(4000);
		//click third pagination dot
		gl.ClickRadioButton(Camel_ProductPage_Turkish.imgPaginationDot3, "pagination dot 3");
		Thread.sleep(4000);
		//Verify pack image of tile 3 is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weImgTurkish3, "Turkish pack image");

		Thread.sleep(4000);
		//click fourth pagination dot
		gl.ClickRadioButton(Camel_ProductPage_Turkish.imgPaginationDot4, "pagination dot 4");
		Thread.sleep(4000);
		//Verify pack image of tile 4 is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weImgTurkish4, "Turkish pack image");
		Thread.sleep(4000);
		//click fifth pagination dot
		gl.ClickRadioButton(Camel_ProductPage_Turkish.imgPaginationDot5, "pagination dot 5");
		Thread.sleep(2000);
		//Verify pack image of tile 5 is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weImgTurkish5, "Turkish pack image");
		Thread.sleep(4000);
		//click sixth pagination dot
		gl.ClickRadioButton(Camel_ProductPage_Turkish.imgPaginationDot6, "pagination dot 6");
		Thread.sleep(2000);
		//Verify pack image of tile 6 is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weImgTurkish6, "Turkish pack image");

		Thread.sleep(4000);
		//click seventh pagination dot
		gl.ClickRadioButton(Camel_ProductPage_Turkish.imgPaginationDot7, "pagination dot 7");
		Thread.sleep(2000);
		//Verify pack image of tile 7 is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weImgTurkish7, "Turkish pack image");
		Thread.sleep(4000);
		//hover the mouse on pagination dot1
		gl.HowerMouse(Camel_ProductPage_Turkish.imgPaginationDot1,"pagination dot 1");
		//verify pagination dot name is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.wePaginationDotText, "Turkish blends");

		//hover the mouse on pagination dot2
		gl.HowerMouse(Camel_ProductPage_Turkish.imgPaginationDot2,"pagination dot 2");
		//verify pagination dot name is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.wePaginationDot2, "Royal");

		//hover the mouse on pagination dot3
		gl.HowerMouse(Camel_ProductPage_Turkish.imgPaginationDot3,"pagination dot 3");
		//verify pagination dot name is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.wePaginationDot3, "Gold");

		//hover the mouse on pagination dot4
		gl.HowerMouse(Camel_ProductPage_Turkish.imgPaginationDot4,"pagination dot 4");
		//verify pagination dot name is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.wePaginationDot4, "Silver");

		//hover the mouse on pagination dot5
		gl.HowerMouse(Camel_ProductPage_Turkish.imgPaginationDot5,"pagination dot 5");
		//verify pagination dot name is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.wePaginationDot5, "Jade");

		//hover the mouse on pagination dot6
		gl.HowerMouse(Camel_ProductPage_Turkish.imgPaginationDot6,"pagination dot 6");
		//verify pagination dot name is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.wePaginationDot6, "Jade Silver");

		//hover the mouse on pagination dot7
		gl.HowerMouse(Camel_ProductPage_Turkish.imgPaginationDot7,"pagination dot 7");
		//verify pagination dot name is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.wePaginationDot7, "Offers");

		//Click on Offer button
		gl.clickbutton(Camel_ProductPage_Turkish.btnViewOffers,"View Offers button");
		Thread.sleep(4000);
		//Verify Offers page is displayed
		gl.VerifyPageDisplayed(Camel_Offers.weYourOffers, "Offers Page");



		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");






	}

	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  To verify the content and images of the products landing page 
	//Test Case name :Camel_Redesign_Products_009
	//Verify the contents of each products such as 
	//TURKISH
	//CRUSH
	//CLASSIC
	//WIDES
	//NO.9
	//RedKamel
	//SNUS

	//Pre-Requisite:
	//User should be having a valid login credentials. 
	//Author : Vikram T Date: 26.10.2018

	public void  Camel_Redesign_Products_009(String UN,String pwd,String url, String browserName,String txtTurkish ,String txtClassics,String txtCrush,String txtWides,String txtRedKamel,String txtNo9,String txtSnus)throws Exception
	{
		// Launch Application
		gl.launchApplication(browserName, url);
		Thread.sleep(2000);

		//*********************************************************************************************************************      
		//Camel Login page is displayed.
		//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//*********************************************************************************************************************          
		//Enter valid email id 
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter valid password

		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd) ;
		//Click login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
				Thread.sleep(5000);
		Thread.sleep(5000);
		Thread.sleep(5000);
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "HomePage");
		Thread.sleep(25000);
		
		//hover the mouse on Products
		gl.HowerMouse(Camel_Common.lnkProducts,"Products link from main navigation");
		Thread.sleep(5000);
		//Verify the submenu links are displayed
		gl.VerifyElementVisible(Camel_Common.lnkCamelCreations1, "Camel Creations submenu link");
		gl.VerifyElementVisible(Camel_Common.lnkClassics, "Classics submenu link");

		gl.VerifyElementVisible(Camel_Common.lnkTurkish, "Turkish submenu link");

		gl.VerifyElementVisible(Camel_Common.lnkCrush, "Crush submenu link");

		gl.VerifyElementVisible(Camel_Common.lnkNo9, "No 9 submenu link");

		gl.VerifyElementVisible(Camel_Common.lnkWides, "wides submenu link");

		gl.VerifyElementVisible(Camel_Common.lnkSnus, "snus submenu link");

		gl.VerifyElementVisible(Camel_Common.lnkRedKamel1, "Red kamel submenu link");
		//hover the mouse on Products
		gl.HowerMouse(Camel_Common.lnkProducts,"Products link from main navigation");
		//Click on turkish submenu link
		gl.clickbutton(Camel_Common.lnkCamelCreations1, "Camel Creations submenu link");
		Thread.sleep(4000);
		//Verify the ti page
		gl.VerifyPageDisplayedUsingPageTitle("Camel");
		//Verify the camel creations page is displayed.
		gl.VerifyElementVisible(Camel_ProductPages.weCreationsPage, " Camel creations page");
		//hover the mouse on Products
		gl.HowerMouse(Camel_Common.lnkProducts,"Products link from main navigation");
		//Click on turkish submenu link
		gl.clickbutton(Camel_Common.lnkTurkish1, "Turkish submenu link");
		Thread.sleep(4000);
		//Verify the tile 1 content of turkish page
		gl.VerifyPageDisplayedUsingPageTitle("Products - Turkish | Camel");
		gl.fnContentValidation( txtTurkish,Camel_ProductPage_Turkish.weTurkish1); 
		//Verify pack image is displayed
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weImgTurkish1, "Turkish pack image");
		//Verify tile title
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weTileTitle1, "Turkish blends");
		//Click the downward button
		gl.VerifyElementVisible(Camel_ProductPage_Turkish.weDownArrow, "downward Arrow");
		//hover the mouse on products
		gl.HowerMouse(Camel_Common.lnkProducts,"Products link from main navigation");
		//click on the crush product
		gl.clickbutton(Camel_Common.lnkCrush1, "Crush submenu link");


		Thread.sleep(4000);
		//Verify crush product page is displayed
	//	gl.VerifyPageDisplayedUsingPageTitle("Products - Crush | Camel");
		gl.clickUsingJs(Camel_ProductPages.pgCrush, "Crush Page");
		//verify the text content of crush page
		gl.fnContentValidation( txtCrush,Camel_ProductPages.weTxtCrush); 
		//Verify hero image is displayed
		gl.VerifyElementVisible(Camel_ProductPages.weCrushPack, "Crush pack image");
		//Verify title is displayed
		//	gl.VerifyElementVisible(Camel_ProductPages.weCrushTitle, "Crush Title");
		//Verify title is displayed
		//hover the mouse on products
		gl.HowerMouse(Camel_Common.lnkProducts,"Products link from main navigation");
		//click on the  product
		gl.clickbutton(Camel_Common.lnkClassics1, "Classics submenu link");


		Thread.sleep(13000);
		//Verify classics product page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Products - Classics | Camel");
		//Verify the content of classics page
		gl.fnContentValidation(txtClassics, Camel_ProductPages.weTxtClassics);
		//Verify title is displayed
		//gl.VerifyElementVisible(Camel_ProductPages.imgClassicsTitle, "Classics Title");
		//hover the mouse on products
		gl.HowerMouse(Camel_Common.lnkProducts,"Products link from main navigation");
		//click on the  product
		gl.clickbutton(Camel_Common.lnkWides1, "Wides submenu link");

		//Verify wides product page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Products");
		//Veirfy the content of wides page
		gl.fnContentValidation(txtWides, Camel_ProductPages.weTxtWides);
		//Verify the pack image of wides page
		gl.VerifyElementVisible(Camel_ProductPages.weImgWidesPack, " Wide pack image");
		//hover the mouse on products
		gl.HowerMouse(Camel_Common.lnkProducts,"Products link from main navigation");
		//click on the  product
		gl.clickbutton(Camel_Common.lnkRedKamel, "Red kamel submenu link");


		//Verify Redkamel product page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Products");
		//Veirfy the content of Red Kamel page
		gl.fnContentValidation(txtRedKamel, Camel_ProductPages.weTxtRedKamel);
		//Verify the pack image of Red kamel page
		gl.VerifyElementVisible(Camel_ProductPages.weImgRedKamel, " Red kamel pack image");
		//hover the mouse on products
		gl.HowerMouse(Camel_Common.lnkProducts,"Products link from main navigation");
		//click on the  product
		gl.clickbutton(Camel_Common.lnkNo91, "No 9 submenu link");

		Thread.sleep(4000);
		//Verify No 9 product page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Products");
		//Veirfy the content of No 9 page
		gl.fnContentValidation(txtNo9, Camel_ProductPages.weNo9);
		//Verify the pack image of No 9 page
		gl.VerifyElementVisible(Camel_ProductPages.weImgNo9, " Red kamel pack image");
		//hover the mouse on products
		gl.HowerMouse(Camel_Common.lnkProducts,"Products link from main navigation");
		//click on the  product
		gl.clickbutton(Camel_Common.lnkSnus1, "Snus submenu link");
		Thread.sleep(6000);
		//Verify Snus product page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Products - Snus | Camel");
		//Veirfy the content of No 9 page
		//	gl.fnContentValidation(Camel_ProductPages.weSnus, txtSnus);
		//Verify the pack image of No 9 page
		gl.VerifyElementVisible(Camel_ProductPages.weImgSnus, " Snus pack image");




		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");



	}




	public void afterMethod() {
		driver.quit();
		gl.endReport();
		//extent.flush();
	}

















}
