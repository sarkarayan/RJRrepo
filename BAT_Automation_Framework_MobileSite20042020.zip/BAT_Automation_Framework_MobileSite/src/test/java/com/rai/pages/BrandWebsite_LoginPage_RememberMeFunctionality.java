package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;

import com.rai.pageObjects.brandWebsitePageObjects;

public class BrandWebsite_LoginPage_RememberMeFunctionality extends BaseClass {

	String testcaseName;
	public BrandWebsite_LoginPage_RememberMeFunctionality(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(brandWebsitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Login Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	public void invokeApplication_brandwebsite()
	{
	    String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
	
   public void loginfields_ValidateInlinetext() throws Exception
   {
	   
	   String Expected_UsernameInlinetext = "Username / Email Address";
	   String Expected_PasswordInlinetext = "Password";
	   
	   String Actual_UsernameInlintext = commonFunction.getValueFromAttribute(getPageElement(brandWebsitePageObjects.txt_LoginUsername), brandWebsitePageObjects.txt_LoginUsername.getObjectname(), "placeholder");
	   String Actual_PasswordInlinetext = commonFunction.getValueFromAttribute(getPageElement(brandWebsitePageObjects.txt_LoginPassword), brandWebsitePageObjects.txt_LoginPassword.getObjectname(), "placeholder");
	   
	   Assert.assertEquals(Actual_UsernameInlintext, Expected_UsernameInlinetext, "Expected UsernameInlin text was not displayed on LoginPage");
	   Assert.assertEquals(Actual_PasswordInlinetext, Expected_PasswordInlinetext, "Expected PasswordInline text was not displayed on LoginPage");	   
	   
   }	
	
	public void loginPage_RememberMeValidation() throws IOException, InterruptedException
	{
		String ValidUserId = dataTable.getData("General_Data","Username");
		String ValidPassword = dataTable.getData("General_Data","Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginUsername),ValidUserId,brandWebsitePageObjects.txt_LoginUsername.getObjectname());
        commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginPassword),ValidPassword,brandWebsitePageObjects.txt_LoginPassword.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.chkbx_RememberMe), brandWebsitePageObjects.chkbx_RememberMe.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login), brandWebsitePageObjects.btn_Login.getObjectname());

	}
	
	public void revelVelologinPage_RememberMeValidation() throws IOException, InterruptedException
	{
		String ValidUserId = dataTable.getData("General_Data","Username");
		String ValidPassword = dataTable.getData("General_Data","Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginUsername),ValidUserId,brandWebsitePageObjects.txt_LoginUsername.getObjectname());
        commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginPassword),ValidPassword,brandWebsitePageObjects.txt_LoginPassword.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.chkbx_RevelVelo_RememberMe), brandWebsitePageObjects.chkbx_RevelVelo_RememberMe.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login), brandWebsitePageObjects.btn_Login.getObjectname());

	}
	
	public void loginPage_ValidatedisplayedUserId() throws Exception
	{
		String Expected_UserId = dataTable.getData("General_Data", "Username");
		
		String Actual_UserId = commonFunction.getTextFromTextBox(getPageElement(brandWebsitePageObjects.txt_LoginUsername), brandWebsitePageObjects.txt_LoginUsername.getObjectname());
		
		Assert.assertEquals(Actual_UserId, Expected_UserId, "RememberMe - Entered User Id not displayed in Username field");
		
	}
	
	public void logout_RememberMeValidation() throws Exception
	{
		
		if((getPageElement(brandWebsitePageObjects.chkbx_RememberMe)).isSelected())
		{
			System.out.println("RememberMe Checkbox was selected");
		}
		else
		{
			System.out.println("RememberMe Checkbox was not selected");
		}
		
	}
	
	public void vuseloginPage_RememberMeValidation() throws IOException, InterruptedException
	{
		String ValidUserId = dataTable.getData("General_Data","Username");
		String ValidPassword = dataTable.getData("General_Data","Password");
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.loginLnk_VUSECertifyAgePage), brandWebsitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginUsername),ValidUserId,brandWebsitePageObjects.txt_VUSELoginUsername.getObjectname());
        commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginPassword),ValidPassword,brandWebsitePageObjects.txt_VUSELoginPassword.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.chkbox_VUSELoginRememberMe), brandWebsitePageObjects.chkbox_VUSELoginRememberMe.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_VUSELogin), brandWebsitePageObjects.btn_VUSELogin.getObjectname());

	}
	
	public void vuseloginPage_ValidatedisplayedUserId() throws Exception
	{
		String Expected_UserId = dataTable.getData("General_Data", "Username");
		
		String Actual_UserId = commonFunction.getTextFromTextBox(getPageElement(brandWebsitePageObjects.txt_VUSELoginUsername), brandWebsitePageObjects.txt_VUSELoginUsername.getObjectname());
		
		Assert.assertEquals(Actual_UserId, Expected_UserId, "RememberMe - Entered User Id not displayed in Username field");
		
	}
	
	public void vuselogout_RememberMeValidation() throws Exception
	{
		
		if((getPageElement(brandWebsitePageObjects.chkbox_VUSELoginRememberMe)).isSelected())
		{
			System.out.println("RememberMe Checkbox was selected");
		}
		
	}
	
	public void revelVelologout_RememberMeValidation() throws Exception
	{
		
		if((getPageElement(brandWebsitePageObjects.chkbx_RevelVelo_RememberMe)).isSelected())
		{
			System.out.println("RememberMe Checkbox was selected");
		}
		
	}
	
	
	

		
	
	
}

