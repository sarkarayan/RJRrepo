package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.framework.Status;
import com.rai.pageObjects.MobileSiteForgotusernamePageObjects;
import com.rai.pageObjects.MobileSiteLoginPageObjects;
import com.rai.pageObjects.MobileSiteResetPageObjects;
import com.rai.pageObjects.MobilesitePageObjects;

public class Mobilesite_LoginFlow_LoginResetPandY_PrimaryUandN extends BaseClass{
	
	String testcaseName;
	public Mobilesite_LoginFlow_LoginResetPandY_PrimaryUandN(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(MobileSiteForgotusernamePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	private WebElement getPageElement(MobileSiteResetPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	private WebElement getPageElement(MobilesitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	private WebElement getPageElement(MobileSiteLoginPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Mobile Site Login Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
		
	
	public void invokeApplication_brandMobilesite()
	{
		String WebsiteURL = dataTable.getData("General_Data","URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
	public void login_EnterValidDataPandY() throws IOException
	{
		
		String Email = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data","Password");
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btnSignInTab),MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteLoginPageObjects.txt_LoginUsername),Email,MobileSiteLoginPageObjects.txt_LoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteLoginPageObjects.txt_LoginPassword),Password,MobileSiteLoginPageObjects.txt_LoginPassword.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btn_Login),MobileSiteLoginPageObjects.btn_Login.getObjectname());
	}
	
	public void resetflow_GeneralInfoPageviaLogin() throws InterruptedException, IOException
	{
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
		String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
				
		commonFunction.selectAnyElement(getPageElement(MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameBirthMonth), month, MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameBirthMonth.getObjectname());
		Thread.sleep(5000);
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameBirthDay),day,MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameBirthYear), year, MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameFirstName), FirstName, MobileSiteForgotusernamePageObjects.txt_ForgotUsernameFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameLastName), LastName, MobileSiteForgotusernamePageObjects.txt_ForgotUsernameLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameAddress), Address, MobileSiteForgotusernamePageObjects.txt_ForgotUsernameAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameZipcode), Zipcode,MobileSiteForgotusernamePageObjects.txt_ForgotUsernameZipcode.getObjectname());
		Thread.sleep(4000);
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameCity), City, MobileSiteForgotusernamePageObjects.txt_ForgotUsernameCity.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameState),State, MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameState.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.Continuebtn_LoginResetviaLoginonGeneralInfo),MobileSiteResetPageObjects.Continuebtn_LoginResetviaLoginonGeneralInfo.getObjectname());
				
	}
	public void vuselogin_EnterValidDataPandY() throws IOException
	{
		
		String Email = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data","Password");
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.loginLnk_VUSECertifyAgePage),MobilesitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		
		//commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.header_VUSELogin),brandWebsitePageObjects.header_VUSELogin.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginUsername),Email,MobilesitePageObjects.txt_VUSELoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginPassword),Password,MobilesitePageObjects.txt_VUSELoginPassword.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_VUSELogin),MobilesitePageObjects.btn_VUSELogin.getObjectname());
	}
	
	public void resetflow_AnotherBrandAlreadyRegisteredPage() throws Exception 
	{
		
		String ExpectedErrormsg_diffBrandAlreadyRegistered = "It looks like you are already registered with another Reynolds American operating company's brand website.";
		
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errmsg_AlreadyRegisteredPage), MobileSiteResetPageObjects.errmsg_AlreadyRegisteredPage.getObjectname(), ExpectedErrormsg_diffBrandAlreadyRegistered);
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.btn_AlreadyRegisteredLogin), MobileSiteResetPageObjects.btn_AlreadyRegisteredLogin.getObjectname());
	}
	

}
