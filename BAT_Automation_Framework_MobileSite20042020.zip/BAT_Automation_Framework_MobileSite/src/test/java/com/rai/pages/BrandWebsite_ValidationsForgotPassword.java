package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.brandWebsitePageObjects;

public class BrandWebsite_ValidationsForgotPassword extends BaseClass {

	String testcaseName;

	public BrandWebsite_ValidationsForgotPassword(String testcaseName) {
		this.testcaseName = testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper The {@link ScriptHelper} object passed from the
	 *                     {@link DriverScript}
	 */

	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	private WebElement getPageElement(brandWebsitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("ForgotPassword Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}

	public void invokeApplication_brandwebsite() {
		System.out.println("Invoking application");
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

	}

	public void navigateToForgotPasswordPage() throws IOException {
		  commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.lnktxt_Forgotpassword),brandWebsitePageObjects.lnktxt_Forgotpassword.getObjectname());
	}
	public void forgotPassword_NegativeValidationsUsernamePage() throws Exception {
		String InvalidUserIdformat = dataTable.getData("General_Data", "InvalidUserIDformat");
		String InvalidUserId = dataTable.getData("General_Data", "NonExistUserId");

		String Errormsg_NoUserId = "Please enter your Username / Email Address.";
		String Errormsg_UserIdInvalidformat = "Username must be a combination of 8-30 letters and numbers.";
		String Errormsg_InvalidUserId = "We could not locate your Login ID, please try again.";

		// Clicking on Continue without UserId data
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue),
				brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
		commonFunction.isElementPresentContainsText(
				getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordNoUsername),
				brandWebsitePageObjects.errormsg_ForgotPasswordNoUsername.getObjectname(), Errormsg_NoUserId);

		// User entered Invalid UserID format
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordUsername),
				InvalidUserIdformat, brandWebsitePageObjects.txt_ForgotPasswordUsername.getObjectname());
		// Thread.sleep(2000);
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue),
				brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
		commonFunction.isElementPresentContainsText(
				getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordInvalidUserIdformat),
				brandWebsitePageObjects.errormsg_ForgotPasswordInvalidUserIdformat.getObjectname(),
				Errormsg_UserIdInvalidformat);

		// User enters Invalid/Inactive UserId
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordUsername),
				InvalidUserId, brandWebsitePageObjects.txt_ForgotPasswordUsername.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue),
				brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
		commonFunction.isElementPresentContainsText(
				getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordInvalidUserId),
				brandWebsitePageObjects.errormsg_ForgotPasswordInvalidUserId.getObjectname(), Errormsg_InvalidUserId);

	}

	public void forgotPassword_EnterValidUsername() throws IOException {
		String Email = dataTable.getData("General_Data", "Email");
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordUsername),
				Email, brandWebsitePageObjects.txt_ForgotPasswordUsername.getObjectname());
		// Thread.sleep(2000);
		commonFunction.clickIfElementPresentJavaScript(
				getPageElement(brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue),
				brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
		// commonFunction.sendKeyENTER(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue),brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
	}

	public void forgotPassword_NegativeValidationsGeneralInfoPage() throws InterruptedException, IOException {
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String InvalidLastName = dataTable.getData("General_Data", "InvalidLastName");
		String InvalidAddress = dataTable.getData("General_Data", "InvalidAddress");
		String InvalidZipcode = dataTable.getData("General_Data", "InvalidZipcode");
		String City = dataTable.getData("General_Data", "City");
		String State = dataTable.getData("General_Data", "State");

		String date = dataTable.getData("General_Data", "DOB");
		String dateParts[] = date.split("/");
		String month = dateParts[0];
		String day = dateParts[1];
		String year = dateParts[2];

		String Errormessage_ForgotPasswordNoDOB = "Please provide a Date Of Birth";
		String Errormessage_ForgotPasswordNoDataonGeneralInfo = "Please fix the errors above";
		String Errormessage_ForgotPasswordNoLegalName = "Please enter your legal name";
		String Errormessage_ForgotPasswordNoAddress = "Please provide a street address";
		String Errormessage_ForgotPasswordNoZipcode = "Please provide a ZIP Code";
		String Errormessage_ForgotPasswordNoCity = "Please Provide City";
		String Errormessage_ForgotPasswordNoState = "Please Provide State";
		String Errormessage_ForgotPasswordInvalidUserInfo = "We were not able to find your information. Please check and try again.";

		// Clicking on Continue without any data on GeneralInfo page
		//Thread.sleep(6000);
		// commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.lnk_ForgotPasswordGeneralInfoLogin));
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordFirstName),
				FirstName, brandWebsitePageObjects.txt_ForgotPasswordFirstName.getObjectname());
		commonFunction.clickIfElementPresent(
				getPageElement(brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation),
				brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation.getObjectname());
		// commonFunction.clickIfElementPresentJavaScript(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation),
		// brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation.getObjectname());
		commonFunction
				.scrollIntoView(getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordNoDataonGeneralInfo));

		commonFunction.isElementPresentContainsText(
				getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordNoDataonGeneralInfo),
				brandWebsitePageObjects.errormsg_ForgotPasswordNoDataonGeneralInfo.getObjectname(),
				Errormessage_ForgotPasswordNoDataonGeneralInfo);
		commonFunction.isElementPresentContainsText(
				getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordNoDOB),
				brandWebsitePageObjects.errormsg_ForgotPasswordNoDOB.getObjectname(), Errormessage_ForgotPasswordNoDOB);
		commonFunction.isElementPresentContainsText(
				getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordNoLegalName),
				brandWebsitePageObjects.errormsg_ForgotPasswordNoLegalName.getObjectname(),
				Errormessage_ForgotPasswordNoLegalName);
		commonFunction.isElementPresentContainsText(
				getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordNoAddress),
				brandWebsitePageObjects.errormsg_ForgotPasswordNoAddress.getObjectname(),
				Errormessage_ForgotPasswordNoAddress);
		commonFunction.isElementPresentContainsText(
				getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordNoZipcode),
				brandWebsitePageObjects.errormsg_ForgotPasswordNoZipcode.getObjectname(),
				Errormessage_ForgotPasswordNoZipcode);
		commonFunction.isElementPresentContainsText(
				getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordNoCity),
				brandWebsitePageObjects.errormsg_ForgotPasswordNoCity.getObjectname(),
				Errormessage_ForgotPasswordNoCity);
		commonFunction.isElementPresentContainsText(
				getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordNoState),
				brandWebsitePageObjects.errormsg_ForgotPasswordNoState.getObjectname(),
				Errormessage_ForgotPasswordNoState);

		// User entered Invalid user info on GeneralInfo page
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordBirthMonth), month,
				brandWebsitePageObjects.drpdwn_ForgotPasswordBirthMonth.getObjectname());
		//Thread.sleep(3000);
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordBirthDay),
				day, brandWebsitePageObjects.drpdwn_ForgotPasswordBirthDay.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordBirthYear),
				year, brandWebsitePageObjects.drpdwn_ForgotPasswordBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordFirstName), FirstName,
				brandWebsitePageObjects.txt_ForgotPasswordFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordLastName),
				InvalidLastName, brandWebsitePageObjects.txt_ForgotPasswordLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordAddress),
				InvalidAddress, brandWebsitePageObjects.txt_ForgotPasswordAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordZipcode),
				InvalidZipcode, brandWebsitePageObjects.txt_ForgotPasswordZipcode.getObjectname());
		Thread.sleep(3000);
		if (getPageElement(brandWebsitePageObjects.txt_ForgotPasswordCity).getText().contains("")) {
			commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordCity), City,
					brandWebsitePageObjects.txt_ForgotPasswordCity.getObjectname());
			commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordState),
					State, brandWebsitePageObjects.drpdwn_ForgotPasswordState.getObjectname());
		}

		commonFunction.clickIfElementPresent(
				getPageElement(brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation),
				brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation.getObjectname());
		commonFunction.isElementPresentContainsText(
				getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordUsernotfound),
				brandWebsitePageObjects.errormsg_ForgotPasswordUsernotfound.getObjectname(),
				Errormessage_ForgotPasswordInvalidUserInfo);

	}

	public void forgotPassword_ValidDataOnGeneralInformationPage() throws InterruptedException, IOException {
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data", "City");
		String State = dataTable.getData("General_Data", "State");
		String DOB = dataTable.getData("General_Data", "DOB");

		String date = DOB;
		String dateParts[] = date.split("/");
		String month = dateParts[0];
		String day = dateParts[1];
		String year = dateParts[2];

		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordBirthMonth), month, brandWebsitePageObjects.drpdwn_ForgotPasswordBirthMonth.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordBirthDay), day, brandWebsitePageObjects.drpdwn_ForgotPasswordBirthDay.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordBirthYear), year,brandWebsitePageObjects.drpdwn_ForgotPasswordBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordFirstName), FirstName,
				brandWebsitePageObjects.txt_ForgotPasswordFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordLastName), LastName,
				brandWebsitePageObjects.txt_ForgotPasswordLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordAddress), Address,
				brandWebsitePageObjects.txt_ForgotPasswordAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordZipcode),
				Zipcode, brandWebsitePageObjects.txt_ForgotPasswordZipcode.getObjectname());
		//Thread.sleep(2000);
		if (getPageElement(brandWebsitePageObjects.txt_ForgotPasswordCity).getText().contains("")) {
			commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordCity), City,
					brandWebsitePageObjects.txt_ForgotPasswordCity.getObjectname());
			commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordState),
					State, brandWebsitePageObjects.drpdwn_ForgotPasswordState.getObjectname());
		}
		commonFunction.clickIfElementPresent(
				getPageElement(brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation),
				brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation.getObjectname());

	}

	public void forgotPassword_NegativeValidationsVerifyIdentity() throws InterruptedException, IOException {
		String InvalidChallengeAnswer = dataTable.getData("General_Data", "InvalidChallengeAnswer");

		String Errormessage_ForgotPasswordNoChallengeAnswer = "Please provide an answer to account recovery question";
		String Errormessage_ForgotPasswordIncorrectChallengeAnswer = "The answer does not match our records. Please re-enter your answer to the challenge question";

		// ChallengeAnswer not entered on VerifyIdentity Page
		//Thread.sleep(4000);
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity),
				brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
		//Thread.sleep(5000);
		commonFunction.isElementPresentContainsText(
				getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordNoChallengeAnswer),
				brandWebsitePageObjects.errormsg_ForgotPasswordNoChallengeAnswer.getObjectname(),
				Errormessage_ForgotPasswordNoChallengeAnswer);

		// User entered Incorrect ChallengeAnswer on VerifyIdentity page
		commonFunction.clearAndEnterTextTabOut(
				getPageElement(brandWebsitePageObjects.txt_ForgotPasswordChallengeAnswer), InvalidChallengeAnswer,
				brandWebsitePageObjects.txt_ForgotPasswordChallengeAnswer.getObjectname());
		//Thread.sleep(2000);
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity),
				brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
		commonFunction.isElementPresentContainsText(
				getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordInvalidChallengeAnswer),
				brandWebsitePageObjects.errormsg_ForgotPasswordInvalidChallengeAnswer.getObjectname(),
				Errormessage_ForgotPasswordIncorrectChallengeAnswer);

	}

	public void forgotPassword_ValidDataVerifyIdentity() throws InterruptedException, IOException {
		String ChallengeAnswer = dataTable.getData("General_Data", "ChallengeAnswer");

		commonFunction.clearAndEnterTextTabOut(
				getPageElement(brandWebsitePageObjects.txt_ForgotPasswordChallengeAnswer), ChallengeAnswer,
				brandWebsitePageObjects.txt_ForgotPasswordChallengeAnswer.getObjectname());
		//Thread.sleep(2000);
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity),
				brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
		//Thread.sleep(4000);

	}

	public void forgotPassword_NegativeValidationsResetPassword() throws InterruptedException, IOException {
		String InvalidPasswordformat = dataTable.getData("General_Data", "InvalidPasswordformat");
		String DifferntPassword = dataTable.getData("General_Data", "InvalidPassword");
		String Password = dataTable.getData("General_Data", "Password");

		String Errormessage_ForgotPasswordNoPassword = "Please provide a password";
		String Errormessage_ForgotPasswordInvalidPasswordformat = "Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.";
		String Errormessage_ForgotPasswordDiffPassword = "Passwords did not match";

		// User clicked Continue without entering Password on ResetPassword page
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordResetPassword),
				brandWebsitePageObjects.btn_ForgotPasswordResetPassword.getObjectname());
		commonFunction.isElementPresentContainsText(
				getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordNoPasswordentered),
				brandWebsitePageObjects.errormsg_ForgotPasswordNoPasswordentered.getObjectname(),
				Errormessage_ForgotPasswordNoPassword);

		// User entered Invalid format in Password field
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordPassword),
				InvalidPasswordformat, brandWebsitePageObjects.txt_ForgotPasswordPassword.getObjectname());
		commonFunction.isElementPresentContainsText(
				getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordInvalidPasswordformatentered),
				brandWebsitePageObjects.errormsg_ForgotPasswordInvalidPasswordformatentered.getObjectname(),
				Errormessage_ForgotPasswordInvalidPasswordformat);

		// User entered different data in Password & ConfirmPassword fields
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordPassword),
				Password, brandWebsitePageObjects.txt_ForgotPasswordPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(
				getPageElement(brandWebsitePageObjects.txt_ForgotPasswordConfirmPassword), DifferntPassword,
				brandWebsitePageObjects.txt_ForgotPasswordConfirmPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordResetPassword),
				brandWebsitePageObjects.btn_ForgotPasswordResetPassword.getObjectname());
		//Thread.sleep(4000);
		commonFunction.isElementPresentContainsText(
				getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordDifferentPasswordentered),
				brandWebsitePageObjects.errormsg_ForgotPasswordDifferentPasswordentered.getObjectname(),
				Errormessage_ForgotPasswordDiffPassword);

	}

	public void forgotPassword_ValidDataResetPassword() throws InterruptedException, IOException {
		String Password = dataTable.getData("General_Data", "Password");
		String ConfirmPassword = dataTable.getData("General_Data", "Password");

		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordPassword),
				Password, brandWebsitePageObjects.txt_ForgotPasswordPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(
				getPageElement(brandWebsitePageObjects.txt_ForgotPasswordConfirmPassword), ConfirmPassword,
				brandWebsitePageObjects.txt_ForgotPasswordConfirmPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordResetPassword),
				brandWebsitePageObjects.btn_ForgotPasswordResetPassword.getObjectname());
		//Thread.sleep(4000);
	}

	public void forgotPassword_NegativeValidationsCongratsPage() throws IOException {
		String Email = dataTable.getData("General_Data", "Email");

		String Errormessage_ForgotPasswordNoDataonCongratspage = "Please fix the errors above";
		String Errormessage_ForgotPasswordNoPasswordonCongratspage = "Please enter your password.";

		// User clicked on Login without any data on Congrats Page
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_CongratsPageLoginbutton),
				brandWebsitePageObjects.btn_CongratsPageLoginbutton.getObjectname());
		commonFunction.isElementPresentContainsText(
				getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordCongratsPageNoDataEntered),
				brandWebsitePageObjects.errormsg_ForgotPasswordCongratsPageNoDataEntered.getObjectname(),
				Errormessage_ForgotPasswordNoDataonCongratspage);

		// User clicked on Login without Password
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_CongratsPageUsername), Email,
				brandWebsitePageObjects.txt_CongratsPageUsername.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_CongratsPageLoginbutton),
				brandWebsitePageObjects.btn_CongratsPageLoginbutton.getObjectname());
		commonFunction.isElementPresentContainsText(
				getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordCongratsPagePasswordNotentered),
				brandWebsitePageObjects.errormsg_ForgotPasswordCongratsPagePasswordNotentered.getObjectname(),
				Errormessage_ForgotPasswordNoPasswordonCongratspage);

	}

	public void forgotPassword_CongratsPage() throws IOException {
		String Email = dataTable.getData("General_Data", "Email");
		String Password = dataTable.getData("General_Data", "Password");

		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_CongratsPageUsername), Email,
				brandWebsitePageObjects.txt_CongratsPageUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_CongratsPagePassword),
				Password, brandWebsitePageObjects.txt_CongratsPagePassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_CongratsPageLoginbutton),
				brandWebsitePageObjects.btn_CongratsPageLoginbutton.getObjectname());

	}

	public void navigateToRevelVeloForgotPasswordPage() throws IOException 
	{
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.lnktxt_RevelVeloForgotPassword), brandWebsitePageObjects.lnktxt_RevelVeloForgotPassword.getObjectname());
	}
	
	public void navigateToVUSEForgotPasswordPage() throws IOException 
	{
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.loginLnk_VUSECertifyAgePage), brandWebsitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.lnk_VUSELoginForgotPassword), brandWebsitePageObjects.lnk_VUSELoginForgotPassword.getObjectname());
	}
	
}
