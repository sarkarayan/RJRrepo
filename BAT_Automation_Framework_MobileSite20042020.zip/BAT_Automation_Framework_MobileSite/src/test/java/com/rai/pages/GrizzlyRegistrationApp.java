package com.rai.pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.AppRegistrationPageObjects;


public class GrizzlyRegistrationApp extends BaseClass {

	String testcaseName;
	public GrizzlyRegistrationApp(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(AppRegistrationPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	public void validateErrormessageonStep1() throws InterruptedException, IOException
	{
		String Errormessage = "Please fix the errors above";
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_GrizzlyAPPRegister),AppRegistrationPageObjects.btn_GrizzlyAPPRegister.getObjectname());
		Thread.sleep(4000);
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_RegistrationStep1Next),AppRegistrationPageObjects.btn_RegistrationStep1Next.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(AppRegistrationPageObjects.erromsg_RegistrationStep1),AppRegistrationPageObjects.erromsg_RegistrationStep1.getObjectname(), Errormessage);
		
	}
	
	
	public void enterValidateDataStep1() throws InterruptedException, IOException
	{
		
		
		commonFunction.selectAnyElement(getPageElement(AppRegistrationPageObjects.drpdwn_RegistrationStep1BirthMonth),"", AppRegistrationPageObjects.drpdwn_RegistrationStep1BirthMonth.getObjectname());
		commonFunction.selectAnyElement(getPageElement(AppRegistrationPageObjects.drpdwn_RegistrationStep1BirthDay),"",AppRegistrationPageObjects.drpdwn_RegistrationStep1BirthDay.getObjectname());
		commonFunction.selectAnyElement(getPageElement(AppRegistrationPageObjects.drpdwn_RegistrationStep1BirthYear),"",AppRegistrationPageObjects.drpdwn_RegistrationStep1BirthYear.getObjectname());
		
		commonFunction.clearAndEnterText(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep1FirstName),"FirstName", AppRegistrationPageObjects.txt_RegistrationStep1FirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep1LastName), "LastName",AppRegistrationPageObjects.txt_RegistrationStep1LastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep1Address1), "Address",AppRegistrationPageObjects.txt_RegistrationStep1Address1.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep1Zipcode),"Zipcode",AppRegistrationPageObjects.txt_RegistrationStep1Zipcode.getObjectname());
		Thread.sleep(6000);
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep1Email), "Email", AppRegistrationPageObjects.txt_RegistrationStep1Email.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.chkbox_RegistrationStep1), AppRegistrationPageObjects.chkbox_RegistrationStep1.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_RegistrationStep1Next), AppRegistrationPageObjects.btn_RegistrationStep1Next.getObjectname());
		
	}
	
	
	public void enterValidateDataStep2() throws IOException
	{
		
		
		commonFunction.clearAndEnterText(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep2Password),"Password", AppRegistrationPageObjects.txt_RegistrationStep2Password.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep2NewPassword),"Password",AppRegistrationPageObjects.txt_RegistrationStep2NewPassword.getObjectname());
		
		commonFunction.selectAnyElement(getPageElement(AppRegistrationPageObjects.drpdwn_RegistrationStep2ChallengeQuestion),"Question",AppRegistrationPageObjects.drpdwn_RegistrationStep2ChallengeQuestion.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep2ChallengeAnswer),"Answer",AppRegistrationPageObjects.txt_RegistrationStep2ChallengeAnswer.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_RegistrationStep2Next),AppRegistrationPageObjects.btn_RegistrationStep2Next.getObjectname());
		
	}
	
	
	public void enterValidateAgebySSN() throws IOException
	{
		
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.radbtn_RegistrationStep3SSN),AppRegistrationPageObjects.radbtn_RegistrationStep3SSN.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep3SSN),"SSN",AppRegistrationPageObjects.txt_RegistrationStep3SSN.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_RegistrationStep3Submit),AppRegistrationPageObjects.btn_RegistrationStep3Submit.getObjectname());
		
	}
	
	
	public void navigateTutorial() throws InterruptedException, IOException
	{
		
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.lnk_CreatePINSkip),AppRegistrationPageObjects.lnk_CreatePINSkip.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_AppTutorialStep1TurnON),AppRegistrationPageObjects.btn_AppTutorialStep1TurnON.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_AppTutorialStep2Allow),AppRegistrationPageObjects.btn_AppTutorialStep2Allow.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_AppTutorialStep3GotIt),AppRegistrationPageObjects.btn_AppTutorialStep3GotIt.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_AppTutorialStep4GotIt),AppRegistrationPageObjects.btn_AppTutorialStep4GotIt.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_AppTutorialStep5GotIt),AppRegistrationPageObjects.btn_AppTutorialStep5GotIt.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_DeviceLocationAllow),AppRegistrationPageObjects.btn_DeviceLocationAllow.getObjectname());
		Thread.sleep(4000);
			
	}
	
	

}
