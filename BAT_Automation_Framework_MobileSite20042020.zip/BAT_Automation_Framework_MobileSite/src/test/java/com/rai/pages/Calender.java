package com.rai.pages;

public class Calender {
	
	public void DOB()
	{

	String dt = "01-23-2004";
	String dateParts[] = dt.split("-");
	String month  = dateParts[0];
	String day  = dateParts[1];
	String year = dateParts[2];
	
	System.out.println(month);
	System.out.println(day);
	System.out.println(year);
	}
}

