package com.rai.pages;

import java.util.Properties;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.pageObjects.*;
import com.rai.framework.GenericLib;

@Listeners(ExtentITestListenerClassAdapter.class)
public class Camel_ProductsPage extends BaseClass{

	GenericLib gl = new GenericLib(this.getClass().getSimpleName());
	Properties config = new Properties();
	SoftAssert softAssert=new SoftAssert();


	@BeforeMethod
	public void beforemethod(String TestCaseName,String TestCaseObjective,String TestEnvironmentUrl) {
		gl.start_report(TestCaseName, TestCaseObjective, TestEnvironmentUrl);
		//extent = ExtentManager.GetExtent();	
		//extent = ExtentManager.createTest(test, description)
	}



	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  To Verify all the images and contents of Classics product page 
	//Test Case name :Camel_Redesign_Products_012
	//Images
	//Scroll down/Up functionality
	//Pagination dots functionality 
	//Text of each product page
	//Additional Pack images (Platinum and 99) are added


	//Pre-Requisite:
	//User should be having a valid login credentials. 
	//Author : Priyanka P Date: 12.03.2019

	public void  Camel_Products_012(String UN,String pwd,String url, String browserName)throws Exception
	{
		// Launch Application
		gl.launchApplication(browserName, url);
		Thread.sleep(2000);

		//*********************************************************************************************************************      
		//Camel Login page is displayed.
		//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//*********************************************************************************************************************          
		//Enter valid email id 
		gl.inputText(Camel_LoginProp.txtUsername,"txtUsername", UN) ;
		//Enter valid password

		gl.inputText(Camel_LoginProp.txtPassword,"txtPassword", pwd) ;
		//Click login button
		gl.clickbutton(Camel_LoginProp.lnkLogin,"lnkLogin");
		Thread.sleep(5000);
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "Home Page");

		//click on Products
		gl.clickLink(Camel_Common.lnkProducts, "Products");
		Thread.sleep(2000);

		//verify product page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Products");

		//click on classics
		gl.clickLink(Camel_ProductPage_Classics.weClassics, "Classics");
		Thread.sleep(5000);
		//Verify classics product page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Products - Classics | Camel");
		//Verify the content of classics tile
		gl.VerifyObjectDisplayed(Camel_ProductPages.weTxtClassics);
		Thread.sleep(2000);

		//scroll down
		gl.fnScrollToView(Camel_ProductPage_Classics.weBluepack);

		//verify blue pack is displayed
		gl.VerifyObjectDisplayed(Camel_ProductPage_Classics.weBluepack);

		//scroll down
		gl.fnScrollToView(Camel_ProductPage_Classics.weFilterpack);

		//verify filter pack is displayed
		gl.VerifyObjectDisplayed(Camel_ProductPage_Classics.weFilterpack);

		//scroll down
		gl.fnScrollToView(Camel_ProductPage_Classics.weplatinumpack);

		//verify platinum pack is displayed
		gl.VerifyObjectDisplayed(Camel_ProductPage_Classics.weplatinumpack);

		//scroll down
		gl.fnScrollToView(Camel_ProductPage_Classics.we99pack);

		//verify 99 pack is displayed
		gl.VerifyObjectDisplayed(Camel_ProductPage_Classics.we99pack);

		//Hover on first dot
		gl.HowerPaginationDots(Camel_ProductPage_Classics.weFirstdot, "First dot");

		//verify classics text is displayed while hovering

		gl.VerifyElementPresent(Camel_ProductPage_Classics.weClassics1, "Classics");

		//Hover on second dot
		gl.HowerPaginationDots(Camel_ProductPage_Classics.weSeconddot, "Second dot");

		//verify blue text is displayed while hovering
		gl.VerifyElementPresent(Camel_ProductPage_Classics.weBlue1, "Blue");

		//Hover on third dot
		gl.HowerPaginationDots(Camel_ProductPage_Classics.weThirddot, "Third dot");

		//verify filter text is displayed while hovering
		gl.VerifyElementPresent(Camel_ProductPage_Classics.wefilter1, "Filter");

		//Hover on foutht dot
		gl.HowerPaginationDots(Camel_ProductPage_Classics.weFourthdot, "Fourth dot");

		//verify platinum text is displayed while hovering
		gl.VerifyElementPresent(Camel_ProductPage_Classics.wePlatinum1, "Platinum");

		//Hover on fivth dot
		gl.HowerPaginationDots(Camel_ProductPage_Classics.weFivthdot, "Fivth dot");

		//verify 99 is displayed while hovering
		gl.VerifyElementPresent(Camel_ProductPage_Classics.we99, "99");

		//Click on first dot
		gl.clickbutton(Camel_ProductPage_Classics.weFirstdot, "First dot");

		//verify classics tile
		gl.VerifyObjectDisplayed(Camel_ProductPage_Classics.weClassicspack);

		//click on second dot
		gl.clickbutton(Camel_ProductPage_Classics.weSeconddot, "Second dot");

		//verify blue tile
		gl.VerifyObjectDisplayed(Camel_ProductPage_Classics.weBluepack);

		//click on third dot
		gl.clickbutton(Camel_ProductPage_Classics.weThirddot, "Third dot");

		//verfiy filter tile
		gl.VerifyObjectDisplayed(Camel_ProductPage_Classics.weFilterpack);

		//click on fourth dot
		gl.clickbutton(Camel_ProductPage_Classics.weFourthdot, "Fourth dot");

		//verify platinum tile
		gl.VerifyObjectDisplayed(Camel_ProductPage_Classics.weplatinumpack);

		//click on fivth dot
		gl.clickbutton(Camel_ProductPage_Classics.weFivthdot, "Fifth dot");

		//verify 99 tile
		gl.VerifyObjectDisplayed(Camel_ProductPage_Classics.we99pack);

		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_LoginProp.txtUsername,"Camel Login");
	}
	public void  Camel_Snus_ParticularProductPage(String UN,String pwd,String url, String browserName, String SecondSection)throws Exception
	{
		// Launch Application
		gl.launchApplication(browserName, url);
		Thread.sleep(2000);

		//*********************************************************************************************************************      
		//Camel Login page is displayed.
		//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//*********************************************************************************************************************          
		//Enter valid email id 
		gl.inputText(Camel_LoginProp.txtUsername,"txtUsername", UN) ;
		//Enter valid password

		gl.inputPasswordEncrypted(Camel_LoginProp.txtPassword,"txtPassword", pwd) ;
		//Click login button
		gl.clickbutton(Camel_LoginProp.lnkLogin,"lnkLogin");
		Thread.sleep(5000);
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "Home Page");
	
		//hover the mouse on Products
		gl.HowerMouse(Camel_Common.lnkProducts,"Products link from main navigation");


		gl.VerifyElementVisible(Camel_Common.lnkSnus, "snus submenu link");


		gl.HowerMouse(Camel_Common.lnkProducts,"Products link from main navigation");

		//Click on Snus Sub menu
		gl.clickLink(Camel_Common.lnkSnus, "snus submenu link");
		Thread.sleep(2000);			

		//Verify Snus product page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Products - Snus | Camel");
		Thread.sleep(2000);

		//Click on Snus frost tin of the 6 tins displayed under snus section
		gl.ClickUsingRobo(211, 318);
		/*Robot r = new Robot();
		r.mouseMove(250, 550);
		r.mousePress( InputEvent.BUTTON1_MASK );
		r.mouseRelease( InputEvent.BUTTON1_MASK );*/

		//Verify the first section of the page
		gl.VerifyObjectDisplayed(Camel_ProductPages.weSnusFrost);
		gl.VerifyObjectDisplayed(Camel_ProductPages.lnkBacktoAll);
		gl.VerifyObjectDisplayed(Camel_ProductPages.lnkClicktoOpen);
		gl.VerifyObjectDisplayed(Camel_ProductPages.weRightArrow);

		//Click on Snus tin/click to open
		gl.clickUsingJs(Camel_ProductPages.lnkClicktoOpen, "Click to open");
		Thread.sleep(2000);

		/*//Verify that tin is opened .
		-Verify the text "Tap to close" is displayed*/
		gl.VerifyObjectDisplayed(Camel_ProductPages.lnkClickClose);
		Thread.sleep(2000);
		gl.ScrollDownUsingAction();
		Thread.sleep(2000);
		//r.keyPress(KeyEvent.VK_PAGE_DOWN);

		//Click on the right navigational arrow button
		gl.clickbutton(Camel_ProductPages.weRightArrow, "Right arrow");
		Thread.sleep(2000);
		//Verify the text "Camel Snus large robust" is displayed.
		gl.VerifyObjectDisplayed(Camel_ProductPages.weLargestrobost);
		//Click on Snus tin/click to open
		gl.clickUsingJs(Camel_ProductPages.lnkClicktoOpen, "Click to open");
		Thread.sleep(2000);

		/*//Verify that tin is opened .
				-Verify the text "Tap to close" is displayed*/
		gl.VerifyObjectDisplayed(Camel_ProductPages.lnkClickClose);
		Thread.sleep(20000);

		//Click on the right navigational arrow button
		gl.clickbutton(Camel_ProductPages.weRightArrow, "Right arrow");
		Thread.sleep(2000);

		//Verify the text "Camel Snus mellow" is displayed.
		gl.VerifyObjectDisplayed(Camel_ProductPages.weSnussMellow);

		//Click on Snus tin/click to open
		gl.clickUsingJs(Camel_ProductPages.lnkClicktoOpen, "Click to open");
		Thread.sleep(2000);

		/*//Verify that tin is opened .
						-Verify the text "Tap to close" is displayed*/
		gl.VerifyObjectDisplayed(Camel_ProductPages.lnkClickClose);
		Thread.sleep(2000);

		//Click on the right navigation arrow button
		gl.clickLink(Camel_ProductPages.weRightArrow, "Right arrow");
		Thread.sleep(2000);

		//Verify the text "Camel Snus large frost" is displayed.
		gl.VerifyObjectDisplayed(Camel_ProductPages.weSnusLargeFrost);

		//Click on Snus tin/click to open
		gl.clickUsingJs(Camel_ProductPages.lnkClicktoOpen, "Click to open");
		Thread.sleep(2000);

		/*//Verify that tin is opened .
								-Verify the text "Tap to close" is displayed*/
		gl.VerifyObjectDisplayed(Camel_ProductPages.lnkClickClose);
		Thread.sleep(20000);

		//Click on the right navigation arrow button
		gl.clickLink(Camel_ProductPages.weRightArrow, "Right arrow");
		Thread.sleep(2000);

		//Verify the text "Camel Snus mint" is displayed.
		gl.VerifyObjectDisplayed(Camel_ProductPages.weSnusMint);

		//Click on Snus tin/click to open
		gl.clickUsingJs(Camel_ProductPages.lnkClicktoOpen, "Click to open");
		Thread.sleep(2000);

		/*//Verify that tin is opened .
										-Verify the text "Tap to close" is displayed*/
		gl.VerifyObjectDisplayed(Camel_ProductPages.lnkClickClose);
		Thread.sleep(20000);

		//Click on the right navigation arrow button
		gl.clickLink(Camel_ProductPages.weRightArrow, "Right arrow");
		Thread.sleep(2000);

		//Verify the text "Camel snus large winterchill" is displayed.
		gl.VerifyObjectDisplayed(Camel_ProductPages.weSnusLargeWinterchill);
		//Click on Snus tin/click to open
		gl.clickUsingJs(Camel_ProductPages.lnkClicktoOpen, "Click to open");
		Thread.sleep(2000);

		/*//Verify that tin is opened .
		-Verify the text "Tap to close" is displayed*/
		gl.VerifyObjectDisplayed(Camel_ProductPages.lnkClickClose);
		Thread.sleep(20000);


		//Verify the left and Right arrow functionality

		//Click on the left navigation arrow button
		gl.clickLink(Camel_ProductPages.weLeftArrow, "Left arrow");
		Thread.sleep(2000);

		//Verify the text "Camel Snus mint" is displayed.
		gl.VerifyObjectDisplayed(Camel_ProductPages.weSnusMint);
		gl.ScrollDownUsingAction();


		//Verify the second section of the page
		gl.VerifyObjectDisplayed(Camel_ProductPages.weSecondSection);
		Thread.sleep(2000);

		//Verify the Text in section 2
		gl.fnContentValidation(SecondSection, Camel_ProductPages.weSecondSection);
		Thread.sleep(2000);
		gl.ScrollDownUsingAction();
		Thread.sleep(2000);

		//Verify the Offer tile of the page
		gl.VerifyObjectDisplayed(Camel_ProductPages.weExperiencemyFlavor);
		gl.VerifyObjectDisplayed(Camel_ProductPages.btnViewCoupon);

		//Click on "View Offer" button
		gl.clickUsingJs(Camel_ProductPages.btnViewCoupon, "View Offer");
		Thread.sleep(4000);

		//Verify that offers page is displayed
		gl.VerifyPageDisplayed(Camel_Offers.weOffersPage, "Offers");
		Thread.sleep(2000);

		//Click on browser back button
		gl.browserBack();
		Thread.sleep(2000);

		//Verify that snus product page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Products - Snus | Camel");
		Thread.sleep(2000);
		gl.ClickUsingRobo(211, 318);

		/*r.mouseMove(250, 550);
		r.mousePress( InputEvent.BUTTON1_MASK );
		r.mouseRelease( InputEvent.BUTTON1_MASK );*/

		/*//Scroll down to last section
		//Verify that disclaimer text is displayed 
		Verify that Snus warning label is displayed with "Snus" trigger message.*/

		gl.VerifyObjectDisplayed(Camel_ProductPages.weSnusWarning);

		//Verify that the footer links are displayed
		gl.VerifyObjectDisplayed(Camel_ProductPages.weFooter);
		Thread.sleep(2000);

		//Click on "Back to all" button
		gl.clickLink(Camel_ProductPages.lnkBacktoAll, "Back to All");
		Thread.sleep(2000);

		//Verify that snus product page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Products - Snus | Camel");
		Thread.sleep(2000);


		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_LoginProp.txtUsername,"Camel Login");



	}

	//********************************************************************************************************************************************************



	public void afterMethod() {
		driver.quit();
		gl.endReport();
		//extent.flush();
	}

}
