package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.brandWebsitePageObjects;

public class BrandWebsite_VUSE_MyProfileValidations extends BaseClass {

	String testcaseName;

	public BrandWebsite_VUSE_MyProfileValidations(String testcaseName) {
		this.testcaseName = testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper The {@link ScriptHelper} object passed from the
	 *                     {@link DriverScript}
	 */

	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	private WebElement getPageElement(brandWebsitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}

	public void invokeApplication_brandwebsite() {
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	}

	public void loginPage_VUSELogin() throws InterruptedException, IOException {

		String Username = dataTable.getData("General_Data", "Username");
		String Password = dataTable.getData("General_Data", "Password");

		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.loginLnk_VUSECertifyAgePage),brandWebsitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginUsername), Username,brandWebsitePageObjects.txt_VUSELoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginPassword), Password,brandWebsitePageObjects.txt_VUSELoginPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_VUSELogin),brandWebsitePageObjects.btn_VUSELogin.getObjectname());
		//Thread.sleep(5000);
	}

	
	public void vuseProfile_NavigatetoMyProfile() throws IOException
	{
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSE_MyAccount),brandWebsitePageObjects.PostLoginVUSE_MyAccount.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSE_MyAccountlink),brandWebsitePageObjects.PostLoginVUSE_MyAccountlink.getObjectname());
	}	
	
	public void vuseProfile_navigatetoBillingAddress() throws IOException
	{
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSE_AddressBook),brandWebsitePageObjects.PostLoginVUSE_AddressBook.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btnEdit_ProfileVUSE_BillingAddress),brandWebsitePageObjects.btnEdit_ProfileVUSE_BillingAddress.getObjectname());
		
	}
	
	public void vuseProfile_BillingAddress_negativevalidations() throws IOException
	{
		
		
		commonFunction.clearText(getPageElement(brandWebsitePageObjects.txt_VUSEProfile_BillingAddress_Telephone), brandWebsitePageObjects.txt_VUSEProfile_BillingAddress_Telephone.getObjectname());
		commonFunction.clearText(getPageElement(brandWebsitePageObjects.txt_VUSEProfile_BillingAddress_Address), brandWebsitePageObjects.txt_VUSEProfile_BillingAddress_Address.getObjectname());
		commonFunction.clearText(getPageElement(brandWebsitePageObjects.txt_VUSEProfile_BillingAddress_Zipcode), brandWebsitePageObjects.txt_VUSEProfile_BillingAddress_Zipcode.getObjectname());
		commonFunction.clearText(getPageElement(brandWebsitePageObjects.btn_VUSEProfile_BillingAddress_Save), brandWebsitePageObjects.btn_VUSEProfile_BillingAddress_Save.getObjectname());
		
		String ExpectedErrormsg = "This is a required field.";
			
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_VUSE_BillingAddress_NoTelephone), brandWebsitePageObjects.errormsg_VUSE_BillingAddress_NoTelephone.getObjectname(), ExpectedErrormsg);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_VUSE_BillingAddress_NoAddress1), brandWebsitePageObjects.errormsg_VUSE_BillingAddress_NoAddress1.getObjectname(), ExpectedErrormsg);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_VUSE_BillingAddress_NoZipcode), brandWebsitePageObjects.errormsg_VUSE_BillingAddress_NoZipcode.getObjectname(), ExpectedErrormsg);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_VUSE_BillingAddress_NoCity), brandWebsitePageObjects.errormsg_VUSE_BillingAddress_NoCity.getObjectname(), ExpectedErrormsg);
		
	}
	
	
	public void vuseProfile_BillingAddress_UpdateUserData() throws IOException, InterruptedException
	{
		
		String Phone = dataTable.getData("General_Data", "Telephone");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSEProfile_BillingAddress_Telephone),Phone, brandWebsitePageObjects.txt_VUSEProfile_BillingAddress_Telephone.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSEProfile_BillingAddress_Address),Address, brandWebsitePageObjects.txt_VUSEProfile_BillingAddress_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSEProfile_BillingAddress_Zipcode),Zipcode, brandWebsitePageObjects.txt_VUSEProfile_BillingAddress_Zipcode.getObjectname());
		Thread.sleep(4000);
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_VUSEProfile_BillingAddress_Save),brandWebsitePageObjects.btn_VUSEProfile_BillingAddress_Save.getObjectname());
		
	}
	
	
	public void vuse_Logout() throws IOException
	{
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSE_MyAccount),brandWebsitePageObjects.PostLoginVUSE_MyAccount.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSE_LogOut),brandWebsitePageObjects.PostLoginVUSE_LogOut.getObjectname());
		
	}

}
