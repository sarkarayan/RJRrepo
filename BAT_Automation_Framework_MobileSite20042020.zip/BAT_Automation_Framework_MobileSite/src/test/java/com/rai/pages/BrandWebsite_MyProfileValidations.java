package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.brandWebsitePageObjects;

public class BrandWebsite_MyProfileValidations extends BaseClass {

	String testcaseName;

	public BrandWebsite_MyProfileValidations(String testcaseName) {
		this.testcaseName = testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper The {@link ScriptHelper} object passed from the
	 *                     {@link DriverScript}
	 */

	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	private WebElement getPageElement(brandWebsitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}

	public void invokeApplication_brandwebsite() {
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	}

	public void loginPage_AppToWebsiteLogin() throws InterruptedException, IOException {

		String Username = dataTable.getData("General_Data", "Username");
		String Password = dataTable.getData("General_Data", "Password");

		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginUsername), Username,brandWebsitePageObjects.txt_LoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginPassword), Password,brandWebsitePageObjects.txt_LoginPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login),brandWebsitePageObjects.btn_Login.getObjectname());
		//Thread.sleep(5000);
	}

	public void camelProfile_NavigatetoMyProfile() throws Exception {
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.lnk_CamelMyAccount),brandWebsitePageObjects.lnk_CamelMyAccount.getObjectname());
		//Thread.sleep(5000);
	}
	
	public void grizzlyProfile_NavigatetoMyProfile() throws Exception {
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.lnk_GrizzlyMyAccount),brandWebsitePageObjects.lnk_GrizzlyMyAccount.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_GrizzlyUpdateInfo),brandWebsitePageObjects.btn_GrizzlyUpdateInfo.getObjectname());
		//Thread.sleep(5000);
	}
	
	public void newportProfile_NavigatetoMyProfile() throws Exception {
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.lnk_NewportMyAccount),brandWebsitePageObjects.lnk_NewportMyAccount.getObjectname());
		//Thread.sleep(5000);
	}
	
	public void nascigsProfile_NavigatetoMyProfile() throws Exception {
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.lnk_NASCIGSProfile),brandWebsitePageObjects.lnk_NASCIGSProfile.getObjectname());
		//Thread.sleep(5000);
	}

	public void pallmallProfile_NavigatetoMyProfile() throws Exception {
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.lnk_PallmallProfile),brandWebsitePageObjects.lnk_PallmallProfile.getObjectname());
		//Thread.sleep(5000);
	}
	
	public void profileUpdate_UserInfoValidations() throws IOException {

		String ProfileAddress = dataTable.getData("General_Data", "Address");
		String ProfileCity = dataTable.getData("General_Data", "City");
		String ProfileZipcode = dataTable.getData("General_Data", "Zipcode");

		// MyProfile - Address field validation
		commonFunction.clearText(getPageElement(brandWebsitePageObjects.txt_ProfileAddressLine1),brandWebsitePageObjects.txt_ProfileAddressLine1.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ProfileUpdateInfo),brandWebsitePageObjects.btn_ProfileUpdateInfo.getObjectname());
		//String ActualErrormsg_ProfileNoAddress = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ProfileNoAddress));
		String ExpectedErrormsg_ProfileNoAddress = "The Address Line 1 field is required.";
		if (commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_ProfileNoAddress), brandWebsitePageObjects.errormsg_ProfileNoAddress.getObjectname(), ExpectedErrormsg_ProfileNoAddress)) {
			System.out.println("MyProfile - Expected errormsg displayed if user try to Update without AddressLine");
		} else {
			System.out.println("MyProfile - Expected errormsg was not displayed if user try to Update without AddressLine");
		}

		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ProfileAddressLine1),ProfileAddress, brandWebsitePageObjects.txt_ProfileAddressLine1.getObjectname());

		// MyProfile - City field validation
		commonFunction.clearText(getPageElement(brandWebsitePageObjects.txt_ProfileCity),brandWebsitePageObjects.txt_ProfileCity.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ProfileUpdateInfo),brandWebsitePageObjects.btn_ProfileUpdateInfo.getObjectname());
		String ActualErrormsg_ProfileNoCity = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ProfileNoCity));
		String ExpectedErrormsg_ProfileNoCity = "The City field is required.";
		if (ActualErrormsg_ProfileNoCity.contains(ExpectedErrormsg_ProfileNoCity)) {
			System.out.println("MyProfile - Expected errormsg displayed if user try to Update without CityInfo");
		} else {
			System.out.println("MyProfile - Expected errormsg was not displayed if user try to Update without CityInfo");
		}

		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ProfileCity), ProfileCity,brandWebsitePageObjects.txt_ProfileCity.getObjectname());

		// MyProfile - Zipcode field validation
		commonFunction.clearText(getPageElement(brandWebsitePageObjects.txt_ProfileZipcode),brandWebsitePageObjects.txt_ProfileZipcode.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ProfileUpdateInfo),brandWebsitePageObjects.btn_ProfileUpdateInfo.getObjectname());
		//String ActualErrormsg_ProfileNoZipcode = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ProfileNoZipcode));
		String ExpectedErrormsg_ProfileNoZipcode = "The Zip Code field is required.";
		if (commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_ProfileNoZipcode), brandWebsitePageObjects.errormsg_ProfileNoZipcode.getObjectname(), ExpectedErrormsg_ProfileNoZipcode)) {
			System.out.println("MyProfile - Expected errormsg displayed if user try to Update without ZipcodeInfo");
		} else {
			System.out.println("MyProfile - Expected errormsg was not displayed if user try to Update without CityInfo");
		}

		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ProfileZipcode),ProfileZipcode, brandWebsitePageObjects.txt_ProfileZipcode.getObjectname());

	}

	public void profileUpdate_NegativeValidationsUpdateEmail() throws IOException {
		String InvalidEmail = dataTable.getData("General_Data", "InvalidUserIDformat");
		String NonExistingEmail = dataTable.getData("General_Data", "NonExistUserId");
		String ExistingEmail = dataTable.getData("General_Data", "ExistingUserId");

		// MyProfile - User entered InvalidEmail
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ProfileNewEmail),InvalidEmail, brandWebsitePageObjects.txt_ProfileNewEmail.getObjectname());
		driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		//String Actualerrormsg_ProfileInvalidEmail = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ProfileInValidEmail));
		String Expectederrormsg_ProfileInvalidEmail = "Please enter a valid email address";
		if (commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_ProfileInValidEmail), brandWebsitePageObjects.errormsg_ProfileInValidEmail.getObjectname(), Expectederrormsg_ProfileInvalidEmail)) {
			System.out.println("MyProfile - Expected errormsg displayed when user entered InvalidEmail");
		} else {
			System.out.println("MyProfile - Expected errormsg not displayed when user entered InvalidEmail");
		}

		// MyProfile - User entered NonExistingEmail
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ProfileNewEmail),NonExistingEmail, brandWebsitePageObjects.txt_ProfileNewEmail.getObjectname());
		//String Actualerrormsg_ProfileNonExistingEmail = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ProfileInactiveEmail));
		String Expectederrormsg_ProfileNonExistingEmail = "This is not an active email address. Please provide an active email address.";
		if (commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_ProfileInactiveEmail), brandWebsitePageObjects.errormsg_ProfileInactiveEmail.getObjectname(), Expectederrormsg_ProfileNonExistingEmail)) {
			System.out.println("MyProfile - Expected errormsg displayed when user entered Inactive/NonExisting email");
		} else {
			System.out.println("MyProfile - Expected errormsg not displayed when user entered Inactive/NonExisting email");
		}

		// MyProfile - User entered already ExistingEmail
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ProfileNewEmail),ExistingEmail, brandWebsitePageObjects.txt_ProfileNewEmail.getObjectname());
		//String Actualerrormsg_ProfileExistingEmail = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ProfileEnteredExistingEmail));
		String Expectederrormsg_ProfileExistingEmail = "User Name already taken. Please try a different one.";
		if (commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_ProfileEnteredExistingEmail), brandWebsitePageObjects.errormsg_ProfileEnteredExistingEmail.getObjectname(), Expectederrormsg_ProfileExistingEmail)) {
			System.out.println("MyProfile - Expected errormsg displayed when user entered already Existing email");
		} else 
		{
			System.out.println("MyProfile - Expected errormsg not displayed when user entered already Existing email");
		}
	}

	public void profileUpdate_NegativeValidationsUpdatePassword() throws InterruptedException, IOException {
		
		String CurrentPassword = dataTable.getData("General_Data", "Password");
		String InvalidPasswordformat = dataTable.getData("General_Data", "InvalidPasswordformat");
		String NewPassword = dataTable.getData("General_Data", "Password");
		String DifferentPassword = dataTable.getData("General_Data", "InvalidPassword");
		
		String Errormsg_InvalidPasswordformat = "Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.";
		String Errormsg_DifferentPassword = "The New Password and Confirm New Password fields do not match.";

		// MyProfile - User not entered CurrentPassword
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ProfileUpdatePassword),brandWebsitePageObjects.btn_ProfileUpdatePassword.getObjectname());
		//String Actualerrormsg_CurrentPasswordnotEntered = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ProfileNoCurrentPassword));
		String Expectederrormsg_CurrentPasswordnotEntered = "The Current Password field is required.";
		if (commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_ProfileNoCurrentPassword), brandWebsitePageObjects.errormsg_ProfileNoCurrentPassword.getObjectname(), Expectederrormsg_CurrentPasswordnotEntered)) {
			System.out.println("MyProfile - Expected errormsg displayed when user clicked on Update without CurrentPassword");
		} else 
		{
			System.out.println("MyProfile - Expected errormsg not displayed when user clicked on Update without CurrentPassword");
		}
		
		//MyProfile - User entered Invalid Password format in NewPassword field
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ProfileCurrentPassword),CurrentPassword, brandWebsitePageObjects.txt_ProfileCurrentPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ProfileNewPassword),InvalidPasswordformat, brandWebsitePageObjects.txt_ProfileNewPassword.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_ProfileInvalidPasswordformatinNewPassword), brandWebsitePageObjects.errormsg_ProfileInvalidPasswordformatinNewPassword.getObjectname(), Errormsg_InvalidPasswordformat);
		
		//MyProfile - User entered different data in NewPassword & ConfirmNewPassword fields
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ProfileCurrentPassword),CurrentPassword, brandWebsitePageObjects.txt_ProfileCurrentPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ProfileNewPassword),NewPassword, brandWebsitePageObjects.txt_ProfileNewPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ProfileConfirmNewPassword),DifferentPassword, brandWebsitePageObjects.txt_ProfileConfirmNewPassword.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_ProfileDifferentPassword), brandWebsitePageObjects.errormsg_ProfileDifferentPassword.getObjectname(), Errormsg_DifferentPassword);
		

	}
	
	public void veloHomePage_Logout() throws IOException
	{
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVelo_AccountMenu),brandWebsitePageObjects.PostLoginVelo_AccountMenu.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVelo_LogOut),brandWebsitePageObjects.PostLoginVelo_LogOut.getObjectname());
		
	}

	public void profileUpdate_UpdatePassword() throws IOException {
		String CurrentPassword = dataTable.getData("General_Data", "Password");
		String NewPassword = dataTable.getData("General_Data", "Password");
		String ConfirmNewPassword = dataTable.getData("General_Data", "Password");

		// MyProfile - User updated NewPassword
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ProfileCurrentPassword),CurrentPassword, brandWebsitePageObjects.txt_ProfileCurrentPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ProfileNewPassword),NewPassword, brandWebsitePageObjects.txt_ProfileNewPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ProfileConfirmNewPassword),ConfirmNewPassword, brandWebsitePageObjects.txt_ProfileConfirmNewPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ProfileUpdatePassword),brandWebsitePageObjects.btn_ProfileUpdatePassword.getObjectname());
		WebDriverWait wait = new WebDriverWait(driver, 5);
		wait.until(ExpectedConditions.alertIsPresent());
		driver.switchTo().alert().accept();
	}
	public void veloProfile_NavigatetoMyProfile() throws IOException
	{
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVelo_AccountMenu),brandWebsitePageObjects.PostLoginVelo_AccountMenu.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVelo_Profile),brandWebsitePageObjects.PostLoginVelo_Profile.getObjectname());
		
	}

	public void profileUpdate_NegativevalidationsUpdateChallegeAnswer() throws IOException {

		// User clicked on Update without ChallengeAnswer
		try {
			commonFunction.scrolldownToEndOfWebPage();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ProfileUpdateChallengeQuestion),brandWebsitePageObjects.btn_ProfileUpdateChallengeQuestion.getObjectname());
		//String Actualerrormsg_NoChallengeAnswerProfile = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ProfileNoChallengeAnswer));
		String Expectederrormsg_NoChallengeAnswerProfile = "The Challenge Answer field is required.";
		if (commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_ProfileNoChallengeAnswer), brandWebsitePageObjects.errormsg_ProfileNoChallengeAnswer.getObjectname(), Expectederrormsg_NoChallengeAnswerProfile)) {
			System.out.println("MyProfile - Expected errormsg displayed when ChallengeAnswer not entered");
		} else {
			System.out.println("MyProfile - Expected errormsg not displayed when ChallengeAnswer not entered");
		}
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ProfileBacktoSite),brandWebsitePageObjects.btn_ProfileBacktoSite.getObjectname());
	}

	public void profileUpdate_UpdateChallegeAnswer() throws IOException {
		String ValidChallengeAnswer = dataTable.getData("General_Data", "ChallengeAnswer");

		// User updated the ChallengeAnswer
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ProfileChallengeAnswer),ValidChallengeAnswer, brandWebsitePageObjects.txt_ProfileChallengeAnswer.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ProfileUpdateChallengeQuestion),brandWebsitePageObjects.btn_ProfileUpdateChallengeQuestion.getObjectname());
		WebDriverWait wait = new WebDriverWait(driver, 5);
		wait.until(ExpectedConditions.alertIsPresent());
		driver.switchTo().alert().accept();
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ProfileBacktoSite),brandWebsitePageObjects.btn_ProfileBacktoSite.getObjectname());

	}

	public void profileUpdate_NegativevalidationsTobaccoPreferences() throws InterruptedException, IOException {
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ProfileTobaccoPreferences),brandWebsitePageObjects.btn_ProfileTobaccoPreferences.getObjectname());

		// User clicked on Update without selecting TobaccoPreferences
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_TobaccoPreferencesUpdate),brandWebsitePageObjects.btn_TobaccoPreferencesUpdate.getObjectname());
		//String Actualerrormsg_NoTobaccoReferences = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ProfileNoTobaccoPreferencesUpdate));
		String Expectederrormsg_NoTobaccoReferences = "Answering the question above is required to continue";
		if (commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_ProfileNoTobaccoPreferencesUpdate), brandWebsitePageObjects.errormsg_ProfileNoTobaccoPreferencesUpdate.getObjectname(), Expectederrormsg_NoTobaccoReferences)) {
			System.out.println("MyProfile - Expected errormsg displayed when user try to Update without any TobaccoReferences");
		} else {
			System.out.println("MyProfile - Expected errormsg not displayed when user try to Update without any TobaccoReferences");
		}
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ProfileUserInfo),brandWebsitePageObjects.btn_ProfileUserInfo.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ProfileBacktoSite),brandWebsitePageObjects.btn_ProfileBacktoSite.getObjectname());

	}

	public void profileUpdate_TobaccoPreferencesUpdate() throws IOException, InterruptedException {
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ProfileTobaccoPreferences),brandWebsitePageObjects.btn_ProfileTobaccoPreferences.getObjectname());

		// User selected type of TobaccoProduct (Dissolvable Tobacco)
		if(!(getPageElement(brandWebsitePageObjects.chckbox_TobaccoPreferencesDissolvableTobacco)).isSelected()){
			commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.chckbox_TobaccoPreferencesDissolvableTobacco),brandWebsitePageObjects.chckbox_TobaccoPreferencesDissolvableTobacco.getObjectname());
		}
		
		//Thread.sleep(2000);

		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_TobaccoPreferencesDissolvable1),"STONEWALL",brandWebsitePageObjects.drpdwn_TobaccoPreferencesDissolvable1.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_TobaccoPreferencesDissolvable2),"10001|DISSOLVABLE|1000011|10131",brandWebsitePageObjects.drpdwn_TobaccoPreferencesDissolvable2.getObjectname());
		if(!(getPageElement(brandWebsitePageObjects.chckbox_TobaccoPreferencesDissolvable3)).isSelected()){
			commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.chckbox_TobaccoPreferencesDissolvable3),brandWebsitePageObjects.chckbox_TobaccoPreferencesDissolvable3.getObjectname());
		}
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_TobaccoPreferencesUpdate),brandWebsitePageObjects.btn_TobaccoPreferencesUpdate.getObjectname());
		WebDriverWait wait = new WebDriverWait(driver, 5);
		wait.until(ExpectedConditions.alertIsPresent());
		driver.switchTo().alert().accept();
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ProfileUserInfo),brandWebsitePageObjects.btn_ProfileUserInfo.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ProfileBacktoSite),brandWebsitePageObjects.btn_ProfileBacktoSite.getObjectname());

	}

	public void Camel_logout() throws Exception {
		
			commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginCamelfooterlnk_Logout),brandWebsitePageObjects.PostLoginCamelfooterlnk_Logout.getObjectname());

	}
	
	public void americanSpiritHomePage_Logout() throws IOException 
	{
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginNASfooterlnk_LogOut), brandWebsitePageObjects.PostLoginNASfooterlnk_LogOut.getObjectname());
	
	}
	
	public void grizzlyHomePage_Logout() throws IOException
	{
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLogin_Menu), brandWebsitePageObjects.PostLogin_Menu.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLogin_Menu_Logout), brandWebsitePageObjects.PostLogin_Menu_Logout.getObjectname());
		
	}
	
	public void newportHomePage_Logout() throws IOException
	{
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginNewportfooterlnk_Logout), brandWebsitePageObjects.PostLoginNewportfooterlnk_Logout.getObjectname());
		
	}
	
	public void vuseHomePage_Logout() throws IOException
	{
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSE_MyAccount), brandWebsitePageObjects.PostLoginVUSE_MyAccount.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSE_LogOut), brandWebsitePageObjects.PostLoginVUSE_LogOut.getObjectname());
		
	}
	
	public void pallmallHomePage_Logout() throws IOException
	{
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginPallmallfooterlnk_Logout), brandWebsitePageObjects.PostLoginPallmallfooterlnk_Logout.getObjectname());
		
	}

}
