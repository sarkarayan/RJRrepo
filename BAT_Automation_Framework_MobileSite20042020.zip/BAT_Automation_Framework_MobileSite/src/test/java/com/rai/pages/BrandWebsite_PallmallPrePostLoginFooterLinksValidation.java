package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.brandWebsitePageObjects;

public class BrandWebsite_PallmallPrePostLoginFooterLinksValidation extends BaseClass {

	String testcaseName;
	public BrandWebsite_PallmallPrePostLoginFooterLinksValidation(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(brandWebsitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("FooterLinks Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	public void invokeApplication_brandwebsite()
	{
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
	
	public void loginPage_PallmallPreLoginFooterLinksValidation() throws Exception
	{ 
		//PreLogin - FAQs footerlink
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_FAQs));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_FAQs),brandWebsitePageObjects.PreLoginfooterlnk_FAQs.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualFAQsTitle = driver.getTitle();
		String ExpectedFAQsTitle = "Frequently Asked Questions";
		if(ActualFAQsTitle.contains(ExpectedFAQsTitle))
		{
			System.out.println("PreLogin - FAQs footerlink page displayed");
		}
		else
		{
			System.out.println("PreLogin - FAQs footerlink page was not displayed");
		}
		Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login),brandWebsitePageObjects.btn_Login.getObjectname());
	
		//PreLogin - ContactUs
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_ContactUs));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_ContactUs),brandWebsitePageObjects.PreLoginfooterlnk_ContactUs.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualContactUsTitle = driver.getTitle();
		String ExpectedContactUsTitle = "Contact Us";
		if(ActualContactUsTitle.contains(ExpectedContactUsTitle))
		{
			System.out.println("PreLogin - ContactUs footerlink page displayed");
		}
		else
		{
			System.out.println("PreLogin - ContactUs footerlink page was not displayed");
		}
		Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login),brandWebsitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - TobaccoRights
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TobaccoRights));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TobaccoRights),brandWebsitePageObjects.PreLoginfooterlnk_TobaccoRights.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualTobaccoRightsTitle = driver.getTitle();
		String ExpectedTobaccoRightsTitle = "Own It Voice It";
		if(ActualTobaccoRightsTitle.contains(ExpectedTobaccoRightsTitle))
		{
			System.out.println("PreLogin - TobaccoRights footerlink page displayed");
		}
		else
		{
			System.out.println("PreLogin - TobaccoRights footerlink page was not displayed");
		}
		Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login),brandWebsitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - SiteRequirements
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_SiteRequrmnts));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_SiteRequrmnts),brandWebsitePageObjects.PreLoginfooterlnk_SiteRequrmnts.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualSiteRequrmntsTitle = driver.getTitle();
		String ExpectedSiteRequrmntsTitle = "Site Requirements";
		if(ActualSiteRequrmntsTitle.contains(ExpectedSiteRequrmntsTitle))
		{
			System.out.println("PreLogin - SiteRequirements footerlink page displayed");
		}
		else
		{
			System.out.println("PreLogin - SiteRequirements footerlink page was not displayed");
		}
		Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login),brandWebsitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - AgeFiltering
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_AgeFiltering));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_AgeFiltering),brandWebsitePageObjects.PreLoginfooterlnk_AgeFiltering.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualAgeFilteringTitle = driver.getTitle();
		String ExpectedAgeFilteringTitle = "Age Filtering Software:";
		if(ActualAgeFilteringTitle.contains(ExpectedAgeFilteringTitle))
		{
			System.out.println("PreLogin - AgeFiltering footerlink page displayed");
		}
		else
		{
			System.out.println("PreLogin - AgeFiltering footerlink page was not displayed");
		}
		Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login),brandWebsitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - TermsOfUse
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse),brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualTermsofUseTitle = driver.getTitle();
		String ExpectedTermsofUseTitle = "Terms of use";
		if(ActualTermsofUseTitle.contains(ExpectedTermsofUseTitle))
		{
			System.out.println("PreLogin - TermsofUse footerlink page displayed");
		}
		else
		{
			System.out.println("PreLogin - TermsofUse footerlink page was not displayed");
		}
		Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login),brandWebsitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - PrivacyPolicy
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_PrivacyPolicy));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_PrivacyPolicy),brandWebsitePageObjects.PreLoginfooterlnk_PrivacyPolicy.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPrivacyPolicyTitle = driver.getTitle();
		String ExpectedPrivacyPolicyTitle = "Privacy Policy and Your California Privacy Rights";
		if(ActualPrivacyPolicyTitle.contains(ExpectedPrivacyPolicyTitle))
		{
			System.out.println("PreLogin - PrivacyPolicy footerlink page displayed");
		}
		else
		{
			System.out.println("PreLogin - PrivacyPolicy footerlink page was not displayed");
		}
		Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login),brandWebsitePageObjects.btn_Login.getObjectname());
	}
	
	
	public void loginPage_AppToWebsiteLogin() throws InterruptedException, IOException
	{
		
		String Username = dataTable.getData("General_Data", "Username");
		String Password = dataTable.getData("General_Data", "Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginUsername),Username,brandWebsitePageObjects.txt_LoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginPassword),Password, brandWebsitePageObjects.txt_LoginPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login), brandWebsitePageObjects.btn_Login.getObjectname());
		Thread.sleep(5000);
	}
	
	
	public void homePage_PallmallPostLoginFooterLinksValidation() throws Exception
	{
		
		//PostLogin - FAQs footerlink
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginPallmallfooterlnk_FAQs));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginPallmallfooterlnk_FAQs),brandWebsitePageObjects.PostLoginPallmallfooterlnk_FAQs.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginFAQsTitle = driver.getTitle();
		String ExpectedPostLoginFAQsTitle = "Frequently Asked Questions";
		if(ActualPostLoginFAQsTitle.contains(ExpectedPostLoginFAQsTitle))
		{
			System.out.println("PostLogin - FAQs footerlink page displayed");
		}
		else
		{
		    System.out.println("PostLogin - FAQs footerlink page was not displayed");
		}
		Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
	
		
		//PostLogin - ContactUs footer link
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginPallmallfooterlnk_ContactUs));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginPallmallfooterlnk_ContactUs),brandWebsitePageObjects.PostLoginPallmallfooterlnk_ContactUs.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginContactUsTitle = driver.getTitle();
		String ExpectedPostLoginContactUsTitle = "Contact us";
		if(ActualPostLoginContactUsTitle.contains(ExpectedPostLoginContactUsTitle))
		{
		     System.out.println("PostLogin - ContactUs footerlink page displayed");
		}
		else
		{
			System.out.println("PostLogin - ContactUs footerlink page was not displayed");
		}
		Thread.sleep(5000);
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.PostLoginfooterlnk_ContactUsQuestion),2 ,brandWebsitePageObjects.PostLoginfooterlnk_ContactUsQuestion.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.PostLoginfooterlnk_ContactUsAnswer),"Validate",brandWebsitePageObjects.PostLoginfooterlnk_ContactUsAnswer.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginfooterlnk_ContactUsSubmit),brandWebsitePageObjects.PostLoginfooterlnk_ContactUsSubmit.getObjectname());
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		
		
		//PostLogin - TobaccoRights
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginPallmallfooterlnk_TobaccoRights));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginPallmallfooterlnk_TobaccoRights),brandWebsitePageObjects.PostLoginPallmallfooterlnk_TobaccoRights.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginTobaccoRightsTitle = driver.getTitle();
		String ExpectedPostLoginTobaccoRightsTitle = "Own It Voice It";
		if(ActualPostLoginTobaccoRightsTitle.contains(ExpectedPostLoginTobaccoRightsTitle))
		{
			System.out.println("PostLogin - TobaccoRights footerlink page displayed");
		}
		else
		{
		    System.out.println("PostLogin - TobaccoRights footerlink page was not displayed");
		}
		Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		
		
		//PostLogin - SiteRequirements
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginPallmallfooterlnk_SiteRequirements));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginPallmallfooterlnk_SiteRequirements),brandWebsitePageObjects.PostLoginPallmallfooterlnk_SiteRequirements.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginSiteRequirementsTitle = driver.getTitle();
		String ExpectedPostLoginSiteRequirementsTitle = "Site Requirements";
		if(ActualPostLoginSiteRequirementsTitle.contains(ExpectedPostLoginSiteRequirementsTitle))
		{
			System.out.println("PostLogin - SiteRequirements footerlink page displayed");
		}
		else
		{
		    System.out.println("PostLogin - SiteRequirements footerlink page was not displayed");
		}
		Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		
		//PostLogin - AgeFiltering
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginPallmallfooterlnk_AgeFiltering));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginPallmallfooterlnk_AgeFiltering),brandWebsitePageObjects.PostLoginPallmallfooterlnk_AgeFiltering.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginAgeFilteringTitle = driver.getTitle();
		String ExpectedPostLoginAgeFilteringTitle = "Age Filtering Software:";
		if(ActualPostLoginAgeFilteringTitle.contains(ExpectedPostLoginAgeFilteringTitle))
		{
			System.out.println("PostLogin - AgeFiltering footerlink page displayed");
		}
		else
		{
		    System.out.println("PostLogin - AgeFiltering footerlink page was not displayed");
		}
		Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		
		//PostLogin - TermsOfUse
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginPallmallfooterlnk_TermsOfUse));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginPallmallfooterlnk_TermsOfUse),brandWebsitePageObjects.PostLoginPallmallfooterlnk_TermsOfUse.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginTermsOfUseTitle = driver.getTitle();
		String ExpectedPostLoginTermsOfUseTitle = "Terms of use";
		if(ActualPostLoginTermsOfUseTitle.contains(ExpectedPostLoginTermsOfUseTitle))
		{
			System.out.println("PostLogin - TermsOfUse footerlink page displayed");
		}
		else
		{
		    System.out.println("PostLogin - TermsOfUse footerlink page was not displayed");
		}
		Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		
		//PostLogin - PrivacyPolicy
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginPallmallfooterlnk_PrivacyPolicy));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginPallmallfooterlnk_PrivacyPolicy),brandWebsitePageObjects.PostLoginPallmallfooterlnk_PrivacyPolicy.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginPrivacyPolicyTitle = driver.getTitle();
		String ExpectedPostLoginPrivacyPolicyTitle = "Privacy Policy";
		if(ActualPostLoginPrivacyPolicyTitle.contains(ExpectedPostLoginPrivacyPolicyTitle))
		{
			System.out.println("PostLogin - PrivacyPolicy footerlink page displayed");
		}
		else
		{
		    System.out.println("PostLogin - PrivacyPolicy footerlink page was not displayed");
		}
		Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		
	}
	
	public void pallmallHomePage_Logout() throws IOException
	{
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginPallmallfooterlnk_Logout), brandWebsitePageObjects.PostLoginPallmallfooterlnk_Logout.getObjectname());
		
	}
		
	
}
