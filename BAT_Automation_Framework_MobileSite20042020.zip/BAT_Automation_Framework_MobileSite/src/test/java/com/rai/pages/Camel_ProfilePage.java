package com.rai.pages;

import java.util.Properties;


import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;


import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.pageObjects.*;
import com.rai.framework.GenericLib;

@Listeners(ExtentITestListenerClassAdapter.class)
public class Camel_ProfilePage extends BaseClass {
	GenericLib gl = new GenericLib(this.getClass().getSimpleName());
	Properties config = new Properties();
	SoftAssert softAssert=new SoftAssert();
	// AS_HomePage homePage=new AS_HomePage();

	@BeforeMethod
	public void beforemethod(String TestCaseName,String TestCaseObjective,String TestEnvironmentUrl) {
		gl.start_report(TestCaseName, TestCaseObjective, TestEnvironmentUrl);
		//extent = ExtentManager.GetExtent();	
		//extent = ExtentManager.createTest(test, description
	}

	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Camel_Redesign_Profile_002
	//Objectives:  To verify users can update their Mailing address and email address

	//Pre-Requisites: 
	//User should have the Valid Username and Password
	//Author : Vikram T Date: 05.11.2018
	public void  Camel_Redesign_Profile_002(String UN,String pwd,String url, String browserName,String txtAddress,String txtCity,String txtZipcode,String txtEmail,String txtState )throws Exception
	{
		// Launch Application
		gl.launchApplication(browserName, url);
		Thread.sleep(2000);

		//*********************************************************************************************************************      
		//Camel Login page is displayed.
		//gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//*********************************************************************************************************************          
		//Enter valid email id 
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter valid password

		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword",pwd) ;
		//Click login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "Home");
		//Click Welcome, Profile name button
		gl.clickbutton(Camel_Profile.lnkWelcomeProfileName,"Welcome, Profile name link");
		//Camel profile page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("My Profile","Profile page");

		//clear the address editfield
		gl.clearElementText(Camel_Profile.txtAddress, "User Address field");
		//clear the city field
		gl.clearElementText(Camel_Profile.txtCity, "User city field");
		//clear the zipcode field
		gl.clearElementText(Camel_Profile.txtZipcode, "User zipcode");


		//Enter Valid address
		gl.inputText(Camel_Profile.txtAddress, "User Address field", txtAddress) ;
		//Enter Valid City
		gl.inputText(Camel_Profile.txtCity, "User city field",txtCity );


		//Enter state
		gl.SelectByOption(Camel_Profile.txtState, txtState);


		//Enter valid zipcode
		gl.inputText(Camel_Profile.txtZipcode,"User zipcode",txtZipcode);

		//enter valid email id
		gl.inputText(Camel_Profile.txtNewEmail,"User new email text field",txtEmail);
		//enter confirm email id
		gl.inputText(Camel_Profile.txtConfirmNewEmail,"User confirm new email",txtEmail);
		gl.fnScrollToView(Camel_Profile.txtConfirmNewEmail);
		//click on update button
		gl.clickbutton(Camel_Profile.btnUpdate,"User profile update button");

		//Verify that "Update successful" message is displayed
	//	gl.fnVerifyTextFromAlert("Update Successful");


		//clik ok from the update successful pop up
		gl.confirmAlert();


		//click browser back button
		gl.browserBack();
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "Home");

		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//*******************************************************************************************************************************************************
		//Launch the url
		gl.launchUrl(url);
		//Enter valid email id 
		gl.inputText(Camel_Login.txtUsername,"txtUsername", txtEmail) ;
		//Enter valid password

		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd) ;
		//Click login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "Home");
		//Click Welcome, Profile name button
		gl.clickbutton(Camel_Profile.lnkWelcomeProfileName,"Welcome, Profile name link");
		//Camel profile page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("My Profile","Profile page");
		Thread.sleep(2000);
		//get address
		gl.getExtractAttributeValue(Camel_Profile.txtAddress,txtAddress,"value");

		//Get city
		gl.getExtractAttributeValue(Camel_Profile.txtCity,txtCity,"value");

		Thread.sleep(2000);
		//Get zipcode
		gl.getExtractAttributeValue(Camel_Profile.txtZipcode,txtZipcode,"value");
		Thread.sleep(2000);
		//Get email
		gl.getExtractAttributeValue(Camel_Profile.txtEmail,txtEmail,"value");

		//click browser back button
		gl.browserBack();

		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
	}
	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Camel_Redesign_Profile_005
	//Objectives:   To verify users can update their password and challenge question.

	//Pre-Requisites: 
	//User should have the Valid Username and Password
	//Author : Vikram T Date: 06.11.2018
	public void  Camel_Redesign_Profile_005(String UN,String pwd,String url, String browserName,String PasswordChange )throws Exception
	{

		
		//String PasswordChange="Password123";
		String ChallengeAnswer="none";
		
		
		
		// Launch Application
		gl.launchApplication(browserName, url);
		Thread.sleep(2000);

		//*********************************************************************************************************************      
		//Camel Login page is displayed.
	//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//*********************************************************************************************************************          
		//Enter valid email id 
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter valid password

		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd) ;
		//Click login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
		Thread.sleep(5000);
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "Home");
		//Click Welcome, Profile name button
		gl.clickbutton(Camel_Profile.lnkWelcomeProfileName,"Welcome, Profile name link");
		//Camel profile page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("My Profile","Profile page");
		gl.fnScrollToView(Camel_Profile.txtCurrentPassword);
		//Enter Current password
		gl.inputText(Camel_Profile.txtCurrentPassword, "User Current Password", pwd) ;
		//Enter New Password
		gl.inputPasswordEncrypted(Camel_Profile.txtNewPassword, "User New Password",PasswordChange);
		//Enter Confirm new password
		gl.inputPasswordEncrypted(Camel_Profile.txtConfirmNewPassword, "User Confirm New Password",PasswordChange);
		//Click update button
		gl.clickbutton(Camel_Profile.btnPasswordUpdate,"User password update button");
		//Verify that Update successfully message is displayed
	//	gl.fnVerifyTextFromAlert("Update Successful");


		//clik ok from the update successful pop up
		gl.confirmAlert();
		//Select challenge question from the  dropdown
		gl.SelectByOption(Camel_Profile.weDropdownChallengeQuestion, "Who was your childhood hero?");

		//Enter answer to the challenge question
		gl.inputText(Camel_Profile.txtChallengeAnswer, "User Challenge Question answer",ChallengeAnswer );
		//Click update button
		gl.clickbutton(Camel_Profile.btnChallengeQUpdate,"User password update button");
		//Verify that "Update successful" message is displayed
	//			gl.fnVerifyTextFromAlert("Update Successful");

		//clik ok from the update successful pop up
		gl.confirmAlert();
		//Click browser back button
		gl.browserBack();
		Thread.sleep(2000);
		//Verify that homepage is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "Home");
		Thread.sleep(2000);
		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");

		//*******************************************************************************************************************************************************
	/*	This is commented due to changes in GC process  by vikram 02/14/2019
	 * 
	 * 
	 * 
	 * 
	 * //Click on "Forgot Password" link
		gl.clickLink(Camel_Login.lnkForgotPassword, "lnkForgotPassword");
		//Verify Forgot Password page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Forgot Your Password");
		//Enter User ID
		gl.inputText(Camel_Profile.txtUserID, "User ID",UN);
		//Click continue
		gl.clickLink(Camel_Profile.btnContinue, "Continue Button");
		//Verify Verify your identity page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Verify Your Identity");
		//verify the challenge question displayed
		gl.VerifyElementVisible(Camel_Profile.txtChallengeQuestion, "Who was your childhood hero?");
		//Enter wrong answer
		gl.inputText(Camel_Profile.txtChallengeAnswer1, "wrong challenge answer","wrong");
		//Click continue
		gl.clickLink(Camel_Profile.btnContinue1, "Continue Button");
		//Verify error message is displayed
		gl.VerifyElementVisible(Camel_Profile.weMsgError,"Error message");
		//Enter Correct answer
		gl.inputText(Camel_Profile.txtChallengeAnswer1, "Correct challenge answer","none");
		//Click continue
		gl.clickLink(Camel_Profile.btnContinue1, "Continue Button");
		//Verify that Reset your password page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("Reset Your Password","Reset your password page");
		//Click go to login link
		gl.clickLink(Camel_Profile.lnkGoToLogin, "Go to login link");
		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		
		*
		*
		*
		*
		*
		*
		*/
		//*********************************************************************************************************************          
	//Launch URL
		gl.launchUrl(url);
		//Enter valid email id 
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter valid password

		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword",PasswordChange ) ;
		//Click login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "Home");




	}
	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Camel_Redesign_Profile_003
	//Objectives:    To verify preference tab under the Profile page
	//Pre-Requisites: 
	//User should have the Valid Username and Password
	//Author : Vikram T Date: 28.11.2018
	public void  Camel_Redesign_Profile_003(String UN,String pwd,String url, String browserName ,String txtDefault,String txtCombustible,String txtMoistSnuff,String txtVapor,String txtSnus,String txtDissolvableTobacco)throws Exception
	{

		// Launch Application
		gl.launchApplication(browserName, url);
		Thread.sleep(2000);

		//*********************************************************************************************************************      
		//Camel Login page is displayed.
	//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//*********************************************************************************************************************          
		//Enter valid email id 
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter valid password

		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd) ;
		//Click login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "Home");
		//Click Welcome, Profile name button
		gl.clickbutton(Camel_Profile.lnkWelcomeProfileName,"Welcome, Profile name link");
		//Camel profile page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("My Profile","Profile page");
		//Click on prefernce tab
		gl.clickbutton(Camel_Profile.btnTobaccoPreferences,"Tobacco preference's tab");
		//Verify tab is displayed
		gl.VerifyElementVisible(Camel_Profile.weTPContents,"Tobacco preferences container");
		
 //Verify all check box are unselected ,if selected unselect
		
		//combustible checkbox
		if(gl.IsCheckboxSelected(Camel_Profile.weChkBoxCombustible, "Combustile")){
			gl.unselectCheckbox(Camel_Profile.weChkBoxCombustible, "Combustile");
		}
		//moist snuff checkbox
		if(gl.IsCheckboxSelected(Camel_Profile.weChkBoxMoistSnuff, "Moist Snuff")){
			gl.unselectCheckbox(Camel_Profile.weChkBoxMoistSnuff, "Moist Snuff");
		}
		
		
		//vapor checkbox
		if(gl.IsCheckboxSelected(Camel_Profile.weChkBoxVapor, "Vapor")){
			gl.unselectCheckbox(Camel_Profile.weChkBoxVapor, "Vapor");
		}
		
		
		//snus checkbox
		if(gl.IsCheckboxSelected(Camel_Profile.weChkBoxSnus, "snus")){
			gl.unselectCheckbox(Camel_Profile.weChkBoxSnus, "snus");
		}
		
		
		//dissolvable tobbaco checkbox
		if(gl.IsCheckboxSelected(Camel_Profile.weChkBoxDissolvableTobacco, "DissolvableTobacco")){
			gl.unselectCheckbox(Camel_Profile.weChkBoxDissolvableTobacco, "DissolvableTobacco");
		}
		
		
		gl.fnContentValidation(txtDefault, Camel_Profile.weTPContents);

		//click on combustile check box
		gl.selectCheckbox(Camel_Profile.weChkBoxCombustible, "Combustile");
		//verify the content visible
		gl.fnContentValidation(txtCombustible, Camel_Profile.weTPContents);

		//Uncheck the combustible check box
		gl.unselectCheckbox(Camel_Profile.weChkBoxCombustible, "Combustile");


		//check the moist snuff check box
		gl.selectCheckbox(Camel_Profile.weChkBoxMoistSnuff, "Moist Snuff");
		//verify the content visible
		gl.fnContentValidation(txtMoistSnuff, Camel_Profile.weTPContents);
		//Uncheck the combustible check box
		gl.unselectCheckbox(Camel_Profile.weChkBoxMoistSnuff, "Moist Snuff");

		//check the  vapor check box
		gl.selectCheckbox(Camel_Profile.weChkBoxVapor, "Vapor");
		//verify the content visible
		gl.fnContentValidation(txtVapor, Camel_Profile.weTPContents);
		//Uncheck the combustible check box
		gl.unselectCheckbox(Camel_Profile.weChkBoxVapor, "Vapor");

		//check the  snus check box
		gl.selectCheckbox(Camel_Profile.weChkBoxSnus, "snus");
		//verify the content visible
		gl.fnContentValidation(txtSnus, Camel_Profile.weTPContents);
		//Uncheck the combustible check box
		gl.unselectCheckbox(Camel_Profile.weChkBoxSnus, "Snus");

		//check the Dissolvable Tobacco check box
		gl.selectCheckbox(Camel_Profile.weChkBoxDissolvableTobacco, "DissolvableTobacco");
		//verify the content visible
		gl.fnContentValidation(txtDissolvableTobacco, Camel_Profile.weTPContents);
		//Uncheck the combustible check box
		gl.unselectCheckbox(Camel_Profile.weChkBoxDissolvableTobacco, "DissolvableTobacco");


		//click on combustile check box
		gl.selectCheckbox(Camel_Profile.weChkBoxCombustible, "Combustile");
		//Select cigarette brand
		gl.SelectByOption(Camel_Profile.weDropdownCigaretteBrand, "CAMEL");
		//Select how many were your regular brand
		gl.SelectByOption(Camel_Profile.weDropdownRegularBrand, "2");
		//Select do you
		gl.SelectByOption(Camel_Profile.weDropdownPrefer, "BOTH");
		//check the what other cigarettes brand have you purchased
		gl.selectCheckbox(Camel_Profile.weChkBoxPurchased, "CAMEL");
		//click the update button
		gl.clickbutton(Camel_Profile.btnUpdateTobaccoPreferences, "Update button tobacco preferences");
		//Verify that Update successfully message is displayed
		gl.fnVerifyTextFromAlert("Update Successful");
		//PRESS OK TO THE update succrsful popup
		gl.confirmAlert();
		//Click browser back button
		gl.browserBack();
		Thread.sleep(2000);
		//Verify that homepage is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "Home");
		Thread.sleep(2000);
		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");}

	//*******************************************************************************************************************************************************




	public void afterMethod() {
		driver.quit();
		gl.endReport();
		//extent.flush();
	}
}