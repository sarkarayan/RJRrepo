package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.componentgroups.*;
import com.rai.pageObjects.brandWebsitePageObjects;




public class BrandWebsite_AlreadyRegisteredPage extends BaseClass {
	
	String testcaseName;
	
		public BrandWebsite_AlreadyRegisteredPage(String testcaseName) {
			this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(brandWebsitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	public void invokeApplication_brandwebsite()
	{
		String WebsiteURL = dataTable.getData("General_Data","URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
		
	public void registration_ValidDetailsonStep1Page() throws Exception
	{
		
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String Email = dataTable.getData("General_Data", "Email");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
		String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		System.out.println(year);
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Registration),brandWebsitePageObjects.btn_Registration.getObjectname());
		
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthMonth), month, brandWebsitePageObjects.drpdwn_BirthMonth.getObjectname());
		Thread.sleep(3000);
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthDay),day,brandWebsitePageObjects.drpdwn_BirthDay.getObjectname());
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthYear),year, brandWebsitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_FirstName), FirstName, brandWebsitePageObjects.txt_FirstName.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_LastName),LastName, brandWebsitePageObjects.txt_LastName.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_Address),Address, brandWebsitePageObjects.txt_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Zipcode), Zipcode,brandWebsitePageObjects.txt_Zipcode.getObjectname());
		Thread.sleep(4000);
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_City), City, brandWebsitePageObjects.txt_City.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_State),State, brandWebsitePageObjects.drpdwn_State.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_Email),Email,brandWebsitePageObjects.txt_Email.getObjectname());	
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.Chkbx_Certify),brandWebsitePageObjects.Chkbx_Certify.getObjectname());
		
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Step1Next), brandWebsitePageObjects.btn_Step1Next.getObjectname());
		//Thread.sleep(4000);
	}
	
	public void registration_sameBrandAlreadyRegisteredPage() throws IOException
	{
		
		String ActualErrormsg_AlreadyRegistered = driver.getTitle();
		String ExpectedErrormsg_AlreadyRegistered = "Registration Already Registered";
		if(ActualErrormsg_AlreadyRegistered.contains(ExpectedErrormsg_AlreadyRegistered))
		{
			System.out.println("Registration - Directed to Expected page when user try to register the user in same brand");
		}
		else
		{
			System.out.println("Registration - Directed to Expected page displayed when user try to register the user in same brand");
		}
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_AlreadyRegisteredLogin), brandWebsitePageObjects.btn_AlreadyRegisteredLogin.getObjectname());
	}
	
	public void registration_anotherBrand_AccountExistsPage() throws Exception 
	{
		String UserId = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data","Password");
		
		String ExpectedErrormsg_diffBrandAlreadyRegistered = "It looks like you are already registered with another Reynolds American operating company’s brand website.";
		
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errmsg_AlreadyRegisteredPage), brandWebsitePageObjects.errmsg_AlreadyRegisteredPage.getObjectname(), ExpectedErrormsg_diffBrandAlreadyRegistered);
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_AlreadyRegisteredUsername), UserId, brandWebsitePageObjects.txt_AlreadyRegisteredUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_AlreadyRegisteredPassword), Password, brandWebsitePageObjects.txt_AlreadyRegisteredPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_AlreadyRegisteredLogin), brandWebsitePageObjects.btn_AlreadyRegisteredLogin.getObjectname());
	}
	
	public void registration_anotherBrandAlreadyRegisteredPage() throws Exception 
	{
		
		String ExpectedErrormsg_diffBrandAlreadyRegistered = "It looks like you are already registered with another Reynolds American operating company�s brand website.";
		
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errmsg_AlreadyRegisteredPage), brandWebsitePageObjects.errmsg_AlreadyRegisteredPage.getObjectname(), ExpectedErrormsg_diffBrandAlreadyRegistered);
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_AlreadyRegisteredLogin), brandWebsitePageObjects.btn_AlreadyRegisteredLogin.getObjectname());
	}
	
	public void registration_RevelValidDetailsonStep1Page() throws InterruptedException, IOException
	{
		
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String Email = dataTable.getData("General_Data", "Email");
		String PhoneNumber = dataTable.getData("General_Data", "Phone");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
        String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Registration),brandWebsitePageObjects.btn_Registration.getObjectname());
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthMonth), month, brandWebsitePageObjects.drpdwn_BirthMonth.getObjectname());
		Thread.sleep(6000);
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthDay),day,brandWebsitePageObjects.drpdwn_BirthDay.getObjectname());
		//commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_BirthYear), "1938", brandWebsitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthYear),year,brandWebsitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_FirstName), FirstName, brandWebsitePageObjects.txt_FirstName.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_LastName),LastName, brandWebsitePageObjects.txt_LastName.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_Address),Address, brandWebsitePageObjects.txt_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Zipcode), Zipcode,brandWebsitePageObjects.txt_Zipcode.getObjectname());
		Thread.sleep(4000);
					
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Email),Email, brandWebsitePageObjects.txt_Email.getObjectname());
		Thread.sleep(5000);
		commonFunction.clickIfElementPresentJavaScript(getPageElement(brandWebsitePageObjects.txt_PhoneRevelVelo),brandWebsitePageObjects.txt_PhoneRevelVelo.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_PhoneRevelVelo),PhoneNumber, brandWebsitePageObjects.txt_PhoneRevelVelo.getObjectname());
		commonFunction.clickIfElementPresentJavaScript(getPageElement(brandWebsitePageObjects.radiobtn_GenderMaleRevel),brandWebsitePageObjects.radiobtn_GenderMaleRevel.getObjectname());
		//commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.radiobtn_GenderMaleRevel),brandWebsitePageObjects.radiobtn_GenderMaleRevel.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.chkbx_CertifyRevelVelo),brandWebsitePageObjects.chkbx_CertifyRevelVelo.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_City), City, brandWebsitePageObjects.txt_City.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_State),State, brandWebsitePageObjects.drpdwn_State.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Step1Next), brandWebsitePageObjects.btn_Step1Next.getObjectname());
		Thread.sleep(4000);
	}
	
	public void registration_VeloValidDetailsonStep1Page() throws InterruptedException, IOException
	{
		
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String Email = dataTable.getData("General_Data", "Email");
		String PhoneNumber = dataTable.getData("General_Data", "Phone");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
        String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Registration),brandWebsitePageObjects.btn_Registration.getObjectname());
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthMonth), month, brandWebsitePageObjects.drpdwn_BirthMonth.getObjectname());
		Thread.sleep(6000);
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthDay),day,brandWebsitePageObjects.drpdwn_BirthDay.getObjectname());
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthYear),year,brandWebsitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_FirstName), FirstName, brandWebsitePageObjects.txt_FirstName.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_LastName),LastName, brandWebsitePageObjects.txt_LastName.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_Address),Address, brandWebsitePageObjects.txt_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Zipcode), Zipcode,brandWebsitePageObjects.txt_Zipcode.getObjectname());
		Thread.sleep(4000);
					
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Email),Email, brandWebsitePageObjects.txt_Email.getObjectname());
		Thread.sleep(5000);
		commonFunction.clickIfElementPresentJavaScript(getPageElement(brandWebsitePageObjects.txt_PhoneRevelVelo),brandWebsitePageObjects.txt_PhoneRevelVelo.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_PhoneRevelVelo),PhoneNumber, brandWebsitePageObjects.txt_PhoneRevelVelo.getObjectname());
		Thread.sleep(3000);
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.chkbx_CertifyRevelVelo),brandWebsitePageObjects.chkbx_CertifyRevelVelo.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_City), City, brandWebsitePageObjects.txt_City.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_State),State, brandWebsitePageObjects.drpdwn_State.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Step1Next), brandWebsitePageObjects.btn_Step1Next.getObjectname());
		Thread.sleep(4000);
	}
	
	public void registration_VUSEValidDetailsonStep1Page() throws InterruptedException, IOException
	{
		
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String Email = dataTable.getData("General_Data", "Email");
		String PhoneNumber = dataTable.getData("General_Data", "Phone");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
        String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.loginLnk_VUSECertifyAgePage),brandWebsitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.header_VUSECreateAccount),brandWebsitePageObjects.header_VUSECreateAccount.getObjectname());
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthMonth), month, brandWebsitePageObjects.drpdwn_BirthMonth.getObjectname());
		Thread.sleep(6000);
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthDay),day,brandWebsitePageObjects.drpdwn_BirthDay.getObjectname());
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthYear),year,brandWebsitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_FirstName), FirstName, brandWebsitePageObjects.txt_FirstName.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_LastName),LastName, brandWebsitePageObjects.txt_LastName.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_Address),Address, brandWebsitePageObjects.txt_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Zipcode), Zipcode,brandWebsitePageObjects.txt_Zipcode.getObjectname());
		Thread.sleep(4000);
					
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Email),Email, brandWebsitePageObjects.txt_Email.getObjectname());
		Thread.sleep(5000);
		commonFunction.clickIfElementPresentJavaScript(getPageElement(brandWebsitePageObjects.txt_PhoneRevelVelo),brandWebsitePageObjects.txt_PhoneRevelVelo.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_PhoneRevelVelo),PhoneNumber, brandWebsitePageObjects.txt_PhoneRevelVelo.getObjectname());
		Thread.sleep(3000);
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.chkbx_CertifyRevelVelo),brandWebsitePageObjects.chkbx_CertifyRevelVelo.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_City), City, brandWebsitePageObjects.txt_City.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_State),State, brandWebsitePageObjects.drpdwn_State.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Step1Next), brandWebsitePageObjects.btn_Step1Next.getObjectname());
		//Thread.sleep(4000);
	}
	
}

