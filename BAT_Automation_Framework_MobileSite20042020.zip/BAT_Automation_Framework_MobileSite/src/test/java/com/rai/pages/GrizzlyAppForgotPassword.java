package com.rai.pages;

import io.appium.java_client.android.nativekey.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.AppForgotPasswordPageObjects;
import com.rai.pageObjects.AppLoginPageObjects;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;



public class GrizzlyAppForgotPassword extends BaseClass {

	String testcaseName;
		
	public GrizzlyAppForgotPassword(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
		}

		/**
		 * Constructor to initialize the component library
		 * 
		 * @param scriptHelper
		 *            The {@link ScriptHelper} object passed from the
		 *            {@link DriverScript}
		 */
		
		CommonFunctions commonFunction = new CommonFunctions(testcaseName);

		
	private WebElement getPageElement(AppForgotPasswordPageObjects pageEnum) throws IOException {
			WebElement element;
			try {
				element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
						true);
				if (element != null)
					System.out.println("Found the element: " + pageEnum.getObjectname());
				else
					System.out.println("Element Not Found: " + pageEnum.getObjectname());
				return element;
			} catch (Exception e) {
				GenericLib.updateExtentStatus("App Forgot password Page - get page element",
						pageEnum.toString() + " object is not defined or found.", Status.FAIL);
				return null;
			}
		}
		
	private WebElement getPageElement(AppLoginPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("App Login Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	public void allowAPPPermission() throws InterruptedException, IOException
	{
		Thread.sleep(5000);
		
		commonFunction.clickIfElementPresent(getPageElement(AppForgotPasswordPageObjects.btn_AppAllowPermission),AppForgotPasswordPageObjects.btn_AppAllowPermission.getObjectname());
		
		
	}
		
	@SuppressWarnings("rawtypes")
	public void enterValidEmailPage() throws IOException, InterruptedException
    {
		WebDriverWait wait = new WebDriverWait(driver, 30);
    	wait.until(ExpectedConditions.visibilityOf(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginUsername)));
    	String Email = dataTable.getData("General_Data", "Email");
    	commonFunction.scrollDown();
    	commonFunction.clickIfElementPresent(getPageElement(AppForgotPasswordPageObjects.lnk_GrizzlyAPPLoginForgotPassword), AppForgotPasswordPageObjects.lnk_GrizzlyAPPLoginForgotPassword.getObjectname());
    	System.out.println("Email:"+Email);
    	commonFunction.clearAndEnterText(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordEnterEmail),Email,AppForgotPasswordPageObjects.txt_ForgotPasswordEnterEmail.getObjectname());
    	((AndroidDriver)driver).hideKeyboard();
    	((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.TAB));
    	commonFunction.clickIfElementPresent(getPageElement(AppForgotPasswordPageObjects.btn_ForgotPasswordEnterEmailContinue),AppForgotPasswordPageObjects.btn_ForgotPasswordEnterEmailContinue.getObjectname());
    	
    	
    }
    
    @SuppressWarnings("rawtypes")
	public void enterdetailsonGeneralInfoPage() throws IOException
    {
    	String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		 String date = dataTable.getData("General_Data","DOB");
			String dateParts[] = date.split("/");
			String month  = dateParts[0];
			String day  = dateParts[1];
			String year = dateParts[2];
		//commonFunction.selectAnyElement(getPageElement(AppForgotPasswordPageObjects.drpDownBirthMonth), month, AppForgotPasswordPageObjects.drpDownBirthMonth.getObjectname());
    	commonFunction.selectValueMobileDropDown(getPageElement(AppForgotPasswordPageObjects.drpdwn_ForgotPasswordGeneralInforBirthMonth),month,AppForgotPasswordPageObjects.drpdwn_ForgotPasswordGeneralInforBirthMonth.getObjectname());
    	commonFunction.selectValueMobileDropDown(getPageElement(AppForgotPasswordPageObjects.drpdwn_ForgotPasswordGeneralInforBirthDay),day,AppForgotPasswordPageObjects.drpdwn_ForgotPasswordGeneralInforBirthDay.getObjectname());
    	commonFunction.selectValueMobileDropDown(getPageElement(AppForgotPasswordPageObjects.drpdwn_ForgotPasswordGeneralInforBirthYear),year,AppForgotPasswordPageObjects.drpdwn_ForgotPasswordGeneralInforBirthYear.getObjectname());
    	((AndroidDriver)driver).hideKeyboard();
    	commonFunction.enterText(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInforFirstName),FirstName,AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInforFirstName.getObjectname());
    	commonFunction.enterText(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoLastName),LastName,AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoLastName.getObjectname());
    	commonFunction.scrollDown();
    	commonFunction.enterText(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoAddressLine),Address,AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoAddressLine.getObjectname());
    	commonFunction.clearAndEnterText(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoZipcode),Zipcode,AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoZipcode.getObjectname());
    	((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.TAB));
    	((AndroidDriver)driver).hideKeyboard();
    	commonFunction.clickIfElementPresent(getPageElement(AppForgotPasswordPageObjects.btn_ForgotPasswordGeneralInfoConitnue),AppForgotPasswordPageObjects.btn_ForgotPasswordGeneralInfoConitnue.getObjectname());
    }

    
    @SuppressWarnings("rawtypes")
	public void verifyIdentityPage() throws IOException
    {
    	String ChallengeAnswer = dataTable.getData("General_Data", "ChallengeAnswer");
    	
    	commonFunction.clearAndEnterText(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordVerifyIdentityChallengeAnswer),ChallengeAnswer,AppForgotPasswordPageObjects.txt_ForgotPasswordVerifyIdentityChallengeAnswer.getObjectname());
    	((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.TAB));
    	commonFunction.clickIfElementPresent(getPageElement(AppForgotPasswordPageObjects.btn_ForgotPasswordVerifyIdentityContinue),AppForgotPasswordPageObjects.btn_ForgotPasswordVerifyIdentityContinue.getObjectname());
    	
    }
    
    
    @SuppressWarnings("rawtypes")
	public void resetPasswordpage() throws IOException
    {
    	String Password = dataTable.getData("General_Data", "Password");
		String ConfirmPassword = dataTable.getData("General_Data", "Password");
    	
    	commonFunction.clearAndEnterText(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordResetPasswordPasswordfield),Password,AppForgotPasswordPageObjects.txt_ForgotPasswordResetPasswordPasswordfield.getObjectname());
    	((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.TAB));
    	commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordResetPasswordConfirmPasswordfield),ConfirmPassword,AppForgotPasswordPageObjects.txt_ForgotPasswordResetPasswordConfirmPasswordfield.getObjectname());
    	
    	commonFunction.clickIfElementPresent(getPageElement(AppForgotPasswordPageObjects.btn_ForgotPasswordResetPasswordNext),AppForgotPasswordPageObjects.btn_ForgotPasswordResetPasswordNext.getObjectname());
    }
    
    public void navigatebackfromCongratsPage() throws IOException
    {
    	
    	commonFunction.clickIfElementPresent(getPageElement(AppForgotPasswordPageObjects.btn_ForgotPasswordCongratsPageReturntoLogin),AppForgotPasswordPageObjects.btn_ForgotPasswordCongratsPageReturntoLogin.getObjectname());
    	
    }
    
    
    
}
