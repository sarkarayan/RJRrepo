package com.rai.pages;

import java.util.Properties;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.pageObjects.*;
import com.rai.framework.GenericLib;

@Listeners(ExtentITestListenerClassAdapter.class)
public class Camel_SoundBoardPage extends BaseClass{
	GenericLib gl = new GenericLib(this.getClass().getSimpleName());
	Properties config = new Properties();
	SoftAssert softAssert=new SoftAssert();


	@BeforeMethod
	public void beforemethod(String TestCaseName,String TestCaseObjective,String TestEnvironmentUrl) {
		gl.start_report(TestCaseName, TestCaseObjective, TestEnvironmentUrl);
		//extent = ExtentManager.GetExtent();	
		//extent = ExtentManager.createTest(test, description)
	}
	
	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case : To verify that the Soundboard's sub navigational menu functionality

//Pre-Requisites: 
//User should have the valid Username and Password.
 
	//Author : Vikram T Date: 22.11.2018
	public void  Camel_OS_PostPromotion_001 (String UN,String pwd,String url, String browserName )throws Exception
	{
		// Launch Application
		gl.launchApplication(browserName, url);
		Thread.sleep(2000);

		//*********************************************************************************************************************      
		//Camel Login page is displayed.
	//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//*********************************************************************************************************************          
		//Enter valid email id 
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter valid password

		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd) ;
		//Click login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
		Thread.sleep(10000);
		//Camel Home page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("Home | Camel","Camel Home");



		//Click on SoundBoard link
		gl.clickbutton(Camel_Common.lnkSoundBoard,"SoundBoard link");
		//Verify that SoundBoard landing page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("SoundBoard | Camel","Soundboard's landing page");
		//hover the mouse on SoundBoard
		gl.HowerMouse(Camel_Common.lnkSoundBoard,"SoundBoard link from main navigation");
		//Click on SoundBoard-Create link 
		gl.clickbutton(Camel_Common.lnkCreate,"SoundBoard Create link");
		//Verify that SoundBoard create page is displayed
	
		gl.fnVerifyPageDisplayedUsingPageTitle("SoundBoard | Camel","Soundboard's create page");
		gl.VerifyElementVisible(Camel_SoundBoard.btnMakeABeat,"Make a beat button");
		
		//hover the mouse on SoundBoard
		gl.HowerMouse(Camel_Common.lnkSoundBoard,"SoundBoard link from main navigation");
		//Click on SoundBoard-TopTracks link 
		gl.clickbutton(Camel_Common.lnkTopTracks,"SoundBoard TopTracks link");
		//Verify that SoundBoard Top tracks page is displayed
		
		gl.fnVerifyPageDisplayedUsingPageTitle("SoundBoard | Camel","Soundboard's Top tracks page");
		gl.VerifyElementVisible(Camel_SoundBoard.btnBehindTheSounds,"Behind the sounds");
		
		//hover the mouse on SoundBoard
		gl.HowerMouse(Camel_Common.lnkSoundBoard,"SoundBoard link from main navigation");
		//Click on SoundBoard-My beats link 
		gl.clickbutton(Camel_Common.lnkMyBeats,"SoundBoard Mybeats link");
		//Verify that SoundBoard my beats page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("SoundBoard | Camel","Soundboard's my beats page");
		
		//Verify that SoundBoard My beats page is displayed
		
		if(gl.isObjectPresent(Camel_SoundBoard.btnMakeABeat1,"Make a beat button"))
		{
		gl.VerifyElementVisible(Camel_SoundBoard.btnMakeABeat1,"My beats page");}
		else{
			gl.VerifyElementVisible(Camel_SoundBoard.btnCreate, "My beats page");
		}
		//hover the mouse on SoundBoard
		gl.HowerMouse(Camel_Common.lnkSoundBoard,"SoundBoard link from main navigation");
		//Click on SoundBoard-Behind the sounds link 
		gl.clickbutton(Camel_Common.lnkBehindTheSounds,"SoundBoard behind the sounds link");
		//Verify that SoundBoard Behind the sounds page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("SoundBoard | Camel","Soundboard's behind the sounds page");
		//Verify that SoundBoard behind the sounds page is displayed
		gl.VerifyElementVisible(Camel_SoundBoard.btnWatchVideo,"Behind the sound's page");
		
		//hover the mouse on SoundBoard
		gl.HowerMouse(Camel_Common.lnkSoundBoard,"SoundBoard link from main navigation");
		//Click on SoundBoard-FAQ's link 
		gl.clickbutton(Camel_Common.lnkFAQs,"SoundBoard FAQ'a link");
		Thread.sleep(4000);
		//Verify that SoundBoard FAQ page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("SoundBoard | Camel","Soundboard's FAQs page");
		//Verify that SoundBoard FAQ'a page is displayed
		gl.VerifyElementVisible(Camel_SoundBoard.weTxtFAQs,"FAQ's page");
		
		//hover the mouse on SoundBoard
		gl.HowerMouse(Camel_Common.lnkSoundBoard,"SoundBoard link from main navigation");
		//Click on SoundBoard-Terms and Conditions link 
		gl.clickbutton(Camel_Common.lnkTermsAndConditions,"SoundBoard Terms and Conditions link");
		Thread.sleep(6000);
		//Verify that SoundBoard Terms and conditions page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("SoundBoard | Camel","Soundboard's Terms and conditions page");
		//Verify that SoundBoard Terms and conditions page is displayed
		gl.VerifyElementVisible(Camel_SoundBoard.weTxtTermsAndConditions,"Terms and Conditons page");








		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");






	}
	//********************************************************************************************************************************************************
		//********************************************************************************************************************************************************    
		@Test
		//Test Case : To verify that the Soundboard's landing page

	//Pre-Requisites: 
	//User should have the valid Username and Password.
		//Author : Vikram T Date: 22.11.2018

		public void  Camel_OS_PostPromotion_023 (String UN,String pwd,String url, String browserName )throws Exception
		{
			// Launch Application
			gl.launchApplication(browserName, url);
			Thread.sleep(2000);

			//*********************************************************************************************************************      
			//Camel Login page is displayed.
		//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
			//*********************************************************************************************************************          
			//Enter valid email id 
			gl.inputText(Camel_Login.txtUsername,"txtUsername",UN) ;
			//Enter valid password

			gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd) ;
			//Click login button
			gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
			Thread.sleep(10000);
			
			//Camel Home page is displayed
			gl.fnVerifyPageDisplayedUsingPageTitle("Home | Camel","Camel Home");



			//Click on SoundBoard link
			gl.clickbutton(Camel_Common.lnkSoundBoard,"SoundBoard link");
			//Verify that Soundboard landing page is displayed
			gl.fnVerifyPageDisplayedUsingPageTitle("SoundBoard | Camel","Soundboard's landing page");
			//Click on Listen button
			gl.clickbutton(Camel_SoundBoard.btnListen,"SoundBoard Listen button");
			//Verify that Soundboard  page is displayed
			gl.fnVerifyPageDisplayedUsingPageTitle("SoundBoard | Camel","Soundboard's My beats page");
			
			//Verify that Soundboard My beats page is displayed
			gl.VerifyElementVisible(Camel_SoundBoard.btnMakeABeat1,"My beats page");
			
			//Click on Play button
			gl.clickbutton(Camel_SoundBoard.btnPlay,"My beats play button");
			//verify that pause button is visible
			gl.VerifyElementVisible(Camel_SoundBoard.btnPause,"My beats pause button");
			
			//Click on Pause button
			gl.clickbutton(Camel_SoundBoard.btnPause,"My beats pause button");
			//verify that pause button is visible
			gl.VerifyElementVisible(Camel_SoundBoard.btnPlay,"My beats play button");
			
	
			
			//Click on make a beat button
			gl.clickbutton(Camel_SoundBoard.btnMakeABeat1,"My beats Make a beat button");
			//Verify that Soundboard page is displayed
			gl.fnVerifyPageDisplayedUsingPageTitle("SoundBoard | Camel","Soundboard's landing page");
			//verify that beat creation page is visible
			gl.VerifyElementVisible(Camel_SoundBoard.weVerifyMakeABeat,"Beat creation page");
			//Click on browser back button
			gl.browserBack();
			//Verify that Soundboard  page is displayed
			gl.fnVerifyPageDisplayedUsingPageTitle("SoundBoard | Camel","Soundboard's landing page");
			//Verify that more tracks are displayed
			
			gl.VerifyElementVisible(Camel_SoundBoard.btnMakeABeat2,"My beats page");
			
			
			//Click on Logout button
			gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

			//Camel Login page is displayed.
			gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");






		}
	


	public void afterMethod() {
		driver.quit();
		gl.endReport();
		//extent.flush();
	}
	















}
