package com.rai.pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;

import com.rai.pageObjects.AppForgotUsernamePageObjects;

public class GrizzlyAppForgotUsername extends BaseClass {

	
	String testcaseName;
	public GrizzlyAppForgotUsername(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
		}

		/**
		 * Constructor to initialize the component library
		 * 
		 * @param scriptHelper
		 *            The {@link ScriptHelper} object passed from the
		 *            {@link DriverScript}
		 */
		
		CommonFunctions commonFunction = new CommonFunctions(testcaseName);

		
	private WebElement getPageElement(AppForgotUsernamePageObjects pageEnum) throws IOException {
			WebElement element;
			try {
				element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
						true);
				if (element != null)
					System.out.println("Found the element: " + pageEnum.getObjectname());
				else
					System.out.println("Element Not Found: " + pageEnum.getObjectname());
				return element;
			} catch (Exception e) {
				GenericLib.updateExtentStatus("Registration Page - get page element",
						pageEnum.toString() + " object is not defined or found.", Status.FAIL);
				return null;
			}
		}
		
	public void allowAPPPermission()
	{
		
		try {
			commonFunction.clickIfElementPresent(getPageElement(AppForgotUsernamePageObjects.btn_AppAllowPermission),AppForgotUsernamePageObjects.btn_AppAllowPermission.getObjectname());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("App Permission was already enabled");
		}
		
	}
	
    public void enterdetailsonAccountInfoPage() throws InterruptedException, IOException
    {
    	
    	String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
    	
    	commonFunction.clickIfElementPresent(getPageElement(AppForgotUsernamePageObjects.lnk_GrizzlyAPPLoginForgotUsername), AppForgotUsernamePageObjects.lnk_GrizzlyAPPLoginForgotUsername.getObjectname());
    	commonFunction.selectAnyElement(getPageElement(AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthMonth), "10", AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthMonth.getObjectname());
    	Thread.sleep(5000);
    	commonFunction.selectAnyElement(getPageElement(AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthDay),"14",AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthDay.getObjectname());
    	commonFunction.selectAnyElement(getPageElement(AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthYear),"1938",AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
    	
    	commonFunction.clearAndEnterText(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameFirstName),FirstName,AppForgotUsernamePageObjects.txt_ForgotUsernameFirstName.getObjectname());
    	commonFunction.clearAndEnterText(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameLastName),LastName,AppForgotUsernamePageObjects.txt_ForgotUsernameLastName.getObjectname());
    	
    	commonFunction.clearAndEnterText(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameAddressLine),Address,AppForgotUsernamePageObjects.txt_ForgotUsernameAddressLine.getObjectname());
    	commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameZipcode),Zipcode,AppForgotUsernamePageObjects.txt_ForgotUsernameZipcode.getObjectname());
    	
    	commonFunction.clickIfElementPresent(getPageElement(AppForgotUsernamePageObjects.btn_ForgotUsernameAcctInfoConitnue),AppForgotUsernamePageObjects.btn_ForgotUsernameAcctInfoConitnue.getObjectname());
    	
    }
    
    
    public void verifyIdentityPage() throws IOException
    {
    	String ChallengeAnswer = dataTable.getData("General_Data", "ChallengeAnswer");
    	
    	commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameVerifyIdentityChallengeAnswer), ChallengeAnswer, AppForgotUsernamePageObjects.txt_ForgotUsernameVerifyIdentityChallengeAnswer.getObjectname());
    	commonFunction.clickIfElementPresent(getPageElement(AppForgotUsernamePageObjects.btn_ForgotUsernameVerifyIdentityContinue),AppForgotUsernamePageObjects.btn_ForgotUsernameVerifyIdentityContinue.getObjectname());
    	
    }
    
    
    @SuppressWarnings("unused")
	public void navigatebackfromWelcomeBackPage() throws IOException
    {
    	
    	String UserId = commonFunction.getTextFromElement(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameUserIdDetails));
    	
    	commonFunction.clickIfElementPresent(getPageElement(AppForgotUsernamePageObjects.btn_ForgotUsernameReturntoLogin),AppForgotUsernamePageObjects.btn_ForgotUsernameReturntoLogin.getObjectname());
    }
	
}

