package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.brandWebsitePageObjects;

public class BrandWebsite_RevelPrePostLoginFooterLinksValidation extends BaseClass {

	String testcaseName;
	public BrandWebsite_RevelPrePostLoginFooterLinksValidation(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(brandWebsitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("FooterLinks Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	public void invokeApplication_brandwebsite()
	{
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
	
	public void loginPage_RevelPreLoginFooterLinksValidation() throws Exception
	{ 
		//PreLogin - FAQs footerlink
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PreLoginRevelfooterlnk_FAQs));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginRevelfooterlnk_FAQs),brandWebsitePageObjects.PreLoginRevelfooterlnk_FAQs.getObjectname());
//		commonFunction.switchToWindow(commonFunction.noofWindows());
//		commonFunction.close();
//		commonFunction.switchToWindow(commonFunction.noofWindows());
		commonFunction.SwitchControlToChildTab();
		String ActualFAQsTitle = driver.getTitle();
		String ExpectedFAQsTitle = "Frequently Asked Questions";
		if(ActualFAQsTitle.contains(ExpectedFAQsTitle))
		{
			System.out.println("PreLogin - FAQs footerlink page displayed");
		}
		else
		{
			System.out.println("PreLogin - FAQs footerlink page was not displayed");
		}
		//Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login),brandWebsitePageObjects.btn_Login.getObjectname());
	
		//PreLogin - ContactUs
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PreLoginRevelfooterlnk_ContactUs));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginRevelfooterlnk_ContactUs),brandWebsitePageObjects.PreLoginRevelfooterlnk_ContactUs.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualContactUsTitle = driver.getTitle();
		String ExpectedContactUsTitle = "Contact Us";
		if(ActualContactUsTitle.contains(ExpectedContactUsTitle))
		{
			System.out.println("PreLogin - ContactUs footerlink page displayed");
		}
		else
		{
			System.out.println("PreLogin - ContactUs footerlink page was not displayed");
		}
		//Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login),brandWebsitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - TobaccoRights
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PreLoginRevelfooterlnk_TobaccoRights));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginRevelfooterlnk_TobaccoRights),brandWebsitePageObjects.PreLoginRevelfooterlnk_TobaccoRights.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualTobaccoRightsTitle = driver.getTitle();
		String ExpectedTobaccoRightsTitle = "Own It Voice It";
		if(ActualTobaccoRightsTitle.contains(ExpectedTobaccoRightsTitle))
		{
			System.out.println("PreLogin - TobaccoRights footerlink page displayed");
		}
		else
		{
			System.out.println("PreLogin - TobaccoRights footerlink page was not displayed");
		}
		//Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login),brandWebsitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - SiteRequirements
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PreLoginRevelfooterlnk_SiteRequirements));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginRevelfooterlnk_SiteRequirements),brandWebsitePageObjects.PreLoginRevelfooterlnk_SiteRequirements.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualSiteRequrmntsTitle = driver.getTitle();
		String ExpectedSiteRequrmntsTitle = "Site Requirements";
		if(ActualSiteRequrmntsTitle.contains(ExpectedSiteRequrmntsTitle))
		{
			System.out.println("PreLogin - SiteRequirements footerlink page displayed");
		}
		else
		{
			System.out.println("PreLogin - SiteRequirements footerlink page was not displayed");
		}
		//Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login),brandWebsitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - AgeFiltering
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PreLoginRevelfooterlnk_AgeFiltering));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginRevelfooterlnk_AgeFiltering),brandWebsitePageObjects.PreLoginRevelfooterlnk_AgeFiltering.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualAgeFilteringTitle = driver.getTitle();
		String ExpectedAgeFilteringTitle = "Age Filtering Software:";
		if(ActualAgeFilteringTitle.contains(ExpectedAgeFilteringTitle))
		{
			System.out.println("PreLogin - AgeFiltering footerlink page displayed");
		}
		else
		{
			System.out.println("PreLogin - AgeFiltering footerlink page was not displayed");
		}
		//Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login),brandWebsitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - TermsOfUse
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PreLoginRevelfooterlnk_TermsOfUse));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginRevelfooterlnk_TermsOfUse),brandWebsitePageObjects.PreLoginRevelfooterlnk_TermsOfUse.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualTermsofUseTitle = driver.getTitle();
		String ExpectedTermsofUseTitle = "Terms of use";
		if(ActualTermsofUseTitle.contains(ExpectedTermsofUseTitle))
		{
			System.out.println("PreLogin - TermsofUse footerlink page displayed");
		}
		else
		{
			System.out.println("PreLogin - TermsofUse footerlink page was not displayed");
		}
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_TermsOfUse_Restrictions), brandWebsitePageObjects.PostLoginRevelfooterlnk_TermsOfUse_Restrictions.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions_backtoTop), brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff), brandWebsitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff_backtoTop), brandWebsitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_ChoiceOfLaw), brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_ChoiceOfLaw.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.Preloginfooterlnk_TermsOfUse_ChoiceOfLaw_backtoTop), brandWebsitePageObjects.Preloginfooterlnk_TermsOfUse_ChoiceOfLaw_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes), brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes_backtoTop), brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous), brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous_backtoTop), brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous_backtoTop.getObjectname());
		
		
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login),brandWebsitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - PrivacyPolicy
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PreLoginRevelfooterlnk_PrivacyPolicy));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginRevelfooterlnk_PrivacyPolicy),brandWebsitePageObjects.PreLoginRevelfooterlnk_PrivacyPolicy.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPrivacyPolicyTitle = driver.getTitle();
		String ExpectedPrivacyPolicyTitle = "Privacy Policy and Your California Privacy Rights";
		if(ActualPrivacyPolicyTitle.contains(ExpectedPrivacyPolicyTitle))
		{
			System.out.println("PreLogin - PrivacyPolicy footerlink page displayed");
		}
		else
		{
			System.out.println("PreLogin - PrivacyPolicy footerlink page was not displayed");
		}
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_PrivacyPolicy_WhatwecollectandHow), brandWebsitePageObjects.PreLoginfooterlnk_PrivacyPolicy_WhatwecollectandHow.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_PrivacyPolicy_WhatwecollectandHow_backtoTop), brandWebsitePageObjects.PreLoginfooterlnk_PrivacyPolicy_WhatwecollectandHow_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_PrivacyPolicy_LinktoWebsites), brandWebsitePageObjects.PreLoginfooterlnk_PrivacyPolicy_LinktoWebsites.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_PrivacyPolicy_LinktoWebsites_backtoTop), brandWebsitePageObjects.PreLoginfooterlnk_PrivacyPolicy_LinktoWebsites_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_PrivacyPolicy_CaliforniaCCPARights), brandWebsitePageObjects.PreLoginfooterlnk_PrivacyPolicy_CaliforniaCCPARights.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_PrivacyPolicy_CaliforniaCCPARights_backtoTop), brandWebsitePageObjects.PreLoginfooterlnk_PrivacyPolicy_CaliforniaCCPARights_backtoTop.getObjectname());
	
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login),brandWebsitePageObjects.btn_Login.getObjectname());
		
		
		//PreLogin - TermsOfSale
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PreLoginRevelfooterlnk_TermsOfSale));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginRevelfooterlnk_TermsOfSale),brandWebsitePageObjects.PreLoginRevelfooterlnk_TermsOfSale.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualTermsOfSaleTitle = driver.getTitle();
		String ExpectedTermsOfSaleTitle = "Terms of Sale";
		if(ActualTermsOfSaleTitle.contains(ExpectedTermsOfSaleTitle))
		{
			System.out.println("PreLogin - TermsofSale footerlink page displayed");
		}
		else
		{
			System.out.println("PreLogin - TermsofSale footerlink page was not displayed");
		}
		//Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login),brandWebsitePageObjects.btn_Login.getObjectname());
	}
	
	
	public void loginPage_AppToWebsiteLogin() throws InterruptedException, IOException
	{
		
		String Username = dataTable.getData("General_Data", "Username");
		String Password = dataTable.getData("General_Data", "Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginUsername),Username,brandWebsitePageObjects.txt_LoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginPassword),Password, brandWebsitePageObjects.txt_LoginPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login), brandWebsitePageObjects.btn_Login.getObjectname());
		//Thread.sleep(5000);
	}
	
	
	public void homePage_RevelPostLoginFooterLinksValidation() throws Exception
	{
		
		//PostLogin - FAQs footerlink
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_FAQs));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_FAQs),brandWebsitePageObjects.PostLoginRevelfooterlnk_FAQs.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginFAQsTitle = driver.getTitle();
		String ExpectedPostLoginFAQsTitle = "FAQs";
		if(ActualPostLoginFAQsTitle.contains(ExpectedPostLoginFAQsTitle))
		{
			System.out.println("PostLogin - FAQs footerlink page displayed");
		}
		else
		{
		    System.out.println("PostLogin - FAQs footerlink page was not displayed");
		}
		//Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
	
		
		//PostLogin - ContactUs footer link
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_ContactUs));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_ContactUs),brandWebsitePageObjects.PostLoginRevelfooterlnk_ContactUs.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginContactUsTitle = driver.getTitle();
		String ExpectedPostLoginContactUsTitle = "Contact us";
		if(ActualPostLoginContactUsTitle.contains(ExpectedPostLoginContactUsTitle))
		{
		     System.out.println("PostLogin - ContactUs footerlink page displayed");
		}
		else
		{
			System.out.println("PostLogin - ContactUs footerlink page was not displayed");
		}
		//Thread.sleep(5000);
//		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.PostLoginfooterlnk_ContactUsQuestion),2 ,brandWebsitePageObjects.PostLoginfooterlnk_ContactUsQuestion.getObjectname());
//		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.PostLoginfooterlnk_ContactUsAnswer),"Validate",brandWebsitePageObjects.PostLoginfooterlnk_ContactUsAnswer.getObjectname());
//		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginfooterlnk_ContactUsSubmit),brandWebsitePageObjects.PostLoginfooterlnk_ContactUsSubmit.getObjectname());
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		
		
		//PostLogin - TobaccoRights
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_TobaccoRights));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_TobaccoRights),brandWebsitePageObjects.PostLoginRevelfooterlnk_TobaccoRights.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginTobaccoRightsTitle = driver.getTitle();
		String ExpectedPostLoginTobaccoRightsTitle = "Own It Voice It";
		if(ActualPostLoginTobaccoRightsTitle.contains(ExpectedPostLoginTobaccoRightsTitle))
		{
			System.out.println("PostLogin - TobaccoRights footerlink page displayed");
		}
		else
		{
		    System.out.println("PostLogin - TobaccoRights footerlink page was not displayed");
		}
		//Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		
		
		//PostLogin - SiteRequirements
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_SiteRequirements));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_SiteRequirements),brandWebsitePageObjects.PostLoginRevelfooterlnk_SiteRequirements.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginSiteRequirementsTitle = driver.getTitle();
		String ExpectedPostLoginSiteRequirementsTitle = "Site Requirements";
		if(ActualPostLoginSiteRequirementsTitle.contains(ExpectedPostLoginSiteRequirementsTitle))
		{
			System.out.println("PostLogin - SiteRequirements footerlink page displayed");
		}
		else
		{
		    System.out.println("PostLogin - SiteRequirements footerlink page was not displayed");
		}
		//Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		
		//PostLogin - AgeFiltering
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_AgeFiltering));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_AgeFiltering),brandWebsitePageObjects.PostLoginRevelfooterlnk_AgeFiltering.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginAgeFilteringTitle = driver.getTitle();
		String ExpectedPostLoginAgeFilteringTitle = "Age Filtering Software:";
		if(ActualPostLoginAgeFilteringTitle.contains(ExpectedPostLoginAgeFilteringTitle))
		{
			System.out.println("PostLogin - AgeFiltering footerlink page displayed");
		}
		else
		{
		    System.out.println("PostLogin - AgeFiltering footerlink page was not displayed");
		}
		//Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		
		//PostLogin - TermsOfUse
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_TermsOfUse));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_TermsOfUse),brandWebsitePageObjects.PostLoginRevelfooterlnk_TermsOfUse.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginTermsOfUseTitle = driver.getTitle();
		String ExpectedPostLoginTermsOfUseTitle = "Terms of use";
		if(ActualPostLoginTermsOfUseTitle.contains(ExpectedPostLoginTermsOfUseTitle))
		{
			System.out.println("PostLogin - TermsOfUse footerlink page displayed");
		}
		else
		{
		    System.out.println("PostLogin - TermsOfUse footerlink page was not displayed");
		}

		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_TermsOfUse_Restrictions), brandWebsitePageObjects.PostLoginRevelfooterlnk_TermsOfUse_Restrictions.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions_backtoTop), brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff), brandWebsitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff_backtoTop), brandWebsitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_ChoiceOfLaw), brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_ChoiceOfLaw.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.Preloginfooterlnk_TermsOfUse_ChoiceOfLaw_backtoTop), brandWebsitePageObjects.Preloginfooterlnk_TermsOfUse_ChoiceOfLaw_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes), brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes_backtoTop), brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous), brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous_backtoTop), brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous_backtoTop.getObjectname());
		
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		
		//PostLogin - PrivacyPolicy
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy),brandWebsitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginPrivacyPolicyTitle = driver.getTitle();
		String ExpectedPostLoginPrivacyPolicyTitle = "Privacy Policy";
		if(ActualPostLoginPrivacyPolicyTitle.contains(ExpectedPostLoginPrivacyPolicyTitle))
		{
			System.out.println("PostLogin - PrivacyPolicy footerlink page displayed");
		}
		else
		{
		    System.out.println("PostLogin - PrivacyPolicy footerlink page was not displayed");
		}
	
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_Whatwecollect), brandWebsitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_Whatwecollect.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_Whatwecollect_backtoTop), brandWebsitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_Whatwecollect_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_LinktoWebsites), brandWebsitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_LinktoWebsites.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_LinktoWebsites_backtoTop), brandWebsitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_LinktoWebsites_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_CaliforniaRights), brandWebsitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_CaliforniaRights.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_CaliforniaRights_backtoTop), brandWebsitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_CaliforniaRights_backtoTop.getObjectname());
		
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		
		//PreLogin - TermsOfSale
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_TermsOfSale));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_TermsOfSale),brandWebsitePageObjects.PostLoginRevelfooterlnk_TermsOfSale.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualTermsOfSaleTitle = driver.getTitle();
		String ExpectedTermsOfSaleTitle = "Terms of Sale";
		if(ActualTermsOfSaleTitle.contains(ExpectedTermsOfSaleTitle))
		{
			System.out.println("PreLogin - TermsofSale footerlink page displayed");
		}
		else
		{
			System.out.println("PreLogin - TermsofSale footerlink page was not displayed");
		}
		//Thread.sleep(5000);
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		
		
	}
	
	public void revelHomePage_Logout() throws IOException
	{
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevel_AccountMenu), brandWebsitePageObjects.PostLoginRevel_AccountMenu.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevel_LogOut), brandWebsitePageObjects.PostLoginRevel_LogOut.getObjectname());
		
	}
		
	
}
