package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.MobileSiteLoginPageObjects;
import com.rai.pageObjects.MobilesitePageObjects;
import com.rai.pageObjects.MobilesitePageObjects;

public class Mobilesite_AmericanSpiritPrePostLoginFooterLinksValidation extends BaseClass {

	String testcaseName;

	public Mobilesite_AmericanSpiritPrePostLoginFooterLinksValidation(String testcaseName) {
		this.testcaseName = testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper The {@link ScriptHelper} object passed from the
	 *                     {@link DriverScript}
	 */

	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	private WebElement getPageElement(MobilesitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("FooterLinks Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}

	public void invokeApplication_brandwebsite() {
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	}

	public void loginPage_AmericanSpiritPreLoginFooterLinksValidation() throws Exception {
		// PreLogin - FAQs footerlink
		String CurrentUrl = driver.getCurrentUrl();
		// commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginNASfooterlnk_FAQs));
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginNASfooterlnk_FAQs),
				MobilesitePageObjects.PreLoginNASfooterlnk_FAQs.getObjectname());
		Thread.sleep(5000);
		String ActualFAQsTitle = driver.getTitle();
		String ExpectedFAQsTitle = "Frequently Asked Questions";
		commonFunction.compareStrings(ExpectedFAQsTitle, ActualFAQsTitle);
		driver.navigate().to(CurrentUrl);

		// PreLogin - ContactUs
		// commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginNASfooterlnk_ContactUs));
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginNASfooterlnk_ContactUs),
				MobilesitePageObjects.PreLoginNASfooterlnk_ContactUs.getObjectname());
		Thread.sleep(5000);
		String ActualContactUsTitle = driver.getTitle();
		String ExpectedContactUsTitle = "Contact us";
		commonFunction.compareStrings(ExpectedContactUsTitle, ActualContactUsTitle);
		driver.navigate().to(CurrentUrl);

		// PreLogin - TobaccoRights
		// commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginNASfooterlnk_TobaccoRights));
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginNASfooterlnk_TobaccoRights),
				MobilesitePageObjects.PreLoginNASfooterlnk_TobaccoRights.getObjectname());
		Thread.sleep(5000);
		String ActualTobaccoRightsTitle = driver.getTitle();
		String ExpectedTobaccoRightsTitle = "Own It Voice It - Make Your Voice Heard";
		commonFunction.compareStrings(ExpectedTobaccoRightsTitle, ActualTobaccoRightsTitle);
		driver.navigate().to(CurrentUrl);

		// PreLogin - SiteRequirements
		// commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginNASfooterlnk_SiteRequirements));
		commonFunction.clickIfElementPresent(
				getPageElement(MobilesitePageObjects.PreLoginNASfooterlnk_SiteRequirements),
				MobilesitePageObjects.PreLoginNASfooterlnk_SiteRequirements.getObjectname());
		Thread.sleep(5000);
		String ActualSiteRequrmntsTitle = driver.getTitle();
		String ExpectedSiteRequrmntsTitle = "Site Requirements | Natural American Spirit";
		commonFunction.compareStrings(ExpectedSiteRequrmntsTitle, ActualSiteRequrmntsTitle);
		driver.navigate().to(CurrentUrl);

		// PreLogin - AgeFiltering
		// commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginNASfooterlnk_AgeFiltering));
		// commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginNASfooterlnk_AgeFiltering),MobilesitePageObjects.PreLoginNASfooterlnk_AgeFiltering.getObjectname());

		// String ActualAgeFilteringTitle = driver.getTitle();
		// String ExpectedAgeFilteringTitle = "Age Filtering Software:";
		// commonFunction.compareStrings(ExpectedAgeFilteringTitle,
		// ActualAgeFilteringTitle);

		// driver.navigate().to(CurrentUrl);
		// commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btnSignInTab),
		// MobilesitePageObjects.btnSignInTab.getObjectname());
		// commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());

		// PreLogin - TermsOfUse
		// commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginNASfooterlnk_TermsOfUse));
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginNASfooterlnk_TermsOfUse),
				MobilesitePageObjects.PreLoginNASfooterlnk_TermsOfUse.getObjectname());
		Thread.sleep(5000);
		String ActualTermsofUseTitle = driver.getTitle();
		String ExpectedTermsofUseTitle = "Terms of use";
		commonFunction.compareStrings(ExpectedTermsofUseTitle, ActualTermsofUseTitle);
		driver.navigate().to(CurrentUrl);

		// PreLogin - PrivacyPolicy
		// commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginNASfooterlnk_PrivacyPolicy));
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginNASfooterlnk_PrivacyPolicy),
				MobilesitePageObjects.PreLoginNASfooterlnk_PrivacyPolicy.getObjectname());
		Thread.sleep(5000);
		String ActualPrivacyPolicyTitle = driver.getTitle();
		String ExpectedPrivacyPolicyTitle = "Privacy Policy and Your California Privacy Rights";
		commonFunction.compareStrings(ExpectedPrivacyPolicyTitle, ActualPrivacyPolicyTitle);
		driver.navigate().to(CurrentUrl);
	}

	public void loginPage_AppToWebsiteLogin() throws InterruptedException, IOException {

		String Username = dataTable.getData("General_Data", "Username");
		String Password = dataTable.getData("General_Data", "Password");
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btnSignInTab),
				MobilesitePageObjects.btnSignInTab.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_LoginUsername), Username,
				MobilesitePageObjects.txt_LoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_LoginPassword), Password,
				MobilesitePageObjects.txt_LoginPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),
				MobilesitePageObjects.btn_Login.getObjectname());
		Thread.sleep(5000);
	}

	public void homePage_AmericanSpiritPostLoginFooterLinksValidation() throws Exception {
		Thread.sleep(3000);
		// PostLogin - SFNTC footerlink
		String CurrentUrl = driver.getCurrentUrl();
		//commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginNASfooterlnk_SFNTC));
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginNASfooterlnk_SFNTC),
				MobilesitePageObjects.PostLoginNASfooterlnk_SFNTC.getObjectname());
		Thread.sleep(5000);
		String ActualPostLoginFAQsTitle = driver.getTitle();
		String ExpectedPostLoginFAQsTitle = "Frequently Asked Questions";
		commonFunction.compareStrings(ExpectedPostLoginFAQsTitle, ActualPostLoginFAQsTitle);
		driver.navigate().to(CurrentUrl);

		// PostLogin - ResponsibleMarketing footer link
		// commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginNASfooterlnk_ResponsibleMarketing));
		commonFunction.clickIfElementPresent(
				getPageElement(MobilesitePageObjects.PostLoginNASfooterlnk_ResponsibleMarketing),
				MobilesitePageObjects.PostLoginNASfooterlnk_ResponsibleMarketing.getObjectname());
		Thread.sleep(5000);
		String ActualPostLoginMarketingTitle = driver.getTitle();
		String ExpectedPostLoginMarketingTitle = "Responsible Marketing";
		commonFunction.compareStrings(ExpectedPostLoginMarketingTitle, ActualPostLoginMarketingTitle);

		driver.navigate().to(CurrentUrl);
		Thread.sleep(3000);
		// PostLogin - ContactUs footer link
		// commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginNASfooterlnk_ContactUs));
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginNASfooterlnk_ContactUs),
				MobilesitePageObjects.PostLoginNASfooterlnk_ContactUs.getObjectname());
		Thread.sleep(5000);
		String ActualPostLoginContactUsTitle = driver.getTitle();
		String ExpectedPostLoginContactUsTitle = "Contact us";
		commonFunction.compareStrings(ExpectedPostLoginContactUsTitle, ActualPostLoginContactUsTitle);

		commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_ContactUsQuestion), 2,
				MobilesitePageObjects.PostLoginfooterlnk_ContactUsQuestion.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_ContactUsAnswer),
				"Validate", MobilesitePageObjects.PostLoginfooterlnk_ContactUsAnswer.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_ContactUsSubmit),
				MobilesitePageObjects.PostLoginfooterlnk_ContactUsSubmit.getObjectname());
		driver.navigate().to(CurrentUrl);
		Thread.sleep(3000);
		// PostLogin - TobaccoRights
		// commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginNASfooterlnk_TobaccoRights));
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginNASfooterlnk_TobaccoRights),
				MobilesitePageObjects.PostLoginNASfooterlnk_TobaccoRights.getObjectname());
		Thread.sleep(5000);
		String ActualPostLoginTobaccoRightsTitle = driver.getTitle();
		String ExpectedPostLoginTobaccoRightsTitle = "Own It Voice It - Make Your Voice Heard";
		commonFunction.compareStrings(ExpectedPostLoginTobaccoRightsTitle, ActualPostLoginTobaccoRightsTitle);

		driver.navigate().to(CurrentUrl);
		Thread.sleep(3000);
		// PostLogin - SiteRequirements
		// commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginNASfooterlnk_SiteRequirements));
		commonFunction.clickIfElementPresent(
				getPageElement(MobilesitePageObjects.PostLoginNASfooterlnk_SiteRequirements),
				MobilesitePageObjects.PostLoginNASfooterlnk_SiteRequirements.getObjectname());
		Thread.sleep(5000);
		String ActualPostLoginSiteRequirementsTitle = driver.getTitle();
		String ExpectedPostLoginSiteRequirementsTitle = "Site Requirements";
		commonFunction.compareStringsContains(ExpectedPostLoginSiteRequirementsTitle, ActualPostLoginSiteRequirementsTitle);

		driver.navigate().to(CurrentUrl);
		Thread.sleep(3000);
		// PostLogin - AgeFiltering
		// commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginNASfooterlnk_AgeFiltering));
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginNASfooterlnk_AgeFiltering),
				MobilesitePageObjects.PostLoginNASfooterlnk_AgeFiltering.getObjectname());
		Thread.sleep(5000);
		//String ActualPostLoginAgeFilteringTitle = driver.getTitle();
		//String ExpectedPostLoginAgeFilteringTitle = "Age Filtering Software:";
		//commonFunction.compareStrings(ExpectedPostLoginAgeFilteringTitle, ActualPostLoginAgeFilteringTitle);
		//Thread.sleep(5000);
		driver.navigate().to(CurrentUrl);
		Thread.sleep(3000);
		// PostLogin - TermsOfUse
		// commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginNASfooterlnk_TermsOfUse));
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginNASfooterlnk_TermsOfUse),
				MobilesitePageObjects.PostLoginNASfooterlnk_TermsOfUse.getObjectname());
		Thread.sleep(5000);
		String ActualPostLoginTermsOfUseTitle = driver.getTitle();
		String ExpectedPostLoginTermsOfUseTitle = "Terms of use";
		commonFunction.compareStrings(ExpectedPostLoginTermsOfUseTitle, ActualPostLoginTermsOfUseTitle);

		driver.navigate().to(CurrentUrl);
		Thread.sleep(3000);
		// PostLogin - PrivacyPolicy
		// commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginNASfooterlnk_PrivacyPolicy));
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginNASfooterlnk_PrivacyPolicy),
				MobilesitePageObjects.PostLoginNASfooterlnk_PrivacyPolicy.getObjectname());
		Thread.sleep(5000);
		String ActualPostLoginPrivacyPolicyTitle = driver.getTitle();
		String ExpectedPostLoginPrivacyPolicyTitle = "Privacy Policy and Your California Privacy Rights";
		commonFunction.compareStrings(ExpectedPostLoginPrivacyPolicyTitle, ActualPostLoginPrivacyPolicyTitle);

		driver.navigate().to(CurrentUrl);

	}

	public void americanSpiritHomePage_Logout() throws IOException {

		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginNASfooterlnk_LogOut),
				MobilesitePageObjects.PostLoginNASfooterlnk_LogOut.getObjectname());

	}

}
