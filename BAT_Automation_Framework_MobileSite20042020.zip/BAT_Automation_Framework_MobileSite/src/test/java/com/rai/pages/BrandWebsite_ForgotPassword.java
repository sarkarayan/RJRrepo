package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.brandWebsitePageObjects;

public class BrandWebsite_ForgotPassword extends BaseClass {

	String testcaseName;
	public BrandWebsite_ForgotPassword(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(brandWebsitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("ForgotPassword Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	public void invokeApplication_brandwebsite()
	{
		String WebsiteURL = dataTable.getData("General_Data","URL");
		
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
	
	public void forgotPassword_EnterValidUsername() throws IOException
	{
		String Email = dataTable.getData("General_Data", "Email");
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.lnktxt_Forgotpassword), brandWebsitePageObjects.lnktxt_Forgotpassword.getObjectname());
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordUsername), Email, brandWebsitePageObjects.txt_ForgotPasswordUsername.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue), brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
			
	}
	
	public void forgotPassword_ValidateGeneralInformationPage() throws InterruptedException, IOException
	{
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
        String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordBirthMonth), month, brandWebsitePageObjects.drpdwn_ForgotPasswordBirthMonth.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordBirthDay), day, brandWebsitePageObjects.drpdwn_ForgotPasswordBirthDay.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordBirthYear), year,brandWebsitePageObjects.drpdwn_ForgotPasswordBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordFirstName), FirstName, brandWebsitePageObjects.txt_ForgotPasswordFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordLastName), LastName, brandWebsitePageObjects.txt_ForgotPasswordLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordAddress), Address, brandWebsitePageObjects.txt_ForgotPasswordAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordZipcode), Zipcode, brandWebsitePageObjects.txt_ForgotPasswordZipcode.getObjectname());
		Thread.sleep(4000);
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation), brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation.getObjectname());
		
	}
	
	public void forgotPassword_VerifyIdentity() throws InterruptedException, IOException
	{
		String ChallengeAnswer = dataTable.getData("General_Data", "ChallengeAnswer");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordChallengeAnswer), ChallengeAnswer, brandWebsitePageObjects.txt_ForgotPasswordChallengeAnswer.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity), brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
		Thread.sleep(4000);		
		
	}
	
	public void forgotPassword_ResetPassword() throws InterruptedException, IOException
	{
		String Password = dataTable.getData("General_Data", "Password");
		String ConfirmPassword = dataTable.getData("General_Data", "Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordPassword), Password, brandWebsitePageObjects.txt_ForgotPasswordPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordConfirmPassword), ConfirmPassword, brandWebsitePageObjects.txt_ForgotPasswordConfirmPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordResetPassword), brandWebsitePageObjects.btn_ForgotPasswordResetPassword.getObjectname());
		Thread.sleep(4000);
	}
	
	public void forgotPassword_CongratsPage() throws IOException
	{
		String Email = dataTable.getData("General_Data", "Email");;
		String Password = dataTable.getData("General_Data", "Password");
		
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_CongratsPageUsername),Email, brandWebsitePageObjects.txt_CongratsPageUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_CongratsPagePassword), Password,brandWebsitePageObjects.txt_CongratsPagePassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_CongratsPageLoginbutton), brandWebsitePageObjects.btn_CongratsPageLoginbutton.getObjectname());
		
	}
	
	
	
}
