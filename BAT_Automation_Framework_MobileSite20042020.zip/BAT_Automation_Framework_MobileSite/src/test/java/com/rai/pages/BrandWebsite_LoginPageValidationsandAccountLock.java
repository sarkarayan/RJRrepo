package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;

import com.rai.pageObjects.brandWebsitePageObjects;

public class BrandWebsite_LoginPageValidationsandAccountLock extends BaseClass {

	String testcaseName;
	public BrandWebsite_LoginPageValidationsandAccountLock(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(brandWebsitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Login Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	public void invokeApplication_brandwebsite()
	{
	    String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
	
	public void loginPage_fieldValidations() throws IOException 
	{
          String NonExistUserId = dataTable.getData("General_Data","NonExistUserId");
          String ValidPassword = dataTable.getData("General_Data","Password");
          String InvalidUserIdformat = dataTable.getData("General_Data","InvalidUserIDformat");
		
        //Login without any data
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login), brandWebsitePageObjects.btn_Login.getObjectname());
		String Actualerrormsg_LoginwithoutanyData = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_LoginwithoutanyData));
		String Expectederrormsg_LoginwithoutanyData = "Please Provide a Username / Email Address.";
		if(Actualerrormsg_LoginwithoutanyData.contentEquals(Expectederrormsg_LoginwithoutanyData))
		{
			System.out.println("LoginPage - Expected errormsg displayed when user clicked on Login without any data");
		}
		else
		{
			System.out.println("LoginPage - Expected errormsg not displayed when user clicked on Login without any data");
		}
		
		//Login with Username not exists in DB
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginUsername),NonExistUserId,brandWebsitePageObjects.txt_LoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginPassword),ValidPassword, brandWebsitePageObjects.txt_LoginPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login), brandWebsitePageObjects.btn_Login.getObjectname());
		
		String Actualerrormsg_LoginwithNonExistUserId = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_LoginwithNonExistingUserId));
		String Expectederrormsg_LoginwithNonExistUserId = "Username Does Not Exist.";
		if(Actualerrormsg_LoginwithNonExistUserId.contentEquals(Expectederrormsg_LoginwithNonExistUserId))
		{
			System.out.println("LoginPage - Expected errormsg displayed when user try to login with NonExist UserId");
		}
		else
		{
			System.out.println("LoginPage - Expected errormsg not displayed when user try to login with NonExist UserId");
		}
		
		//Login with UserId(having unaccepted characters)
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginUsername),InvalidUserIdformat,brandWebsitePageObjects.txt_LoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginPassword),ValidPassword, brandWebsitePageObjects.txt_LoginPassword.getObjectname());
		//commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login), brandWebsitePageObjects.btn_Login.getObjectname());
		
		String Actualerrormsg_LoginwithUserIdwithunacceptedcharacters = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_Usernamefieldformaterror));
		String Expectederrormsg_LoginwithUserIdwithunacceptedcharacters = "Username must be a combination of 8-30 letters and numbers.";
		if(Actualerrormsg_LoginwithUserIdwithunacceptedcharacters.contentEquals(Expectederrormsg_LoginwithUserIdwithunacceptedcharacters))
		{
			System.out.println("LoginPage - Expected errormsg displayed when user try to login with UserId with Unaccepted characters");
		}
		else
		{
			System.out.println("LoginPage - Expected errormsg not displayed when user try to login with UserId with Unaccepted characters");
		}		
		
	}
	
	public void loginPage_Loginwith128characters() throws IOException, InterruptedException
	{
		String ValidUserId = dataTable.getData("General_Data","Username");
		String ValidPassword = dataTable.getData("General_Data","Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginUsername),ValidUserId,brandWebsitePageObjects.txt_LoginUsername.getObjectname());
        commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginPassword),ValidPassword,brandWebsitePageObjects.txt_LoginPassword.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login), brandWebsitePageObjects.btn_Login.getObjectname());
		//Thread.sleep(4000);
        commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginCamelfooterlnk_Logout), brandWebsitePageObjects.PostLoginCamelfooterlnk_Logout.getObjectname());

	}
	
	
	public void loginPage_ValidateErrormsg_AccountLock() throws IOException
	{
		String ValidUserId = dataTable.getData("General_Data","Username");
        String InvalidPassword = dataTable.getData("General_Data","InvalidPassword");
        
        //User entered Invalid password for 1st time
        commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginUsername),ValidUserId,brandWebsitePageObjects.txt_LoginUsername.getObjectname());
        commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginPassword),InvalidPassword,brandWebsitePageObjects.txt_LoginPassword.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login), brandWebsitePageObjects.btn_Login.getObjectname());
        
        String Actualerrormsg_invalidPassword1sttime = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_WrongPasswrd));
        String Expectederrormsg_invalidPassword1sttime = "Username and Password do not match.";
        if(Actualerrormsg_invalidPassword1sttime.contentEquals(Expectederrormsg_invalidPassword1sttime))
        {
        	System.out.println("LoginPage - Expected errormsg displayed when user enters InvalidPassword for 1st time");
        }
        else
        {
        	System.out.println("LoginPage - Expected errormsg displayed when user enters InvalidPassword for 1st time");
        }
        
        //User entered Invalid password for 2nd time
        commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginPassword),InvalidPassword,brandWebsitePageObjects.txt_LoginPassword.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login), brandWebsitePageObjects.btn_Login.getObjectname());
        
        String Actualerrormsg_invalidPassword2ndtime = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_WrongPasswrd));
        String Expectederrormsg_invalidPassword2ndtime = "Username and Password do not match.";
        if(Actualerrormsg_invalidPassword2ndtime.contentEquals(Expectederrormsg_invalidPassword2ndtime))
        {
        	System.out.println("LoginPage - Expected errormsg displayed when user enters InvalidPassword for 2nd time");
        }
        else
        {
        	System.out.println("LoginPage - Expected errormsg displayed when user enters InvalidPassword for 2nd time");
        }
        
        //User entered Invalid password for 3rd time
        commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginPassword),InvalidPassword,brandWebsitePageObjects.txt_LoginPassword.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login), brandWebsitePageObjects.btn_Login.getObjectname());
        
        String Actualerrormsg_invalidPassword3rdtime = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_WrongPasswrd));
        String Expectederrormsg_invalidPassword3rdtime = "Username and Password do not match.";
        if(Actualerrormsg_invalidPassword3rdtime.contentEquals(Expectederrormsg_invalidPassword3rdtime))
        {
        	System.out.println("LoginPage - Expected errormsg displayed when user enters InvalidPassword for 3rd time");
        }
        else
        {
        	System.out.println("LoginPage - Expected errormsg displayed when user enters InvalidPassword for 3rd time");
        }
        
        //User entered Invalid password for 4th time
        commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginPassword),InvalidPassword,brandWebsitePageObjects.txt_LoginPassword.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login), brandWebsitePageObjects.btn_Login.getObjectname());
        
        String Actualerrormsg_invalidPassword4thtime = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_WrongPasswrd));
        String Expectederrormsg_invalidPassword4thtime = "Username and Password do not match.";
        if(Actualerrormsg_invalidPassword4thtime.contentEquals(Expectederrormsg_invalidPassword4thtime))
        {
        	System.out.println("LoginPage - Expected errormsg displayed when user enters InvalidPassword for 4th time");
        }
        else
        {
        	System.out.println("LoginPage - Expected errormsg displayed when user enters InvalidPassword for 4th time");
        }
        
//        //User entered Invalid password for 5th time
//        commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginPassword),InvalidPassword,brandWebsitePageObjects.txt_LoginPassword.getObjectname());
//        commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login), brandWebsitePageObjects.btn_Login.getObjectname());
//        
//        String Actualerrormsg_AccountLocked = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_Accountlocked));
//        String Expectederrormsg_AccountLocked = "Username and password do not match. account now locked. Click ";
//        if(Actualerrormsg_AccountLocked.contains(Expectederrormsg_AccountLocked))
//        {
//        	System.out.println("LoginPage - Expected errormsg displayed when User Account get locked");
//        }
//        else
//        {
//        	System.out.println("LoginPage - Expected errormsg not displayed when User Account get locked");
//        }
	}
	
	
	public void loginPage_ResetLockedAccount() throws InterruptedException, IOException
	{
		String Email = dataTable.getData("General_Data", "Email");
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
		String ChallengeAnswer = dataTable.getData("General_Data", "ChallengeAnswer");
		String Password = dataTable.getData("General_Data", "Password");
		String ConfirmPassword = dataTable.getData("General_Data", "Password");
				
		String date = dataTable.getData("General_Data","DOB");
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.lnk_LockedAccntResetlink),brandWebsitePageObjects.lnk_LockedAccntResetlink.getObjectname());
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordUsername), Email, brandWebsitePageObjects.txt_ForgotPasswordUsername.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue), brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
		
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordBirthMonth), month, brandWebsitePageObjects.drpdwn_ForgotPasswordBirthMonth.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordBirthDay), day, brandWebsitePageObjects.drpdwn_ForgotPasswordBirthDay.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordBirthYear), year,brandWebsitePageObjects.drpdwn_ForgotPasswordBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordFirstName), FirstName, brandWebsitePageObjects.txt_ForgotPasswordFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordLastName), LastName, brandWebsitePageObjects.txt_ForgotPasswordLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordAddress), Address, brandWebsitePageObjects.txt_ForgotPasswordAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordZipcode), Zipcode, brandWebsitePageObjects.txt_ForgotPasswordZipcode.getObjectname());
		Thread.sleep(2000);
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordCity), City, brandWebsitePageObjects.txt_ForgotPasswordCity.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordState),State, brandWebsitePageObjects.drpdwn_ForgotPasswordState.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation), brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation.getObjectname());
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordChallengeAnswer), ChallengeAnswer, brandWebsitePageObjects.txt_ForgotPasswordChallengeAnswer.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity), brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
		//Thread.sleep(4000);
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordPassword), Password, brandWebsitePageObjects.txt_ForgotPasswordPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordConfirmPassword), ConfirmPassword, brandWebsitePageObjects.txt_ForgotPasswordConfirmPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordResetPassword), brandWebsitePageObjects.btn_ForgotPasswordResetPassword.getObjectname());
		//Thread.sleep(4000);
		
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_CongratsPageUsername),Email, brandWebsitePageObjects.txt_CongratsPageUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_CongratsPagePassword), Password,brandWebsitePageObjects.txt_CongratsPagePassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_CongratsPageLoginbutton), brandWebsitePageObjects.btn_CongratsPageLoginbutton.getObjectname());
			
	}
	public void vuseloginPage_fieldValidations() throws IOException 
	{
          String NonExistUserId = dataTable.getData("General_Data","NonExistUserId");
          String ValidPassword = dataTable.getData("General_Data","Password");
          String InvalidUserIdformat = dataTable.getData("General_Data","InvalidUserIDformat");
          
        commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.loginLnk_VUSECertifyAgePage), brandWebsitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		
        //Login without any data
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_VUSELogin), brandWebsitePageObjects.btn_VUSELogin.getObjectname());
		String Errormsg_LoginwithoutanyData = "Please enter your username";
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_VUSELoginwithoutanyDataUsername), brandWebsitePageObjects.errormsg_VUSELoginwithoutanyDataUsername.getObjectname(), Errormsg_LoginwithoutanyData);
		
		
		//Login with Username not exists in DB
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginUsername),NonExistUserId,brandWebsitePageObjects.txt_VUSELoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginPassword),ValidPassword, brandWebsitePageObjects.txt_VUSELoginPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_VUSELogin), brandWebsitePageObjects.btn_VUSELogin.getObjectname());
		
		String Errormsg_LoginwithNonExistUserId = "Username does not exist.";
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_VUSELoginwithNonExistingUserId), brandWebsitePageObjects.errormsg_VUSELoginwithNonExistingUserId.getObjectname(), Errormsg_LoginwithNonExistUserId);
		
		
		//Login with UserId(having unaccepted characters)
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginUsername),InvalidUserIdformat,brandWebsitePageObjects.txt_VUSELoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginPassword),ValidPassword, brandWebsitePageObjects.txt_VUSELoginPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_VUSELogin), brandWebsitePageObjects.btn_VUSELogin.getObjectname());
		
		String Errormsg_LoginwithUserIdwithunacceptedcharacters = "Username does not exist.";
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_VUSEUsernamefieldformaterror), brandWebsitePageObjects.errormsg_VUSEUsernamefieldformaterror.getObjectname(), Errormsg_LoginwithUserIdwithunacceptedcharacters);	
		
	}
	
	public void loginPage_VUSELoginwith128characters() throws IOException, InterruptedException
	{
		String ValidUserId = dataTable.getData("General_Data","Username");
		String ValidPassword = dataTable.getData("General_Data","Password");
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.loginLnk_VUSECertifyAgePage), brandWebsitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginUsername),ValidUserId,brandWebsitePageObjects.txt_VUSELoginUsername.getObjectname());
        commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginPassword),ValidPassword,brandWebsitePageObjects.txt_VUSELoginPassword.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_VUSELogin), brandWebsitePageObjects.btn_VUSELogin.getObjectname());

	}
	
	public void vuseloginPage_ValidateErrormsg_AccountLock() throws IOException
	{
		
		String ValidUserId = dataTable.getData("General_Data","Username");
	    String InvalidPassword = dataTable.getData("General_Data","InvalidPassword");
	    
	    commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.loginLnk_VUSECertifyAgePage), brandWebsitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
	        
	    //User entered Invalid password for 1st time
	    commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginUsername),ValidUserId,brandWebsitePageObjects.txt_VUSELoginUsername.getObjectname());
	    commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginPassword),InvalidPassword,brandWebsitePageObjects.txt_VUSELoginPassword.getObjectname());
	    commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_VUSELogin), brandWebsitePageObjects.btn_VUSELogin.getObjectname());
	        
	    String Errormsg_invalidPassword1sttime = "Login or Password incorrect";
	    commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_VUSELoginWrongPassword), brandWebsitePageObjects.errormsg_VUSELoginWrongPassword.getObjectname(), Errormsg_invalidPassword1sttime);
	   
	        
	    //User entered Invalid password for 2nd time
	    commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginUsername),ValidUserId,brandWebsitePageObjects.txt_VUSELoginUsername.getObjectname());
	    commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginPassword),InvalidPassword,brandWebsitePageObjects.txt_VUSELoginPassword.getObjectname());
	    commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_VUSELogin), brandWebsitePageObjects.btn_VUSELogin.getObjectname());
	        
	    String Errormsg_invalidPassword2ndtime = "Login or Password incorrect";
	    commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_VUSELoginWrongPassword), brandWebsitePageObjects.errormsg_VUSELoginWrongPassword.getObjectname(), Errormsg_invalidPassword2ndtime);
	   
	        
	    //User entered Invalid password for 3rd time
	    commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginUsername),ValidUserId,brandWebsitePageObjects.txt_VUSELoginUsername.getObjectname());
	    commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginPassword),InvalidPassword,brandWebsitePageObjects.txt_VUSELoginPassword.getObjectname());
	    commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_VUSELogin), brandWebsitePageObjects.btn_VUSELogin.getObjectname());
	        
	    String Errormsg_invalidPassword3rdtime = "Login or Password incorrect";
	    commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_VUSELoginWrongPassword), brandWebsitePageObjects.errormsg_VUSELoginWrongPassword.getObjectname(), Errormsg_invalidPassword3rdtime);
	   
	        
	    //User entered Invalid password for 4th time
	    commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginUsername),ValidUserId,brandWebsitePageObjects.txt_VUSELoginUsername.getObjectname());
	    commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginPassword),InvalidPassword,brandWebsitePageObjects.txt_VUSELoginPassword.getObjectname());
	    commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_VUSELogin), brandWebsitePageObjects.btn_VUSELogin.getObjectname());
	        
	    String Errormsg_AccountLocked = "Username or password incorrect, account now locked. Click";
	    commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_VUSEAccountLocked), brandWebsitePageObjects.errormsg_VUSEAccountLocked.getObjectname(), Errormsg_AccountLocked);
	    
	    //commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.lnk_VUSEAccntResetlink),brandWebsitePageObjects.lnk_VUSEAccntResetlink.getObjectname());
	  
	}
	
	
		
	
	
}

