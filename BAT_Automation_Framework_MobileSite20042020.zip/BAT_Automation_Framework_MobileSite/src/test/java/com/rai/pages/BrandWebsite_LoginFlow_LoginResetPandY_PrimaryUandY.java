package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.brandWebsitePageObjects;

public class BrandWebsite_LoginFlow_LoginResetPandY_PrimaryUandY extends BaseClass {

	String testcaseName;
	public BrandWebsite_LoginFlow_LoginResetPandY_PrimaryUandY(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(brandWebsitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	public void invokeApplication_brandwebsite()
	{
		String WebsiteURL = dataTable.getData("General_Data","URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
	public void login_EnterValidDataPandY() throws IOException
	{
		
		String Email = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data","Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginUsername),Email,brandWebsitePageObjects.txt_LoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginPassword),Password,brandWebsitePageObjects.txt_LoginPassword.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login),brandWebsitePageObjects.btn_Login.getObjectname());
	}
	
		
	public void resetflow_GeneralInfoPageviaLogin() throws InterruptedException, IOException
	{
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
		String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
				
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_ForgotUsernameBirthMonth), month, brandWebsitePageObjects.drpdwn_ForgotUsernameBirthMonth.getObjectname());
		Thread.sleep(5000);
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotUsernameBirthDay),day,brandWebsitePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotUsernameBirthYear), year, brandWebsitePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotUsernameFirstName), FirstName, brandWebsitePageObjects.txt_ForgotUsernameFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotUsernameLastName), LastName, brandWebsitePageObjects.txt_ForgotUsernameLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotUsernameAddress), Address, brandWebsitePageObjects.txt_ForgotUsernameAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotUsernameZipcode), Zipcode,brandWebsitePageObjects.txt_ForgotUsernameZipcode.getObjectname());
		Thread.sleep(4000);
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotUsernameCity), City, brandWebsitePageObjects.txt_ForgotUsernameCity.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotUsernameState),State, brandWebsitePageObjects.drpdwn_ForgotUsernameState.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.Continuebtn_LoginResetviaLoginonGeneralInfo),brandWebsitePageObjects.Continuebtn_LoginResetviaLoginonGeneralInfo.getObjectname());
				
	}
	
	public void resetflow_NegativeValidationsAccountInfoPage() throws IOException, InterruptedException
	{
		
		String InActiveEmail = dataTable.getData("General_Data","NonExistUserId");
		String ExistingEmail = dataTable.getData("General_Data","ExistingUserId");
		String InvalidEmail = dataTable.getData("General_Data","InvalidUserIDformat");
		String Password = dataTable.getData("General_Data","Password");
		String InvalidPasswordformat = dataTable.getData("General_Data","InvalidPasswordformat");
		String DifferentPassword = dataTable.getData("General_Data","InvalidPassword");
		
		
		String Errormsg_NoDataEntered = "Please fix the errors above";
		String Errormsg_NoEmailEntered = "Please enter a valid email address";
		String Errormsg_InvalidEmailEntered = "Please enter a valid email address";
		String Errormsg_InActiveEmailEntered = "This is not an active email address. Please provide an active email address.";
		String Errormsg_ExistingEmailEntered = "Username already taken. Please try a different one.";
		String Errormsg_NoPasswordEntered = "Please provide a password";
		String Errormsg_InvalidPasswordformatEntered = "Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.";
		String Errormsg_DifferentPasswordEntered = "Passwords did not match";
		String Errormsg_NoChallengeQuestion = "Please select a account recovery question";
		String Errormsg_NoChallengeAnswerEntered = "Please provide an answer to account recovery question";
		
		
		//User clicked on Save without any data
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_LoginResetAccntInfoSave), brandWebsitePageObjects.btn_LoginResetAccntInfoSave.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_LoginResetAccntInfoNoDataEntered), brandWebsitePageObjects.errormsg_LoginResetAccntInfoNoDataEntered.getObjectname(), Errormsg_NoDataEntered);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_LoginResetAcctInfoNoEmailEntered), brandWebsitePageObjects.errormsg_LoginResetAcctInfoNoEmailEntered.getObjectname(), Errormsg_NoEmailEntered);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_LoginResetAccntInfoNoPassword), brandWebsitePageObjects.errormsg_LoginResetAccntInfoNoPassword.getObjectname(), Errormsg_NoPasswordEntered);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_LoginResetAccntInfoNoChallengeQuestion), brandWebsitePageObjects.errormsg_LoginResetAccntInfoNoChallengeQuestion.getObjectname(), Errormsg_NoChallengeQuestion);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_LoginResetAccntInfoNoChallengeAnswer), brandWebsitePageObjects.errormsg_LoginResetAccntInfoNoChallengeAnswer.getObjectname(), Errormsg_NoChallengeAnswerEntered);
		
		//User entered InvalidEmail
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginResetAccntInfoEmail),InvalidEmail, brandWebsitePageObjects.txt_LoginResetAccntInfoEmail.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_LoginResetAccntInfoInvalidEmail), brandWebsitePageObjects.errormsg_LoginResetAccntInfoInvalidEmail.getObjectname(), Errormsg_InvalidEmailEntered);
		
		//User entered InactiveEmail
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginResetAccntInfoEmail),InActiveEmail, brandWebsitePageObjects.txt_LoginResetAccntInfoEmail.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_LoginResetAccntInfoInactiveEmail), brandWebsitePageObjects.errormsg_LoginResetAccntInfoInactiveEmail.getObjectname(), Errormsg_InActiveEmailEntered);
		
		//User entered ExistingEmail
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginResetAccntInfoEmail),ExistingEmail, brandWebsitePageObjects.txt_LoginResetAccntInfoEmail.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_LoginResetAccntInfoExistingEmail), brandWebsitePageObjects.errormsg_LoginResetAccntInfoExistingEmail.getObjectname(), Errormsg_ExistingEmailEntered);
		
		
		//User entered InvalidPassword format
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginResetAccntInfoPassword),InvalidPasswordformat, brandWebsitePageObjects.txt_LoginResetAccntInfoPassword.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_LoginResetAccntInfoInvalidPasswordFormat), brandWebsitePageObjects.errormsg_LoginResetAccntInfoInvalidPasswordFormat.getObjectname(), Errormsg_InvalidPasswordformatEntered);
		
		//User entered Differntdata in password & Confirm password fields
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginResetAccntInfoPassword),Password, brandWebsitePageObjects.txt_LoginResetAccntInfoPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginResetAccntInfoConfirmPassword),DifferentPassword, brandWebsitePageObjects.txt_LoginResetAccntInfoConfirmPassword.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_LoginResetAccntInfoDifferentPasswordEntered), brandWebsitePageObjects.errormsg_LoginResetAccntInfoDifferentPasswordEntered.getObjectname(), Errormsg_DifferentPasswordEntered);
	}
	
	
	public void resetflow_AccountInfoPage() throws Exception
	{
		String Email = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data","Password");
		String ConfirmPassword = dataTable.getData("General_Data","Password");
		String Question = dataTable.getData("General_Data","ChallengeQuestion");
		String Answer = dataTable.getData("General_Data","ChallengeAnswer");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginResetAccntInfoEmail),Email, brandWebsitePageObjects.txt_LoginResetAccntInfoEmail.getObjectname());
		Thread.sleep(5000);
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginResetAccntInfoPassword),Password,brandWebsitePageObjects.txt_LoginResetAccntInfoPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginResetAccntInfoConfirmPassword),ConfirmPassword,brandWebsitePageObjects.txt_LoginResetAccntInfoConfirmPassword.getObjectname());
		
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdnw_LoginResetAccntInfoChallengeQuestion), Question,brandWebsitePageObjects.drpdnw_LoginResetAccntInfoChallengeQuestion.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginResetAccntInfoChallengeAnswer), Answer, brandWebsitePageObjects.txt_LoginResetAccntInfoChallengeAnswer.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_LoginResetAccntInfoSave), brandWebsitePageObjects.btn_LoginResetAccntInfoSave.getObjectname());
	}
	
	public void login_VUSEEnterValidDataPandY() throws IOException
	{
		
		String Email = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data","Password");
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.loginLnk_VUSECertifyAgePage),brandWebsitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		
		//commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.header_VUSELogin),brandWebsitePageObjects.header_VUSELogin.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginUsername),Email,brandWebsitePageObjects.txt_VUSELoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginPassword),Password,brandWebsitePageObjects.txt_VUSELoginPassword.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_VUSELogin),brandWebsitePageObjects.btn_VUSELogin.getObjectname());
	}
	
	public void resetflow_CongratsPage() throws IOException
	{
		
		String Email = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data", "Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginResetCongratsPageEmail), Email,brandWebsitePageObjects.txt_LoginResetCongratsPageEmail.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginResetCongratsPagePassword),Password,brandWebsitePageObjects.txt_LoginResetCongratsPagePassword.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_LoginResetCongratsPageLogin), brandWebsitePageObjects.btn_LoginResetCongratsPageLogin.getObjectname());
	}
	
	
	

	
	
	
}

