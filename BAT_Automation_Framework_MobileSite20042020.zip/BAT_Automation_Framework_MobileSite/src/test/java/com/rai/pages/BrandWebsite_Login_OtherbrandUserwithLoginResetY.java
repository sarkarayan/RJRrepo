package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.brandWebsitePageObjects;

public class BrandWebsite_Login_OtherbrandUserwithLoginResetY extends BaseClass {

	String testcaseName;
	public BrandWebsite_Login_OtherbrandUserwithLoginResetY(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(brandWebsitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("OtherBrand H User with Reset N - ContactUs Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	public void invokeApplication_brandwebsite()
	{
		String WebsiteURL = dataTable.getData("General_Data","URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
	public void login_EnterValidData() throws IOException
	{
		
		String Email = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data","Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginUsername),Email,brandWebsitePageObjects.txt_LoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginPassword),Password,brandWebsitePageObjects.txt_LoginPassword.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login),brandWebsitePageObjects.btn_Login.getObjectname());
	}
	
	public void vuselogin_EnterValidData() throws IOException
	{
		
		String Email = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data","Password");
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.loginLnk_VUSECertifyAgePage),brandWebsitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.header_VUSELogin),brandWebsitePageObjects.header_VUSELogin.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginUsername),Email,brandWebsitePageObjects.txt_VUSELoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginPassword),Password,brandWebsitePageObjects.txt_VUSELoginPassword.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_VUSELogin),brandWebsitePageObjects.btn_VUSELogin.getObjectname());
	}
	
	
	public void loginPage_OtherBrandHandSUserwithResetY() throws Exception 
	{
		
		String ExpectedErrormsg = "Username Does Not Exist.";
		
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_LoginwithNonExistingUserId), brandWebsitePageObjects.errormsg_LoginwithNonExistingUserId.getObjectname(), ExpectedErrormsg);
			
	}
	
	public void vuseLoginPage_OtherBrandHandSUserwithResetY() throws Exception 
	{
		
		String ExpectedErrormsg = "Username does not exist.";
		
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_VUSELoginwithNonExistingUserId), brandWebsitePageObjects.errormsg_VUSELoginwithNonExistingUserId.getObjectname(), ExpectedErrormsg);
			
	}
	
	
	
	
}

