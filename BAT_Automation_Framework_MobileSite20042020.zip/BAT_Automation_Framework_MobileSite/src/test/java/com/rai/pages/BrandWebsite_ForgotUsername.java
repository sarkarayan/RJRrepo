package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.brandWebsitePageObjects;

public class BrandWebsite_ForgotUsername extends BaseClass {

	String testcaseName;
	public BrandWebsite_ForgotUsername(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(brandWebsitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("ForgotUsername Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	public void invokeApplication_brandwebsite()
	{
		String WebsiteURL = dataTable.getData("General_Data","URL");
		
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
	public void forgotUsername_AccountInformation() throws InterruptedException, IOException
	{
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.lnktxt_Forgetusername), brandWebsitePageObjects.lnktxt_Forgetusername.getObjectname());
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_ForgotUsernameBirthMonth), month, brandWebsitePageObjects.drpdwn_ForgotUsernameBirthMonth.getObjectname());
		Thread.sleep(5000);
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotUsernameBirthDay),day,brandWebsitePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotUsernameBirthYear), year, brandWebsitePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotUsernameFirstName), FirstName, brandWebsitePageObjects.txt_ForgotUsernameFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotUsernameLastName), LastName, brandWebsitePageObjects.txt_ForgotUsernameLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotUsernameAddress), Address, brandWebsitePageObjects.txt_ForgotUsernameAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotUsernameZipcode), Zipcode,brandWebsitePageObjects.txt_ForgotUsernameZipcode.getObjectname());
		Thread.sleep(4000);
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotUsernameAccountInformation),brandWebsitePageObjects.btn_ForgotUsernameAccountInformation.getObjectname());
				
	}
	
	public void forgotUsername_VerifyIdentity() throws InterruptedException, IOException
	{
		String ChallengeAnswer = dataTable.getData("General_Data", "ChallengeAnswer");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotUsernameChallengeAnswer), ChallengeAnswer,brandWebsitePageObjects.txt_ForgotUsernameChallengeAnswer.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotUsernameVerifyIdentity),brandWebsitePageObjects.btn_ForgotUsernameVerifyIdentity.getObjectname());
		Thread.sleep(4000);
	}
	
	public void forgotUsername_Welcomeback() throws IOException
	{
		String Password = dataTable.getData("General_Data", "Password");
		
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_WelcomeBackPassword), Password,brandWebsitePageObjects.txt_WelcomeBackPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_WelcomBackLogin),brandWebsitePageObjects.btn_WelcomBackLogin.getObjectname());
	}
	
}

