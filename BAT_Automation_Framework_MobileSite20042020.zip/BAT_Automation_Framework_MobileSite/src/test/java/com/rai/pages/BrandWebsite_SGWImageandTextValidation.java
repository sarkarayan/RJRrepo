package com.rai.pages;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.rai.framework.Status;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.framework.RecogniseText;
import com.rai.componentgroups.*;
import com.rai.pageObjects.brandWebsitePageObjects;




public class BrandWebsite_SGWImageandTextValidation extends BaseClass {
	
	String testcaseName;
	
		public BrandWebsite_SGWImageandTextValidation(String testcaseName) {
			this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(brandWebsitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	public void invokeApplication_brandwebsite()
	{
		String WebsiteURL = dataTable.getData("General_Data","URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
		
    public void validatingSGWtext() throws Exception {

        String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
        String path = System.getProperty("user.dir") +  "\\src\\test\\resources\\SGW_Images\\SGW_Image.png";
        commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink));
        commonFunction.validateImage(path, "Pre Login Footer SGW", "SGW Image Validation");
        String altText = commonFunction.getValueFromAttribute(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink),brandWebsitePageObjects.sgwText_PreLoginfooterlink.getObjectname(), "alt");
        String actualImageText = RecogniseText.extractImageText(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink));
        commonFunction.compareStrings(Expected_SGWtext, actualImageText);
        commonFunction.compareStrings(Expected_SGWtext, altText);

}

public void NewportvalidatingSGWtext() throws Exception {

        String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
        String path = System.getProperty("user.dir") +  "\\src\\test\\resources\\SGW_Images\\Newport_SGW_Image.png";
        commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink));
        commonFunction.validateImage(path, "Pre Login Footer SGW", "SGW Image Validation");
        String altText = commonFunction.getValueFromAttribute(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink),brandWebsitePageObjects.sgwText_PreLoginfooterlink.getObjectname(), "alt");
        String actualImageText = RecogniseText.extractImageText(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink));
        commonFunction.compareStrings(Expected_SGWtext, actualImageText);
        commonFunction.compareStrings(Expected_SGWtext, altText);

}

public void pallmall_validateSGWtext() throws Exception {

        String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
        String path = System.getProperty("user.dir") +  "\\src\\test\\resources\\SGW_Images\\PallMall_SGW_Image.png";
        commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink));
        commonFunction.validateImage(path, "Pre Login Footer SGW", "SGW Image Validation");
        String altText = commonFunction.getValueFromAttribute(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink),brandWebsitePageObjects.sgwText_PreLoginfooterlink.getObjectname(), "alt");
        String actualImageText = RecogniseText.extractImageText(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink));
        commonFunction.compareStrings(Expected_SGWtext, actualImageText);
        commonFunction.compareStrings(Expected_SGWtext, altText);

}
public void nascigs_ValidatingSGWtext() throws Exception {
        String expectedSGWText1 = dataTable.getData("General_Data", "NascigsSGWText1");
        String expectedSGWText2 = dataTable.getData("General_Data", "NascigsSGWText2");
        String expectedSGWText3 = dataTable.getData("General_Data", "NascigsSGWText3");
        String altText1 = commonFunction.getValueFromAttribute(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink1_Nascigs),brandWebsitePageObjects.sgwText_PreLoginfooterlink1_Nascigs.getObjectname(), "alt");
        String altText2 = commonFunction.getValueFromAttribute(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink2_Nascigs),brandWebsitePageObjects.sgwText_PreLoginfooterlink2_Nascigs.getObjectname(), "alt");
        String altText3 = commonFunction.getValueFromAttribute(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink3_Nascigs),brandWebsitePageObjects.sgwText_PreLoginfooterlink3_Nascigs.getObjectname(), "alt");
        String NascigsImagePath1 = System.getProperty("user.dir") + "\\src\\test\\resources\\SGW_Images\\Nascigs_SGW_Image_1.png";
        String NascigsImagePath2 = System.getProperty("user.dir") + "\\src\\test\\resources\\SGW_Images\\Nascigs_SGW_Image_2.png";
        String NascigsImagePath3 = System.getProperty("user.dir") + "\\src\\test\\resources\\SGW_Images\\Nascigs_SGW_Image_3.png";
commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink1_Nascigs));
        commonFunction.validateImage(NascigsImagePath1, "Nascigs - American Sprit", "First SGW Image on Footer");
        commonFunction.validateImage(NascigsImagePath2, "Nascigs - American Sprit", "Second SGW Image on Footer");
        commonFunction.validateImage(NascigsImagePath3, "Nascigs - American Sprit", "Third SGW Image on Footer");
        String actualImageText1 = RecogniseText.extractImageText(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink1_Nascigs));
        commonFunction.compareStrings(expectedSGWText1, actualImageText1);
        commonFunction.compareStrings(expectedSGWText1, altText1);
        

        String actualImageText2 = RecogniseText.extractImageText(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink2_Nascigs));
        commonFunction.compareStringsContains(expectedSGWText2, actualImageText2);
        commonFunction.compareStrings(expectedSGWText2, altText2);

        String actualImageText3 = RecogniseText.extractImageText(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink3_Nascigs));
        commonFunction.compareStrings(expectedSGWText3, actualImageText3);
        commonFunction.compareStrings(expectedSGWText3, altText3);

}

public void ecommercesites_ValidatingSGWtext() throws Exception {
        String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
        String altText = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink_ecommercesites));
        commonFunction.compareStrings(Expected_SGWtext, altText);
}

public void nascigsPostLogin_ValidatingSGWtext() throws Exception {
        String expectedSGWText1 = dataTable.getData("General_Data", "NascigsSGWText1");
        String expectedSGWText2 = dataTable.getData("General_Data", "NascigsSGWText2");
        String expectedSGWText3 = dataTable.getData("General_Data", "NascigsSGWText3");
        String altText1 = commonFunction.getValueFromAttribute(getPageElement(brandWebsitePageObjects.sgwText_PostLoginfooterlink1_Nascigs),brandWebsitePageObjects.sgwText_PostLoginfooterlink1_Nascigs.getObjectname(), "alt");
        String altText2 = commonFunction.getValueFromAttribute(getPageElement(brandWebsitePageObjects.sgwText_PostLoginfooterlink2_Nascigs),brandWebsitePageObjects.sgwText_PostLoginfooterlink2_Nascigs.getObjectname(), "alt");
        String altText3 = commonFunction.getValueFromAttribute(getPageElement(brandWebsitePageObjects.sgwText_PostLoginfooterlink3_Nascigs),brandWebsitePageObjects.sgwText_PostLoginfooterlink3_Nascigs.getObjectname(), "alt");
        String NascigsImagePath1 = System.getProperty("user.dir") + "\\src\\test\\resources\\SGW_Images\\Nascigs_SGW_Image_1.png";
        String NascigsImagePath2 = System.getProperty("user.dir") + "\\src\\test\\resources\\SGW_Images\\Nascigs_SGW_Image_2.png";
        String NascigsImagePath3 = System.getProperty("user.dir") + "\\src\\test\\resources\\SGW_Images\\Nascigs_SGW_Image_3.png";
//commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.sgwText_PostLoginfooterlink1_Nascigs));
        commonFunction.validateImage(NascigsImagePath1, "Nascigs - American Sprit", "First SGW Image on Footer");
        commonFunction.validateImage(NascigsImagePath2, "Nascigs - American Sprit", "Second SGW Image on Footer");
        commonFunction.validateImage(NascigsImagePath3, "Nascigs - American Sprit", "Third SGW Image on Footer");
        String actualImageText1 = RecogniseText.extractImageTextUsingScreenShot(getPageElement(brandWebsitePageObjects.sgwText_PostLoginfooterlink1_Nascigs));
        commonFunction.compareStrings(expectedSGWText1, actualImageText1);
        commonFunction.compareStrings(expectedSGWText1, altText1);
        

        String actualImageText2 = RecogniseText.extractImageTextUsingScreenShot(getPageElement(brandWebsitePageObjects.sgwText_PostLoginfooterlink2_Nascigs));
        commonFunction.compareStrings(expectedSGWText2, actualImageText2);
        commonFunction.compareStrings(expectedSGWText2, altText2);

        String actualImageText3 = RecogniseText.extractImageTextUsingScreenShot(getPageElement(brandWebsitePageObjects.sgwText_PostLoginfooterlink3_Nascigs));
        commonFunction.compareStrings(expectedSGWText3, actualImageText3);
        commonFunction.compareStrings(expectedSGWText3, altText3);
}

public void camelPostLogin_ValidatingSGWtext() throws Exception {
        String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
        String path = System.getProperty("user.dir") + File.separator + "/src/test/resources/SGW_Images/SGW_Image.png";
        String altText = commonFunction.getValueFromAttribute(getPageElement(brandWebsitePageObjects.sgwText_PostLoginfooterlink_Camel),brandWebsitePageObjects.sgwText_PostLoginfooterlink_Camel.getObjectname(), "alt");
commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.sgwText_PostLoginfooterlink_Camel));
        commonFunction.validateImage(path, "Camel Brand - Home Page", "SGW Image on Home Page");
        String actualImageText = RecogniseText.extractImageText(getPageElement(brandWebsitePageObjects.sgwText_PostLoginfooterlink_Camel));
        commonFunction.compareStrings(Expected_SGWtext, actualImageText);
        commonFunction.compareStrings(Expected_SGWtext, altText);
        System.out.println(commonFunction.equalsIgnoreNewlineStyle(Expected_SGWtext, actualImageText));

}

public void pallmallPostLogin_ValidatingSGWtext() throws Exception {
        String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
        String path = System.getProperty("user.dir") +  "\\src\\test\\resources\\SGW_Images\\PallMall_SGW_Image.png";
        String altText = commonFunction.getValueFromAttribute(getPageElement(brandWebsitePageObjects.sgwText_PostLoginfooterlink_Pallmall),brandWebsitePageObjects.sgwText_PostLoginfooterlink_Pallmall.getObjectname(), "alt");
commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.sgwText_PostLoginfooterlink_Pallmall));
        commonFunction.validateImage(path, "Pallmall Brand Post Login", "SGW Image on Home Page");
        String actualImageText = RecogniseText.extractImageTextUsingScreenShot(getPageElement(brandWebsitePageObjects.sgwText_PostLoginfooterlink_Pallmall));
        commonFunction.compareStrings(Expected_SGWtext, actualImageText);
        commonFunction.compareStrings(Expected_SGWtext, altText);
        System.out.println(commonFunction.equalsIgnoreNewlineStyle(Expected_SGWtext, actualImageText));

}

public void newportPostLogin_ValidatingSGWtext() throws Exception {
        String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
        String path = System.getProperty("user.dir") +  "\\src\\test\\resources\\SGW_Images\\Newport_SGW_Image.png";
        String altText = commonFunction.getValueFromAttribute(getPageElement(brandWebsitePageObjects.sgwText_PostLoginfooterlink_Newport),brandWebsitePageObjects.sgwText_PostLoginfooterlink_Newport.getObjectname(), "alt");
commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.sgwText_PostLoginfooterlink_Newport));
        commonFunction.validateImage(path, "Pallmall Brand Post Login", "SGW Image on Home Page");
        String actualImageText = RecogniseText.extractImageTextUsingScreenShot(getPageElement(brandWebsitePageObjects.sgwText_PostLoginfooterlink_Newport));
        commonFunction.compareStrings(Expected_SGWtext, actualImageText);
        commonFunction.compareStrings(Expected_SGWtext, altText);
        System.out.println(commonFunction.equalsIgnoreNewlineStyle(Expected_SGWtext, actualImageText));

}

public void grizzlyPostLogin_ValidatingSGWtext() throws Exception {
        String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
        String Actual_SGWtext = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.sgwText_PostLoginfooterlink_Grizzly));

        commonFunction.compareStrings(Expected_SGWtext, Actual_SGWtext);

}

public void vusePostLogin_footerlinks_ValidatingSGWtext() throws Exception {

        String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
        String Actual_SGWtext = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink_ecommercesites));

        // PostLogin - StoreLocator footerlink
commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_StoreLocator));
commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_StoreLocator),brandWebsitePageObjects.PostLoginVUSEfooterlnk_StoreLocator.getObjectname());
        commonFunction.SwitchControlToChildTab();
        String ActualPostLoginStoreLocatorTitle = driver.getTitle();
        String ExpectedPostLoginStoreLocatorTitle = "Retail Locator";
        commonFunction.compareStrings(ExpectedPostLoginStoreLocatorTitle, ActualPostLoginStoreLocatorTitle);
        
        commonFunction.compareStrings(Expected_SGWtext, Actual_SGWtext);

        commonFunction.closeChildTab();
        commonFunction.SwitchControlToParentTab();

        // PostLogin - FAQs footerlink
        commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_FAQs));
commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_FAQs),brandWebsitePageObjects.PostLoginVUSEfooterlnk_FAQs.getObjectname());
        commonFunction.SwitchControlToChildTab();
        String ActualPostLoginFAQsTitle = driver.getTitle();
        String ExpectedPostLoginFAQsTitle = "FAQs";
        commonFunction.compareStrings(ExpectedPostLoginFAQsTitle, ActualPostLoginFAQsTitle);

        commonFunction.compareStrings(Expected_SGWtext, Actual_SGWtext);

        commonFunction.closeChildTab();
        commonFunction.SwitchControlToParentTab();

        // PostLogin - Patents footer link
   commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_Patents));
commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_Patents),brandWebsitePageObjects.PostLoginVUSEfooterlnk_Patents.getObjectname());
        commonFunction.SwitchControlToChildTab();
        String ActualPostLoginPatentsTitle = driver.getTitle();
        String ExpectedPostLoginPatentsTitle = "VUSE Patents";
        commonFunction.compareStrings(ExpectedPostLoginPatentsTitle, ActualPostLoginPatentsTitle);

        commonFunction.compareStrings(Expected_SGWtext, Actual_SGWtext);                              

        commonFunction.closeChildTab();
        commonFunction.SwitchControlToParentTab();

        // PostLogin - SiteMap
 commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_SiteMap));
commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_SiteMap),
                                        brandWebsitePageObjects.PostLoginVUSEfooterlnk_SiteMap.getObjectname());
        commonFunction.SwitchControlToChildTab();
        String ActualPostLoginSiteMapTitle = driver.getTitle();
        String ExpectedPostLoginSiteMapTitle = "SiteMap";
        commonFunction.compareStrings(ExpectedPostLoginSiteMapTitle, ActualPostLoginSiteMapTitle);
        
        commonFunction.compareStrings(Expected_SGWtext, Actual_SGWtext);              

        commonFunction.closeChildTab();
        commonFunction.SwitchControlToParentTab();

        // PostLogin - TermsOfSale
commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_TermsOfSale));
commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_TermsOfSale),
                                        brandWebsitePageObjects.PostLoginVUSEfooterlnk_TermsOfSale.getObjectname());
        commonFunction.SwitchControlToChildTab();
        String ActualPostLoginTermsOfSaleTitle = driver.getTitle();
        String ExpectedPostLoginTermsOfSaleTitle = "Terms of Sale";
commonFunction.compareStrings(ExpectedPostLoginTermsOfSaleTitle, ActualPostLoginTermsOfSaleTitle);
        
        commonFunction.compareStrings(Expected_SGWtext, Actual_SGWtext);

        commonFunction.closeChildTab();
        commonFunction.SwitchControlToParentTab();
}

public void vusePostLogin_AccountDashoard_ValidatingSGWText() throws Exception {

        String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
        String Actual_SGWtext = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink_ecommercesites));

commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSE_MyAccount),brandWebsitePageObjects.PostLoginVUSE_MyAccount.getObjectname());
commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSE_MyAccountlink),brandWebsitePageObjects.PostLoginVUSE_MyAccountlink.getObjectname());
        
        commonFunction.compareStrings(Expected_SGWtext, Actual_SGWtext);

}

public void revelPostLoginFooterLinks_SGWTextValidation() throws Exception {
        String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
        String Actual_SGWtext = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink_ecommercesites));

        // PostLogin - FAQs footerlink
        commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_FAQs));
commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_FAQs),brandWebsitePageObjects.PostLoginRevelfooterlnk_FAQs.getObjectname());
        commonFunction.SwitchControlToChildTab();
        String ActualPostLoginFAQsTitle = driver.getTitle();
        String ExpectedPostLoginFAQsTitle = "FAQs";
        commonFunction.compareStringsContains(ExpectedPostLoginFAQsTitle, ActualPostLoginFAQsTitle);
        
        commonFunction.compareStrings(Expected_SGWtext, Actual_SGWtext);

        commonFunction.closeChildTab();
        commonFunction.SwitchControlToParentTab();

        // PreLogin - TermsOfSale
commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_TermsOfSale));
commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevelfooterlnk_TermsOfSale),brandWebsitePageObjects.PostLoginRevelfooterlnk_TermsOfSale.getObjectname());
        commonFunction.SwitchControlToChildTab();
        String ActualTermsOfSaleTitle = driver.getTitle();
        String ExpectedTermsOfSaleTitle = "Terms of Sale";
        commonFunction.compareStringsContains(ExpectedTermsOfSaleTitle, ActualTermsOfSaleTitle);
        
        commonFunction.compareStrings(Expected_SGWtext, Actual_SGWtext);

        commonFunction.closeChildTab();
        commonFunction.SwitchControlToParentTab();

}

public void grizzly_ValidatingSGWText() throws Exception, Exception {

        if (commonFunction.isElementPresentVerification(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink_Grizzly1200),brandWebsitePageObjects.sgwText_PreLoginfooterlink_Grizzly1200.getObjectname())) {
                        String ExpectedSGWText = dataTable.getData("General_Data", "SGW");
                        String ActualSGWText = commonFunction.getValueFromAttribute(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink_Grizzly1200),brandWebsitePageObjects.sgwText_PreLoginfooterlink_Grizzly1200.getObjectname(), "alt");

                        commonFunction.compareStrings(ExpectedSGWText, ActualSGWText);

        }

        else if (commonFunction.isElementPresentVerification(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink_Grizzly480),brandWebsitePageObjects.sgwText_PreLoginfooterlink_Grizzly480.getObjectname())) {

                        String ExpectedSGWText = dataTable.getData("General_Data", "SGW");
                        String ActualSGWText = commonFunction.getValueFromAttribute(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink_Grizzly480),brandWebsitePageObjects.sgwText_PreLoginfooterlink_Grizzly480.getObjectname(), "alt");

                        commonFunction.compareStrings(ExpectedSGWText, ActualSGWText);
        }

        else if (commonFunction.isElementPresentVerification(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink_Grizzly720),brandWebsitePageObjects.sgwText_PreLoginfooterlink_Grizzly720.getObjectname())) {

                        String ExpectedSGWText = dataTable.getData("General_Data", "SGW");
                        String ActualSGWText = commonFunction.getValueFromAttribute(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink_Grizzly720),brandWebsitePageObjects.sgwText_PreLoginfooterlink_Grizzly720.getObjectname(), "alt");

                        commonFunction.compareStrings(ExpectedSGWText, ActualSGWText);
        }

        else if (commonFunction.isElementPresentVerification(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink_Grizzly960),brandWebsitePageObjects.sgwText_PreLoginfooterlink_Grizzly960.getObjectname())) {

                        String ExpectedSGWText = dataTable.getData("General_Data", "SGW");
                        String ActualSGWText = commonFunction.getValueFromAttribute(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink_Grizzly960),brandWebsitePageObjects.sgwText_PreLoginfooterlink_Grizzly960.getObjectname(), "alt");

                        commonFunction.compareStrings(ExpectedSGWText, ActualSGWText);
        }

        else if (commonFunction.isElementPresentVerification(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink_Grizzly320),brandWebsitePageObjects.sgwText_PreLoginfooterlink_Grizzly320.getObjectname())) {

                        String ExpectedSGWText = dataTable.getData("General_Data", "SGW");
                        String ActualSGWText = commonFunction.getValueFromAttribute(getPageElement(brandWebsitePageObjects.sgwText_PreLoginfooterlink_Grizzly320),brandWebsitePageObjects.sgwText_PreLoginfooterlink_Grizzly320.getObjectname(), "alt");

                        commonFunction.compareStrings(ExpectedSGWText, ActualSGWText);
        }

}

}



