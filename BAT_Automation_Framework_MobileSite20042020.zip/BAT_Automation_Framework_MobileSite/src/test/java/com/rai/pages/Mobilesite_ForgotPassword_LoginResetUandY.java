package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.pageObjects.MobileSiteForgotPasswordPageObjects;
import com.rai.pageObjects.MobileSiteLoginPageObjects;
import com.rai.pageObjects.MobileSiteResetPageObjects;
import com.rai.pageObjects.MobilesitePageObjects;

public class Mobilesite_ForgotPassword_LoginResetUandY extends BaseClass {

	String testcaseName;
	public Mobilesite_ForgotPassword_LoginResetUandY(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(MobileSiteResetPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Forgot Password Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
		
		private WebElement getPageElement(MobilesitePageObjects pageEnum) throws IOException {
			WebElement element;
			try {
				element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
						true);
				if (element != null)
					System.out.println("Found the element: " + pageEnum.getObjectname());
				else
					System.out.println("Element Not Found: " + pageEnum.getObjectname());
				return element;
			} catch (Exception e) {
				GenericLib.updateExtentStatus("Forgot Password Page - get page element",
						pageEnum.toString() + " object is not defined or found.", Status.FAIL);
				return null;
			}
	}
	
	private WebElement getPageElement(MobileSiteLoginPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Forgot Password Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	private WebElement getPageElement(MobileSiteForgotPasswordPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Forgot Password Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	
	public void invokeApplication_brandMobilesite()
	{
		String WebsiteURL = dataTable.getData("General_Data","URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
		
	public void forgotPassword_EnterValidUsername() throws IOException
	{
		String Email = dataTable.getData("General_Data", "Email");
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.lnktxt_Forgotpassword), MobileSiteLoginPageObjects.lnktxt_Forgotpassword.getObjectname());
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordUsername), Email, MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordUsername.getObjectname());
		//Thread.sleep(2000);
		commonFunction.clickIfElementPresentJavaScript(getPageElement(MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordUsernameContinue), MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
	    //commonFunction.sendKeyENTER(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue),brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
	}
	
	public void forgotPassword_ValidDataOnGeneralInformationPage() throws InterruptedException, IOException
	{
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
        String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		commonFunction.selectAnyElement(getPageElement(MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordBirthMonth), month, MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordBirthMonth.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordBirthDay), day, MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordBirthDay.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordBirthYear), year,MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordFirstName), FirstName, MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordLastName), LastName, MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordAddress), Address, MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordZipcode), Zipcode, MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordZipcode.getObjectname());
		Thread.sleep(4000);
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordCity), City, MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordCity.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordState),State, MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordState.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordGeneralInformation), MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordGeneralInformation.getObjectname());
		
	}
	
	public void resetflow_NegativeValidationsAccountInfoPage() throws IOException, InterruptedException
	{
		
		String InActiveEmail = dataTable.getData("General_Data","NonExistUserId");
		String ExistingEmail = dataTable.getData("General_Data","ExistingUserId");
		String InvalidEmail = dataTable.getData("General_Data","InvalidUserIDformat");
		String Password = dataTable.getData("General_Data","Password");
		String InvalidPasswordformat = dataTable.getData("General_Data","InvalidPasswordformat");
		String DifferentPassword = dataTable.getData("General_Data","InvalidPassword");
		
		
		String Errormsg_NoDataEntered = "Please fix the errors above";
		String Errormsg_NoEmailEntered = "Please enter a valid email address";
		String Errormsg_InvalidEmailEntered = "Please enter a valid email address";
		String Errormsg_InActiveEmailEntered = "This is not an active email address. Please provide an active email address.";
		String Errormsg_ExistingEmailEntered = "Username already taken. Please try a different one.";
		String Errormsg_NoPasswordEntered = "Please provide a password";
		String Errormsg_InvalidPasswordformatEntered = "Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.";
		String Errormsg_DifferentPasswordEntered = "Passwords did not match";
		String Errormsg_NoChallengeQuestion = "Please select a account recovery question";
		String Errormsg_NoChallengeAnswerEntered = "Please provide an answer to account recovery question";
		
		
		//User clicked on Save without any data
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.btn_LoginResetAccntInfoSave), MobileSiteResetPageObjects.btn_LoginResetAccntInfoSave.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoNoDataEntered), MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoNoDataEntered.getObjectname(), Errormsg_NoDataEntered);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAcctInfoNoEmailEntered), MobileSiteResetPageObjects.errormsg_LoginResetAcctInfoNoEmailEntered.getObjectname(), Errormsg_NoEmailEntered);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoNoPassword), MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoNoPassword.getObjectname(), Errormsg_NoPasswordEntered);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoNoChallengeQuestion), MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoNoChallengeQuestion.getObjectname(), Errormsg_NoChallengeQuestion);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoNoChallengeAnswer), MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoNoChallengeAnswer.getObjectname(), Errormsg_NoChallengeAnswerEntered);
		
		//User entered InvalidEmail
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoEmail),InvalidEmail, MobileSiteResetPageObjects.txt_LoginResetAccntInfoEmail.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoInvalidEmail), MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoInvalidEmail.getObjectname(), Errormsg_InvalidEmailEntered);
		
		//User entered InactiveEmail
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoEmail),InActiveEmail, MobileSiteResetPageObjects.txt_LoginResetAccntInfoEmail.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoInactiveEmail), MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoInactiveEmail.getObjectname(), Errormsg_InActiveEmailEntered);
		
		//User entered ExistingEmail
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoEmail),ExistingEmail, MobileSiteResetPageObjects.txt_LoginResetAccntInfoEmail.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoExistingEmail), MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoExistingEmail.getObjectname(), Errormsg_ExistingEmailEntered);
		
		
		//User entered InvalidPassword format
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoPassword),InvalidPasswordformat, MobileSiteResetPageObjects.txt_LoginResetAccntInfoPassword.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoInvalidPasswordFormat), MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoInvalidPasswordFormat.getObjectname(), Errormsg_InvalidPasswordformatEntered);
		
		//User entered Differntdata in password & Confirm password fields
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoPassword),Password, MobileSiteResetPageObjects.txt_LoginResetAccntInfoPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoConfirmPassword),DifferentPassword, MobileSiteResetPageObjects.txt_LoginResetAccntInfoConfirmPassword.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoDifferentPasswordEntered), MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoDifferentPasswordEntered.getObjectname(), Errormsg_DifferentPasswordEntered);
	}
	
	
	public void resetflow_AccountInfoPage() throws Exception
	{
		String Email = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data","Password");
		String ConfirmPassword = dataTable.getData("General_Data","Password");
		String Question = dataTable.getData("General_Data","ChallengeQuestion");
		String Answer = dataTable.getData("General_Data","ChallengeAnswer");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoEmail),Email, MobileSiteResetPageObjects.txt_LoginResetAccntInfoEmail.getObjectname());
		Thread.sleep(5000);
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoPassword),Password,MobileSiteResetPageObjects.txt_LoginResetAccntInfoPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoConfirmPassword),ConfirmPassword,MobileSiteResetPageObjects.txt_LoginResetAccntInfoConfirmPassword.getObjectname());
		
		commonFunction.selectAnyElement(getPageElement(MobileSiteResetPageObjects.drpdnw_LoginResetAccntInfoChallengeQuestion), Question,MobileSiteResetPageObjects.drpdnw_LoginResetAccntInfoChallengeQuestion.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoChallengeAnswer), Answer, MobileSiteResetPageObjects.txt_LoginResetAccntInfoChallengeAnswer.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.btn_LoginResetAccntInfoSave), MobileSiteResetPageObjects.btn_LoginResetAccntInfoSave.getObjectname());
	}
	
	public void resetflow_CongratsPage() throws IOException
	{
		
		String Email = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data", "Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetCongratsPageEmail), Email,MobileSiteResetPageObjects.txt_LoginResetCongratsPageEmail.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetCongratsPagePassword),Password,MobileSiteResetPageObjects.txt_LoginResetCongratsPagePassword.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.btn_LoginResetCongratsPageLogin), MobileSiteResetPageObjects.btn_LoginResetCongratsPageLogin.getObjectname());
	}
	
	public void revelVelo_navigatetoForgotPasswordPage() throws IOException
	{
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.lnktxt_RevelVeloForgotPassword), MobilesitePageObjects.lnktxt_RevelVeloForgotPassword.getObjectname());
	}
	
	public void vuse_navigatetoForgotPasswordPage() throws IOException
	{
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.loginLnk_VUSECertifyAgePage), MobilesitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.header_VUSELogin), MobilesitePageObjects.header_VUSELogin.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.lnk_VUSELoginForgotPassword), MobilesitePageObjects.lnk_VUSELoginForgotPassword.getObjectname());
	}
	

	
	
	
}

