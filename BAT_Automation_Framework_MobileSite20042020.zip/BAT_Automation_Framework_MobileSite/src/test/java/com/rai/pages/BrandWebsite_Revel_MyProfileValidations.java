package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.brandWebsitePageObjects;

public class BrandWebsite_Revel_MyProfileValidations extends BaseClass {

	String testcaseName;

	public BrandWebsite_Revel_MyProfileValidations(String testcaseName) {
		this.testcaseName = testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper The {@link ScriptHelper} object passed from the
	 *                     {@link DriverScript}
	 */

	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	private WebElement getPageElement(brandWebsitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}

	public void invokeApplication_brandwebsite() {
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	}

	public void loginPage_AppToWebsiteLogin() throws InterruptedException, IOException {

		String Username = dataTable.getData("General_Data", "Username");
		String Password = dataTable.getData("General_Data", "Password");

		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginUsername), Username,brandWebsitePageObjects.txt_LoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LoginPassword), Password,brandWebsitePageObjects.txt_LoginPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Login),brandWebsitePageObjects.btn_Login.getObjectname());
		//Thread.sleep(5000);
	}

	
	public void revelProfile_NavigatetoMyProfile() throws IOException
	{
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevel_AccountMenu),brandWebsitePageObjects.PostLoginRevel_AccountMenu.getObjectname());		
	}
	
	public void veloProfile_NavigatetoMyProfile() throws IOException
	{
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVelo_AccountMenu),brandWebsitePageObjects.PostLoginVelo_AccountMenu.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVelo_Profile),brandWebsitePageObjects.PostLoginVelo_Profile.getObjectname());
		
	}
	
	
	public void revelProfile_navigatetoBillingAddress() throws IOException
	{
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevel_AddressBook),brandWebsitePageObjects.PostLoginRevel_AddressBook.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btnEdit_ProfileRevel_BillingAddress),brandWebsitePageObjects.btnEdit_ProfileRevel_BillingAddress.getObjectname());
		
	}
	
	public void revelProfile_BillingAddress_negativevalidations() throws IOException
	{
		
		commonFunction.clearText(getPageElement(brandWebsitePageObjects.txt_Profile_BillingAddress_FirstName), brandWebsitePageObjects.txt_Profile_BillingAddress_FirstName.getObjectname());
		commonFunction.clearText(getPageElement(brandWebsitePageObjects.txt_Profile_BillingAddress_LastName), brandWebsitePageObjects.txt_Profile_BillingAddress_LastName.getObjectname());
		commonFunction.clearText(getPageElement(brandWebsitePageObjects.txt_Profile_BillingAddress_Telephone), brandWebsitePageObjects.txt_Profile_BillingAddress_Telephone.getObjectname());
		commonFunction.clearText(getPageElement(brandWebsitePageObjects.txt_Profile_BillingAddress_Address), brandWebsitePageObjects.txt_Profile_BillingAddress_Address.getObjectname());
		commonFunction.clearText(getPageElement(brandWebsitePageObjects.txt_Profile_BillingAddress_Zipcode), brandWebsitePageObjects.txt_Profile_BillingAddress_Zipcode.getObjectname());
		commonFunction.clearText(getPageElement(brandWebsitePageObjects.btn_Profile_BillingAddress_Save), brandWebsitePageObjects.btn_Profile_BillingAddress_Save.getObjectname());
		
		String ExpectedErrormsg = "This is a required field.";
		
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_BillingAddress_NoFirstName), brandWebsitePageObjects.errormsg_BillingAddress_NoFirstName.getObjectname(), ExpectedErrormsg);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_BillingAddress_NoLastName), brandWebsitePageObjects.errormsg_BillingAddress_NoLastName.getObjectname(), ExpectedErrormsg);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_BillingAddress_NoTelephone), brandWebsitePageObjects.errormsg_BillingAddress_NoTelephone.getObjectname(), ExpectedErrormsg);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_BillingAddress_NoAddress1), brandWebsitePageObjects.errormsg_BillingAddress_NoAddress1.getObjectname(), ExpectedErrormsg);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_BillingAddress_NoZipcode), brandWebsitePageObjects.errormsg_BillingAddress_NoZipcode.getObjectname(), ExpectedErrormsg);
		
	}
	
	
	public void revelProfile_BillingAddress_UpdateUserData() throws IOException, InterruptedException
	{
		
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Phone = dataTable.getData("General_Data", "Telephone");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Profile_BillingAddress_FirstName),FirstName, brandWebsitePageObjects.txt_Profile_BillingAddress_FirstName.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Profile_BillingAddress_LastName),LastName, brandWebsitePageObjects.txt_Profile_BillingAddress_LastName.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Profile_BillingAddress_Telephone),Phone, brandWebsitePageObjects.txt_Profile_BillingAddress_Telephone.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Profile_BillingAddress_Address),Address, brandWebsitePageObjects.txt_Profile_BillingAddress_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Profile_BillingAddress_Zipcode),Zipcode, brandWebsitePageObjects.txt_Profile_BillingAddress_Zipcode.getObjectname());
		Thread.sleep(4000);
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Profile_BillingAddress_Save),brandWebsitePageObjects.btn_Profile_BillingAddress_Save.getObjectname());
		
	}
	
	
	public void revel_Logout() throws IOException
	{
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevel_AccountMenu),brandWebsitePageObjects.PostLoginRevel_AccountMenu.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginRevel_LogOut),brandWebsitePageObjects.PostLoginRevel_LogOut.getObjectname());
		
	}

	public void veloHomePage_Logout() throws IOException
	{
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVelo_AccountMenu),brandWebsitePageObjects.PostLoginVelo_AccountMenu.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVelo_LogOut),brandWebsitePageObjects.PostLoginVelo_LogOut.getObjectname());
		
	}
}
