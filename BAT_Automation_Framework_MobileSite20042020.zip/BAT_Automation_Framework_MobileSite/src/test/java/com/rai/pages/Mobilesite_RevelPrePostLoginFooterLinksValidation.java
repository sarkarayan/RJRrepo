package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.MobilesitePageObjects;
import com.rai.pageObjects.MobilesitePageObjects;

public class Mobilesite_RevelPrePostLoginFooterLinksValidation extends BaseClass {

	String testcaseName;
	public Mobilesite_RevelPrePostLoginFooterLinksValidation(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(MobilesitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("FooterLinks Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	public void invokeApplication_brandwebsite()
	{
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
	
	public void loginPage_RevelPreLoginFooterLinksValidation() throws Exception
	{ 
		//PreLogin - FAQs footerlink
		String currenturl = driver.getCurrentUrl();
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginRevelfooterlnk_FAQs));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginRevelfooterlnk_FAQs),MobilesitePageObjects.PreLoginRevelfooterlnk_FAQs.getObjectname());
		String ActualFAQsTitle = driver.getTitle();
		String ExpectedFAQsTitle = "Frequently Asked Questions";
		commonFunction.compareStringsContains(ExpectedFAQsTitle, ActualFAQsTitle);
		driver.navigate().to(currenturl);
		//Thread.sleep(5000);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
	
		//PreLogin - ContactUs
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginRevelfooterlnk_ContactUs));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginRevelfooterlnk_ContactUs),MobilesitePageObjects.PreLoginRevelfooterlnk_ContactUs.getObjectname());
		String ActualContactUsTitle = driver.getTitle();
		String ExpectedContactUsTitle = "Contact Us";
		commonFunction.compareStringsContains(ExpectedContactUsTitle, ActualContactUsTitle);
		driver.navigate().to(currenturl);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - TobaccoRights
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginRevelfooterlnk_TobaccoRights));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginRevelfooterlnk_TobaccoRights),MobilesitePageObjects.PreLoginRevelfooterlnk_TobaccoRights.getObjectname());
		String ActualTobaccoRightsTitle = driver.getTitle();
		String ExpectedTobaccoRightsTitle = "Own It Voice It";
		commonFunction.compareStringsContains(ExpectedTobaccoRightsTitle, ActualTobaccoRightsTitle);
		//Thread.sleep(5000);
		driver.navigate().to(currenturl);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - SiteRequirements
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginRevelfooterlnk_SiteRequirements));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginRevelfooterlnk_SiteRequirements),MobilesitePageObjects.PreLoginRevelfooterlnk_SiteRequirements.getObjectname());
		String ActualSiteRequrmntsTitle = driver.getTitle();
		String ExpectedSiteRequrmntsTitle = "Site Requirements";
		commonFunction.compareStringsContains(ExpectedSiteRequrmntsTitle, ActualSiteRequrmntsTitle);
		//Thread.sleep(5000);
		driver.navigate().to(currenturl);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - AgeFiltering
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginRevelfooterlnk_AgeFiltering));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginRevelfooterlnk_AgeFiltering),MobilesitePageObjects.PreLoginRevelfooterlnk_AgeFiltering.getObjectname());
		String ActualAgeFilteringTitle = driver.getTitle();
		String ExpectedAgeFilteringTitle = "Age Filtering Software:";
		commonFunction.compareStringsContains(ExpectedAgeFilteringTitle, ActualAgeFilteringTitle);
		//Thread.sleep(5000);
		driver.navigate().to(currenturl);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - TermsOfUse
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginRevelfooterlnk_TermsOfUse));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginRevelfooterlnk_TermsOfUse),MobilesitePageObjects.PreLoginRevelfooterlnk_TermsOfUse.getObjectname());
		String ActualTermsofUseTitle = driver.getTitle();
		String ExpectedTermsofUseTitle = "Terms of use";
		commonFunction.compareStringsContains(ExpectedTermsofUseTitle, ActualTermsofUseTitle);
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_TermsOfUse_Restrictions), MobilesitePageObjects.PostLoginRevelfooterlnk_TermsOfUse_Restrictions.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff), MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff_backtoTop), MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ChoiceOfLaw), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ChoiceOfLaw.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_ChoiceOfLaw_backtoTop), MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_ChoiceOfLaw_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous_backtoTop.getObjectname());
		
		
		driver.navigate().to(currenturl);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - PrivacyPolicy
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginRevelfooterlnk_PrivacyPolicy));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginRevelfooterlnk_PrivacyPolicy),MobilesitePageObjects.PreLoginRevelfooterlnk_PrivacyPolicy.getObjectname());
		
		String ActualPrivacyPolicyTitle = driver.getTitle();
		String ExpectedPrivacyPolicyTitle = "Privacy Policy and Your California Privacy Rights";
		commonFunction.compareStringsContains(ExpectedPrivacyPolicyTitle,ActualPrivacyPolicyTitle);
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_WhatwecollectandHow), MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_WhatwecollectandHow.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_WhatwecollectandHow_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_WhatwecollectandHow_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_LinktoWebsites), MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_LinktoWebsites.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_LinktoWebsites_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_LinktoWebsites_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_CaliforniaCCPARights), MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_CaliforniaCCPARights.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_CaliforniaCCPARights_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_CaliforniaCCPARights_backtoTop.getObjectname());
	
		driver.navigate().to(currenturl);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
		
		
		//PreLogin - TermsOfSale
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginRevelfooterlnk_TermsOfSale));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginRevelfooterlnk_TermsOfSale),MobilesitePageObjects.PreLoginRevelfooterlnk_TermsOfSale.getObjectname());
		String ActualTermsOfSaleTitle = driver.getTitle();
		String ExpectedTermsOfSaleTitle = "Terms of Sale";
		commonFunction.compareStringsContains(ExpectedTermsOfSaleTitle,ActualTermsOfSaleTitle);
		//Thread.sleep(5000);
		driver.navigate().to(currenturl);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
	}
	
	
	public void loginPage_AppToWebsiteLogin() throws InterruptedException, IOException
	{
		
		String Username = dataTable.getData("General_Data", "Username");
		String Password = dataTable.getData("General_Data", "Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_LoginUsername),Username,MobilesitePageObjects.txt_LoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_LoginPassword),Password, MobilesitePageObjects.txt_LoginPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login), MobilesitePageObjects.btn_Login.getObjectname());
		//Thread.sleep(5000);
	}
	
	
	public void homePage_RevelPostLoginFooterLinksValidation() throws Exception
	{
		
		//PostLogin - FAQs footerlink
		String currenturl = driver.getCurrentUrl();
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_FAQs));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_FAQs),MobilesitePageObjects.PostLoginRevelfooterlnk_FAQs.getObjectname());
		String ActualPostLoginFAQsTitle = driver.getTitle();
		String ExpectedPostLoginFAQsTitle = "FAQs";
		commonFunction.compareStringsContains(ExpectedPostLoginFAQsTitle,ActualPostLoginFAQsTitle);
		//Thread.sleep(5000);
		driver.navigate().to(currenturl);
	
		
		//PostLogin - ContactUs footer link
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_ContactUs));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_ContactUs),MobilesitePageObjects.PostLoginRevelfooterlnk_ContactUs.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginContactUsTitle = driver.getTitle();
		String ExpectedPostLoginContactUsTitle = "Contact us";
		commonFunction.compareStringsContains(ExpectedPostLoginContactUsTitle,ActualPostLoginContactUsTitle);
		driver.navigate().to(currenturl);
		//Thread.sleep(5000);
//		commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_ContactUsQuestion),2 ,MobilesitePageObjects.PostLoginfooterlnk_ContactUsQuestion.getObjectname());
//		commonFunction.clearAndEnterText(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_ContactUsAnswer),"Validate",MobilesitePageObjects.PostLoginfooterlnk_ContactUsAnswer.getObjectname());
//		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_ContactUsSubmit),MobilesitePageObjects.PostLoginfooterlnk_ContactUsSubmit.getObjectname());
		
		
		
		//PostLogin - TobaccoRights
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_TobaccoRights));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_TobaccoRights),MobilesitePageObjects.PostLoginRevelfooterlnk_TobaccoRights.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginTobaccoRightsTitle = driver.getTitle();
		String ExpectedPostLoginTobaccoRightsTitle = "Own It Voice It";
		commonFunction.compareStringsContains(ExpectedPostLoginTobaccoRightsTitle,ActualPostLoginTobaccoRightsTitle);
		//Thread.sleep(5000);
		driver.navigate().to(currenturl);
		
		
		//PostLogin - SiteRequirements
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_SiteRequirements));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_SiteRequirements),MobilesitePageObjects.PostLoginRevelfooterlnk_SiteRequirements.getObjectname());
		
		String ActualPostLoginSiteRequirementsTitle = driver.getTitle();
		String ExpectedPostLoginSiteRequirementsTitle = "Site Requirements";
		commonFunction.compareStringsContains(ExpectedPostLoginSiteRequirementsTitle,ActualPostLoginSiteRequirementsTitle);
		//Thread.sleep(5000);
		driver.navigate().to(currenturl);
		
		//PostLogin - AgeFiltering
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_AgeFiltering));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_AgeFiltering),MobilesitePageObjects.PostLoginRevelfooterlnk_AgeFiltering.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginAgeFilteringTitle = driver.getTitle();
		String ExpectedPostLoginAgeFilteringTitle = "Age Filtering Software:";
		commonFunction.compareStringsContains(ExpectedPostLoginAgeFilteringTitle,ActualPostLoginAgeFilteringTitle );
		driver.navigate().to(currenturl);
		//PostLogin - TermsOfUse
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_TermsOfUse));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_TermsOfUse),MobilesitePageObjects.PostLoginRevelfooterlnk_TermsOfUse.getObjectname());
		
		String ActualPostLoginTermsOfUseTitle = driver.getTitle();
		String ExpectedPostLoginTermsOfUseTitle = "Terms of use";
		commonFunction.compareStringsContains(ExpectedPostLoginTermsOfUseTitle,ActualPostLoginTermsOfUseTitle );

		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_TermsOfUse_Restrictions), MobilesitePageObjects.PostLoginRevelfooterlnk_TermsOfUse_Restrictions.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff), MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff_backtoTop), MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ChoiceOfLaw), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ChoiceOfLaw.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_ChoiceOfLaw_backtoTop), MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_ChoiceOfLaw_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous_backtoTop.getObjectname());
		driver.navigate().to(currenturl);
		
		
		//PostLogin - PrivacyPolicy
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy),MobilesitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy.getObjectname());
		
		String ActualPostLoginPrivacyPolicyTitle = driver.getTitle();
		String ExpectedPostLoginPrivacyPolicyTitle = "Privacy Policy";
		commonFunction.compareStringsContains(ExpectedPostLoginPrivacyPolicyTitle,ActualPostLoginPrivacyPolicyTitle );
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_Whatwecollect), MobilesitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_Whatwecollect.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_Whatwecollect_backtoTop), MobilesitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_Whatwecollect_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_LinktoWebsites), MobilesitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_LinktoWebsites.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_LinktoWebsites_backtoTop), MobilesitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_LinktoWebsites_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_CaliforniaRights), MobilesitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_CaliforniaRights.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_CaliforniaRights_backtoTop), MobilesitePageObjects.PostLoginRevelfooterlnk_PrivacyPolicy_CaliforniaRights_backtoTop.getObjectname());
		
		driver.navigate().to(currenturl);
		
		//PreLogin - TermsOfSale
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_TermsOfSale));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_TermsOfSale),MobilesitePageObjects.PostLoginRevelfooterlnk_TermsOfSale.getObjectname());
		String ActualTermsOfSaleTitle = driver.getTitle();
		String ExpectedTermsOfSaleTitle = "Terms of Sale";
		commonFunction.compareStringsContains(ExpectedTermsOfSaleTitle ,ActualTermsOfSaleTitle );
		//Thread.sleep(5000);
		driver.navigate().to(currenturl);
		
		
	}
	
	public void revelHomePage_Logout() throws IOException
	{
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginRevel_AccountMenu), MobilesitePageObjects.PostLoginRevel_AccountMenu.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginRevel_LogOut), MobilesitePageObjects.PostLoginRevel_LogOut.getObjectname());
		
	}
		
	
}
