package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.brandWebsitePageObjects;

public class BrandWebsite_RegistrationSSN extends BaseClass {

	String testcaseName;
	public BrandWebsite_RegistrationSSN(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(brandWebsitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	public void invokeApplication_brandwebsite()
	{
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
	public void navigateToRegistrationPage() throws IOException {
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Registration), brandWebsitePageObjects.btn_Registration.getObjectname());
	}
	
	public void registration_ValidateErrormessagesonStep1() throws InterruptedException, IOException
	{
		String Errormessage_NoDOB = "Please provide your full date of birth";
		String Errormessage_NoData = "Please fix the errors above";
		String Errormessage_NoLegalName = "Please enter your legal name";
		String Errormessage_NoAddress = "Please provide a street address";
		String Errormessage_NoZipcode = "Please provide a ZIP Code";
		String Errormessage_NoCity = "Please Provide City";
		String Errormessage_NoState = "Please Provide State";
		String Errormessage_NoEmail = "Please enter a valid email address";
		
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data", "City");
		String State = dataTable.getData("General_Data", "State");
		String InvalidEmail = dataTable.getData("General_Data", "InvalidUserIDformat");
		String InActiveEmail = dataTable.getData("General_Data", "NonExistUserId");
		String ExistingEmail = dataTable.getData("General_Data", "ExistingUserId");
		
		String date = dataTable.getData("General_Data","DOB");
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		//commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Registration), brandWebsitePageObjects.btn_Registration.getObjectname());
		//Thread.sleep(7000);
		
		//User clicked on Next without any data
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Step1Next), brandWebsitePageObjects.btn_Step1Next.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errmsg_Step1), brandWebsitePageObjects.errmsg_Step1.getObjectname(), Errormessage_NoData);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_RegistrationNoDOB), brandWebsitePageObjects.errormsg_RegistrationNoLegalName.getObjectname(), Errormessage_NoDOB);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_RegistrationNoLegalName), brandWebsitePageObjects.errormsg_RegistrationNoLegalName.getObjectname(), Errormessage_NoLegalName);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_RegistrationNoAddress), brandWebsitePageObjects.errormsg_RegistrationNoAddress.getObjectname(), Errormessage_NoAddress);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_RegistrationNoZipcode), brandWebsitePageObjects.errormsg_RegistrationNoZipcode.getObjectname(), Errormessage_NoZipcode);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_RegistrationNoCity), brandWebsitePageObjects.errormsg_RegistrationNoCity.getObjectname(), Errormessage_NoCity);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_RegistrationNoState), brandWebsitePageObjects.errormsg_RegistrationNoState.getObjectname(), Errormessage_NoState);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_RegistrationNoEmail), brandWebsitePageObjects.errormsg_RegistrationNoEmail.getObjectname(), Errormessage_NoEmail);
		
		//User entered InvalidEmail
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthMonth), month, brandWebsitePageObjects.drpdwn_BirthMonth.getObjectname());
		//Thread.sleep(6000);
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthDay),day,brandWebsitePageObjects.drpdwn_BirthDay.getObjectname());
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthYear), year,brandWebsitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_FirstName), FirstName, brandWebsitePageObjects.txt_FirstName.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_LastName),LastName, brandWebsitePageObjects.txt_LastName.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_Address),Address, brandWebsitePageObjects.txt_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Zipcode), Zipcode,brandWebsitePageObjects.txt_Zipcode.getObjectname());
		//Thread.sleep(6000);			
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Email), InvalidEmail,brandWebsitePageObjects.txt_Email.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_City), City, brandWebsitePageObjects.txt_City.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_State),State, brandWebsitePageObjects.drpdwn_State.getObjectname());
		
		
		//User entered InActiveEMail
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Email), InActiveEmail,brandWebsitePageObjects.txt_Email.getObjectname());
		//Thread.sleep(3000);
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Step1Next), brandWebsitePageObjects.btn_Step1Next.getObjectname());
		
		//User entered ExistingEmail
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Email), ExistingEmail,brandWebsitePageObjects.txt_Email.getObjectname());
		Thread.sleep(3000);
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Step1Next), brandWebsitePageObjects.btn_Step1Next.getObjectname());

		
	}
	
	
	public void registration_EnterValidDataonStep1() throws InterruptedException, IOException
	{

        String Email = dataTable.getData("General_Data", "Email");
        String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data", "City");
		String State = dataTable.getData("General_Data", "State");
		String date = dataTable.getData("General_Data","DOB");
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
	
        //User entered Valid email
        commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthMonth), month, brandWebsitePageObjects.drpdwn_BirthMonth.getObjectname());
		//Thread.sleep(6000);
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthDay),day,brandWebsitePageObjects.drpdwn_BirthDay.getObjectname());
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthYear), year,brandWebsitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_FirstName), FirstName, brandWebsitePageObjects.txt_FirstName.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LastName),LastName, brandWebsitePageObjects.txt_LastName.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Address),Address, brandWebsitePageObjects.txt_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Zipcode), Zipcode,brandWebsitePageObjects.txt_Zipcode.getObjectname());
		//Thread.sleep(6000);			
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_City), City, brandWebsitePageObjects.txt_City.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_State),State, brandWebsitePageObjects.drpdwn_State.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Email), Email,brandWebsitePageObjects.txt_Email.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.Chkbx_Certify),brandWebsitePageObjects.Chkbx_Certify.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Step1Next), brandWebsitePageObjects.btn_Step1Next.getObjectname());
		
	}
	public void registration_VeloValidDetailsonStep1Page() throws InterruptedException, IOException
	{
		
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String Email = dataTable.getData("General_Data", "Username");
		String PhoneNumber = dataTable.getData("General_Data", "Phone");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
        String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		//commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Registration),brandWebsitePageObjects.btn_Registration.getObjectname());
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthMonth), month, brandWebsitePageObjects.drpdwn_BirthMonth.getObjectname());
		Thread.sleep(6000);
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthDay),day,brandWebsitePageObjects.drpdwn_BirthDay.getObjectname());
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthYear),year,brandWebsitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_FirstName), FirstName, brandWebsitePageObjects.txt_FirstName.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LastName),LastName, brandWebsitePageObjects.txt_LastName.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Address),Address, brandWebsitePageObjects.txt_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Zipcode), Zipcode,brandWebsitePageObjects.txt_Zipcode.getObjectname());
		Thread.sleep(4000);
					
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Email),Email, brandWebsitePageObjects.txt_Email.getObjectname());
		Thread.sleep(5000);
		commonFunction.clickIfElementPresentJavaScript(getPageElement(brandWebsitePageObjects.txt_PhoneRevelVelo),brandWebsitePageObjects.txt_PhoneRevelVelo.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_PhoneRevelVelo),PhoneNumber, brandWebsitePageObjects.txt_PhoneRevelVelo.getObjectname());
		Thread.sleep(3000);
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.chkbx_CertifyRevelVelo),brandWebsitePageObjects.chkbx_CertifyRevelVelo.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_City), City, brandWebsitePageObjects.txt_City.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_State),State, brandWebsitePageObjects.drpdwn_State.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Step1Next), brandWebsitePageObjects.btn_Step1Next.getObjectname());
		Thread.sleep(4000);
	}
	
	
	public void registration_ValidateErrormessageonStep2() throws IOException
	{
		
		String InvalidPasswordformat = dataTable.getData("General_Data", "InvalidPasswordformat");
		String Password = dataTable.getData("General_Data", "Password");
		String IncorrectPassword = dataTable.getData("General_Data", "InvalidPassword");
		
		String Errormessage_NoData = "Please fix the errors above";
		String Errormessage_NoPassword = "Please provide a password";
		String Errormessage_NoChallengeQuestion = "Please select a account recovery question";
		String Errormessage_NoChallengeAnswer = "Please provide an answer to account recovery question";
		String Errormessage_IncorrectPasswordformat = "Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.";
		String Errormessage_DiffPassword = "Passwords did not match";
		
		//User clicked on Next without any data
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Step2Next), brandWebsitePageObjects.btn_Step2Next.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_RegistrationNoPassword), brandWebsitePageObjects.errormsg_RegistrationNoPassword.getObjectname(), Errormessage_NoPassword);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_RegistrationNoChallengeQuestion), brandWebsitePageObjects.errormsg_RegistrationNoChallengeQuestion.getObjectname(), Errormessage_NoChallengeQuestion);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_RegistrationNoChallengeAnswer), brandWebsitePageObjects.errormsg_RegistrationNoChallengeAnswer.getObjectname(), Errormessage_NoChallengeAnswer);
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_RegistrationNoDataonStep2Page), brandWebsitePageObjects.errormsg_RegistrationNoDataonStep2Page.getObjectname(), Errormessage_NoData);
		
		//User entered Password in Invalid format
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Password), InvalidPasswordformat, brandWebsitePageObjects.txt_Password.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_RegistrationIncorrectPasswordformat), brandWebsitePageObjects.errormsg_RegistrationIncorrectPasswordformat.getObjectname(), Errormessage_IncorrectPasswordformat);
		
		//User entered different data in Password & ConfirmPassword fields
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Password),Password, brandWebsitePageObjects.txt_Password.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ConfirmPassword),IncorrectPassword, brandWebsitePageObjects.txt_ConfirmPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Step2Next), brandWebsitePageObjects.btn_Step2Next.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_RegistrationDifferentPasswordsentered), brandWebsitePageObjects.errormsg_RegistrationDifferentPasswordsentered.getObjectname(), Errormessage_DiffPassword);
		
		
	}
	
	
	public void registration_EnterValidDataonStep2() throws IOException
	{
		
		String Password = dataTable.getData("General_Data", "Password");
		String ConfirmPassword = dataTable.getData("General_Data", "Password");
		String ChallengeAnswer = dataTable.getData("General_Data", "ChallengeAnswer");
		String ChallengeQuestion = "What was the name of your first school?";
		
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_Password), Password, brandWebsitePageObjects.txt_Password.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ConfirmPassword), ConfirmPassword, brandWebsitePageObjects.txt_ConfirmPassword.getObjectname());
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_ChallengeQuestion),ChallengeQuestion ,brandWebsitePageObjects.drpdwn_ChallengeQuestion.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ChallengeAnswer),ChallengeAnswer,brandWebsitePageObjects.txt_ChallengeAnswer.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Step2Next), brandWebsitePageObjects.btn_Step2Next.getObjectname());
				
	}
	
	public void navigateToVUSERegistrationPage() throws IOException 
	{
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.loginLnk_VUSECertifyAgePage), brandWebsitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.header_VUSECreateAccount), brandWebsitePageObjects.header_VUSECreateAccount.getObjectname());
	}
	public void registration_VUSEValidDetailsonStep1Page() throws InterruptedException, IOException
	{
		
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String Email = dataTable.getData("General_Data", "Username");
		String PhoneNumber = dataTable.getData("General_Data", "Phone");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
        String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		//commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Registration),brandWebsitePageObjects.btn_Registration.getObjectname());
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthMonth), month, brandWebsitePageObjects.drpdwn_BirthMonth.getObjectname());
		Thread.sleep(6000);
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthDay),day,brandWebsitePageObjects.drpdwn_BirthDay.getObjectname());
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthYear),year,brandWebsitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_FirstName), FirstName, brandWebsitePageObjects.txt_FirstName.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LastName),LastName, brandWebsitePageObjects.txt_LastName.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Address),Address, brandWebsitePageObjects.txt_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Zipcode), Zipcode,brandWebsitePageObjects.txt_Zipcode.getObjectname());
		Thread.sleep(4000);
					
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Email),Email, brandWebsitePageObjects.txt_Email.getObjectname());
		Thread.sleep(5000);
		commonFunction.clickIfElementPresentJavaScript(getPageElement(brandWebsitePageObjects.txt_PhoneRevelVelo),brandWebsitePageObjects.txt_PhoneRevelVelo.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_PhoneRevelVelo),PhoneNumber, brandWebsitePageObjects.txt_PhoneRevelVelo.getObjectname());
		Thread.sleep(3000);
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.chkbx_CertifyRevelVelo),brandWebsitePageObjects.chkbx_CertifyRevelVelo.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_City), City, brandWebsitePageObjects.txt_City.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_State),State, brandWebsitePageObjects.drpdwn_State.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Step1Next), brandWebsitePageObjects.btn_Step1Next.getObjectname());
		Thread.sleep(4000);
	}
	
	public void registration_ValidateErrormessageonStep3() throws Exception
	{
		
		String InvalidSSN= dataTable.getData("General_Data", "InvalidSSN");
		
		String Errormessage_InvalidSSN = "Your Social Security Number does not match your name and date of birth. Please try again.";
		
		try {
			
		if(getPageElement(brandWebsitePageObjects.txt_onlySSNvisible).isDisplayed())
		{
			
			commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_onlySSNvisible),InvalidSSN,brandWebsitePageObjects.txt_onlySSNvisible.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_SubmitwhenonlySSNVisible), brandWebsitePageObjects.btn_SubmitwhenonlySSNVisible.getObjectname());
			commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.erroMsg_RegistrationInvaliSSNNoKBA), brandWebsitePageObjects.erroMsg_RegistrationInvaliSSNNoKBA.getObjectname(), Errormessage_InvalidSSN);
			
			commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_onlySSNvisible),InvalidSSN,brandWebsitePageObjects.txt_onlySSNvisible.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_SubmitwhenonlySSNVisible), brandWebsitePageObjects.btn_SubmitwhenonlySSNVisible.getObjectname());
			
			
			//Thread.sleep(2000);
			commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_SSNonUnabletoVerifyPage),InvalidSSN,brandWebsitePageObjects.txt_SSNonUnabletoVerifyPage.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_SubmitonUnabletoVerifyPage), brandWebsitePageObjects.btn_SubmitonUnabletoVerifyPage.getObjectname());
			//Thread.sleep(3000);
			
			commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_AgeVerificationFailedReturntoSignIn), brandWebsitePageObjects.btn_AgeVerificationFailedReturntoSignIn.getObjectname());
			
		}
		}
		catch(Exception SSN){
		
					
			commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.radiobtn_SSN), brandWebsitePageObjects.radiobtn_SSN.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_SSN),InvalidSSN,brandWebsitePageObjects.txt_SSN.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Submit), brandWebsitePageObjects.btn_Submit.getObjectname());
			commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_RegistrationInvalidSSN), brandWebsitePageObjects.errormsg_RegistrationInvalidSSN.getObjectname(), Errormessage_InvalidSSN);
			
			commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_SSN),InvalidSSN,brandWebsitePageObjects.txt_SSN.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Submit), brandWebsitePageObjects.btn_Submit.getObjectname());
			
			
			//Thread.sleep(2000);
			commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_SSNonUnabletoVerifyPage),InvalidSSN,brandWebsitePageObjects.txt_SSNonUnabletoVerifyPage.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_SubmitonUnabletoVerifyPage), brandWebsitePageObjects.btn_SubmitonUnabletoVerifyPage.getObjectname());
			
		}
		
	}
	
	
	public void registration_ValidateAgeBySSN() throws InterruptedException, IOException
	{
		String SSN= dataTable.getData("General_Data", "SSN");
		
		try {
		
		if(getPageElement(brandWebsitePageObjects.txt_onlySSNvisible).isDisplayed())
		{
			
			commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_onlySSNvisible),SSN,brandWebsitePageObjects.txt_onlySSNvisible.getObjectname());
			//commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_SubmitwhenonlySSNVisible), brandWebsitePageObjects.btn_SubmitwhenonlySSNVisible.getObjectname());
						
		}
		}
		catch(Exception SSN1)
		{
			
			commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.radiobtn_SSN), brandWebsitePageObjects.radiobtn_SSN.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_SSN),SSN,brandWebsitePageObjects.txt_SSN.getObjectname());
			//commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Submit), brandWebsitePageObjects.btn_Submit.getObjectname());
			
		}
		
	}
	
	
	public void registration_NavigatetoHomePage() throws IOException, InterruptedException
	{
		
		//Thread.sleep(3000);
		commonFunction.clickWhenVisible(getPageElement(brandWebsitePageObjects.link_takemetoSite), brandWebsitePageObjects.link_takemetoSite.getObjectname(), 5000);
	
	}
	
	
	
	public void registration_RevelValidDetailsonStep1Page() throws InterruptedException, IOException
	{
		
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String Email = dataTable.getData("General_Data", "Username");
		String PhoneNumber = dataTable.getData("General_Data", "Phone");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
        String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		//commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Registration),brandWebsitePageObjects.btn_Registration.getObjectname());
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthMonth), month, brandWebsitePageObjects.drpdwn_BirthMonth.getObjectname());
		Thread.sleep(6000);
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthDay),day,brandWebsitePageObjects.drpdwn_BirthDay.getObjectname());
		//commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_BirthYear), "1938", brandWebsitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_BirthYear),year,brandWebsitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_FirstName), FirstName, brandWebsitePageObjects.txt_FirstName.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_LastName),LastName, brandWebsitePageObjects.txt_LastName.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Address),Address, brandWebsitePageObjects.txt_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Zipcode), Zipcode,brandWebsitePageObjects.txt_Zipcode.getObjectname());
		Thread.sleep(4000);
					
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_Email),Email, brandWebsitePageObjects.txt_Email.getObjectname());
		Thread.sleep(5000);
		commonFunction.clickIfElementPresentJavaScript(getPageElement(brandWebsitePageObjects.txt_PhoneRevelVelo),brandWebsitePageObjects.txt_PhoneRevelVelo.getObjectname());
		commonFunction.enterText(getPageElement(brandWebsitePageObjects.txt_PhoneRevelVelo),PhoneNumber, brandWebsitePageObjects.txt_PhoneRevelVelo.getObjectname());
		commonFunction.clickIfElementPresentJavaScript(getPageElement(brandWebsitePageObjects.radiobtn_GenderMaleRevel),brandWebsitePageObjects.radiobtn_GenderMaleRevel.getObjectname());
		//commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.radiobtn_GenderMaleRevel),brandWebsitePageObjects.radiobtn_GenderMaleRevel.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.chkbx_CertifyRevelVelo),brandWebsitePageObjects.chkbx_CertifyRevelVelo.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_City), City, brandWebsitePageObjects.txt_City.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_State),State, brandWebsitePageObjects.drpdwn_State.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_Step1Next), brandWebsitePageObjects.btn_Step1Next.getObjectname());
		Thread.sleep(4000);
	}
			
}



//Issues:
//1.issue with 'take me to site' link on Congrats page - identify the locator attribute again & update
//2.Need to try & catch block for every function.
//3.Need to reduce the time - need to figure out for thread.sleep or Implicit wait

