package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.brandWebsitePageObjects;

public class BrandWebsite_ForgotUsername_UsernotfoundPage extends BaseClass {

	String testcaseName;
	public BrandWebsite_ForgotUsername_UsernotfoundPage(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(brandWebsitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("ForgotUsername Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	public void invokeApplication_brandwebsite()
	{
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);	
		
		
	}
	public void navigateToForgotUsernamePage() throws IOException {
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.lnktxt_Forgetusername), brandWebsitePageObjects.lnktxt_Forgetusername.getObjectname());
	}
	
	public void navigateToRevelVeloForgotUsernamePage() throws IOException {
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.lnktxt_RevelVeloForgotUsername), brandWebsitePageObjects.lnktxt_RevelVeloForgotUsername.getObjectname());	
	}
	
    public void navigateToVUSEForgotUsernamePage() throws IOException
    {
    	commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.loginLnk_VUSECertifyAgePage), brandWebsitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.lnk_VUSELoginForgotUsername), brandWebsitePageObjects.lnk_VUSELoginForgotUsername.getObjectname());	
	}
	
	public void forgotUsername_InvalidUserInfoonAccountInformationPage() throws InterruptedException, IOException
	{
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String DOB = dataTable.getData("General_Data","DOB");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
		
		//UserInformation not found - valid data but Invalid UserInfo - click Continue for the 1st time
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		String Errormessage_UserInfonotfound = "We were not able to find your information. Please check and try again.";
	
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_ForgotUsernameBirthMonth), month, brandWebsitePageObjects.drpdwn_ForgotUsernameBirthMonth.getObjectname());
		Thread.sleep(2000);
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotUsernameBirthDay),day,brandWebsitePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotUsernameBirthYear),year, brandWebsitePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotUsernameFirstName), FirstName, brandWebsitePageObjects.txt_ForgotUsernameFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotUsernameLastName), LastName, brandWebsitePageObjects.txt_ForgotUsernameLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotUsernameAddress), Address, brandWebsitePageObjects.txt_ForgotUsernameAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotUsernameZipcode), Zipcode,brandWebsitePageObjects.txt_ForgotUsernameZipcode.getObjectname());
		Thread.sleep(3000);
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotUsernameCity), City, brandWebsitePageObjects.txt_ForgotUsernameCity.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotUsernameState),State, brandWebsitePageObjects.drpdwn_ForgotUsernameState.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotUsernameAccountInformation),brandWebsitePageObjects.btn_ForgotUsernameAccountInformation.getObjectname());
		
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_ForgotUsernameUsernotfound), brandWebsitePageObjects.errormsg_ForgotUsernameUsernotfound.getObjectname(), Errormessage_UserInfonotfound);
		
		
		//UserInformation not found - valid data but invalid UserInfo - Click Continue for the 2nd time
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotUsernameAccountInformation),brandWebsitePageObjects.btn_ForgotUsernameAccountInformation.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(brandWebsitePageObjects.errormsg_ForgotUsernameUsernotfound), brandWebsitePageObjects.errormsg_ForgotUsernameUsernotfound.getObjectname(), Errormessage_UserInfonotfound);
		
		//UserInformation not found - valid data but Invalid UserInfo - Click Continue for the 3rd time
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotUsernameAccountInformation),brandWebsitePageObjects.btn_ForgotUsernameAccountInformation.getObjectname());
	
	}
	
	
	
	public void forgotUsername_UsernotFoundPage() throws Exception
	{
		
		commonFunction.verifyIfElementIsPresent(getPageElement(brandWebsitePageObjects.forgotUsername_usernotfoundPage), brandWebsitePageObjects.forgotUsername_usernotfoundPage.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.gotoRegistration_UsernotfoundPage), brandWebsitePageObjects.gotoRegistration_UsernotfoundPage.getObjectname());
						
	}
	
	

}

