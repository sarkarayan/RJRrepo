package com.rai.pages;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.rai.framework.Status;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.framework.RecogniseText;
import com.rai.componentgroups.*;
import com.rai.pageObjects.MobileSite_MyprofilePageObjects;
import com.rai.pageObjects.MobilesitePageObjects;
import com.rai.pageObjects.MobilesitePageObjects;

public class Mobilesite_SGWImageandTextValidation extends BaseClass {

	String testcaseName;

	public Mobilesite_SGWImageandTextValidation(String testcaseName) {
		this.testcaseName = testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper The {@link ScriptHelper} object passed from the
	 *                     {@link DriverScript}
	 */

	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	private WebElement getPageElement(MobilesitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}

	public void invokeApplication_brandMobilesite() {
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.get(WebsiteURL);
	}

	public void validatingSGWtext() throws Exception {

		String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
		String path = System.getProperty("user.dir") + "\\src\\test\\resources\\SGW_Images\\SGW_Image.png";
		Thread.sleep(3000);

		// RecogniseText.validateImages(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink));
		// commonFunction.validateImage(path, "Pre Login Footer SGW", "SGW Image
		// Validation");
		Thread.sleep(2000);
		commonFunction.scrollDown();
		commonFunction.scrollDown();
		// commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink));
		String altText = commonFunction.getValueFromAttribute(
				getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink),
				MobilesitePageObjects.sgwText_PreLoginfooterlink.getObjectname(), "alt");
		String actualImageText = RecogniseText.extractImageTextUsingScreenShot(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink));
		commonFunction.compareStrings(Expected_SGWtext, actualImageText);
		commonFunction.compareStrings(Expected_SGWtext, altText);

	}

	public void NewportvalidatingSGWtext() throws Exception {

		String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
		String path = System.getProperty("user.dir") + "\\src\\test\\resources\\SGW_Images\\Newport_SGW_Image.png";
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink));
		commonFunction.validateImage(path, "Pre Login Footer SGW", "SGW Image Validation");
		String altText = commonFunction.getValueFromAttribute(
				getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink),
				MobilesitePageObjects.sgwText_PreLoginfooterlink.getObjectname(), "alt");
		String actualImageText = RecogniseText.extractImageText(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink));
		commonFunction.compareStrings(Expected_SGWtext, actualImageText);
		commonFunction.compareStrings(Expected_SGWtext, altText);

	}

	public void pallmall_validateSGWtext() throws Exception {

		String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
		String path = System.getProperty("user.dir") + "\\src\\test\\resources\\SGW_Images\\PallMall_SGW_Image.png";
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink));
		commonFunction.validateImage(path, "Pre Login Footer SGW", "SGW Image Validation");
		String altText = commonFunction.getValueFromAttribute(
				getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink),
				MobilesitePageObjects.sgwText_PreLoginfooterlink.getObjectname(), "alt");
		String actualImageText = RecogniseText.extractImageText(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink));
		commonFunction.compareStrings(Expected_SGWtext, actualImageText);
		commonFunction.compareStrings(Expected_SGWtext, altText);

	}

	public void nascigs_ValidatingSGWtext() throws Exception {
		String expectedSGWText1 = dataTable.getData("General_Data", "NascigsSGWText1");

		String altText1 = commonFunction.getValueFromAttribute(
				getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink1_Nascigs),
				MobilesitePageObjects.sgwText_PreLoginfooterlink1_Nascigs.getObjectname(), "alt");
		commonFunction.scrollDown();
		commonFunction.scrollDown();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		String actualImageText1 = RecogniseText.extractImageTextUsingScreenShotNascigs(
				getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink1_Nascigs));
		commonFunction.compareStrings(expectedSGWText1, actualImageText1);
		commonFunction.compareStrings(expectedSGWText1, altText1);

	}

	public void ecommercesites_ValidatingSGWtext() throws Exception {
		String Expected_SGWtext = dataTable.getData("General_Data", "SGW");

		String actualImageText = RecogniseText.extractImageText(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink_ecommercesites));
		String altText = commonFunction
				.getTextFromElement(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink_ecommercesites));
		commonFunction.compareStrings(Expected_SGWtext, actualImageText);
		commonFunction.compareStrings(Expected_SGWtext, altText);
	}

	public void nascigsPostLogin_ValidatingSGWtext() throws Exception {
		String expectedSGWText1 = dataTable.getData("General_Data", "NascigsSGWText1");
		
		String altText1 = commonFunction.getValueFromAttribute(
				getPageElement(MobilesitePageObjects.sgwText_PostLoginfooterlink1_Nascigs),
				MobilesitePageObjects.sgwText_PostLoginfooterlink1_Nascigs.getObjectname(), "alt");
		
		commonFunction.scrollDown();
		commonFunction.scrollDown();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		
		String actualImageText1 = RecogniseText.extractImageTextUsingScreenShotNascigs(getPageElement(MobilesitePageObjects.sgwText_PostLoginfooterlink1_Nascigs));
		commonFunction.compareStrings(expectedSGWText1, actualImageText1);
		commonFunction.compareStrings(expectedSGWText1, altText1);

	}

	public void camelPostLogin_ValidatingSGWtext() throws Exception {
		String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
		String path = System.getProperty("user.dir") + File.separator + "/src/test/resources/SGW_Images/SGW_Image.png";
		String altText = commonFunction.getValueFromAttribute(getPageElement(MobilesitePageObjects.sgwText_PostLoginfooterlink_Camel),
				MobilesitePageObjects.sgwText_PostLoginfooterlink_Camel.getObjectname(), "alt");
		// commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.sgwText_PostLoginfooterlink_Camel));
		// commonFunction.validateImage(path, "Camel Brand - Home Page", "SGW Image on
		// Home Page");
		commonFunction.scrollDown();
		String actualImageText = RecogniseText.extractImageTextUsingScreenShot(getPageElement(MobilesitePageObjects.sgwText_PostLoginfooterlink_Camel));
		commonFunction.compareStrings(Expected_SGWtext, actualImageText);
		commonFunction.compareStrings(Expected_SGWtext, altText);
		// System.out.println(commonFunction.equalsIgnoreNewlineStyle(Expected_SGWtext,
		// actualImageText));

	}

	public void pallmallPostLogin_ValidatingSGWtext() throws Exception {
		String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
		String path = "C:\\Users\\814109\\Downloads\\RAI-framework-Jan 18\\RAI-framework\\src\\test\\resources\\SGW_ImagesPallMall_SGW_Image.png";
		String altText = commonFunction.getValueFromAttribute(
				getPageElement(MobilesitePageObjects.sgwText_PostLoginfooterlink_Pallmall),
				MobilesitePageObjects.sgwText_PostLoginfooterlink_Pallmall.getObjectname(), "alt");
		// commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.sgwText_PostLoginfooterlink_Pallmall));
		// commonFunction.validateImage(path, "Pallmall Brand Post Login", "SGW Image on
		// Home Page");
		commonFunction.scrollDown();
		String actualImageText = RecogniseText.extractImageTextUsingScreenShot(getPageElement(MobilesitePageObjects.sgwText_PostLoginfooterlink_Pallmall));
		commonFunction.compareStrings(Expected_SGWtext, actualImageText);
		commonFunction.compareStrings(Expected_SGWtext, altText);
		System.out.println(commonFunction.equalsIgnoreNewlineStyle(Expected_SGWtext, actualImageText));

	}

	public void newportPostLogin_ValidatingSGWtext() throws Exception {
		String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
		String path = System.getProperty("user.dir") + "\\src\\test\\resources\\SGW_Images\\Newport_SGW_Image.png";
		String altText = commonFunction.getValueFromAttribute(getPageElement(MobilesitePageObjects.sgwText_PostLoginfooterlink_Newport),
				MobilesitePageObjects.sgwText_PostLoginfooterlink_Newport.getObjectname(), "alt");
		// commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.sgwText_PostLoginfooterlink_Newport));
		// commonFunction.validateImage(path, "Pallmall Brand Post Login", "SGW Image on
		// Home Page");
		commonFunction.scrollDown();
		String actualImageText = RecogniseText.extractImageTextUsingScreenShot(getPageElement(MobilesitePageObjects.sgwText_PostLoginfooterlink_Newport));
		commonFunction.compareStrings(Expected_SGWtext, actualImageText);
		commonFunction.compareStrings(Expected_SGWtext, altText);
		System.out.println(commonFunction.equalsIgnoreNewlineStyle(Expected_SGWtext, actualImageText));

	}

	public void grizzlyPostLogin_ValidatingSGWtext() throws Exception {
		String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
		String Actual_SGWtext = commonFunction.getTextFromElement(getPageElement(MobilesitePageObjects.sgwText_PostLoginfooterlink_Grizzly));

		commonFunction.compareStrings(Expected_SGWtext, Actual_SGWtext);

	}

	public void vusePostLogin_footerlinks_ValidatingSGWtext() throws Exception {

		String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
		String Actual_SGWtext = commonFunction.getTextFromElement(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink_ecommercesites));
		String CurrentUrl = driver.getCurrentUrl();
		// PostLogin - StoreLocator footerlink
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_StoreLocator));
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_StoreLocator),
				MobilesitePageObjects.PostLoginVUSEfooterlnk_StoreLocator.getObjectname());

		String ActualPostLoginStoreLocatorTitle = driver.getTitle();
		String ExpectedPostLoginStoreLocatorTitle = "Retail Locator";
		commonFunction.compareStrings(ExpectedPostLoginStoreLocatorTitle, ActualPostLoginStoreLocatorTitle);

		commonFunction.compareStrings(Expected_SGWtext, Actual_SGWtext);

		driver.navigate().to(CurrentUrl);

		// PostLogin - FAQs footerlink
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_FAQs));
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_FAQs),MobilesitePageObjects.PostLoginVUSEfooterlnk_FAQs.getObjectname());

		String ActualPostLoginFAQsTitle = driver.getTitle();
		String ExpectedPostLoginFAQsTitle = "FAQs";
		commonFunction.compareStrings(ExpectedPostLoginFAQsTitle, ActualPostLoginFAQsTitle);

		commonFunction.compareStrings(Expected_SGWtext, Actual_SGWtext);

		driver.navigate().to(CurrentUrl);

		// PostLogin - Patents footer link
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_Patents));
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_Patents),MobilesitePageObjects.PostLoginVUSEfooterlnk_Patents.getObjectname());

		String ActualPostLoginPatentsTitle = driver.getTitle();
		String ExpectedPostLoginPatentsTitle = "VUSE Patents";
		commonFunction.compareStrings(ExpectedPostLoginPatentsTitle, ActualPostLoginPatentsTitle);

		commonFunction.compareStrings(Expected_SGWtext, Actual_SGWtext);

		driver.navigate().to(CurrentUrl);

		// PostLogin - SiteMap
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_SiteMap));
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_SiteMap),MobilesitePageObjects.PostLoginVUSEfooterlnk_SiteMap.getObjectname());

		String ActualPostLoginSiteMapTitle = driver.getTitle();
		String ExpectedPostLoginSiteMapTitle = "SiteMap";
		commonFunction.compareStrings(ExpectedPostLoginSiteMapTitle, ActualPostLoginSiteMapTitle);

		commonFunction.compareStrings(Expected_SGWtext, Actual_SGWtext);

		driver.navigate().to(CurrentUrl);

		// PostLogin - TermsOfSale
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_TermsOfSale));
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_TermsOfSale),MobilesitePageObjects.PostLoginVUSEfooterlnk_TermsOfSale.getObjectname());

		String ActualPostLoginTermsOfSaleTitle = driver.getTitle();
		String ExpectedPostLoginTermsOfSaleTitle = "Terms of Sale";
		commonFunction.compareStrings(ExpectedPostLoginTermsOfSaleTitle, ActualPostLoginTermsOfSaleTitle);

		commonFunction.compareStrings(Expected_SGWtext, Actual_SGWtext);
		driver.navigate().to(CurrentUrl);

	}

	public void vusePostLogin_AccountDashoard_ValidatingSGWText() throws Exception {

		String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
		String Actual_SGWtext = commonFunction
				.getTextFromElement(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink_ecommercesites));

		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSE_MyAccount),
				MobilesitePageObjects.PostLoginVUSE_MyAccount.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSE_MyAccountlink),
				MobilesitePageObjects.PostLoginVUSE_MyAccountlink.getObjectname());

		commonFunction.compareStrings(Expected_SGWtext, Actual_SGWtext);

	}

	public void revelPostLoginFooterLinks_SGWTextValidation() throws Exception {
		String Expected_SGWtext = dataTable.getData("General_Data", "SGW");
		String Actual_SGWtext = commonFunction
				.getTextFromElement(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink_ecommercesites));
		String CurrentUrl = driver.getCurrentUrl();
		// PostLogin - FAQs footerlink
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_FAQs));
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_FAQs),
				MobilesitePageObjects.PostLoginRevelfooterlnk_FAQs.getObjectname());

		String ActualPostLoginFAQsTitle = driver.getTitle();
		String ExpectedPostLoginFAQsTitle = "FAQs";
		commonFunction.compareStringsContains(ExpectedPostLoginFAQsTitle, ActualPostLoginFAQsTitle);

		commonFunction.compareStrings(Expected_SGWtext, Actual_SGWtext);

		driver.navigate().to(CurrentUrl);

		// PreLogin - TermsOfSale
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_TermsOfSale));
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginRevelfooterlnk_TermsOfSale),
				MobilesitePageObjects.PostLoginRevelfooterlnk_TermsOfSale.getObjectname());

		String ActualTermsOfSaleTitle = driver.getTitle();
		String ExpectedTermsOfSaleTitle = "Terms of Sale";
		commonFunction.compareStringsContains(ExpectedTermsOfSaleTitle, ActualTermsOfSaleTitle);

		commonFunction.compareStrings(Expected_SGWtext, Actual_SGWtext);

		driver.navigate().to(CurrentUrl);

	}

	public void grizzly_ValidatingSGWText() throws Exception, Exception {

		if (commonFunction.isElementPresentVerification(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink_Grizzly1200),
				MobilesitePageObjects.sgwText_PreLoginfooterlink_Grizzly1200.getObjectname())) {
			String ExpectedSGWText = dataTable.getData("General_Data", "SGW");
			String ActualSGWText = commonFunction.getValueFromAttribute(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink_Grizzly1200),
					MobilesitePageObjects.sgwText_PreLoginfooterlink_Grizzly1200.getObjectname(), "alt");

			commonFunction.compareStrings(ExpectedSGWText, ActualSGWText);

		}

		else if (commonFunction.isElementPresentVerification(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink_Grizzly480),
				MobilesitePageObjects.sgwText_PreLoginfooterlink_Grizzly480.getObjectname())) {

			String ExpectedSGWText = dataTable.getData("General_Data", "SGW");
			String ActualSGWText = commonFunction.getValueFromAttribute(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink_Grizzly480),
					MobilesitePageObjects.sgwText_PreLoginfooterlink_Grizzly480.getObjectname(), "alt");

			commonFunction.compareStrings(ExpectedSGWText, ActualSGWText);
		}

		else if (commonFunction.isElementPresentVerification(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink_Grizzly720),
				MobilesitePageObjects.sgwText_PreLoginfooterlink_Grizzly720.getObjectname())) {

			String ExpectedSGWText = dataTable.getData("General_Data", "SGW");
			String ActualSGWText = commonFunction.getValueFromAttribute(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink_Grizzly720),
					MobilesitePageObjects.sgwText_PreLoginfooterlink_Grizzly720.getObjectname(), "alt");

			commonFunction.compareStrings(ExpectedSGWText, ActualSGWText);
		}

		else if (commonFunction.isElementPresentVerification(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink_Grizzly960),
				MobilesitePageObjects.sgwText_PreLoginfooterlink_Grizzly960.getObjectname())) {

			String ExpectedSGWText = dataTable.getData("General_Data", "SGW");
			String ActualSGWText = commonFunction.getValueFromAttribute(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink_Grizzly960),
					MobilesitePageObjects.sgwText_PreLoginfooterlink_Grizzly960.getObjectname(), "alt");

			commonFunction.compareStrings(ExpectedSGWText, ActualSGWText);
		}

		else if (commonFunction.isElementPresentVerification(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink_Grizzly320),
				MobilesitePageObjects.sgwText_PreLoginfooterlink_Grizzly320.getObjectname())) {

			String ExpectedSGWText = dataTable.getData("General_Data", "SGW");
			String ActualSGWText = commonFunction.getValueFromAttribute(getPageElement(MobilesitePageObjects.sgwText_PreLoginfooterlink_Grizzly320),
					MobilesitePageObjects.sgwText_PreLoginfooterlink_Grizzly320.getObjectname(), "alt");

			commonFunction.compareStrings(ExpectedSGWText, ActualSGWText);
		}

	}
}
