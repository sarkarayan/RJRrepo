package com.rai.pages;

import java.util.Properties;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.pageObjects.*;
import com.rai.framework.GenericLib;

@Listeners(ExtentITestListenerClassAdapter.class)
public class Camel_OffersPage extends BaseClass {
	GenericLib gl = new GenericLib(this.getClass().getSimpleName());
	Properties config = new Properties();
	SoftAssert softAssert=new SoftAssert();


	@BeforeMethod
	public void beforemethod(String TestCaseName,String TestCaseObjective,String TestEnvironmentUrl) {
		gl.start_report(TestCaseName, TestCaseObjective, TestEnvironmentUrl);
		//extent = ExtentManager.GetExtent();	
		//extent = ExtentManager.createTest(test, description)
	}

	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Verify the Offers Landing page Content, images and buttons.
	//Test case name : Camel_Redesign_Offers_006
	//Verifies:
	//Offer landing page UI/buttons and images
	//Pre requisites :
	//User should have valid username and password
	//Author : Vikram T Date: 21.11.2018
	public void  Camel_Redesign_Offers_007(String UN,String pwd,String url, String browserName,String txtContent1,String txtContent2 )throws Exception
	{
		// Launch Application
		gl.launchApplication(browserName, url);
		Thread.sleep(2000);

		//*********************************************************************************************************************      
		//Camel Login page is displayed.
		//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login page is displayed");
		//*********************************************************************************************************************          
		//Enter valid email id 
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter valid password

		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd) ;
		//Click login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
		//Camel Home page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("Camel","Camel Home");
		//Click on offers link
		gl.clickbutton(Camel_Common.lnkCoupons,"Coupons link");
		//Verify that Offers page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("Camel","Coupon's page");
		//Verify text "Your offers is visible"
		//gl.VerifyElementVisible(Camel_Offers.weYourOffers,"Your Offers");
		//		//Verify Crush banner is displayed
		//		gl.VerifyElementVisible(Camel_Offers.weBannerTile,"crush");
		//		
		//		//Click on "Explore crush " button
		//		gl.clickbutton(Camel_Offers.btnExploreCrush,"Explore Crush");
		//		//Verify that crush product page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("Products - Crush | Camel","Crush product page");
		//		//Click on browser back button
		//		gl.browserBack();
		//		//Verify that Offers page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("Offers | Camel","Camel Offer's page");
		//Click on Crush Instant win rules
		//gl.clickbutton(Camel_Offers.lnkCrushInstantRules,"Crush Instant win official rule");
		//Verify that crush official rules page is displayed
		//	gl.fnVerifyPageDisplayedUsingPageTitle("Crush | Camel","Crush Instant win Official rules page");
		//Click on browser back button
		//	gl.fnBrowserBack();
		//Verify that Offers page is displayed
		//	gl.fnVerifyPageDisplayedUsingPageTitle("Offers | Camel","Camel Offer's page");
		//verify text mobile coupons is displayed
		gl.VerifyElementVisible(Camel_Offers.weMobileCoupons,"Mobile Coupons");
		//verify coupon section is displayed
		gl.VerifyElementVisible(Camel_Offers.weCouponTile,"Mobile coupon");


		//Verify text "Void where ......"  is displayed
		gl.fnContentValidation(txtContent2,Camel_Offers.weRules1);
		//Click on google play icon
		gl.clickUsingJs(Camel_Offers.btnGetItOnGooglePlay, "Get it on google play");
		//Verify that Play store page is opened in new tab
		//Switch to new tab
		gl.fnSwitchToSucceedingTab();

		gl.fnVerifyPageDisplayedUsingPageTitle("The Oasis - Mobile - Apps on Google Play","Play store Oasis app page");
		//Close the current tab 
		//      //Close tab
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();

		//Verify that Offers page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("Camel","Camel offers page");
		gl.fnScrollToView(Camel_Offers.btnNeedMoreHelp);
		//Verify images are visible
		gl.VerifyElementVisible(Camel_Offers.imgHowToUse1,"How to use");
		//Verify images are visible
		gl.VerifyElementVisible(Camel_Offers.imgHowToUse2,"How to use");
		//Verify images are visible
		gl.VerifyElementVisible(Camel_Offers.imgHowToUse3,"How to use");
		//Verify images are visible
		gl.VerifyElementVisible(Camel_Offers.imgHowToUse4,"How to use");
		//Verify that how to use content is displayed
		gl.fnContentValidation(txtContent1,Camel_Offers.weHowToUseTile);
		//Click on "need more help" button
		gl.clickbutton(Camel_Offers.btnNeedMoreHelp,"Need for help?");
		//Switch to new tab
		gl.fnSwitchToSucceedingTab();
		//Verify that FAQ page is displayed 
		gl.fnVerifyPageDisplayedUsingPageTitle("Frequently Asked Questions","CAMEL faq's page");
		//Close the current tab 
		//      //Close tab
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();

		//Verify that Offers page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("Camel","Camel offers page");



		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");






	}




	public void afterMethod() {
		driver.quit();
		gl.endReport();
		//extent.flush();
	}
	//


}
