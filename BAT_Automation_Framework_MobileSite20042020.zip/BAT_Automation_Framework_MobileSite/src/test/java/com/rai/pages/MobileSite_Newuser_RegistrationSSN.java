package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.framework.Status;
import com.rai.pageObjects.MobileSiteLoginPageObjects;
import com.rai.pageObjects.MobileSite_Newuser_SSN_RegistrationPageObjects;
import com.rai.pageObjects.MobilesitePageObjects;
import com.rai.pageObjects.MobilesitePageObjects;
import com.rai.pageObjects.MobilesitePageObjects;


public class MobileSite_Newuser_RegistrationSSN extends BaseClass{
	
	String testcaseName;
	public MobileSite_Newuser_RegistrationSSN(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}
	
   CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	private WebElement getPageElement(MobilesitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	private WebElement getPageElement(MobileSiteLoginPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Mobile Site Login Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	public void invokeApplication_brandMobilesite()
	{
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);	
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
	}
	
	public void navigateToRegistrationPage() throws IOException {
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btn_Registration), MobilesitePageObjects.btn_Registration.getObjectname());
	}
	
	public void navigateToRevelRegistrationPage() throws IOException {
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_RegistrationRevel), MobilesitePageObjects.btn_RegistrationRevel.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btn_Registration), MobilesitePageObjects.btn_Registration.getObjectname());
	}
	
	public void registration_ValidateErrormessagesonStep1() throws InterruptedException, IOException
	{
		String Errormessage_NoDOB = "Please provide your full date of birth";
		String Errormessage_NoData = "Please fix the errors above";
		String Errormessage_NoLegalName = "Please enter your legal name";
		String Errormessage_NoAddress = "Please provide a street address";
		String Errormessage_NoZipcode = "Please provide a ZIP Code";
		String Errormessage_NoCity = "Please Provide City";
		String Errormessage_NoState = "Please Provide State";
		String Errormessage_NoEmail = "Please enter a valid email address";
		
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data", "City");
		String State = dataTable.getData("General_Data", "State");
		String InvalidEmail = dataTable.getData("General_Data", "InvalidUserIDformat");
		String InActiveEmail = dataTable.getData("General_Data", "NonExistUserId");
		String ExistingEmail = dataTable.getData("General_Data", "ExistingUserId");
		
		String date = dataTable.getData("General_Data","DOB");
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		//commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Registration), MobilesitePageObjects.btn_Registration.getObjectname());
		//Thread.sleep(7000);
		
		//User clicked on Next without any data
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.btn_Step1Next), MobilesitePageObjects.btn_Step1Next.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.errmsg_Step1), MobilesitePageObjects.errmsg_Step1.getObjectname(), Errormessage_NoData);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.errormsg_RegistrationNoDOB), MobilesitePageObjects.errormsg_RegistrationNoLegalName.getObjectname(), Errormessage_NoDOB);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.errormsg_RegistrationNoLegalName), MobilesitePageObjects.errormsg_RegistrationNoLegalName.getObjectname(), Errormessage_NoLegalName);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.errormsg_RegistrationNoAddress), MobilesitePageObjects.errormsg_RegistrationNoAddress.getObjectname(), Errormessage_NoAddress);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.errormsg_RegistrationNoZipcode), MobilesitePageObjects.errormsg_RegistrationNoZipcode.getObjectname(), Errormessage_NoZipcode);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.errormsg_RegistrationNoCity), MobilesitePageObjects.errormsg_RegistrationNoCity.getObjectname(), Errormessage_NoCity);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.errormsg_RegistrationNoState), MobilesitePageObjects.errormsg_RegistrationNoState.getObjectname(), Errormessage_NoState);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.errormsg_RegistrationNoEmail), MobilesitePageObjects.errormsg_RegistrationNoEmail.getObjectname(), Errormessage_NoEmail);
		
		//User entered InvalidEmail
		commonFunction.selectAnyElement(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.drpdwn_BirthMonth), month, MobilesitePageObjects.drpdwn_BirthMonth.getObjectname());
		//Thread.sleep(6000);
		commonFunction.selectAnyElement(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.drpdwn_BirthDay),day,MobilesitePageObjects.drpdwn_BirthDay.getObjectname());
		commonFunction.selectAnyElement(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.drpdwn_BirthYear), year,MobilesitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.enterText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_FirstName), FirstName, MobilesitePageObjects.txt_FirstName.getObjectname());
		commonFunction.enterText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_LastName),LastName, MobilesitePageObjects.txt_LastName.getObjectname());
		commonFunction.enterText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_Address),Address, MobilesitePageObjects.txt_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_Zipcode), Zipcode,MobilesitePageObjects.txt_Zipcode.getObjectname());
		//Thread.sleep(6000);			
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_Email), InvalidEmail,MobilesitePageObjects.txt_Email.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_City), City, MobilesitePageObjects.txt_City.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.drpdwn_State),State, MobilesitePageObjects.drpdwn_State.getObjectname());
		
		
		//User entered InActiveEMail
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_Email), InActiveEmail,MobilesitePageObjects.txt_Email.getObjectname());
		//Thread.sleep(3000);
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.btn_Step1Next), MobilesitePageObjects.btn_Step1Next.getObjectname());
		
		//User entered ExistingEmail
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_Email), ExistingEmail,MobilesitePageObjects.txt_Email.getObjectname());
		Thread.sleep(3000);
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.btn_Step1Next), MobilesitePageObjects.btn_Step1Next.getObjectname());

		
	}
	
	public void registration_VUSEValidDetailsonStep1Page() throws InterruptedException, IOException
	{
		
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String Email = dataTable.getData("General_Data", "Username");
		String PhoneNumber = dataTable.getData("General_Data", "Phone");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
        String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		//commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Registration),MobilesitePageObjects.btn_Registration.getObjectname());
		commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.drpdwn_BirthMonth), month, MobilesitePageObjects.drpdwn_BirthMonth.getObjectname());
		Thread.sleep(6000);
		commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.drpdwn_BirthDay),day,MobilesitePageObjects.drpdwn_BirthDay.getObjectname());
		commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.drpdwn_BirthYear),year,MobilesitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_FirstName), FirstName, MobilesitePageObjects.txt_FirstName.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_LastName),LastName, MobilesitePageObjects.txt_LastName.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_Address),Address, MobilesitePageObjects.txt_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_Zipcode), Zipcode,MobilesitePageObjects.txt_Zipcode.getObjectname());
		Thread.sleep(4000);
					
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_Email),Email, MobilesitePageObjects.txt_Email.getObjectname());
		Thread.sleep(5000);
		commonFunction.clickIfElementPresentJavaScript(getPageElement(MobilesitePageObjects.txt_PhoneRevelVelo),MobilesitePageObjects.txt_PhoneRevelVelo.getObjectname());
		commonFunction.enterText(getPageElement(MobilesitePageObjects.txt_PhoneRevelVelo),PhoneNumber, MobilesitePageObjects.txt_PhoneRevelVelo.getObjectname());
		Thread.sleep(3000);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.chkbx_CertifyRevelVelo),MobilesitePageObjects.chkbx_CertifyRevelVelo.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_City), City, MobilesitePageObjects.txt_City.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobilesitePageObjects.drpdwn_State),State, MobilesitePageObjects.drpdwn_State.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Step1Next), MobilesitePageObjects.btn_Step1Next.getObjectname());
		Thread.sleep(4000);
	}
	
	public void registration_EnterValidDataonStep1() throws InterruptedException, IOException
	{

        String Email = dataTable.getData("General_Data", "Email");
        String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data", "City");
		String State = dataTable.getData("General_Data", "State");
		String date = dataTable.getData("General_Data","DOB");
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
	
        //User entered Valid email
        commonFunction.selectAnyElement(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.drpdwn_BirthMonth), month, MobilesitePageObjects.drpdwn_BirthMonth.getObjectname());
		//Thread.sleep(6000);
		commonFunction.selectAnyElement(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.drpdwn_BirthDay),day,MobilesitePageObjects.drpdwn_BirthDay.getObjectname());
		commonFunction.selectAnyElement(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.drpdwn_BirthYear), year,MobilesitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_FirstName), FirstName, MobilesitePageObjects.txt_FirstName.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_LastName),LastName, MobilesitePageObjects.txt_LastName.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_Address),Address, MobilesitePageObjects.txt_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_Zipcode), Zipcode,MobilesitePageObjects.txt_Zipcode.getObjectname());
		//Thread.sleep(6000);			
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_City), City, MobilesitePageObjects.txt_City.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.drpdwn_State),State, MobilesitePageObjects.drpdwn_State.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_Email), Email,MobilesitePageObjects.txt_Email.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.Chkbx_Certify),MobilesitePageObjects.Chkbx_Certify.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.btn_Step1Next), MobilesitePageObjects.btn_Step1Next.getObjectname());
		
	}
	
	public void registration_ValidateErrormessageonStep2() throws IOException
	{
		
		String InvalidPasswordformat = dataTable.getData("General_Data", "InvalidPasswordformat");
		String Password = dataTable.getData("General_Data", "Password");
		String IncorrectPassword = dataTable.getData("General_Data", "InvalidPassword");
		
		String Errormessage_NoData = "Please fix the errors above";
		String Errormessage_NoPassword = "Please provide a password";
		String Errormessage_NoChallengeQuestion = "Please select a account recovery question";
		String Errormessage_NoChallengeAnswer = "Please provide an answer to account recovery question";
		String Errormessage_IncorrectPasswordformat = "Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.";
		String Errormessage_DiffPassword = "Passwords did not match";
		
		//User clicked on Next without any data
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.btn_Step2Next), MobilesitePageObjects.btn_Step2Next.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.errormsg_RegistrationNoPassword), MobilesitePageObjects.errormsg_RegistrationNoPassword.getObjectname(), Errormessage_NoPassword);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.errormsg_RegistrationNoChallengeQuestion), MobilesitePageObjects.errormsg_RegistrationNoChallengeQuestion.getObjectname(), Errormessage_NoChallengeQuestion);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.errormsg_RegistrationNoChallengeAnswer), MobilesitePageObjects.errormsg_RegistrationNoChallengeAnswer.getObjectname(), Errormessage_NoChallengeAnswer);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.errormsg_RegistrationNoDataonStep2Page), MobilesitePageObjects.errormsg_RegistrationNoDataonStep2Page.getObjectname(), Errormessage_NoData);
		
		//User entered Password in Invalid format
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_Password), InvalidPasswordformat, MobilesitePageObjects.txt_Password.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.errormsg_RegistrationIncorrectPasswordformat), MobilesitePageObjects.errormsg_RegistrationIncorrectPasswordformat.getObjectname(), Errormessage_IncorrectPasswordformat);
		
		//User entered different data in Password & ConfirmPassword fields
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_Password),Password, MobilesitePageObjects.txt_Password.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_ConfirmPassword),IncorrectPassword, MobilesitePageObjects.txt_ConfirmPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.btn_Step2Next), MobilesitePageObjects.btn_Step2Next.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.errormsg_RegistrationDifferentPasswordsentered), MobilesitePageObjects.errormsg_RegistrationDifferentPasswordsentered.getObjectname(), Errormessage_DiffPassword);
		
		}
	public void registration_VeloValidDetailsonStep1Page() throws InterruptedException, IOException
	{
		
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String Email = dataTable.getData("General_Data", "Username");
		String PhoneNumber = dataTable.getData("General_Data", "Phone");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
        String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		//commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Registration),MobilesitePageObjects.btn_Registration.getObjectname());
		commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.drpdwn_BirthMonth), month, MobilesitePageObjects.drpdwn_BirthMonth.getObjectname());
		Thread.sleep(6000);
		commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.drpdwn_BirthDay),day,MobilesitePageObjects.drpdwn_BirthDay.getObjectname());
		commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.drpdwn_BirthYear),year,MobilesitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_FirstName), FirstName, MobilesitePageObjects.txt_FirstName.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_LastName),LastName, MobilesitePageObjects.txt_LastName.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_Address),Address, MobilesitePageObjects.txt_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_Zipcode), Zipcode,MobilesitePageObjects.txt_Zipcode.getObjectname());
		Thread.sleep(4000);
					
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_Email),Email, MobilesitePageObjects.txt_Email.getObjectname());
		Thread.sleep(5000);
		commonFunction.clickIfElementPresentJavaScript(getPageElement(MobilesitePageObjects.txt_PhoneRevelVelo),MobilesitePageObjects.txt_PhoneRevelVelo.getObjectname());
		commonFunction.enterText(getPageElement(MobilesitePageObjects.txt_PhoneRevelVelo),PhoneNumber, MobilesitePageObjects.txt_PhoneRevelVelo.getObjectname());
		Thread.sleep(3000);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.chkbx_CertifyRevelVelo),MobilesitePageObjects.chkbx_CertifyRevelVelo.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_City), City, MobilesitePageObjects.txt_City.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobilesitePageObjects.drpdwn_State),State, MobilesitePageObjects.drpdwn_State.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Step1Next), MobilesitePageObjects.btn_Step1Next.getObjectname());
		Thread.sleep(4000);
	}
	
	
	public void registration_EnterValidDataonStep2() throws IOException
	{
		
		String Password = dataTable.getData("General_Data", "Password");
		String ConfirmPassword = dataTable.getData("General_Data", "Password");
		String ChallengeAnswer = dataTable.getData("General_Data", "ChallengeAnswer");
		String ChallengeQuestion = "What was the name of your first school?";
		
		commonFunction.clearAndEnterText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_Password), Password, MobilesitePageObjects.txt_Password.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_ConfirmPassword), ConfirmPassword, MobilesitePageObjects.txt_ConfirmPassword.getObjectname());
		commonFunction.selectAnyElement(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.drpdwn_ChallengeQuestion),ChallengeQuestion ,MobilesitePageObjects.drpdwn_ChallengeQuestion.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_ChallengeAnswer),ChallengeAnswer,MobilesitePageObjects.txt_ChallengeAnswer.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.btn_Step2Next), MobilesitePageObjects.btn_Step2Next.getObjectname());
				
	}
	
	public void registration_ValidateErrormessageonStep3() throws Exception
	{
		
		String InvalidSSN= dataTable.getData("General_Data", "InvalidSSN");
		
		String Errormessage_InvalidSSN = "Your Social Security Number does not match your name and date of birth. Please try again.";
		
		try {
			
		if(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_onlySSNvisible).isDisplayed())
		{
			
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_onlySSNvisible),InvalidSSN,MobilesitePageObjects.txt_onlySSNvisible.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.btn_SubmitwhenonlySSNVisible), MobilesitePageObjects.btn_SubmitwhenonlySSNVisible.getObjectname());
			commonFunction.isElementPresentContainsText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.erroMsg_RegistrationInvaliSSNNoKBA), MobilesitePageObjects.erroMsg_RegistrationInvaliSSNNoKBA.getObjectname(), Errormessage_InvalidSSN);
			
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_onlySSNvisible),InvalidSSN,MobilesitePageObjects.txt_onlySSNvisible.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.btn_SubmitwhenonlySSNVisible), MobilesitePageObjects.btn_SubmitwhenonlySSNVisible.getObjectname());
			
			
			//Thread.sleep(2000);
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_SSNonUnabletoVerifyPage),InvalidSSN,MobilesitePageObjects.txt_SSNonUnabletoVerifyPage.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.btn_SubmitonUnabletoVerifyPage), MobilesitePageObjects.btn_SubmitonUnabletoVerifyPage.getObjectname());
			//Thread.sleep(3000);
			
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.btn_AgeVerificationFailedReturntoSignIn), MobilesitePageObjects.btn_AgeVerificationFailedReturntoSignIn.getObjectname());
			
		}
		}
		catch(Exception SSN){
		
					
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.radiobtn_SSN), MobilesitePageObjects.radiobtn_SSN.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_SSN),InvalidSSN,MobilesitePageObjects.txt_SSN.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.btn_Submit), MobilesitePageObjects.btn_Submit.getObjectname());
			commonFunction.isElementPresentContainsText(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.errormsg_RegistrationInvalidSSN), MobilesitePageObjects.errormsg_RegistrationInvalidSSN.getObjectname(), Errormessage_InvalidSSN);
			
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_SSN),InvalidSSN,MobilesitePageObjects.txt_SSN.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.btn_Submit), MobilesitePageObjects.btn_Submit.getObjectname());
			
			
			//Thread.sleep(2000);
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_SSNonUnabletoVerifyPage),InvalidSSN,MobilesitePageObjects.txt_SSNonUnabletoVerifyPage.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.btn_SubmitonUnabletoVerifyPage), MobilesitePageObjects.btn_SubmitonUnabletoVerifyPage.getObjectname());
			
		}
		
	}
	
	public void registration_ValidateAgeBySSN() throws InterruptedException, IOException
	{
		String SSN= dataTable.getData("General_Data", "SSN");
		
		//try {
		
		//if(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_onlySSNvisible).isDisplayed())
		//{
			
			//commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_onlySSNvisible),SSN,MobilesitePageObjects.txt_onlySSNvisible.getObjectname());
			//commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_SubmitwhenonlySSNVisible), MobilesitePageObjects.btn_SubmitwhenonlySSNVisible.getObjectname());
						
		//}
		//}
		//catch(Exception SSN1)
		//{
			
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.radiobtn_SSN), MobilesitePageObjects.radiobtn_SSN.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.txt_SSN),SSN,MobilesitePageObjects.txt_SSN.getObjectname());
			//commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Submit), MobilesitePageObjects.btn_Submit.getObjectname());
			//commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Submit), MobilesitePageObjects.btn_Submit.getObjectname());
			
		
	}
	
	public void navigateToVUSERegistrationPage() throws IOException 
	{
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.loginLnk_VUSECertifyAgePage), MobilesitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.header_VUSECreateAccount), MobilesitePageObjects.header_VUSECreateAccount.getObjectname());
	}
	
	
		public void registration_NavigatetoHomePage() throws IOException, InterruptedException
		{
			
			//Thread.sleep(3000);
			commonFunction.clickWhenVisible(getPageElement(MobileSite_Newuser_SSN_RegistrationPageObjects.link_takemetoSite), MobilesitePageObjects.link_takemetoSite.getObjectname(), 5000);
		
		}
		
		
		public void registration_RevelValidDetailsonStep1Page() throws InterruptedException, IOException
		{
			
			String FirstName = dataTable.getData("General_Data", "FirstName");
			String LastName = dataTable.getData("General_Data", "LastName");
			String Address = dataTable.getData("General_Data", "Address");
			String Zipcode = dataTable.getData("General_Data", "Zipcode");
			String Email = dataTable.getData("General_Data", "Username");
			String PhoneNumber = dataTable.getData("General_Data", "Phone");
			String City = dataTable.getData("General_Data","City");
			String State = dataTable.getData("General_Data", "State");
	        String DOB = dataTable.getData("General_Data","DOB");
			
			String date = DOB;
			String dateParts[] = date.split("/");
			String month  = dateParts[0];
			String day  = dateParts[1];
			String year = dateParts[2];
			
			//commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Registration),MobilesitePageObjects.btn_Registration.getObjectname());
			commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.drpdwn_BirthMonth), month, MobilesitePageObjects.drpdwn_BirthMonth.getObjectname());
			Thread.sleep(6000);
			commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.drpdwn_BirthDay),day,MobilesitePageObjects.drpdwn_BirthDay.getObjectname());
			//commonFunction.selectAnyElementByValue(getPageElement(MobilesitePageObjects.drpdwn_BirthYear), "1938", MobilesitePageObjects.drpdwn_BirthYear.getObjectname());
			commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.drpdwn_BirthYear),year,MobilesitePageObjects.drpdwn_BirthYear.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_FirstName), FirstName, MobilesitePageObjects.txt_FirstName.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_LastName),LastName, MobilesitePageObjects.txt_LastName.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_Address),Address, MobilesitePageObjects.txt_Address.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_Zipcode), Zipcode,MobilesitePageObjects.txt_Zipcode.getObjectname());
			Thread.sleep(4000);
						
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_Email),Email, MobilesitePageObjects.txt_Email.getObjectname());
			Thread.sleep(5000);
			commonFunction.clickIfElementPresentJavaScript(getPageElement(MobilesitePageObjects.txt_PhoneRevelVelo),MobilesitePageObjects.txt_PhoneRevelVelo.getObjectname());
			commonFunction.enterText(getPageElement(MobilesitePageObjects.txt_PhoneRevelVelo),PhoneNumber, MobilesitePageObjects.txt_PhoneRevelVelo.getObjectname());
			commonFunction.clickIfElementPresentJavaScript(getPageElement(MobilesitePageObjects.radiobtn_GenderMaleRevel),MobilesitePageObjects.radiobtn_GenderMaleRevel.getObjectname());
			//commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.radiobtn_GenderMaleRevel),MobilesitePageObjects.radiobtn_GenderMaleRevel.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.chkbx_CertifyRevelVelo),MobilesitePageObjects.chkbx_CertifyRevelVelo.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_City), City, MobilesitePageObjects.txt_City.getObjectname());
			commonFunction.selectAnyElementByValue(getPageElement(MobilesitePageObjects.drpdwn_State),State, MobilesitePageObjects.drpdwn_State.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Step1Next), MobilesitePageObjects.btn_Step1Next.getObjectname());
			Thread.sleep(4000);
		}
		
	
	
}

