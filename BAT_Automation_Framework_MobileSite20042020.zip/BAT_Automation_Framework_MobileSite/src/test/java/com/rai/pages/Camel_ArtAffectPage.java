package com.rai.pages;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.pageObjects.*;
import com.rai.framework.GenericLib;
@Listeners(ExtentITestListenerClassAdapter.class)
public class Camel_ArtAffectPage extends BaseClass {
	GenericLib gl = new GenericLib(this.getClass().getSimpleName());
	/*Properties config = new Properties();
	SoftAssert softAssert=new SoftAssert();*/
	// AS_HomePage homePage=new AS_HomePage();

	@BeforeMethod
	public void beforemethod(String TestCaseName,String TestCaseObjective,String TestEnvironmentUrl) {
		gl.start_report(TestCaseName, TestCaseObjective, TestEnvironmentUrl);
		//extent = ExtentManager.GetExtent();	
		//extent = ExtentManager.createTest(test, description)
	}

	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Verify the Project Collaborators (New Orleans) Landing page Content, images and buttons.
	//Verifies:
	//All Artists sections
	//Pre requisites :
	//User should have valid username and password
	//Author : Vikram T Date: 13.11.2018


	public void Camel_ArtAffect_NewOrleans_003 (String UN,String pwd,String url,String browserName,String txtCollaborator1,String txtCollaborator2,String txtCollaborator3,String txtCollaborator4) throws Exception
	{
		//****************************************************************************************************************
		//Launch application
		gl.launchApplication(browserName,url);
		Thread.sleep(5000);

		//Camel Login page is displayed.
		//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Enter Valid Username
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter Valid Password
		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd);
		//Click on Login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
		Thread.sleep(10000);

		//Camel Home page is displayed
		//gl.fnVerifyPageDisplayedUsingPageTitle("Home | Camel","Camel Home");
		gl.VerifyPageDisplayed(Camel_Home.pghome, "Home Page");

		//hover the mouse on ArtAffect
		gl.HowerMouse(Camel_Common.lnkArtAffect,"ArtAffect link from main navigation");
		//Verify sublinks are displayed
		//gl.VerifyElementVisible(,"ArtAffect sub menu");

		//Click Build link from menu navigation bar
		gl.clickUsingJs(Camel_Common.lnkBuilds, "Builds from ArtAffect");
		Thread.sleep(2000);
		//Verify that Builds Landing page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_NewOrleans.pgBuilds, "Build page");

		//Scroll to Paper Machine (New Orleans) section
		Actions pgdn = new Actions(driver);
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		Thread.sleep(2000);

		//Verify Paper Machine (New Orleans) is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.weSectionPaperMachine);

		//Click on "SEE BUILDS"
		gl.clickUsingJs(Camel_ArtAffect_NewOrleans.btnSeeBuildPaperMachine, "See Build for Paper Machine");
		Thread.sleep(2000);

		//Verify that Paper Machine (New Orleans) page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_NewOrleans.pgPaperMachine, "Paper Machine New Orleans page");
		//Scroll to Project Collaborators section
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		Thread.sleep(2000);

		//Verify that Project Collaborators section is displayed with Artist Images
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.weProjectCollaborators);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.imgBobSnead);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.imgBryanLee);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.imgChristopherDeris);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.imgJessicaPeterson);

		//Click on "MEET BEN"
		gl.clickUsingJs(Camel_ArtAffect_NewOrleans.btnMeetBob, "Meet Bob");
		Thread.sleep(5000);

		//Verify that artist modal displayed and Content of the model"
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.weArtistModel);
		gl.fnContentValidation(txtCollaborator1, Camel_ArtAffect_NewOrleans.weArtistModel);

		//Click on X button
		gl.clickUsingJs(Camel_ArtAffect_NewOrleans.btnArtistModelClose, "X button");
		Thread.sleep(5000);

		//Verify Artist modal closes successfully
		gl.VerifyElementNotVisible(Camel_ArtAffect_NewOrleans.weArtistModel, "Artist Model pop closed");

		//Click on "MEET JESSICA"
		gl.clickUsingJs(Camel_ArtAffect_NewOrleans.btnMeetJessica, "Meet Jessica");
		Thread.sleep(5000);

		//Verify that artist modal displayed and content of the model.
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.weArtistModel);
		gl.fnContentValidation(txtCollaborator2, Camel_ArtAffect_NewOrleans.weArtistModel);

		//Click on X button
		gl.clickUsingJs(Camel_ArtAffect_NewOrleans.btnArtistModelClose, "X button");	
		Thread.sleep(5000);

		//Verify Artist modal closes successfully
		gl.VerifyElementNotVisible(Camel_ArtAffect_NewOrleans.weArtistModel, "Artist Model pop closed");

		//Click on "MEET CHRISTOPHER"
		gl.clickUsingJs(Camel_ArtAffect_NewOrleans.btnMeetChristopher, "Meet Christopher");
		Thread.sleep(5000);

		//Verify that artist modal displayed and model content
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.weArtistModel);
		gl.fnContentValidation(txtCollaborator3, Camel_ArtAffect_NewOrleans.weArtistModel);

		//Click on X button
		gl.clickUsingJs(Camel_ArtAffect_NewOrleans.btnArtistModelClose, "X button");
		Thread.sleep(5000);

		//Verify Artist modal closes successfully
		gl.VerifyElementNotVisible(Camel_ArtAffect_NewOrleans.weArtistModel, "Artist Model pop closed");

		//Click on "MEET BRYAN"
		gl.clickUsingJs(Camel_ArtAffect_NewOrleans.btnMeetBryan, "Meet Bryan");
		Thread.sleep(5000);

		//Verify that artist modal displayed and content validation
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.weArtistModel);
		gl.fnContentValidation(txtCollaborator4, Camel_ArtAffect_NewOrleans.weArtistModel);

		//Click on X button
		gl.clickUsingJs(Camel_ArtAffect_NewOrleans.btnArtistModelClose, "X button");
		Thread.sleep(5000);

		//Verify Artist modal closes successfully
		gl.VerifyElementNotVisible(Camel_ArtAffect_NewOrleans.weArtistModel, "Artist Model pop closed");






		//		//Click ArtAffect link from main navigation menu
		//		gl.clickbutton(Camel_Common.lnkNewOrleans, "New Orleans from ArtAffect");
		//		//Verify that New Orleans page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect - New Orleans | Camel","Art Affect New Orleans Page");
		//		//Verify the images of collaborators are displayed"artAffect - New Orleans | Camel"
		//		gl.VerifyElementVisible(Camel_ArtAffect_NewOrleans.weImgNewOrleansCollaborators,"New Orleans Project Collaborators images");
		//		//Click on Meet the Artist button
		//		gl.clickUsingJs(Camel_ArtAffect_NewOrleans.btnNewOrleansMeetTheArtist,"New Orleans Meet the Artist");
		//		//Verify that Meet the Artist New Orleans page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect - New Orleans Collaborators | Camel","Meet the Artists-New Orleans");
		//		//Verify the text element New Orleans project collaborators is displayed
		//		gl.VerifyElementVisible(Camel_ArtAffect_NewOrleans.weTxtNewOrleansProjectCollaboratorsTitle, "Art Affect New Orleans Project Collaborators");
		//		gl.fnScrollToView(Camel_ArtAffect_NewOrleans.weImgNewOrleansCollaborator1);
		//		//Verify the image of collaborator 1 is displayed
		//		gl.VerifyElementVisible(Camel_ArtAffect_NewOrleans.weImgNewOrleansCollaborator1,"New Orleans Project Collaborators images");
		//		//Verify the content of the collaborator 1
		//		gl.fnContentValidation( Camel_ArtAffect_NewOrleans.weNewOrleansCollaborator1,txtCollaborator1);
		//		gl.fnScrollToView(Camel_ArtAffect_NewOrleans.weImgNewOrleansCollaborator2);
		//		//Verify the image of collaborator 2 is displayed
		//		gl.VerifyElementVisible(Camel_ArtAffect_NewOrleans.weImgNewOrleansCollaborator2,"New Orleans Project Collaborators images");
		//		//Verify the content of the collaborator 2
		//		gl.fnContentValidation( Camel_ArtAffect_NewOrleans.weNewOrleansCollaborator2,txtCollaborator2); 
		//		gl.fnScrollToView(Camel_ArtAffect_NewOrleans.weImgNewOrleansCollaborator3);
		//		//Verify the image of collaborator 3 is displayed
		//		gl.VerifyElementVisible(Camel_ArtAffect_NewOrleans.weImgNewOrleansCollaborator3,"New Orleans Project Collaborators images");
		//		//Verify the content of the collaborator 3
		//		gl.fnContentValidation( Camel_ArtAffect_NewOrleans.weTxtNewOrleansCollaborator3,txtCollaborator3); 
		//		gl.fnScrollToView(Camel_ArtAffect_NewOrleans.weImgNewOrleansCollaborator4);
		//		//Verify the image of collaborator 4 is displayed
		//		gl.VerifyElementVisible(Camel_ArtAffect_NewOrleans.weImgNewOrleansCollaborator4,"New Orleans Project Collaborators images");
		//		//Verify the content of the collaborator 4
		//		gl.fnContentValidation( Camel_ArtAffect_NewOrleans.weTxtNewOrleansCollaborator4,txtCollaborator4); 
		//		//Click on back to top button
		//		gl.clickLink(Camel_ArtAffect_NewOrleans.btnBackToTop, "Back to top button");
		//		//Verify the text element New Orleans project collaborators is displayed
		//		gl.VerifyElementVisible(Camel_ArtAffect_NewOrleans.weTxtNewOrleansProjectCollaboratorsTitle, "Art Affect New Orleans Project Collaborators");
		//Click on Logout button
		gl.clickUsingJs(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//                        //Close tab
		gl.closeAllBrowser();

	}

	@SuppressWarnings("unused")
	@Test
	//Test Case :  Verify the Project Collaborators (Kansas City) Landing page Content, images and buttons.
	//Verifies:
	//All Artists sections
	//Pre requisites :
	//User should have valid username and password
	//Author : Vikram T Date: 13.11.2018


	public void Camel_ArtAffect_KansasCity_003 (String UN,String pwd,String url,String browserName,String txtCollaborator1,String txtCollaborator2,String txtCollaborator3,String txtCollaborator4) throws Exception
	{
		//****************************************************************************************************************
		//Launch application
		gl.launchApplication(browserName,url);
		Thread.sleep(5000);
		Actions pgdn = new Actions(driver);
		Actions pgup = new Actions(driver);

		//Camel Login page is displayed.
		//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Enter Valid Username
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter Valid Password
		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd);
		//Click on Login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
		Thread.sleep(15000);

		//step 2//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_KansasCity.WeHomePage,"Home Page");

		//hover the mouse on ArtAffect
		gl.HowerMouse(Camel_Common.lnkArtAffect,"ArtAffect link from main navigation");
		//Verify sublinks are displayed
		//gl.VerifyElementVisible(,"ArtAffect sub menu");

		//step 3 //Click on the "Builds" Link from artAffect submenu
		gl.clickbutton(Camel_ArtAffectHome.lnkBuilds, "Builds");

		//Verify ArtAffectHome page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffectHome.imgArtEffectLogo,"image ArtEffectLogo");


		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();

		//Step 4 Scroll to Confluence (Kansas City) section 
		//gl.VerifyPageDisplayed(Camel_ArtAffect_KansasCity.WeConfluence,"Confluence");
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeConfluence);
		Thread.sleep(3000);

		//Verify the Confluence section is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeKansasCityMO);
		Thread.sleep(3000);

		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		Thread.sleep(5000);
		//step 5//Click on "See Build" button
		gl.clickbutton(Camel_ArtAffect_KansasCity.WeKansasCitySeeBuild, "Kansas City See Build");
		Thread.sleep(3000);

		//Verify that Confluence Page is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.TxtKansasartAffect);
		Thread.sleep(3000);

		//Verify text as "Confluence" is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.TxtKansasConfluence);//
		Thread.sleep(5000);


		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		Thread.sleep(5000);
		//Step 6 Scroll to Project Collaborators section Verify that Project Collaborators section is displayed with Artist Images and CTA buttons

		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeProjctCollaborators);
		Thread.sleep(7000);

		//step 7 Click on "MEET BEN"
		gl.clickUsingJs(Camel_ArtAffect_KansasCity.BtnMeetBen, "Meet Ben");
		Thread.sleep(7000);
		//gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeBenWolf);

		//Verify that artist modal displayed as stated below:

		//Text as "BEN WOLF"

		//Text as "CONFLUENCE KANSAS CITY, MO"

		//Q & A are displayed - Refer Specs for content

		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeSanArtistModel);
		Thread.sleep(7000);
		//Step 8 Click on X button

		gl.clickUsingJs(Camel_ArtAffect_KansasCity.btnSanArtistModelClose, "Close Button");
		Thread.sleep(7000);

		//Step 9 Click on "ELVIS"
		gl.clickUsingJs(Camel_ArtAffect_KansasCity.BtnMeetElvis, "Meet Elvis");
		Thread.sleep(7000);

		//Verify that artist modal displayed as stated below:
		//Text as "ELVIS ACHELPOHL"
		//Text as "CONFLUENCE KANSAS CITY, MO"
		//Q & A are displayed - Refer Specs for content

		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeSanArtistModel);
		Thread.sleep(7000);
		//Step 10 Click on X button

		gl.clickUsingJs(Camel_ArtAffect_KansasCity.btnSanArtistModelClose, "Close Button");
		Thread.sleep(7000);


		//Step 11 Click on "ADAM"
		gl.clickUsingJs(Camel_ArtAffect_KansasCity.BtnMeetAdam, "Meet ADAM");
		Thread.sleep(7000);

		//Verify that artist modal displayed as stated below:
		//Text as "ADAM JONES"
		//Text as "CONFLUENCE KANSAS CITY, MO"
		//Q & A are displayed - Refer Specs for content
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeSanArtistModel);
		Thread.sleep(7000);

		//Step 12 Click on X button
		gl.clickUsingJs(Camel_ArtAffect_KansasCity.btnSanArtistModelClose, "Close Button");
		Thread.sleep(7000);


		//step13 Click on "NIKITA"
		gl.clickUsingJs(Camel_ArtAffect_KansasCity.BtnMeetNikita, "Meet NIKITA");
		Thread.sleep(7000);
		//Verify that artist modal displayed as stated below:
		//Text as "NIKITA GALE"
		//Text as "CONFLUENCE KANSAS CITY, MO"
		//Q & A are displayed - Refer Specs for content
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeSanArtistModel);
		Thread.sleep(7000);
		//Step 14 Click on X button
		gl.clickUsingJs(Camel_ArtAffect_KansasCity.btnSanArtistModelClose, "Close Button");
		Thread.sleep(7000);


		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Close tab
		gl.closeAllBrowser();


	}

	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Verify the New Orleans Landing page Content, images and buttons.
	//Verifies:
	//All sections of the page
	//Pre requisites :
	//User should have valid username and password
	//Author : Vikram T Date: 14.11.2018



	public void Camel_ArtAffect_NewOrleans_001 (String UN,String pwd,String url,String browserName,String txtNewOrleans,String txtContent1,String txtContent2,String txtContent3,String txtContent4,String txtContent5, String txtSection1,String txtArtist1,String txtArtist2,String txtArtist3,String txtArtist4) throws Exception
	{
		//****************************************************************************************************************
		//Launch application
		gl.launchApplication(browserName,url);
		Thread.sleep(5000);

		//Camel Login page is displayed.
		//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Enter Valid Username
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter Valid Password
		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd);
		//Click on Login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
		Thread.sleep(5000);

		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "Home Page");

		//hover the mouse on ArtAffect
		gl.HowerMouse(Camel_Common.lnkArtAffect,"ArtAffect link from main navigation");

		//Click Build link from menu navigation bar
		gl.clickUsingJs(Camel_Common.lnkBuilds, "Builds from ArtAffect");
		Thread.sleep(2000);
		//Verify that Builds Landing page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_NewOrleans.pgBuilds, "Build page");

		//Scroll to Paper Machine (New Orleans) section
		Actions pgdn = new Actions(driver);
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		Thread.sleep(2000);

		//Verify Paper Machine (New Orleans) is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.weSectionPaperMachine);

		//Click on "SEE BUILDS"
		gl.clickUsingJs(Camel_ArtAffect_NewOrleans.btnSeeBuildPaperMachine, "See Build for Paper Machine");
		Thread.sleep(2000);

		//Verify that Paper Machine (New Orleans) page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_NewOrleans.pgPaperMachine, "Paper Machine New Orleans page");

		//Verify the first section
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.wesection1PaperMachine);
		//Verify content of section 1
		gl.fnContentValidation(txtSection1,Camel_ArtAffect_NewOrleans.wesection1PaperMachine);

		//Click on Play Video button
		gl.clickUsingJs(Camel_ArtAffect_NewOrleans.btnPlayVideoPaperMachine, "Play Video");
		Thread.sleep(2000);

		//		//Camel Home page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("Home | Camel","Camel Home");
		//		//hover the mouse on ArtAffect
		//		gl.HowerMouse(Camel_Common.lnkArtAffect,"ArtAffect link from main navigation");
		//		//Verify sublinks are displayed
		//		//gl.VerifyElementVisible(,"ArtAffect sub menu");
		//		//Click ArtAffect link from main navigation menu
		//		gl.clickbutton(Camel_Common.lnkNewOrleans, "New Orleans from ArtAffect");
		//		//Verify that New Orleans page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect - New Orleans | Camel","Art Affect New Orleans Page");
		//		//Verify the hero tile of the New Orleans page
		//		gl.VerifyElementVisible(Camel_ArtAffect_NewOrleans.weImgNewOrleansHeroTile,"ArtAffect Paper Machine hero tile");

		//		//Click the play button of the hero tile
		//		gl.clickbutton(Camel_ArtAffect_NewOrleans.btnNewOrleansHeroTile, "Play Video button");
		//Verify video overlay is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.weArtistModel);
		//Close the video overlay
		gl.clickbutton(Camel_ArtAffect_NewOrleans.btnArtistModelClose,"CLOSE button of Video overlay of hero tile" );
		Thread.sleep(2000);

		//Verify Paper Machine page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_NewOrleans.pgPaperMachine, "Paper Machine New Orleans page");

		//Scroll to next section (The project)
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		Thread.sleep(2000);
		//Verify Images are displayed and content validation
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.img1projectsection);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.img2projectsection);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.img3projectsection);
		gl.fnContentValidation(txtNewOrleans,Camel_ArtAffect_NewOrleans.weProjectsectionPaperMachine);

		//Scroll to next section (Project Gallery)
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		Thread.sleep(2000);

		//Verify that Project Gallery section, image and content.
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.wesubheadingProjectGallerysection);
		gl.fnScrollToView(Camel_ArtAffect_NewOrleans.btnRightArrowProjectGallerysection);
		Thread.sleep(2000);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.img1ProjectGallerysection);
		gl.ExtractAttributeFromObject(Camel_ArtAffect_NewOrleans.wesubheadingProjectGallerysection, "innerText", "Sub Heading EXTERIOR MURAL", "EXTERIOR MURAL");
		gl.fnContentValidation(txtContent1,Camel_ArtAffect_NewOrleans.wesectionProjectGallerytext);

		//Click Right Arrow
		pgdn.sendKeys(Keys.ARROW_UP).build().perform();
		pgdn.sendKeys(Keys.ARROW_UP).build().perform();
		pgdn.sendKeys(Keys.ARROW_UP).build().perform();
		Thread.sleep(3000);
		gl.clickLink(Camel_ArtAffect_NewOrleans.btnRightArrowProjectGallerysection, "Right Arrow");

		Thread.sleep(2000);

		//Verify Image, heading and content
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.img2ProjectGallerysection);
		gl.ExtractAttributeFromObject(Camel_ArtAffect_NewOrleans.wesubheadingProjectGallerysection, "innerText", "Sub Heading KINETIC SCULPTURE", "KINETIC SCULPTURE");
		gl.fnContentValidation(txtContent2,Camel_ArtAffect_NewOrleans.wesectionProjectGallerytext);

		//Click Right Arrow
		gl.clickLink(Camel_ArtAffect_NewOrleans.btnRightArrowProjectGallerysection, "Right Arrow");
		Thread.sleep(2000);

		//Verify Image, heading and content
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.img3ProjectGallerysection);
		gl.ExtractAttributeFromObject(Camel_ArtAffect_NewOrleans.wesubheadingProjectGallerysection, "innerText", "Sub Heading PROJECTION CANAL", "PROJECTION CANAL");
		gl.fnContentValidation(txtContent3,Camel_ArtAffect_NewOrleans.wesectionProjectGallerytext);

		//Click Right Arrow
		gl.clickLink(Camel_ArtAffect_NewOrleans.btnRightArrowProjectGallerysection, "Right Arrow");
		Thread.sleep(2000);

		//Verify Image, heading and content
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.img4ProjectGallerysection);
		gl.ExtractAttributeFromObject(Camel_ArtAffect_NewOrleans.wesubheadingProjectGallerysection, "innerText", "Sub Heading PRINTSHOP", "PRINTSHOP");
		gl.fnContentValidation(txtContent4,Camel_ArtAffect_NewOrleans.wesectionProjectGallerytext);

		//Click Right Arrow
		gl.clickLink(Camel_ArtAffect_NewOrleans.btnRightArrowProjectGallerysection, "Right Arrow");
		Thread.sleep(2000);

		//Verify Image, heading and content
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.img5ProjectGallerysection);
		gl.ExtractAttributeFromObject(Camel_ArtAffect_NewOrleans.wesubheadingProjectGallerysection, "innerText", "Sub Heading GALLERY", "GALLERY");
		gl.fnContentValidation(txtContent5,Camel_ArtAffect_NewOrleans.wesectionProjectGallerytext);

		//Click on all dots and verify heading and image
		gl.clickLink(Camel_ArtAffect_NewOrleans.weDot1Gallerysection, "Dot 1");
		Thread.sleep(2000);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.img1ProjectGallerysection);
		gl.ExtractAttributeFromObject(Camel_ArtAffect_NewOrleans.wesubheadingProjectGallerysection, "innerText", "Sub Heading EXTERIOR MURAL", "EXTERIOR MURAL");
		gl.clickLink(Camel_ArtAffect_NewOrleans.weDot1Gallerysection, "Dot 2");
		Thread.sleep(3000);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.img2ProjectGallerysection);
		gl.ExtractAttributeFromObject(Camel_ArtAffect_NewOrleans.wesubheadingProjectGallerysection, "innerText", "Sub Heading KINETIC SCULPTURE", "KINETIC SCULPTURE");
		Thread.sleep(3000);
		gl.clickLink(Camel_ArtAffect_NewOrleans.weDot2Gallerysection, "Dot 3");
		Thread.sleep(3000);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.img3ProjectGallerysection);
		gl.ExtractAttributeFromObject(Camel_ArtAffect_NewOrleans.wesubheadingProjectGallerysection, "innerText", "Sub Heading PROJECTION CANAL", "PROJECTION CANAL");
		gl.clickLink(Camel_ArtAffect_NewOrleans.weDot3Gallerysection, "Dot 4");
		Thread.sleep(3000);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.img4ProjectGallerysection);
		gl.ExtractAttributeFromObject(Camel_ArtAffect_NewOrleans.wesubheadingProjectGallerysection, "innerText", "Sub Heading PRINTSHOP", "PRINTSHOP");
		gl.clickLink(Camel_ArtAffect_NewOrleans.weDot4Gallerysection, "Dot 5");
		Thread.sleep(3000);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.img5ProjectGallerysection);
		gl.ExtractAttributeFromObject(Camel_ArtAffect_NewOrleans.wesubheadingProjectGallerysection, "innerText", "Sub Heading GALLERY", "GALLERY");
		Thread.sleep(3000);

		//Scroll to next section (Project Collaborators)
		gl.fnScrollToView(Camel_ArtAffect_NewOrleans.wesubheadingProjectGallerysection);
		Thread.sleep(3000);
		// Verify PROJECT COLLABORATORS section is displayed and content validation
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.weProjectCollaborators);
		gl.fnScrollToView(Camel_ArtAffect_NewOrleans.weProjectCollaborators);
		gl.fnContentValidation(txtArtist1,Camel_ArtAffect_NewOrleans.weArtistName1);
		gl.fnContentValidation(txtArtist2,Camel_ArtAffect_NewOrleans.weArtistName2);
		gl.fnContentValidation(txtArtist3,Camel_ArtAffect_NewOrleans.weArtistName3);
		gl.fnContentValidation(txtArtist4,Camel_ArtAffect_NewOrleans.weArtistName4);

		//Scroll to EXPLORE MORE BUILDS
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		Thread.sleep(3000);

		//Verification of section and images
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.wesectionExploreMoreBuildsHeading);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.imgGrantProgramExploreMoreSection);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.imgPoppsEmporiumExploreMoreSection);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_NewOrleans.imgConfluenceExploreMoreSection);

		//Click on Learn More from GRANT PROGRAM Image
		gl.clickUsingJs(Camel_ArtAffect_NewOrleans.btnLearnMoreGrantProgramExploreMoreSection, "Learn More");
		Thread.sleep(3000);
		//Verify GRANT PROGRAM page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_NewOrleans.pgGrantProgram, "Grant Program");

		//Click on Browser Back button
		gl.browserBack();
		Thread.sleep(3000);
		//Verify Paper Machine page is displayed.
		gl.VerifyPageDisplayed(Camel_ArtAffect_NewOrleans.pgPaperMachine, "Paper Machine New Orleans page");

		//Click on Learn More from POPPS EMPORIUM Image
		gl.clickUsingJs(Camel_ArtAffect_NewOrleans.btnLearnMorePoppsEmporiumExploreMoreSection, "Learn More");
		Thread.sleep(3000);
		//Verify POPPS EMPORIUM page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_NewOrleans.pgPoppsEmporium, "Popps Emporium");

		//Click on Browser Back button
		gl.browserBack();
		Thread.sleep(3000);
		//Verify Paper Machine page is displayed.
		gl.VerifyPageDisplayed(Camel_ArtAffect_NewOrleans.pgPaperMachine, "Paper Machine New Orleans page");

		//Click on Learn More from CONFLUENCE Image
		gl.clickUsingJs(Camel_ArtAffect_NewOrleans.btnLearnMoreConfluenceExploreMoreSection, "Learn More");
		Thread.sleep(3000);

		//Verify CONFLUENCE page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_NewOrleans.pgConfluence, "Confluence");

		//Click on Browser Back button
		gl.browserBack();
		Thread.sleep(3000);
		//Verify Paper Machine page is displayed.
		gl.VerifyPageDisplayed(Camel_ArtAffect_NewOrleans.pgPaperMachine, "Paper Machine New Orleans page");		







		//		//Verify that New Orleans page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect - New Orleans | Camel","Art Affect New Orleans Page");
		//		gl.fnScrollToView(Camel_ArtAffect_NewOrleans.weSectionNewOrleans);
		//		//Verify that New Orleans section is displayed
		//		gl.fnContentValidation(Camel_ArtAffect_NewOrleans.weSectionNewOrleans,txtNewOrleans);
		//		//Verify the image is displayed
		//		//	gl.VerifyElementVisible(Camel_ArtAffect_NewOrleans.imgNewOrleans1, "New Orleans image 1");
		//		//Verify the image is displayed
		//		//	gl.VerifyElementVisible(Camel_ArtAffect_NewOrleans.imgNewOrleans2, "New Orleans image 2");
		//		//Verify the image is displayed
		//		//	gl.VerifyElementVisible(Camel_ArtAffect_NewOrleans.imgNewOrleans3, "New Orleans image 3");
		//		gl.fnScrollToView(Camel_ArtAffect_NewOrleans.weSectionProjectGallery);
		//		//Verify that project gallery section is displayed
		//		gl.VerifyElementVisible(Camel_ArtAffect_NewOrleans.weSectionProjectGallery, "Project Gallery section is displayed");
		//		//Verify the content 1 of project gallery
		//		gl.fnContentValidation(Camel_ArtAffect_NewOrleans.weContent1ProjectGallery,txtContent1);
		//		//Click the right arrow of the project gallery section
		//		gl.clickUsingJs(Camel_ArtAffect_NewOrleans.weRightArrowProjectGallery,"Right arrow of the project gallery" );
		//		Thread.sleep(3000);
		//		//Verify the content 2 of project gallery
		//		gl.fnContentValidation(Camel_ArtAffect_NewOrleans.weContent2ProjectGallery, txtContent2);
		//		//Click the right arrow of the project gallery section
		//		gl.clickImage(Camel_ArtAffect_NewOrleans.weRightArrowProjectGallery,"Right arrow of the project gallery" );
		//		Thread.sleep(8000);
		//		//Verify the content 3 of project gallery
		//		gl.fnContentValidation(Camel_ArtAffect_NewOrleans.weContent3ProjectGallery,txtContent3);
		//		//Click the left arrow of the project gallery section
		//		gl.clickImage(Camel_ArtAffect_NewOrleans.weLeftArrowProjectGallery,"Left arrow of the project gallery" );
		//
		//		//Verify the content 2 of project gallery
		//		gl.fnContentValidation(Camel_ArtAffect_NewOrleans.weContent2ProjectGallery, txtContent2);
		//		//Click the 3rd pagination dot of the project gallery section
		//		gl.clickbutton(Camel_ArtAffect_NewOrleans.wePaginationDot3ProjectGallery,"Third pagination dot of the project gallery section" );
		//		Thread.sleep(3000);
		//
		//		//Verify the content 3 of project gallery
		//		gl.fnContentValidation(Camel_ArtAffect_NewOrleans.weContent3ProjectGallery, txtContent3);
		//		//Click the 4th pagination dot of the project gallery section
		//		gl.clickbutton(Camel_ArtAffect_NewOrleans.wePaginationDot4ProjectGallery,"fourth pagination dot of the project gallery section" );
		//		Thread.sleep(3000);
		//
		//		//Verify the content 4 of project gallery
		//		gl.fnContentValidation(Camel_ArtAffect_NewOrleans.weContent4ProjectGallery, txtContent4);
		//		//Click the 5th pagination dot of the project gallery section
		//		gl.clickbutton(Camel_ArtAffect_NewOrleans.wePaginationDot5ProjectGallery,"fifth pagination dot of the project gallery section" );
		//		Thread.sleep(5000);
		//		//Verify the content 5 of project gallery
		//		gl.fnContentValidation(Camel_ArtAffect_NewOrleans.weContent5ProjectGallery, txtContent5);
		//
		//
		//
		//		gl.fnScrollToView(Camel_ArtAffect_NewOrleans.weImgNewOrleansCollaborators);
		//		//Verify the images of collaborators are displayed"artAffect - New Orleans | Camel"
		//		gl.VerifyElementVisible(Camel_ArtAffect_NewOrleans.weImgNewOrleansCollaborators,"New Orleans Project Collaborators images");
		//		//Verify collaborator 1
		//		gl.VerifyElementVisible(Camel_ArtAffect_NewOrleans.weTxtProjectCollabaorator1NewOrleans,"New Orleans Project Collaborator 1");
		//		//Verify collaborator 2
		//		gl.VerifyElementVisible(Camel_ArtAffect_NewOrleans.weTxtProjectCollabaorator2NewOrleans,"New Orleans Project Collaborator 2");
		//		//Verify collaborator 3
		//		gl.VerifyElementVisible(Camel_ArtAffect_NewOrleans.weTxtProjectCollabaorator3NewOrleans,"New Orleans Project Collaborator 3");
		//		//Verify collaborator 4
		//		gl.VerifyElementVisible(Camel_ArtAffect_NewOrleans.weTxtProjectCollabaorator4NewOrleans,"New Orleans Project Collaborator 4");
		//
		//		//Click on Meet the Artist button
		//		gl.clickUsingJs(Camel_ArtAffect_NewOrleans.btnNewOrleansMeetTheArtist,"New Orleans Meet the Artist");
		//		Thread.sleep(3000);
		//		//Verify that Meet the Artist New Orleans page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect - New Orleans Collaborators | Camel","Meet the Artists-New Orleans");
		//		//Click on browser back button
		//		gl.browserBack();
		//		Thread.sleep(3000);
		//		//Verify that New Orleans page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect - New Orleans | Camel","Art Affect New Orleans Page");
		//
		//
		//
		//
		//		gl.fnScrollToView(Camel_ArtAffect_KansasCity.weTxtExploreArtAffectCities);
		//		//Click on learn more button from grant program tile
		//		gl.clickUsingJs(Camel_ArtAffect_NewOrleans.btnGrantProgram,"Button to navigate to Grant program ");
		//		Thread.sleep(3000);
		//		//Verify that GrantProgram page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect - Grant Program | Camel","Art Affect Grant Program Page");
		//		//Click on browser back button
		//		gl.browserBack();
		//		Thread.sleep(3000);
		//		//Verify that New Orleans page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect - New Orleans | Camel","Art Affect New Orleans Page");
		//
		//		//Click on learn more button from Popps Emporium tile
		//		gl.clickUsingJs(Camel_ArtAffect_NewOrleans.btnPoppsEmporium,"Button to navigate to Popps Emporium ");
		//		Thread.sleep(3000);
		//		//Verify that Popps Emporium page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect - Detroit Program | Camel","Art Affect Grant Program Page");
		//		//Click on browser back button
		//		gl.browserBack();
		//		Thread.sleep(3000);
		//		//Verify that New Orleans page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect - New Orleans | Camel","Art Affect New Orleans Page");
		//
		//		//Click on learn more button from Confluence tile
		//		gl.clickUsingJs(Camel_ArtAffect_NewOrleans.btnConfluence,"Button to navigate to Confluence ");
		//		Thread.sleep(3000);
		//		//Verify that Confluence page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect - Kansas City | Camel","Art Affect Grant Program Page");
		//		//Click on browser back button
		//		gl.browserBack();
		//		Thread.sleep(3000);
		//		//Verify that New Orleans page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect - New Orleans | Camel","Art Affect New Orleans Page");
		//		//click on back to Top button
		//		gl.clickbutton(Camel_ArtAffect_NewOrleans.btnBackToTop,"Back to Top button");
		//		//Verify the hero tile of the New Orleans page
		//		gl.VerifyElementVisible(Camel_ArtAffect_NewOrleans.weImgNewOrleansHeroTile,"ArtAffect Paper Machine hero tile");
		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Close tab
		gl.closeAllBrowser();
	}





	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Verify the KansasCity Landing page Content, images and buttons.
	//Verifies:
	//All sections of the page
	//Pre requisites :
	//User should have valid username and password
	//Author : Vikram T Date: 15.11.2018


	public void Camel_ArtAffect_KansasCity_001 (String UN,String pwd,String url,String browserName,String txtKansasCity,String txtContent1,String txtContent2,String txtContent3,String txtContent4,String txtContent5) throws Exception
	{
		//****************************************************************************************************************
		//Launch application
		gl.launchApplication(browserName,url);
		Thread.sleep(5000);
		Actions pgdn = new Actions(driver);
		Actions pgup = new Actions(driver);

		//Camel Login page is displayed.
		//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Enter Valid Username
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter Valid Password
		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd);
		//Click on Login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
		Thread.sleep(15000);

		//step 2//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_KansasCity.WeHomePage,"Home Page");


		//hover the mouse on ArtAffect
		gl.HowerMouse(Camel_Common.lnkArtAffect,"ArtAffect link from main navigation");
		//Verify sublinks are displayed
		//gl.VerifyElementVisible(,"ArtAffect sub menu");

		//step 3 //Click on the "Builds" Link from artAffect submenu
		gl.clickbutton(Camel_ArtAffectHome.lnkBuilds, "Builds");

		//Verify ArtAffectHome page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffectHome.imgArtEffectLogo,"image ArtEffectLogo");


		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();

		//Confluence section and Click on "See Build" button
		//gl.VerifyPageDisplayed(Camel_ArtAffect_KansasCity.WeConfluence,"Confluence");
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeConfluence);
		Thread.sleep(3000);

		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeKansasCityMO);
		Thread.sleep(3000);

		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();

		//step 4//Click on "See Build" button
		gl.clickbutton(Camel_ArtAffect_KansasCity.WeKansasCitySeeBuild, "Kansas City See Build");
		Thread.sleep(3000);

		//step 5//Verify that Confluence Image is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_KansasCity.ImgConfluenceImage,"Confluence Image");
		Thread.sleep(3000);
		//Verify text as "artAffect" is displayed

		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.TxtKansasartAffect);
		Thread.sleep(3000);

		//Verify text as "Confluence" is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.TxtKansasConfluence);
		Thread.sleep(3000);
		//gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.TxtKansasConfluence, "Confluence");
		Thread.sleep(3000);
		//Verify text "Kansas City" is displayed.
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.TxtKansasartAffect);
		//gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.TxtKansasartAffect, "Kansas City");
		Thread.sleep(3000);
		//Verify text "'A one-of-a-kind fountain that fully captures a neighborhood's essence." is displayed.
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.TxtKansasText);



		//Button - Play Video is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.BtnPlayVideo);


		//Click the play button of the hero tile
		gl.clickbutton(Camel_ArtAffect_KansasCity.BtnPlayVideo, "Play Video button");
		Thread.sleep(6000);

		//Step 6://Verify video overlay is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.VideoOverlay);

		//Step7://Close the video overlay
		gl.clickbutton(Camel_ArtAffect_KansasCity.VideoOverlayClose,"CLOSE button of Video overlay" );

		pgup.sendKeys(Keys.PAGE_UP).build().perform();
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();

		//Step 8:Scroll to next section (The project)
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeTheProject);

		//Verify that Kansas City Images are displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.ImgTheProjectImages);

		//For Content please refer specs
		//gl.fnContentValidation(Camel_ArtAffect_KansasCity.WeProjectContent, "The Project content");
		Thread.sleep(5000);

		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		//Step9://Scroll to next section (THE MATERIALS)
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeProjectGallery);

		//Verify that THE MATERIALS Primary Image is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WePGTileConfluenceArt);
		//Left and Right arrows are displayed to scroll between images

		//Text as - "Confluence" is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.TxtPGConfluenece);


		//Text as - The generosity of the West Bottoms community helped build Confluence with as many up-cycled materials as possible." is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.TxtPGConflurncelongText);

		//Pagination dots are displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WePaginationPG);


		//Step10: Click on Left Arrow
		gl.clickLink(Camel_ArtAffect_KansasCity.lnkRightArrowProjectGaller,"Right arrow");
		//gl.clickbutton(Camel_ArtAffect_KansasCity.WePaginationDot2,"PaginationDot2" );
		Thread.sleep(5000);
		//Next image Back Wall is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WePGTileBackWall);

		//Text as - Back Wall is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.TxtPGBackwall);


		//Text as - "Fabricated from a deconstructed water tower donated by The Hobbs Bldg" is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.TxtPGBackwalllongtext);


		//Step11: Click on Left Arrow
		gl.clickLink(Camel_ArtAffect_KansasCity.lnkRightArrowProjectGaller,"Right arrow");

		Thread.sleep(5000);
		//Next image Scaffolding is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WePGTileScaffolding);

		//Text as - SCAFFOLDING is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.TxtPGScaffolding);

		//Text as - "Constructed from reclaimed train rails donated by Kansas City Southern Rail" is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.TxtScaffoldinglongText);



		//Step12: Click on Left Arrow

		gl.clickLink(Camel_ArtAffect_KansasCity.lnkRightArrowProjectGaller,"Right arrow");
		Thread.sleep(5000);
		//Next image FOUNDATION is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WePGTileBuildingFoundation);

		//Text as - FOUNDATION is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.TxtBuildingFoundation);

		//Text as - "Built from natural limestone slabs locally sourced from Bluestem Quarry & Stoneworks" is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.TxtBuildingFoundationlongText);

		//Step13: Click on Left Arrow
		gl.clickLink(Camel_ArtAffect_KansasCity.lnkRightArrowProjectGaller,"Right arrow");
		Thread.sleep(5000);
		//Next image CANOPY is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WePGTileCanopy);
		Thread.sleep(5000);
		//Text as - CANOPY is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.TxtCanopy);
		//Text as - "Assembled from up-cycled scrap metal supplied by Asner Metals" is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.TxtCanopylongText);

		//Step14 Verify the Pagination dots functionality
		gl.clickLink(Camel_ArtAffect_KansasCity.WePaginationDot1,"PaginationDot1");
		Thread.sleep(5000);

		//Text as - "Confluence" is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.TxtPGConfluenece);

		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();

		//Step 15 Scroll to next section (The Collaborators)
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeProjctCollaborators);

		//Verify that The Collaborators section displayed as below:
		//Verify artist's image with text "BEN WOLF - Lead Artist" is displayed,//-Button "MEET BEN" is displayed.
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeBenWolf);



		//Verify artist's image with text "ELVIS ACHELPOHL - Architectural Designer" is displayed.//-Button - "MEET ELVIS" is displayed.

		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeELVISACHELPOHL);

		//Verify artist's image with text "ADAM JONES - Project Partner/General Contractor" is displayed.//-Button - "MEET ADAM" is displayed.
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeADAMJONES);


		//Verify artist's image with text "NIKITA GALE - Contributing artist" is displayed.//-Button - "MEET NIKITA" is displayed.
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeNIKITAGALE);

		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();

		//Step 24 Scroll to EXPLORE MORE BUILDS  
		//Verify that Explore more builds section is displayed with other artaffect city images
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeExploreMoreBuilds);

		//GRANT PROGRAM Image with Learn More button is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeGrantProgram);
		//POPPS EMPORIUM Image with Learn More button is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WePOPPSEMPORIUM);
		//Paper Machine Image with Learn More button is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WePaperMachine);

		//Step 25 Click on Learn More from GRANT PROGRAM Image
		gl.clickbutton(Camel_ArtAffect_KansasCity.BtnLearnmoreGrantProgram,"GrantProgram" );
		Thread.sleep(5000);
		//Verify GRANT PROGRAM page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_KansasCity.WeGrantProgramPage,"GrantProgram Page");
		Thread.sleep(3000);

		//Step 26 Click on Browser Back button
		gl.browserBack();
		Thread.sleep(3000);
		//Verify that Confluence (Kansas City) Landing page is displayed.
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeGrantProgram);

		//step 27 Click on Learn More from POPPS EMPORIUM Image
		gl.clickbutton(Camel_ArtAffect_KansasCity.BtnLearnmorePOPPSEMPORIUM,"POPPSEMPORIUM" );
		Thread.sleep(5000);
		//POPPS EMPORIUM page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_KansasCity.WePOPPSEMPORIUMPage,"POPPSEMPORIUM Page");
		Thread.sleep(3000);

		//Step 28 Click on Browser Back button
		gl.browserBack();
		Thread.sleep(3000);

		//Verify that Confluence (Kansas City) Landing page is displayed.
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeGrantProgram);

		//Step 29 Click on Learn More from Paper Machine Image
		gl.clickbutton(Camel_ArtAffect_KansasCity.BtnLearnmorePaperMachine,"Paper Machine" );
		Thread.sleep(5000);
		//Paper Machine (New Orleans) page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_KansasCity.WePaperMachinePage,"Paper Machine Page");
		Thread.sleep(3000);

		//Step 30 Click on Browser Back button
		gl.browserBack();
		Thread.sleep(3000);

		//Verify that Confluence (Kansas City) Landing page is displayed.
		gl.VerifyObjectDisplayed(Camel_ArtAffect_KansasCity.WeGrantProgram);

		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Close tab
		gl.closeAllBrowser();
	}
	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Verify the ArtAffect Landing page Content, images and buttons.
	//Verifies:
	//All sections of the page
	//Pre requisites :
	//User should have valid username and password
	//Author : Vikram T Date: 16.11.2018


	public void Camel_ArtAffect_LandingPage_001 (String UN,String pwd,String url,String browserName,String txtOurBuilds,String txtGrantProgram) throws Exception
	{


		//****************************************************************************************************************
		//Launch application
		gl.launchApplication(browserName,url);
		Thread.sleep(5000);
		
		//Camel Login page is displayed.
		//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Enter Valid User name
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter Valid Password
		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd);
		//Click on Login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
		Thread.sleep(4000);
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "Home Page");
		//Hover the art affect link
		gl.HowerMouse(Camel_Common.lnkArtAffect,"ArtAffect link from main navigation");
		//Verify Builds link is displayed
		gl.VerifyElementVisible(Camel_ArtAffectHome.lnkBuilds,"Builds link");

		//Verify Grant program link is displayed
		gl.VerifyElementVisible(Camel_ArtAffectHome.lnkGrantProgram,"Grant program link");

		//Click the ArtAffect 
		gl.clickbutton(Camel_Common.lnkArtAffect,"ArtAffect link from main navigation");	
		Thread.sleep(4000);
		//Verify that ArtAffect landing page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffectHome.imgArtEffectLogo,"ArtAffect logo");
		Thread.sleep(4000);
		//Verify the hero tile of the ArtAffect landing page
		gl.VerifyElementVisible(Camel_ArtAffectHome.weImgArtAffectHeroTile,"ArtAffect  hero tile");
		//Verify the text "artAffect supports the transformation of" displayed on hero tile
		gl.VerifyElementVisible(Camel_ArtAffectHome.weTxtArtAffectHeroTile,"ArtAffect  hero tile text 'artAffect supports the transformation of'  ");
		//Verify the text "communities through the power of art." displayed on hero tile
		gl.VerifyElementVisible(Camel_ArtAffectHome.weTxtArtAffectHeroTile2,"ArtAffect  hero tile text 'communities through the power of art.' ");


		//Verify the hero tile text
		//gl.VerifyElementVisible(Camel_ArtAffectHome.weTitleHeroTile,"ArtAffect  hero tile title");



		//Click the play button of the hero tile
		gl.clickbutton(Camel_ArtAffectHome.btnArtAffectHeroTile, "Play Video button");
		//Verify video overlay is displayed
		gl.VerifyElementVisible(Camel_ArtAffectHome.weHeroTileVideoOverlay, "Video overlay of hero tile");
		Thread.sleep(4000);
		//Close the video overlay
		gl.clickUsingJs(Camel_ArtAffectHome.btnHeroTileVideoOverlayClose,"CLOSE button of Video overlay of hero tile" );
		//Verify that ArtAffect landing page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffectHome.imgArtEffectLogo,"ArtAffect logo");
		//Verify the text "artAffect supports the transformation of" displayed on hero tile
		gl.VerifyElementVisible(Camel_ArtAffectHome.weTxtArtAffectHeroTile,"ArtAffect  hero tile text ");
		//Verify the text "communities through the power of art." displayed on hero tile
		gl.VerifyElementVisible(Camel_ArtAffectHome.weTxtArtAffectHeroTile2,"ArtAffect  hero tile text ");



		//Verify that ArtAffect Our Builds content section is displayed
		gl.fnContentValidation(txtOurBuilds,Camel_ArtAffectHome.weSectionOurBuilds);
		//Verify the images of popps emporium
		gl.VerifyElementVisible(Camel_ArtAffectHome.weImgPoppsEmporium,"Popps emporium image 1");
		gl.VerifyElementVisible(Camel_ArtAffectHome.weImgPoppsEmporium1,"Popps emporium image 2");
		gl.VerifyElementVisible(Camel_ArtAffectHome.weImgPoppsEmporium2,"Popps emporium image 3");
		//Scroll to view
		gl.fnScrollToView(Camel_ArtAffectHome.weSectionOurBuilds);
		//Click on "View latest button"
		gl.clickUsingJs(Camel_ArtAffectHome.btnViewLatestBuild, "View latest button");
		//Verify that Detroit page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_Detroit.wePoppsEmporiumLogo, "Detroit page");
		//Click on browser back
		gl.browserBack();

		//Verify that ArtAffect landing page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffectHome.imgArtEffectLogo,"ArtAffect logo");
		//Verify the text "artAffect supports the transformation of" displayed on hero tile
		gl.VerifyElementVisible(Camel_ArtAffectHome.weTxtArtAffectHeroTile,"ArtAffect  hero tile text ");
		//Verify the text "communities through the power of art." displayed on hero tile
		gl.VerifyElementVisible(Camel_ArtAffectHome.weTxtArtAffectHeroTile2,"ArtAffect  hero tile text ");


		//Click on "See builds" button 
		gl.clickUsingJs(Camel_ArtAffectHome.btnSeeBuilds, "See builds button");

		//Verify that builds landing page is displayed.
		gl.VerifyPageDisplayed(Camel_ArtAffectHome.wePgBuildsLogo, "Builds page");

		//Click on browser back
		gl.browserBack();

		//Verify that ArtAffect landing page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffectHome.imgArtEffectLogo,"ArtAffect logo");
		//Verify the text "artAffect supports the transformation of" displayed on hero tile
		gl.VerifyElementVisible(Camel_ArtAffectHome.weTxtArtAffectHeroTile,"ArtAffect  hero tile text ");
		//Verify the text "communities through the power of art." displayed on hero tile
		gl.VerifyElementVisible(Camel_ArtAffectHome.weTxtArtAffectHeroTile2,"ArtAffect  hero tile text ");

		//Verify that ArtAffect Grant program content section is displayed
		gl.fnContentValidation(txtGrantProgram,Camel_ArtAffectHome.weSectionGrantProgram);
		//Scroll to view
		gl.fnScrollToView(Camel_ArtAffectHome.weSectionGrantProgram);
		//Verify the image "The generator"
		gl.VerifyElementVisible(Camel_ArtAffectHome.weImgGrantProgram,"Grant Program image");
		gl.VerifyElementVisible(Camel_ArtAffectHome.weImgGrantProgram1,"Grant Program image1");
		gl.VerifyElementVisible(Camel_ArtAffectHome.weImgGrantProgram2,"Grant Program image2");
		//Click on "See Grantees"
		gl.clickUsingJs(Camel_ArtAffectHome.btnSeeGrantees, "See grantees button");
		//Verify that Grant program  page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffectHome.wePgGrantProgramLogo, "Grant program page");
		//Click on browser back
		gl.browserBack();

		//Verify that ArtAffect landing page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffectHome.imgArtEffectLogo,"ArtAffect logo");
		//Verify the text "artAffect supports the transformation of" displayed on hero tile
		gl.VerifyElementVisible(Camel_ArtAffectHome.weTxtArtAffectHeroTile,"ArtAffect  hero tile text ");
		//Verify the text "communities through the power of art." displayed on hero tile
		gl.VerifyElementVisible(Camel_ArtAffectHome.weTxtArtAffectHeroTile2,"ArtAffect  hero tile text ");
		//Scroll to view explore more builds section
		gl.fnScrollToView(Camel_ArtAffectHome.wePoppsEmporiumTileTitle);

		//Verify the Explore More builds section
		gl.VerifyElementVisible(Camel_ArtAffectHome.weTxtExploreMoreBuilds, "Text explore more builds");
		//verify all the build tiles are displayed.
		gl.VerifyElementVisible(Camel_ArtAffectHome.wePoppsEmporiumTile, "Popps Emporium tile");
		gl.VerifyElementVisible(Camel_ArtAffectHome.wePaperMachineTile, "Paper machine tile");
		gl.VerifyElementVisible(Camel_ArtAffectHome.weConfluenceTile, "Confluence tile");
		//Verify the Titles inside the respective tiles
		gl.VerifyElementVisible(Camel_ArtAffectHome.wePoppsEmporiumTileTitle, "Popps Emporium tile title");
		gl.VerifyElementVisible(Camel_ArtAffectHome.wePaperMachineTileTitle, "Paper machine tile title");
		gl.VerifyElementVisible(Camel_ArtAffectHome.weConfluenceTileTitle, "Confluence tile title");

		//Click on Learn more button from the Popps Emporium tile
		gl.clickUsingJs(Camel_ArtAffectHome.btnPoppsEmporiumLearMore, "Learn button of Popps emporium tile");
		//Verify that Detroit page is displayed.
		gl.VerifyPageDisplayed(Camel_ArtAffectHome.wePgPoppsEmporiumLogo,"Popps Emporium logo of detroit");
		//Click on browser back button
		gl.browserBack();
		//verify that ArtAffect landing page is displayed.
		gl.VerifyPageDisplayed(Camel_ArtAffectHome.imgArtEffectLogo,"ArtAffect logo");
		//Verify the text "artAffect supports the transformation of" displayed on hero tile
		gl.VerifyElementVisible(Camel_ArtAffectHome.weTxtArtAffectHeroTile,"ArtAffect  hero tile text ");
		//Verify the text "communities through the power of art." displayed on hero tile
		gl.VerifyElementVisible(Camel_ArtAffectHome.weTxtArtAffectHeroTile2,"ArtAffect  hero tile text ");



		//Scroll to view explore more builds section
		gl.fnScrollToView(Camel_ArtAffectHome.wePoppsEmporiumTileTitle);
		//Click on Learn more button from the Paper machine tile
		gl.clickUsingJs(Camel_ArtAffectHome.btnPaperMachineLearnMore, "Learn button of Paper Machine tile");
		//Verify that New Orleans page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffectHome.wePgPaperMachineLogo,"PaperMachine logo of New Orleans");
		//Click on browser back button
		gl.browserBack();
		//verify that ArtAffect landing page is displayed.
		gl.VerifyPageDisplayed(Camel_ArtAffectHome.imgArtEffectLogo,"ArtAffect logo");
		//Verify the text "artAffect supports the transformation of" displayed on hero tile
		gl.VerifyElementVisible(Camel_ArtAffectHome.weTxtArtAffectHeroTile,"ArtAffect  hero tile text ");
		//Verify the text "communities through the power of art." displayed on hero tile
		gl.VerifyElementVisible(Camel_ArtAffectHome.weTxtArtAffectHeroTile2,"ArtAffect  hero tile text ");




		//Scroll to view explore more builds section
		gl.fnScrollToView(Camel_ArtAffectHome.wePoppsEmporiumTileTitle);
		//Click on Learn more button from the Confluence tile
		gl.clickUsingJs(Camel_ArtAffectHome.btnConfluenceLearnMore, "Learn button of Confluence tile");
		//Verify that Kansas city page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffectHome.wePgConfluenceLogo,"Confluence logo of Kansas city");
		//Click on browser back button
		gl.browserBack();
		//verify that ArtAffect landing page is displayed.
		gl.VerifyPageDisplayed(Camel_ArtAffectHome.imgArtEffectLogo,"ArtAffect logo");
		//Verify the text "artAffect supports the transformation of" displayed on hero tile
		gl.VerifyElementVisible(Camel_ArtAffectHome.weTxtArtAffectHeroTile,"ArtAffect  hero tile text ");
		//Verify the text "communities through the power of art." displayed on hero tile
		gl.VerifyElementVisible(Camel_ArtAffectHome.weTxtArtAffectHeroTile2,"ArtAffect  hero tile text ");
		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//  Close tab                   
		gl.closeAllBrowser();
		//		
		//		//Click on Play button of Grant program Video
		//		gl.clickbutton(Camel_ArtAffectHome.weBtnPlayGrantProgramVideo, "Play Video button of Grant Program Video Section");
		//		Thread.sleep(4000);
		//		//Verify that Video is displayed
		//		gl.VerifyElementVisible(Camel_ArtAffectHome.weBtnCloseGrantProgramVideo, "Close Video button of Grant Program Video Section");
		//		//Close the video overlay
		//		gl.clickbutton(Camel_ArtAffectHome.weBtnCloseGrantProgramVideo, "Close Video button of Grant Program Video Section");
		//		Thread.sleep(3000);
		//		//Verify that ArtAffect landing page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect | Camel","Camel ArtAffect landing page");
		//
		//		//Click on "Learn more" button 
		//		gl.clickbutton(Camel_ArtAffectHome.weBtnLearnMoreGrantProgramVideo, "Learn more button of the Grant Program video section");
		//		Thread.sleep(4000);
		//		//Verify that Grant program page is displayed.
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect - Grant Program | Camel","Camel ArtAffect Grant program page");
		//		//Click on browser back
		//		gl.browserBack();
		//		//Verify that ArtAffect landing page is displayed.
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect | Camel","Camel ArtAffect landing page");
		//
		//
		//
		//		gl.fnScrollToView(Camel_ArtAffectHome.weSectionGrantProgram);
		//		//Verify the section grant program is displayed
		//		gl.VerifyElementVisible(Camel_ArtAffectHome.weSectionGrantProgram, "Grant Program section");
		//		//Verify the content 
		//		gl.fnContentValidation(Camel_ArtAffectHome.weSectionGrantProgram,txtContent1);
		//		//Verify the images displayed
		//		/*gl.VerifyElementVisible(Camel_ArtAffectHome.imgGrantProgram1, "Grant Program images");
		//		gl.VerifyElementVisible(Camel_ArtAffectHome.imgGrantProgram2, "Grant Program images");
		//		gl.VerifyElementVisible(Camel_ArtAffectHome.imgGrantProgram3, "Grant Program images");*/
		//		//click the view project button
		//		gl.clickUsingJs(Camel_ArtAffectHome.btnGrantProgramViewProject,"ArtAffect link from main navigation");
		//		Thread.sleep(6000);
		//		//Verify that grant program page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect - Grant Program | Camel","Camel ArtAffect Grant program page");
		//		//click on browser back button
		//		gl.browserBack();
		//		//Verify that ArtAffect landing page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect | Camel","Art Affect Landing Page");
		//
		//
		//		//Verify the section popps emporium is displayed
		//		gl.VerifyElementVisible(Camel_ArtAffectHome.weSectionPoppsEmporium, "Popps Emporium section");
		//		//Verify the content 
		//		gl.fnContentValidation(Camel_ArtAffectHome.weSectionPoppsEmporium,txtContent2);
		//		//Verify the images displayed
		//		/*	gl.VerifyElementVisible(Camel_ArtAffectHome.imgPoppsEmporium1, "Popps Emporium images");
		//		gl.VerifyElementVisible(Camel_ArtAffectHome.imgPoppsEmporium2, "Popps Emporium images");
		//		gl.VerifyElementVisible(Camel_ArtAffectHome.imgPoppsEmporium3, "Popps Emporium images");*/
		//		//click the view project button
		//		gl.clickUsingJs(Camel_ArtAffectHome.btnPoppsEmporiumViewProject,"PoppsEmporium view project button");
		//		Thread.sleep(3000);
		//		//Verify that grant program page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect - Detroit Program | Camel","Art Affect Popps Emporium page is displayed");
		//		//click on browser back button
		//		gl.browserBack();
		//		//Verify that ArtAffect landing page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect | Camel","Art Affect Landing Page");
		//
		//
		//		//Verify the section PaperMachine is displayed
		//		gl.VerifyElementVisible(Camel_ArtAffectHome.weSectionPaperMachine, "PaperMachine section");
		//		//Verify the content 
		//		gl.fnContentValidation(Camel_ArtAffectHome.weSectionPaperMachine,txtContent3);
		//		//Verify the images displayed
		//		/*gl.VerifyElementVisible(Camel_ArtAffectHome.imgPaperMachine1, "PaperMachine images");
		//		gl.VerifyElementVisible(Camel_ArtAffectHome.imgPaperMachine2, "PaperMachine images");
		//		gl.VerifyElementVisible(Camel_ArtAffectHome.imgPaperMachine3, "PaperMachine images");*/
		//		//click the view project button
		//		gl.clickUsingJs(Camel_ArtAffectHome.btnPaperMachineViewProject,"PaperMachine view project button");
		//		Thread.sleep(3000);
		//		//Verify that grant program page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect - New Orleans | Camel","Art Affect Paper Machine");
		//		//click on browser back button
		//		gl.browserBack();
		//		//Verify that ArtAffect landing page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect | Camel","Art Affect Landing Page");
		//
		//
		//		//Verify the section Confluence is displayed
		//		gl.VerifyElementVisible(Camel_ArtAffectHome.weSectionConfluence, "PaperMachine section");
		//		//Verify the content 
		//		gl.fnContentValidation(Camel_ArtAffectHome.weSectionConfluence,txtContent4);
		//		//Verify the images displayed
		//		/*	gl.VerifyElementVisible(Camel_ArtAffectHome.imgConfluence1, "Confluence images");
		//		gl.VerifyElementVisible(Camel_ArtAffectHome.imgConfluence2, "Confluence images");
		//		gl.VerifyElementVisible(Camel_ArtAffectHome.imgConfluence3, "Confluence images");*/
		//		//click the view project button
		//		gl.clickUsingJs(Camel_ArtAffectHome.btnConfluenceViewProject,"Confluence view project button");
		//		Thread.sleep(3000);
		//		//Verify that grant program page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect - Kansas City | Camel","Art Affect Confluence");
		//		//click on browser back button
		//		gl.browserBack();
		//		//Verify that ArtAffect landing page is displayed
		//		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect | Camel","Art Affect Landing Page");
		//
		//		//Click on back to top button
		//
		//		gl.clickbutton(Camel_ArtAffectHome.btnBackToTop,"Back to Top button");
		//		//Verify the hero tile title
		//		gl.VerifyElementVisible(Camel_ArtAffectHome.weImgArtAffectHeroTile,"ArtAffect  hero tile");
		//		//gl.VerifyElementVisible(Camel_ArtAffectHome.weTitleHeroTile,"ArtAffect hero tile title");


	}

	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Verify the Grant Reno landing page Contents, images and buttons..
	//Verifies:
	//All sections of the page
	//Pre requisites :
	//User should have valid username and password
	//Author : Raj Lakshmi Date: 5.02.2019	

	//Updated by: Prathisha V
	//Date: 8/28/2019


	public void Camel_artAffect_GrantsProgramLandingPage(String UN,String pwd,String url,String browserName,
			String txtFeaturedGrantees1,String txtFeaturedGrantees2,String txtGrantProgram, String ArtistAric, String ArtistChris, String ArtistJeromie, String ArtistKatie,
			String ArtistBob, String ArtistThem, String ArtistDB, String LatestBuild) throws Exception
	{
		//****************************************************************************************************************
		//Launch application
		gl.launchApplication(browserName,url);
		Thread.sleep(7000);

		//Camel Login page is displayed.
		//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Enter Valid Username
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter Valid Password
		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd);
		//Click on Login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
		Thread.sleep(7000);
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "Home Page");
		if(browserName.equalsIgnoreCase("IE")){
			//hover the mouse on SoundBoard
			gl.HowerMouse(Camel_Common.lnkSoundBoard,"SoundBoard link from main navigation");
		}
		//hover the mouse on ArtAffect
		gl.HowerMouse(Camel_Common.lnkArtAffect,"ArtAffect link from main navigation");
		Thread.sleep(10000);

		//Click ArtAffect link from main navigation menu
		gl.clickbutton(Camel_Common.lnkGrantProgram, "Grant program from ArtAffect");
		Thread.sleep(2000);
		//Verify that Grant Program page is displayed
		gl.VerifyPageDisplayed(Camel_Common.pgGrantProgram, "Grant Program");
		Thread.sleep(2000);

		//Verify the hero tile of the Grant Program page
		gl.VerifyElementVisible(Camel_ArtAffect_GrantProgram.weGrantProgramHeroTile,"ArtAffect Grant Program hero tile");
		//Click the play button of the hero tile
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnVideoGrantProgramHeroTile, "Play Video button");
		//Verify video overlay is displayed
		gl.VerifyElementPresent(Camel_ArtAffect_GrantProgram.weHeroTileVideoOverlay, "Video overlay of hero tile");
		//Close the video overlay
		gl.clickbutton(Camel_ArtAffect_GrantProgram.btnHeroTileVideoOverlayClose, "CLOSE button of Video overlay of hero tile" );
		//Verify that Grant Program page is displayed
		gl.VerifyPageDisplayed(Camel_Common.pgGrantProgram, "Grant Program");
		Thread.sleep(2000);

		Actions pgdn = new Actions(driver);
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform(); 


		//Verify text Featured Grantees is displayed
		gl.VerifyElementPresent(Camel_ArtAffect_GrantProgram.weTxtFeaturedGrantees, "Sub heading featured grantees");

		//Verify the DB burkeman images and content are displayed.

		gl.VerifyElementPresent(Camel_ArtAffect_GrantProgram.weImgArtistDB1, "DB Burkeman image1");
		gl.VerifyElementVisible(Camel_ArtAffect_GrantProgram.weImgArtistDB2, "DB Burkeman image2");
		gl.VerifyElementVisible(Camel_ArtAffect_GrantProgram.weImgArtistDB3, "DB Burkeman image3");

		//Verify the DBburkeman artist content
		gl.fnContentValidation(txtFeaturedGrantees1, Camel_ArtAffect_GrantProgram.weTxtFeaturedGrantees1);

		//Click on View project button from the DB Burkeman section
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnViewProjectDBBurkeman, "View project button DB Burkeman");
		//Verify that DB Burkeman page is displayed.
		gl.VerifyPageDisplayed(Camel_ArtAffect_DBBurkeman.wePgDBBurkeman, "DB Burkeman page");
		//Click on browser back button 
		gl.browserBack();
		//Verify that ArtAffect grant program page is displayed.
		gl.VerifyPageDisplayed(Camel_Common.pgGrantProgram, "Grant Program");

		//Verify the Chris images and content are displayed.

		gl.VerifyElementPresent(Camel_ArtAffect_GrantProgram.weImgArtistChris1, "Chris image1");
		gl.VerifyElementVisible(Camel_ArtAffect_GrantProgram.weImgArtistChris2, "Chris Burkeman image2");
		gl.VerifyElementVisible(Camel_ArtAffect_GrantProgram.weImgArtistChris3, "Chris Burkeman image3");

		//Verify the Chris artist content
		gl.fnContentValidation(txtFeaturedGrantees2, Camel_ArtAffect_GrantProgram.weTxtFeaturedGrantees2);

		//Click on View project button from the Chris section
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnViewProjectPublicShelter, "View project button Public Shelter");
		//Verify that Public shelter page is displayed.
		gl.VerifyPageDisplayed(Camel_ArtAffect_PublicShelter.wePgPublicShelter, "The Public Shelter page");
		//Click on browser back button 
		gl.browserBack();
		//Verify that ArtAffect grant program page is displayed.
		gl.VerifyPageDisplayed(Camel_Common.pgGrantProgram, "Grant Program");




		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform(); 
		gl.VerifyElementVisible(Camel_ArtAffect_GrantProgram.weTxtAbout, "SubHeading About");
		//Verify that Grant Program section is displayed
		gl.fnContentValidation(txtGrantProgram,Camel_ArtAffect_GrantProgram.weSectionGrantProgram);

		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();

		//Verify Grantee Bio section is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_GrantProgram.weGranteeSection1);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_GrantProgram.weGranteeSection2);

		//Click on Meet Aric and verify the pop up for the respected section also verify the content on the page
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnArtistAric, "Grante Program");
		Thread.sleep(2000);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_GrantProgram.weArtistModel);
		gl.fnContentValidation(ArtistAric, Camel_ArtAffect_GrantProgram.weArtistModel);
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnArtistModelClose, "ArtistModelClose");

		//Click on Meet Chris and verify the pop up for the respected section also verify the content on the page
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnArtistChris, "Grante Program");
		Thread.sleep(2000);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_GrantProgram.weArtistModel);
		gl.fnContentValidation(ArtistChris, Camel_ArtAffect_GrantProgram.weArtistModel);
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnArtistModelClose, "ArtistModelClose");

		//Click on Meet Jeromie and verify the pop up for the respected section also verify the content on the page
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnArtistJeromie, "Grante Program");
		Thread.sleep(2000);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_GrantProgram.weArtistModel);
		gl.fnContentValidation(ArtistJeromie, Camel_ArtAffect_GrantProgram.weArtistModel);
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnArtistModelClose, "ArtistModelClose");

		//Click on Meet Katie and verify the pop up for the respected section also verify the content on the page
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnArtistKatie, "Grante Program");
		Thread.sleep(2000);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_GrantProgram.weArtistModel);
		gl.fnContentValidation(ArtistKatie, Camel_ArtAffect_GrantProgram.weArtistModel);
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnArtistModelClose, "ArtistModelClose");
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();

		//Click on Meet BOb and verify the pop up for the respected section also verify the content on the page
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnArtistBob, "Grante Program");
		Thread.sleep(2000);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_GrantProgram.weArtistModel);
		gl.fnContentValidation(ArtistBob, Camel_ArtAffect_GrantProgram.weArtistModel);
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnArtistModelClose, "ArtistModelClose");

		//Click on Meet Them and verify the pop up for the respected section also verify the content on the page
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnArtistThem, "Grante Program");
		Thread.sleep(2000);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_GrantProgram.weArtistModel);
		gl.fnContentValidation(ArtistThem, Camel_ArtAffect_GrantProgram.weArtistModel);
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnArtistModelClose, "ArtistModelClose");

		//Click on Meet DB and verify the pop up for the respected section also verify the content on the page
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnArtistDB, "Grante Program");
		Thread.sleep(2000);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_GrantProgram.weArtistModel);
		gl.fnContentValidation(ArtistDB, Camel_ArtAffect_GrantProgram.weArtistModel);
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnArtistModelClose, "ArtistModelClose");

		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();

		//Verify Latest build is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_GrantProgram.weLatestBuild);
		gl.fnContentValidation(LatestBuild, Camel_ArtAffect_GrantProgram.weLatestBuild);

		//Click on See build button
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnSeeBuild, "See build");
		Thread.sleep(2000);

		//Verify Detroit Page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_Detroit.pgDetroit, "Detroit Page");

		//Click on Browser back
		gl.browserBack();
		Thread.sleep(2000);

		//Verify that Grant Program page is displayed
		gl.VerifyPageDisplayed(Camel_Common.pgGrantProgram, "Grant Program");
		Thread.sleep(2000);

		gl.clickUsingJs(Camel_Home.lnkLogOut, "lnkLogout");
		Thread.sleep(2000);

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Close tab
		gl.closeAllBrowser();
	}


	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	/*@Test
	//Test Case :  Verify the Project Collaborators (Grant Program) Landing page Content, images and buttons.
	//Verifies:
	//All Artists sections
	//Pre requisites :
	//User should have valid username and password
	//Author : RajLakshmi Date: 6.02.2019


	public void Camel_artAffect_GrantReno_003 (String UN,String pwd,String url,String browserName,String txtCollaborator1,String txtCollaborator2,String txtCollaborator3,String txtCollaborator4) throws Exception
	{
		//****************************************************************************************************************
		//Launch application
		gl.launchApplication(browserName,url);
		Thread.sleep(5000);

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Enter Valid Username
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter Valid Password
		gl.inputText(Camel_Login.txtPassword,"txtPassword", pwd);
		//Click on Login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");

		//Camel Home page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("Home | Camel","Camel Home");
		//hover the mouse on ArtAffect
		gl.HowerMouse(Camel_Common.lnkArtAffect,"ArtAffect link from main navigation");


		//Click ArtAffect link from main navigation menu
		gl.clickbutton(Camel_Common.lnkGrantProgram, "Grant program from ArtAffect");
		Thread.sleep(3000);
		//Verify that Grant Program page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect - Grant Program | Camel","Art Affect Grant Program Page");
		Thread.sleep(3000);
		//Verify the image is displayed
		gl.VerifyElementVisible(Camel_ArtAffect_GrantProgram.weImgTheGenerator3, "The Generator  image 3");
		Thread.sleep(1000);
		//Click on Meet the Artist button
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnGrantProgramMeetTheArtist,"Grant Program Meet the Artist");
		Thread.sleep(1000);
		//Verify that Meet the Artist Grant Program page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("artAffect - Grant Program Collaborators | Camel","Meet the Artists-The Generator Project Collaborators");
		Thread.sleep(1000);
		//Verify the text element Grant Program  project collaborators is displayed
		gl.VerifyElementVisible(Camel_ArtAffect_GrantProgram.weArtAffectProjectCollaboratorTitle, "Art Affect Grant Progarm Project Collaborators");
		Thread.sleep(1000);
		//Verify the image of collaborator 1 is displayed
		gl.VerifyElementVisible(Camel_ArtAffect_GrantProgram.weImgGrantProgramProjectCollabaorator1,"Grant Program Project Collaborators images");

		//Verify the content of the collaborator 1
		gl.fnContentValidation( Camel_ArtAffect_GrantProgram.weTxtProjectCollabaorator1,txtCollaborator1); 
		//Verify the image of collaborator 2 is displayed
		gl.VerifyElementVisible(Camel_ArtAffect_GrantProgram.weImgGrantProgramProjectCollabaorator2,"Grant Program Project Collaborators images");
		//Verify the content of the collaborator 2
		gl.fnContentValidation( Camel_ArtAffect_GrantProgram.weTxtProjectCollabaorator2,txtCollaborator2); 
		//Verify the image of collaborator 3 is displayed
		gl.VerifyElementVisible(Camel_ArtAffect_GrantProgram.weImgGrantProgramProjectCollabaorator3,"Grant Program Project Collaborators images");
		//Verify the content of the collaborator 3
		gl.fnContentValidation( Camel_ArtAffect_GrantProgram.weTxtProjectCollabaorator3,txtCollaborator3); 
		//Verify the image of collaborator 4 is displayed
		gl.VerifyElementVisible(Camel_ArtAffect_GrantProgram.weImgGrantProgramProjectCollabaorator4,"Grant Program Project Collaborators images");
		//Verify the content of the collaborator 4
		gl.fnContentValidation( Camel_ArtAffect_GrantProgram.weTxtProjectCollabaorator4,txtCollaborator4); 
		//Click on back to top button
		gl.clickLink(Camel_ArtAffect_NewOrleans.btnBackToTop, "Back to top button");
		//Verify the text element Grant Program project collaborators is displayed
		gl.VerifyElementVisible(Camel_ArtAffect_GrantProgram.weArtAffectProjectCollaboratorTitle, "Art Affect Grant Program Project Collaborators");
		//Scroll to take screenshots of the page
		//				gl.fnScrollToView(Camel_ArtAffect_GrantProgram.weImgGrantProgramProjectCollabaorator1);
		//				gl.fnScrollToView(Camel_ArtAffect_GrantProgram.weTxtProjectCollabaorator1);
		//				gl.fnScrollToView(Camel_ArtAffect_GrantProgram.weImgGrantProgramProjectCollabaorator2);
		//				gl.fnScrollToView(Camel_ArtAffect_GrantProgram.weTxtProjectCollabaorator2);
		//				gl.fnScrollToView(Camel_ArtAffect_GrantProgram.weImgGrantProgramProjectCollabaorator3); 
		//				gl.fnScrollToView(Camel_ArtAffect_GrantProgram.weTxtProjectCollabaorator3);
		//				gl.fnScrollToView(Camel_ArtAffect_GrantProgram.weImgGrantProgramProjectCollabaorator4);
		//				gl.fnScrollToView(Camel_ArtAffect_GrantProgram.weTxtProjectCollabaorator4);
		//				
		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//                        //Close tab
		gl.closeAllBrowser();
	}

	 */

	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Verify the Detroit Landing page Content, images and buttons.
	//Verifies:
	//All sections of the page
	//Pre requisites :
	//User should have valid username and password
	//Author : Raj Lakshmi Date: 07.02.2019
	//Updated By : Prathisha V
	//Date: 8/29/2019
	//****************************************************************************************************************
	public void Camel_ArtAffect_Detroit_001 (String UN,String pwd,String url,String browserName, 
			String TheProject, String Poops, String Tool, String Artist, String Design) throws Exception
	{
		//****************************************************************************************************************
		//Launch application
		gl.launchApplication(browserName,url);
		Thread.sleep(5000);

		//Enter Valid Username
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter Valid Password
		gl.inputText(Camel_Login.txtPassword,"txtPassword", pwd);
		//Click on Login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
		Thread.sleep(5000);

		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "Home Page");

		//hover the mouse on ArtAffect
		gl.HowerMouse(Camel_Common.lnkArtAffect,"ArtAffect link from main navigation");

		//Click Build link from menu navigation bar
		gl.clickUsingJs(Camel_Common.lnkBuilds, "Builds from ArtAffect");
		Thread.sleep(2000);
		//Verify that Builds Landing page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_NewOrleans.pgBuilds, "Build page");

		//Scroll to Detroit section
		Actions pgdn = new Actions(driver);
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		Thread.sleep(2000);

		//Click  link from main navigation menu
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnSeeBuild, "See build button");
		Thread.sleep(2000);

		//Verify that Detroit page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_Detroit.pgDetroit, "Detroit");

		//Verify the hero tile of the Detroit page
		gl.VerifyElementVisible(Camel_ArtAffect_Detroit.weDetroitHeroTile,"ArtAffect Detroit hero tile");

		//Click the play button of the hero tile
		gl.clickUsingJs(Camel_ArtAffect_Detroit.btnDetroitVideo, "Play Video button");
		Thread.sleep(2000);

		//Verify video overlay is displayed
		gl.VerifyElementVisible(Camel_ArtAffect_Detroit.weHeroTileVideoOverlay, "Video overlay of hero tile");
		//Close the video overlay
		gl.clickbutton(Camel_ArtAffect_Detroit.btnHeroTileVideoOverlayClose,"CLOSE button of Video overlay of hero tile" );
		Thread.sleep(2000);

		//Verify that Detroit page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_Detroit.pgDetroit, "Detroit");

		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		Thread.sleep(2000);

		//Verify Detrit imgae(The Project Section) is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_Detroit.weProjectText);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_Detroit.weImgProjectSection);
		gl.fnContentValidation(TheProject, Camel_ArtAffect_Detroit.weProjectContent);

		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		Thread.sleep(2000);

		//Verify Project Gallery Section is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_Detroit.weProjectGallery);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_Detroit.weimgPoopsProjectgallery);
		gl.getExtractAttributeValue(Camel_ArtAffect_Detroit.weSubHeadingProjrtGallery, "Popps Emporium", "innerText");
		gl.fnContentValidation(Poops, Camel_ArtAffect_Detroit.weContentProjrctGallery);

		//Click Right Arrow
		pgdn.sendKeys(Keys.ARROW_UP).build().perform();
		pgdn.sendKeys(Keys.ARROW_UP).build().perform();
		Thread.sleep(3000);
		gl.clickLink(Camel_ArtAffect_Detroit.lnkRightArrowProjectGaller, "Right Arrow");
		Thread.sleep(2000);

		//Verify Image, heading and content
		gl.VerifyObjectDisplayed(Camel_ArtAffect_Detroit.weimgToolProjectgallery);
		gl.getExtractAttributeValue(Camel_ArtAffect_Detroit.weSubHeadingProjrtGallery, "Tool Library", "innerText");
		gl.fnContentValidation(Tool, Camel_ArtAffect_Detroit.weContentProjrctGallery);
		gl.clickLink(Camel_ArtAffect_Detroit.lnkRightArrowProjectGaller, "Right Arrow");
		Thread.sleep(2000);

		//Verify Image, heading and content
		gl.VerifyObjectDisplayed(Camel_ArtAffect_Detroit.weimgDesignProjectgallery);
		gl.getExtractAttributeValue(Camel_ArtAffect_Detroit.weSubHeadingProjrtGallery, "Design Library", "innerText");
		gl.fnContentValidation(Design, Camel_ArtAffect_Detroit.weContentProjrctGallery);
		gl.clickLink(Camel_ArtAffect_Detroit.lnkRightArrowProjectGaller, "Right Arrow");
		Thread.sleep(2000);

		//Verify Image, heading and content
		gl.VerifyObjectDisplayed(Camel_ArtAffect_Detroit.weimgArtistProjectgallery);
		gl.getExtractAttributeValue(Camel_ArtAffect_Detroit.weSubHeadingProjrtGallery, "Artist Residency", "innerText");
		gl.fnContentValidation(Artist, Camel_ArtAffect_Detroit.weContentProjrctGallery);
		gl.clickLink(Camel_ArtAffect_Detroit.lnkRightArrowProjectGaller, "Right Arrow");
		Thread.sleep(2000);

		//Click on any dots and verify heading and image
		/*for(int i=1;i<=3;i++)
		{
		gl.clickLink(By.xpath(Camel_ArtAffect_Detroit.weETest1+i+Camel_ArtAffect_Detroit.weETest2),"Dots");
		Thread.sleep(2000);
		}*/
		gl.clickLink(Camel_ArtAffect_Detroit.lnkPaginationDots, "Dot 2");
		Thread.sleep(2000);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_Detroit.weimgToolProjectgallery);
		gl.getExtractAttributeValue(Camel_ArtAffect_Detroit.weSubHeadingProjrtGallery, "Tool Library", "innerText");

		//Scroll to next section
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		Thread.sleep(2000);

		//Verify PROJECT COLLABORATORS section is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_Detroit.weProjectCollaborators);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_Detroit.weFainaLermanProjectCollaborators);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_Detroit.weGraemWhyteProjectCollaborators);

		//Scroll to next section
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		Thread.sleep(2000);

		//Verification of section and images
		gl.VerifyObjectDisplayed(Camel_ArtAffect_Detroit.wesectionExploreMoreBuildsHeading);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_Detroit.imgGrantProgramExploreMoreSection);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_Detroit.imgPaperMachineExploreMoreSection);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_Detroit.imgConfluenceExploreMoreSection);

		//Click on Learn More from GRANT PROGRAM Image
		gl.clickUsingJs(Camel_ArtAffect_Detroit.btnLearnMoreGrantProgramExploreMoreSection, "Learn More");
		Thread.sleep(3000);
		//Verify GRANT PROGRAM page is displayed
		gl.VerifyPageDisplayed(Camel_Common.pgGrantProgram, "Grant Program");

		//Click on Browser Back button
		gl.browserBack();
		Thread.sleep(3000);
		//Verify Detroit  page is displayed.
		gl.VerifyPageDisplayed(Camel_ArtAffect_Detroit.pgDetroit, "Detroit");

		//Click on Learn More from POPPS EMPORIUM Image
		gl.clickUsingJs(Camel_ArtAffect_Detroit.btnLearnMorePoppsEmporiumExploreMoreSection, "Learn More");
		Thread.sleep(3000);
		//Verify POPPS EMPORIUM page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_Detroit.pgPaperMachine, "Popps Emporium");

		//Click on Browser Back button
		gl.browserBack();
		Thread.sleep(3000);
		//Verify Detroit  page is displayed.
		gl.VerifyPageDisplayed(Camel_ArtAffect_Detroit.pgDetroit, "Detroit");

		//Click on Learn More from CONFLUENCE Image
		gl.clickUsingJs(Camel_ArtAffect_Detroit.btnLearnMoreConfluenceExploreMoreSection, "Learn More");
		Thread.sleep(3000);

		//Verify CONFLUENCE page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_Detroit.pgConfluence, "Confluence");

		//Click on Browser Back button
		gl.browserBack();
		Thread.sleep(3000);
		//Verify Detroit  page is displayed.
		gl.VerifyPageDisplayed(Camel_ArtAffect_Detroit.pgDetroit, "Detroit");


		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Close tab
		gl.closeAllBrowser();
	}



	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Verify the Project Collaborators (Grant Program) Landing page Content, images and buttons.
	//Verifies:
	//All Artists sections
	//Pre requisites :
	//User should have valid username and password
	//Author : Raj Lakshmi Date: 08.02.2019

	//Updated by: Prathisha V
	//Date: 8/30/2019

	public void Camel_ArtAffect_Detroit_003 (String UN,String pwd,String url,String browserName, String ArtistFaina, String ArtistGraem ) throws Exception
	{
		//****************************************************************************************************************
		//Launch application
		gl.launchApplication(browserName,url);
		Thread.sleep(5000);

		//Enter Valid Username
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter Valid Password
		gl.inputText(Camel_Login.txtPassword,"txtPassword", pwd);
		//Click on Login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
		Thread.sleep(5000);

		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "Home Page");

		//hover the mouse on ArtAffect
		gl.HowerMouse(Camel_Common.lnkArtAffect,"ArtAffect link from main navigation");

		//Click Build link from menu navigation bar
		gl.clickUsingJs(Camel_Common.lnkBuilds, "Builds from ArtAffect");
		Thread.sleep(2000);
		//Verify that Builds Landing page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_NewOrleans.pgBuilds, "Build page");

		//Scroll to Detroit section
		Actions pgdn = new Actions(driver);
		pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
		Thread.sleep(2000);

		//Click  link from main navigation menu
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnSeeBuild, "See build button");
		Thread.sleep(2000);

		//Verify that Detroit page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_Detroit.pgDetroit, "Detroit");

		for(int i=1;i<=4;i++)
		{
			pgdn.sendKeys(Keys.PAGE_DOWN).build().perform();
			Thread.sleep(1000);
		}
		//Verify PROJECT COLLABORATORS section is displayed
		gl.VerifyObjectDisplayed(Camel_ArtAffect_Detroit.weProjectCollaborators);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_Detroit.weFainaLermanProjectCollaborators);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_Detroit.weGraemWhyteProjectCollaborators);

		//Click on Meet Faina and verify the pop up for the respected section also verify the content on the page
		gl.clickUsingJs(Camel_ArtAffect_Detroit.btnMeetFaina, "Detroit Program");
		Thread.sleep(2000);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_Detroit.weArtistModel);
		gl.fnContentValidation(ArtistFaina, Camel_ArtAffect_Detroit.weArtistModel);
		gl.clickUsingJs(Camel_ArtAffect_Detroit.btnArtistModelClose, "ArtistModelClose");
		Thread.sleep(2000);

		//Click on Meet Faina and verify the pop up for the respected section also verify the content on the page
		gl.clickUsingJs(Camel_ArtAffect_Detroit.btnMeetGraem, "Detroit Program");
		Thread.sleep(2000);
		gl.VerifyObjectDisplayed(Camel_ArtAffect_Detroit.weArtistModel);
		gl.fnContentValidation(ArtistGraem, Camel_ArtAffect_Detroit.weArtistModel);
		gl.clickUsingJs(Camel_ArtAffect_Detroit.btnArtistModelClose, "ArtistModelClose");
		Thread.sleep(2000);

		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Close tab
		gl.closeAllBrowser();


	}

	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Verify the Builds Landing page Contents, images and buttons.
	//Verifies:
	//All Artists sections
	//Pre requisites :
	//User should have valid username and password
	//Author : Rakesh Hassan Ravikumar Date: 27.08.2019



	public void Camel_artAffect_Q3_Builds_Landing_Page_001 (String UN,String pwd,String url,String browserName, 
			String txtArtAffect, String txtPoppsEmprm, String txtDtrtMI,String txtFllwng, String txtltsBld,
			String txtPprMchne, String txtNwOrlns, String txtMsgpprMchne, String txtCnflnce, String txtKnsCity,
			String txtMsgCnflnce, String txtGrntPgm, String txtMsgGrntPgm) throws Exception
	{
		//****************************************************************************************************************
		//Launch application
		gl.launchApplication(browserName,url);
		Thread.sleep(5000);
		//Camel Login page is displayed.
		gl.VerifyElementVisible(Camel_Login.txtUsername, "Camel Login");
		//Enter Valid Username
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter Valid Password
		gl.inputText(Camel_Login.txtPassword,"txtPassword", pwd);
		//Click on Login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
		//Camel Home page is displayed
		Thread.sleep(10000);
		gl.VerifyPageDisplayed(Camel_ArtAffect_Builds.lnkArtAffect);
		//Hover the mouse on ArtAffect
		gl.HowerMouse(Camel_ArtAffect_Builds.lnkArtAffect,"ArtAffect link from main navigation");
		//Click  link builds from main navigation menu
		gl.clickElement(Camel_ArtAffect_Builds.lnkBuilds, "builds from ArtAffect ");
		//ArtAffect Builds page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_Builds.imgTxtArtAffect);
		//Verify artAffect is displayed in header section
		gl.VerifyElementVisible(Camel_ArtAffect_Builds.imgTxtArtAffect, "artAffect displayed in header section");
		//Verify BUILDS is displayed in header section 
		gl.VerifyElementVisible(Camel_ArtAffect_Builds.imgTxtBuilds, "BUILDS displayed in header section");
		//Verify text message in header section 
		gl.fnContentValidation(txtArtAffect, Camel_ArtAffect_Builds.imgTxtHeader);
		//scroll to Popps Emporium section
		gl.fnScrollToView(Camel_ArtAffect_Builds.imgTxtHeader);
		gl.VerifyElementVisible(Camel_ArtAffect_Builds.txtDtrtMI, "Popps Emporium section");;
		//Verify text POPPS EMPORIUM in popps emporium section
		gl.fnContentValidation(txtPoppsEmprm, Camel_ArtAffect_Builds.txtPoppsEmprm);
		//Verify text DETROIT, MI in popps emporium section
		gl.fnContentValidation(txtDtrtMI, Camel_ArtAffect_Builds.txtDtrtMI);
		//Verify text about post industrial in Detroit
		gl.fnContentValidation(txtFllwng, Camel_ArtAffect_Builds.txtFllwng);
		//Verify See builds button visible
		gl.isEnabled(Camel_ArtAffect_Builds.seeBuildsBtn, "See Builds button in popps emporium section");
		//Verify text LATEST BUILD in popps emporium section
		gl.fnContentValidation(txtltsBld, Camel_ArtAffect_Builds.txtLatstBlds);
		//verify 3 images dispalyed
		gl.VerifyElementVisible(Camel_ArtAffect_Builds.img1CityMap, "City map image in popps emporium section");
		gl.VerifyElementVisible(Camel_ArtAffect_Builds.img2PpsEmprm, "Home exterior image in Popps emporium section");
		gl.VerifyElementVisible(Camel_ArtAffect_Builds.img3PpsEmprm, "house interior image in popps emporium section");
		//Click on See Builds button of popps emporium section
		gl.clickUsingJs(Camel_ArtAffect_Builds.seeBuildsBtn, "Click on See Builds Button");
		Thread.sleep(3000);
		//Verify that POPPS EMPORIUM page is displayed upon clicking See Builds button
		gl.VerifyPageDisplayed(Camel_ArtAffect_Builds.popsEmprmPageElmnt);
		//click back button in browser
		gl.browserBack();
		if(browserName.equalsIgnoreCase("IE")){
			gl.fnScrollToView(Camel_ArtAffect_Builds.imgTxtHeader);
		}
		//verify navigated back to Popps Emporium section of ArtAffect builds page
		gl.VerifyElementVisiblescrncptr(Camel_ArtAffect_Builds.img1CityMap,"Popps Emporium section");
		//scroll down to PAPER MACHINE section
		gl.fnScrollToView(Camel_ArtAffect_Builds.seeBuildsBtn);
		gl.VerifyElementVisiblescrncptr(Camel_ArtAffect_Builds.txtPprMachne, "Paper Machine section");
		//verify 3 images in Paper Machine section
		gl.VerifyElementVisible(Camel_ArtAffect_Builds.img1NewOrlns, "New Orleans image in Paper Machine section");
		gl.VerifyElementVisible(Camel_ArtAffect_Builds.img2PprMchne, "Paper Machine prrinting hub image in Paper Machine section");
		gl.VerifyElementVisible(Camel_ArtAffect_Builds.img3PprMchne, "Paint wall image in Paper Machine section");
		//Verify Text PAPER MACHINE in Paper machine section
		gl.fnContentValidation(txtPprMchne, Camel_ArtAffect_Builds.txtPprMachne);
		//Verify Test NEW ORLEANS, LA in Paper Machine section
		gl.fnContentValidation(txtNwOrlns, Camel_ArtAffect_Builds.txtNewOrlns);
		//Verify text message displayed in Paper Machine section
		gl.fnContentValidation(txtMsgpprMchne, Camel_ArtAffect_Builds.txtForDcds);
		//Click on See build button in Paper Machine Section
		gl.clickUsingJs(Camel_ArtAffect_Builds.pprMchnSeeBld, "Clcik on See Build button of Paper Machine section");
		Thread.sleep(3000);
		//Verify Paper Machine Page displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_Builds.pprMchnPageElmnt, "Paper Machine Page displayed");
		//click on back button in browser
		gl.browserBack();
		if(browserName.equalsIgnoreCase("IE")){
			gl.fnScrollToView(Camel_ArtAffect_Builds.seeBuildsBtn);
		}
		//verify Papetr Machine section of Art Affect builds page is displayed
		Thread.sleep(5000);
		gl.VerifyElementVisiblescrncptr(Camel_ArtAffect_Builds.img1NewOrlns,"Paper Machine Section");
		//Scroll down to COnfluence section
		gl.fnScrollToView(Camel_ArtAffect_Builds.pprMchnSeeBld);
		gl.VerifyElementVisible(Camel_ArtAffect_Builds.txtConflunce, "Confluence Section");
		//Verify text CONFLUENCE is displayed in Confluence section
		gl.fnContentValidation(txtCnflnce, Camel_ArtAffect_Builds.txtConflunce);
		//Verify text KANSAS CITY, MO is displayed in Confluence section
		gl.fnContentValidation(txtKnsCity, Camel_ArtAffect_Builds.txtKnsasCity);
		//Verify text message in Confluence section
		gl.fnContentValidation(txtMsgCnflnce, Camel_ArtAffect_Builds.txtMsgCnflnc);
		//Verify 3 images are displayed in Confluence section
		gl.VerifyElementVisible(Camel_ArtAffect_Builds.img1Cnflnce, "Out Door Canopy image in Confluence section");
		gl.VerifyElementVisible(Camel_ArtAffect_Builds.img2Cnflnce, "Canopy Close Up image in Confluence section");
		gl.VerifyElementVisible(Camel_ArtAffect_Builds.img3Cnflnce, "Canopy wall image in Confluence section");
		//click on see builds of Confluence section
		gl.clickUsingJs(Camel_ArtAffect_Builds.cnflnceSeeBld, "Click on See Build in onfluence section");
		Thread.sleep(3000);
		//verify Confluence page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_Builds.cnflncePgElmnt);
		//click on browser back button
		gl.browserBack();
		if(browserName.equalsIgnoreCase("IE")){
			gl.fnScrollToView(Camel_ArtAffect_Builds.pprMchnSeeBld);
		}
		//Verify usre navigated back to Confluence section of Artaffect Builds page
		gl.VerifyElementVisiblescrncptr(Camel_ArtAffect_Builds.img1Cnflnce,"Confluence section");
		//Scroll down to Grant Program section
		gl.fnScrollToView(Camel_ArtAffect_Builds.txtMsgGrntPgm);
		gl.VerifyElementVisible(Camel_ArtAffect_Builds.txtGrntPgm, "Grant Program section");
		//Verify text GRANT PROGRAM in Grant Program section
		gl.fnContentValidation(txtGrntPgm, Camel_ArtAffect_Builds.txtGrntPgm);
		//Verify text message in Grant Program section
		gl.fnContentValidation(txtMsgGrntPgm, Camel_ArtAffect_Builds.txtMsgGrntPgm);
		//click on Learm More
		gl.clickUsingJs(Camel_ArtAffect_Builds.learnMoreBtn, "Click on Learn More in Grant Program section");
		Thread.sleep(3000);
		//Verify Grant Program section is dispalyed
		gl.VerifyPageDisplayed(Camel_ArtAffect_Builds.grntPgmPgElmnt);
		//click on back button in browser
		gl.navigateBack();
		if(browserName.equalsIgnoreCase("IE")){
			gl.fnScrollToView(Camel_ArtAffect_Builds.txtMsgGrntPgm);
		}
		//Verify navigated back to Grant Program section of ArtAffect Builds page
		gl.VerifyElementVisiblescrncptr(Camel_ArtAffect_Builds.txtMsgGrntPgm,"Grant Program Section");
		gl.clickUsingJs(Camel_Common.lnkLogout, "Click logout button from footer section");
		//Verify Camel Login Page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("Camel.com � Camel Cigarettes Official Website", "Camel Login");


	}

	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Verify the DB Burkeman Landing page Contents, images and buttons.

	//Pre requisites :
	//User should have valid username and password
	//Author : Vikram T Date: 20.11.2019



	public void Camel_artAffect_Q4_GrantProgram_DBBurkemanProjectPage_001(String UN,String pwd,String url,String browserName, 
			String txtTheProjectContent) throws Exception
	{
		//****************************************************************************************************************
		//Launch application
		gl.launchApplication(browserName,url);
		Thread.sleep(5000);
		//Camel Login page is displayed.
		gl.VerifyElementVisible(Camel_Login.txtUsername, "Camel Login");
		//Enter Valid User name
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter Valid Password in encrypted format
		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd);
		//Click on Login button
		gl.clickUsingJs(Camel_Login.lnkLogin,"lnkLogin");
		//Camel Home page is displayed
		gl.VerifyElementVisible(Camel_Common.PgHome,"Homepage beast icon");
		Thread.sleep(10000);
		//hover the mouse on ArtAffect
		gl.HowerMouse(Camel_Common.lnkArtAffect,"ArtAffect link from main navigation");
		Thread.sleep(5000);

		//Click ArtAffect sub menu links are displayed
		gl.VerifyElementVisible(Camel_Common.lnkGrantProgram, "Grant program submenu link from ArtAffect");
		Thread.sleep(2000);
		gl.VerifyElementVisible(Camel_ArtAffect_Builds.lnkBuilds,"Builds submenu link from ArtAffect");

		//Click  link builds from main navigation menu
		gl.clickbutton(Camel_Common.lnkGrantProgram, "Grant program submenu link from ArtAffect");

		//Verify that Grant program page is displayed.
		gl.VerifyElementVisible(Camel_Common.pgGrantProgram,"Grant program text displayed on the hero tile");

		//click on "View project" from DB Burkeman of the featured grantees section of the grant program page.
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnViewProjectDBBurkeman, "'View project' button from DB Burkeman of the featured grantees section");

		//Verify that DBBurkeman page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_DBBurkeman.wePgDBBurkeman,"DBBurkeman ArtSleeves page");
		//Verify that hero tile is displayed with Logo artaffect
		//	gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weArtAffectLogo,"ArtAffect Logo on hero tile");
		//Verify that hero tile is displayed with text DB burkeman
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weTxtDBBurkeman,"Text DB Burkeman on hero tile");
		//Verify that hero tile is displayed with text "Archiving album art in a world that would rather stream." 

		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weTxtArchivingAlbum,"Text Archiving album art....");
		gl.fnScrollToView(Camel_ArtAffect_DBBurkeman.weTxtTheProject);
		//verify the section heading "the project"
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weTxtTheProject,"Text The Project");

		gl.fnScrollToView(Camel_ArtAffect_DBBurkeman.weImgTheProject3);
		//Verify that images are displayed
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weImgTheProject1,"DB Burkeman outside image");
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weImgTheProject2,"Records on the shelf image");
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weImgTheProject3,"Playing record on the shelf image");
		gl.fnScrollToView(Camel_ArtAffect_DBBurkeman.weTxtTheProjectContent);
		//Verify the content under the project section
		gl.fnContentValidation(txtTheProjectContent,Camel_ArtAffect_DBBurkeman.weTxtTheProjectContent); 
		gl.fnScrollToView(Camel_ArtAffect_DBBurkeman.weTxtProjectGallery);
		//verify the section heading "Project Gallery"
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weTxtProjectGallery,"Text The Project Gallery");

		//Verify the image text in the project gallery section
		gl.fnScrollToView(Camel_ArtAffect_DBBurkeman.weImgProjectGallery1);
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weImgProjectGallery1," Project Gallery Image 1");
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weTxtProjectGallery1," Project Gallery Text 1");
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weTxtDBBurkemanProjectGallery," Project Gallery Text DB BURKEMAN");
		//Click on right arrow and verify the next image and text of the project gallery section
		gl.clickLink(Camel_ArtAffect_DBBurkeman.btnRightArrowProjectGallerysection, "Right Arrow");

		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weImgProjectGallery2," Project Gallery Image 2");
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weTxtProjectGallery2," Project Gallery Text 2");
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weTxtDBBurkemanProjectGallery," Project Gallery Text DB BURKEMAN");


		//Click on right arrow and verify the next image and text of the project gallery section
		gl.clickLink(Camel_ArtAffect_DBBurkeman.btnRightArrowProjectGallerysection, "Right Arrow");

		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weImgProjectGallery3," Project Gallery Image 3");
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weTxtProjectGallery3," Project Gallery Text 3");
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weTxtDBBurkemanProjectGallery," Project Gallery Text DB BURKEMAN");


		//Click on right arrow and verify the next image and text of the project gallery section
		gl.clickLink(Camel_ArtAffect_DBBurkeman.btnRightArrowProjectGallerysection, "Right Arrow");

		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weImgProjectGallery4," Project Gallery Image 4");
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weTxtProjectGallery4," Project Gallery Text 4");
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weTxtDBBurkemanProjectGallery," Project Gallery Text DB BURKEMAN");
		//Click on left arrow and verify the previous image and text of the project gallery section
		gl.clickLink(Camel_ArtAffect_DBBurkeman.btnLeftArrowProjectGallerysection, "Left Arrow");

		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weImgProjectGallery3," Project Gallery Image 3");
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weTxtProjectGallery3," Project Gallery Text 3");
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weTxtDBBurkemanProjectGallery," Project Gallery Text DB BURKEMAN");
		//Click on Pagination dot 1 and verify the previous image and text of the project gallery section
		gl.clickUsingJs(Camel_ArtAffect_DBBurkeman.btnPaginationDot1, "Pagination Dot 1");

		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weImgProjectGallery1," Project Gallery Image 1");
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weTxtProjectGallery1," Project Gallery Text 1");
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weTxtDBBurkemanProjectGallery," Project Gallery Text DB BURKEMAN");

		//verify the text "Explore more builds" 
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.WeExploreMoreBuilds," Text explore more builds");
		gl.fnScrollToView(Camel_ArtAffect_DBBurkeman.WePOPPSEMPORIUM);

		//POPPS EMPORIUM Image with Learn More button is displayed
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.WePOPPSEMPORIUM,"Popps emporium tile from explore more builds section");
		//Paper Machine Image with Learn More button is displayed
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.WePaperMachine,"Paper machine tile from explore more builds section");
		//Confluence Image with Learn More button is displayed
		gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.WeConfluence,"Confluence tile from explore more builds section");



		//Click on Learn More from POPPS EMPORIUM Image
		gl.clickbutton(Camel_ArtAffect_DBBurkeman.BtnLearnmorePOPPSEMPORIUM,"Learn more button from POPPSEMPORIUM" );
		Thread.sleep(5000);
		//POPPS EMPORIUM page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_DBBurkeman.WePOPPSEMPORIUMPage,"POPPSEMPORIUM Page");
		Thread.sleep(3000);

		// Click on Browser Back button
		gl.browserBack();
		Thread.sleep(3000);

		//Verify that DBBurkeman page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_DBBurkeman.wePgDBBurkeman,"DBBurkeman ArtSleeves page");

		// Click on Learn More from Paper Machine Image
		gl.clickbutton(Camel_ArtAffect_DBBurkeman.BtnLearnmorePaperMachine,"Learn more button of Paper Machine tile" );
		Thread.sleep(5000);
		//Paper Machine (New Orleans) page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_DBBurkeman.WePaperMachinePage,"Paper Machine Page");
		Thread.sleep(3000);

		// Click on Browser Back button
		gl.browserBack();
		Thread.sleep(3000);

		//Verify that DBBurkeman page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_DBBurkeman.wePgDBBurkeman,"DBBurkeman ArtSleeves page");

		// Click on Learn More from Confluence Image
		gl.clickbutton(Camel_ArtAffect_DBBurkeman.BtnLearnmoreConfluence,"Learn more button of Confluence tile" );
		Thread.sleep(5000);
		//Confluence page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_DBBurkeman.WeConfluencePage,"Confluence Page");
		Thread.sleep(3000);

		// Click on Browser Back button
		gl.browserBack();
		Thread.sleep(3000);

		//Verify that DBBurkeman page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_DBBurkeman.wePgDBBurkeman,"DBBurkeman ArtSleeves page");
		//Click on "Log out" button from the footer section
		gl.clickUsingJs(Camel_Common.lnkLogout, "Click logout button from footer section");
		//Verify Camel Login Page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("Camel.com � Camel Cigarettes Official Website", "Camel Login");


	}
	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Verify the Public Shelter Landing page Contents, images and buttons.

	//Pre requisites :
	//User should have valid username and password
	//Author : Vikram T Date: 21.11.2019



	public void Camel_artAffect_Q4_GrantProgram_ThePublicShelterProjectPage_001(String UN,String pwd,String url,String browserName, String txtThePublicShelterProjectContent) throws Exception
	{
		//****************************************************************************************************************
		//Launch application
		gl.launchApplication(browserName,url);
		Thread.sleep(5000);
		//Camel Login page is displayed.
		gl.VerifyElementVisible(Camel_Login.txtUsername, "Camel Login");
		//Enter Valid User name
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter Valid Password in encrypted format
		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd);
		//Click on Login button
		gl.clickUsingJs(Camel_Login.lnkLogin,"lnkLogin");
		//Camel Home page is displayed
		gl.VerifyElementVisible(Camel_Common.PgHome,"Homepage beast icon");
		Thread.sleep(10000);
		//hover the mouse on ArtAffect
		gl.HowerMouse(Camel_Common.lnkArtAffect,"ArtAffect link from main navigation");
		Thread.sleep(5000);

		//Click ArtAffect sub menu links are displayed
		gl.VerifyElementVisible(Camel_Common.lnkGrantProgram, "Grant program submenu link from ArtAffect");
		Thread.sleep(2000);
		gl.VerifyElementVisible(Camel_ArtAffect_Builds.lnkBuilds,"Builds submenu link from ArtAffect");

		//Click  link builds from main navigation menu
		gl.clickbutton(Camel_Common.lnkGrantProgram, "Grant program submenu link from ArtAffect");

		//Verify that Grant program page is displayed.
		gl.VerifyElementVisible(Camel_Common.pgGrantProgram,"Grant program text displayed on the hero tile");

		//click on "View project" from The Public shelter  of the featured grantees section of the grant program page.
		gl.clickUsingJs(Camel_ArtAffect_GrantProgram.btnViewProjectPublicShelter, "'View project' button from The public shelter of the featured grantees section");

		//Verify that Public Shelter page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_PublicShelter.wePgPublicShelter,"Public shelter page");
		//Verify that hero tile is displayed with Logo artaffect
		//	gl.VerifyElementVisible(Camel_ArtAffect_DBBurkeman.weArtAffectLogo,"ArtAffect Logo on hero tile");
		//Verify that hero tile is displayed with text Chris wyatt scott
		gl.VerifyElementVisible(Camel_ArtAffect_PublicShelter.weTxtChrisWyattScott,"Text Chris wyatt scott on hero tile");
		//Verify that hero tile is displayed with text "Building an Oasis..." 

		gl.VerifyElementVisible(Camel_ArtAffect_PublicShelter.weTxtBuildingAnOasis,"Building an Oasis....");
		gl.fnScrollToView(Camel_ArtAffect_PublicShelter.weTxtTheProject);
		//verify the section heading "the project"
		gl.VerifyElementVisible(Camel_ArtAffect_PublicShelter.weTxtTheProject,"Text The Project");

		gl.fnScrollToView(Camel_ArtAffect_PublicShelter.weImgTheProject3);
		//Verify that images are displayed
		gl.VerifyElementPresent(Camel_ArtAffect_PublicShelter.weImgTheProject1,"Public shelter Image 1");
		gl.VerifyElementVisible(Camel_ArtAffect_PublicShelter.weImgTheProject2,"Public shelter Image 2");
		gl.VerifyElementVisible(Camel_ArtAffect_PublicShelter.weImgTheProject3,"Public shelter Image 3");
		gl.fnScrollToView(Camel_ArtAffect_PublicShelter.weTxtTheProjectContent);
		//Verify the content under the project section
		gl.fnContentValidation(txtThePublicShelterProjectContent,Camel_ArtAffect_PublicShelter.weTxtTheProjectContent); 
		gl.fnScrollToView(Camel_ArtAffect_PublicShelter.weTxtProjectGallery);
		//verify the section heading "Project Gallery"
		gl.VerifyElementPresent(Camel_ArtAffect_PublicShelter.weTxtProjectGallery,"Text The Project Gallery");

		//Verify the image text in the project gallery section
		gl.fnScrollToView(Camel_ArtAffect_PublicShelter.weImgProjectGallery1);
		gl.VerifyElementPresent(Camel_ArtAffect_PublicShelter.weImgProjectGallery1," Project Gallery Image 1");
		gl.VerifyElementVisible(Camel_ArtAffect_PublicShelter.weTxtProjectGallery1," Project Gallery Text 1");
		gl.VerifyElementVisible(Camel_ArtAffect_PublicShelter.weTxtChrisProjectGallery," Project Gallery Text Chris");
		//Click on right arrow and verify the next image and text of the project gallery section
		gl.clickLink(Camel_ArtAffect_PublicShelter.btnRightArrowProjectGallerysection, "Right Arrow");

		gl.VerifyElementPresent(Camel_ArtAffect_PublicShelter.weImgProjectGallery2," Project Gallery Image 2");
		gl.VerifyElementVisible(Camel_ArtAffect_PublicShelter.weTxtProjectGallery2," Project Gallery Text 2");
		gl.VerifyElementVisible(Camel_ArtAffect_PublicShelter.weTxtChrisProjectGallery," Project Gallery Text Chris");


		//Click on right arrow and verify the next image and text of the project gallery section
		gl.clickLink(Camel_ArtAffect_PublicShelter.btnRightArrowProjectGallerysection, "Right Arrow");

		gl.VerifyElementPresent(Camel_ArtAffect_PublicShelter.weImgProjectGallery3," Project Gallery Image 3");
		gl.VerifyElementVisible(Camel_ArtAffect_PublicShelter.weTxtProjectGallery3," Project Gallery Text 3");
		gl.VerifyElementVisible(Camel_ArtAffect_PublicShelter.weTxtChrisProjectGallery," Project Gallery Text Chris");


		//Click on right arrow and verify the next image and text of the project gallery section
		gl.clickLink(Camel_ArtAffect_PublicShelter.btnRightArrowProjectGallerysection, "Right Arrow");

		gl.VerifyElementPresent(Camel_ArtAffect_PublicShelter.weImgProjectGallery4," Project Gallery Image 4");
		gl.VerifyElementVisible(Camel_ArtAffect_PublicShelter.weTxtProjectGallery4," Project Gallery Text 4");
		gl.VerifyElementVisible(Camel_ArtAffect_PublicShelter.weTxtChrisProjectGallery," Project Gallery Text Chris");
		//Click on left arrow and verify the previous image and text of the project gallery section
		gl.clickLink(Camel_ArtAffect_PublicShelter.btnLeftArrowProjectGallerysection, "Left Arrow");

		gl.VerifyElementPresent(Camel_ArtAffect_PublicShelter.weImgProjectGallery3," Project Gallery Image 3");
		gl.VerifyElementVisible(Camel_ArtAffect_PublicShelter.weTxtProjectGallery3," Project Gallery Text 3");
		gl.VerifyElementVisible(Camel_ArtAffect_PublicShelter.weTxtChrisProjectGallery," Project Gallery Text Chris");
		//Click on Pagination dot 1 and verify the previous image and text of the project gallery section
		gl.clickUsingJs(Camel_ArtAffect_PublicShelter.btnPaginationDot1, "Pagination Dot 1");

		gl.VerifyElementPresent(Camel_ArtAffect_PublicShelter.weImgProjectGallery1," Project Gallery Image 1");
		gl.VerifyElementVisible(Camel_ArtAffect_PublicShelter.weTxtProjectGallery1," Project Gallery Text 1");
		gl.VerifyElementVisible(Camel_ArtAffect_PublicShelter.weTxtChrisProjectGallery," Project Gallery Text Chris");

		//verify the text "Explore more builds" 
		gl.VerifyElementVisible(Camel_ArtAffect_PublicShelter.WeExploreMoreBuilds," Text explore more builds");
		gl.fnScrollToView(Camel_ArtAffect_PublicShelter.WePOPPSEMPORIUM);

		//POPPS EMPORIUM Image with Learn More button is displayed
		gl.VerifyElementPresent(Camel_ArtAffect_PublicShelter.WePOPPSEMPORIUM,"Popps emporium tile from explore more builds section");
		//Paper Machine Image with Learn More button is displayed
		gl.VerifyElementVisible(Camel_ArtAffect_PublicShelter.WePaperMachine,"Paper machine tile from explore more builds section");
		//Confluence Image with Learn More button is displayed
		gl.VerifyElementVisible(Camel_ArtAffect_PublicShelter.WeConfluence,"Confluence tile from explore more builds section");



		//Click on Learn More from POPPS EMPORIUM Image
		gl.clickbutton(Camel_ArtAffect_PublicShelter.BtnLearnmorePOPPSEMPORIUM,"Learn more button from POPPSEMPORIUM" );
		Thread.sleep(5000);
		//POPPS EMPORIUM page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_PublicShelter.WePOPPSEMPORIUMPage,"POPPSEMPORIUM Page");
		Thread.sleep(3000);

		// Click on Browser Back button
		gl.browserBack();
		Thread.sleep(3000);

		//Verify that Public Shelter page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_PublicShelter.wePgPublicShelter,"Public shelter page");

		// Click on Learn More from Paper Machine Image
		gl.clickbutton(Camel_ArtAffect_PublicShelter.BtnLearnmorePaperMachine,"Learn more button of Paper Machine tile" );
		Thread.sleep(5000);
		//Paper Machine (New Orleans) page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_PublicShelter.WePaperMachinePage,"Paper Machine Page");
		Thread.sleep(3000);

		// Click on Browser Back button
		gl.browserBack();
		Thread.sleep(3000);


		//Verify that Public Shelter page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_PublicShelter.wePgPublicShelter,"Public shelter page");

		// Click on Learn More from Confluence Image
		gl.clickbutton(Camel_ArtAffect_PublicShelter.BtnLearnmoreConfluence,"Learn more button of Confluence tile" );
		Thread.sleep(5000);
		//Confluence page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_PublicShelter.WeConfluencePage,"Confluence Page");
		Thread.sleep(3000);

		// Click on Browser Back button
		gl.browserBack();
		Thread.sleep(3000);

		//Verify that Public Shelter page is displayed
		gl.VerifyPageDisplayed(Camel_ArtAffect_PublicShelter.wePgPublicShelter,"Public shelter page");
		//Click on "Log out" button from the footer section
		gl.clickUsingJs(Camel_Common.lnkLogout, "Click logout button from footer section");

		Thread.sleep(10000);
		//Verify Camel Login Page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("Camel.com � Camel Cigarettes Official Website", "Camel Login");

		Thread.sleep(5000);
	}
	public void afterMethod() {
		driver.quit();
		gl.endReport();
		//extent.flush();
	}



}
