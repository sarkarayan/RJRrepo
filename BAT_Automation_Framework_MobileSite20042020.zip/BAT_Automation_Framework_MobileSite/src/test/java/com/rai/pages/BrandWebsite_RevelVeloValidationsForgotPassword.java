package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.brandWebsitePageObjects;

public class BrandWebsite_RevelVeloValidationsForgotPassword extends BaseClass {

	String testcaseName;
	public BrandWebsite_RevelVeloValidationsForgotPassword(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(brandWebsitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("ForgotPassword Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
			
	public void invokeApplication_RevelVelobrandwebsite() throws IOException
	{
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);	
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.lnktxt_RevelVeloForgotPassword), brandWebsitePageObjects.lnktxt_RevelVeloForgotPassword.getObjectname());
	}
	
	public void forgotPassword_NegativeValidationsUsernamePage() throws IOException
	{
		String InvalidUserIdformat = dataTable.getData("General_Data", "InvalidUserIDformat");
		
		//Thread.sleep(4000);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Clicking on Continue without UserId data
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue),brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
		String Actualerrormsg_NoUsernameentered = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordNoUsername));
		String Expectederrormsg_NoUsernameentered = "Please enter your Username / Email Address.";
		if(Actualerrormsg_NoUsernameentered.contains(Expectederrormsg_NoUsernameentered))
		{
			System.out.println("ForgotPassword - Expected error message displayed when user clicks on Continue without UserId");
		}
		else
		{
			System.out.println("ForgotPassword - Expected error message was not displayed when user clicks on Continue without UserId");
		}
		
		//User entered Invalid UserID format
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordUsername),InvalidUserIdformat, brandWebsitePageObjects.txt_ForgotPasswordUsername.getObjectname());
		//Thread.sleep(2000);
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue),brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
		String Actualerrormsg_InvalidUserIDformat = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordInvalidUserIdformat));
		String Expectederrormsg_InvalidUserIDformat = "Username must be a combination of 8-30 letters and numbers.";
		if(Actualerrormsg_InvalidUserIDformat.contentEquals(Expectederrormsg_InvalidUserIDformat))
		{
			System.out.println("ForgotPassword - Expected error message displayed when user enters UserId in invalid format");
		}
		else
		{
			System.out.println("ForgotPassword - Expected error message was not displayed when user enters UserId in invalid format");
		}
		
	}
	
	public void forgotPassword_EnterValidUsername() throws IOException
	{
		String Email = dataTable.getData("General_Data", "Email");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordUsername), Email, brandWebsitePageObjects.txt_ForgotPasswordUsername.getObjectname());
		//Thread.sleep(2000);
		commonFunction.clickIfElementPresentJavaScript(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue), brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
	    //commonFunction.sendKeyENTER(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue),brandWebsitePageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
	}
	
	
	public void forgotPassword_NegativeValidationsGeneralInfoPage() throws InterruptedException, IOException
	{
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String InvalidLastName = dataTable.getData("General_Data", "InvalidLastName");
		String InvalidAddress = dataTable.getData("General_Data", "InvalidAddress");
		String InvalidZipcode = dataTable.getData("General_Data", "InvalidZipcode");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
		
		String date = dataTable.getData("General_Data","DOB");
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		//Clicking on Continue without any data on GeneralInfo page
		Thread.sleep(6000);
		//commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.lnk_ForgotPasswordGeneralInfoLogin));
		//commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordFirstName), FirstName, brandWebsitePageObjects.txt_ForgotPasswordFirstName.getObjectname());
		//commonFunction.clearText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordFirstName), brandWebsitePageObjects.txt_ForgotPasswordFirstName.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation), brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation.getObjectname());
        //commonFunction.clickIfElementPresentJavaScript(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation), brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation.getObjectname());
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordNoDataonGeneralInfo));
		String ActualErrormsg_nodataonGeneralInfo = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordNoDataonGeneralInfo));
		String ExpectedErrormsg_nodataonGeneralInfo = "Please fix the errors above";
		if(ActualErrormsg_nodataonGeneralInfo.contentEquals(ExpectedErrormsg_nodataonGeneralInfo))
		{
			System.out.println("ForgotPassword - Expected error message displayed when user click Continue on GeneralInfo page");
		}
		else
		{
			System.out.println("ForgotPassword - Expected error message not displayed when user click Continue on GeneralInfo page");
		}
		
		//User entered Invalid user info on GeneralInfo page
		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordBirthMonth), month, brandWebsitePageObjects.drpdwn_ForgotPasswordBirthMonth.getObjectname());
		Thread.sleep(5000);
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordBirthDay), day, brandWebsitePageObjects.drpdwn_ForgotPasswordBirthDay.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordBirthYear), year,brandWebsitePageObjects.drpdwn_ForgotPasswordBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordFirstName), FirstName, brandWebsitePageObjects.txt_ForgotPasswordFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordLastName), InvalidLastName, brandWebsitePageObjects.txt_ForgotPasswordLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordAddress), InvalidAddress, brandWebsitePageObjects.txt_ForgotPasswordAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordZipcode), InvalidZipcode, brandWebsitePageObjects.txt_ForgotPasswordZipcode.getObjectname());
		Thread.sleep(4000);
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordCity), City, brandWebsitePageObjects.txt_ForgotPasswordCity.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordState),State, brandWebsitePageObjects.drpdwn_ForgotPasswordState.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation), brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation.getObjectname());
		
		String Actualerrormsg_InvalidUserInfo = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordUsernotfound));
		String Expectederrormsg_InvalidUserInfo = "We were not able to find your information. Please check and try again.";
		if(Actualerrormsg_InvalidUserInfo.contentEquals(Expectederrormsg_InvalidUserInfo))
		{
			System.out.println("ForgotPassword - Expected error message displayed when user entered Invalid UserInfo");
		}
		else
		{
			System.out.println("ForgotPassword - Expected error message not displayed when user entered Invalid UserInfo");
		}
			
		
	}
	
		
	public void forgotPassword_ValidDataOnGeneralInformationPage() throws InterruptedException, IOException
	{
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
		
//		commonFunction.selectAnyElement(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordBirthMonth), 10, brandWebsitePageObjects.drpdwn_ForgotPasswordBirthMonth.getObjectname());
//		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordBirthDay), "14", brandWebsitePageObjects.drpdwn_ForgotPasswordBirthDay.getObjectname());
//		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordBirthYear), "1938",brandWebsitePageObjects.drpdwn_ForgotPasswordBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordFirstName), FirstName, brandWebsitePageObjects.txt_ForgotPasswordFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordLastName), LastName, brandWebsitePageObjects.txt_ForgotPasswordLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordAddress), Address, brandWebsitePageObjects.txt_ForgotPasswordAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordZipcode), Zipcode, brandWebsitePageObjects.txt_ForgotPasswordZipcode.getObjectname());
		Thread.sleep(4000);
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordCity), City, brandWebsitePageObjects.txt_ForgotPasswordCity.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(brandWebsitePageObjects.drpdwn_ForgotPasswordState),State, brandWebsitePageObjects.drpdwn_ForgotPasswordState.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation), brandWebsitePageObjects.btn_ForgotPasswordGeneralInformation.getObjectname());
		
	}
	
	
	public void forgotPassword_NegativeValidationsVerifyIdentity() throws InterruptedException, IOException
	{
		String InvalidChallengeAnswer = dataTable.getData("General_Data", "InvalidChallengeAnswer");
		
		//ChallengeAnswer not entered on VerifyIdentity Page
		Thread.sleep(4000);
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity), brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
		Thread.sleep(5000);
		String Actualerrormsg_Noanswerentered = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordNoChallengeAnswer));
		String Expectederrormsg_Noanswerentered = "Please provide an answer to account recovery question";
		if(Actualerrormsg_Noanswerentered.contentEquals(Expectederrormsg_Noanswerentered))
		{
			System.out.println("ForgotPassword - Expected errormsg displayed when user click continue without providing ChallengeAnswer");
		}
		else
		{
			System.out.println("ForgotPassword - Expected errormsg not displayed when user click continue without providing ChallengeAnswer");
		}
		
		//User entered Incorrect ChallengeAnswer on VerifyIdentity page
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordChallengeAnswer), InvalidChallengeAnswer, brandWebsitePageObjects.txt_ForgotPasswordChallengeAnswer.getObjectname());
		Thread.sleep(2000);
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity), brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
        String Actualerrormsg_enteredInvalidanswer = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordInvalidChallengeAnswer));
        String Expectederrormsg_enteredInvalidanswer = "The answer does not match our records. Please re-enter your answer to the challenge question";
        if(Actualerrormsg_enteredInvalidanswer.contentEquals(Expectederrormsg_enteredInvalidanswer))
        {
        	System.out.println("ForgotPassword - Expected errormsg displayed when user enters Invalid ChallengeAnswer");
        }
        else
        {
        	System.out.println("ForgotPassword - Expected errormsg not displayed when user enters Invalid ChallengeAnswer");
        }
        		
	}
	
	
	public void forgotPassword_ValidDataVerifyIdentity() throws InterruptedException, IOException
	{
		String ChallengeAnswer = dataTable.getData("General_Data", "ChallengeAnswer");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordChallengeAnswer), ChallengeAnswer, brandWebsitePageObjects.txt_ForgotPasswordChallengeAnswer.getObjectname());
		Thread.sleep(2000);
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity), brandWebsitePageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
		Thread.sleep(4000);		
		
	}
	
	
	public void forgotPassword_NegativeValidationsResetPassword() throws InterruptedException, IOException
	{
		String InvalidPasswordformat = dataTable.getData("General_Data", "InvalidPasswordformat");
		String DifferntPassword = dataTable.getData("General_Data", "InvalidPassword");
		String Password = dataTable.getData("General_Data", "Password");
		
		//User clicked Continue without entering Password on ResetPassword page
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordResetPassword), brandWebsitePageObjects.btn_ForgotPasswordResetPassword.getObjectname());
		String Actualerrormsg_noPasswordentered = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordNoPasswordentered));
		String Expectederrormsg_noPasswordentered = "Please provide a password";
		if(Actualerrormsg_noPasswordentered.contentEquals(Expectederrormsg_noPasswordentered))
		{
			System.out.println("ForgotPassword - Expected errormsg displayed when user click Continue without entering Password");
		}
		else
		{
			System.out.println("ForgotPassword - Expected errormsg not displayed when user click Continue without entering Password");
		}
		
		
		//User entered Invalid format in Password field
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordPassword),InvalidPasswordformat,brandWebsitePageObjects.txt_ForgotPasswordPassword.getObjectname());
		String Actualerrormsg_InvalidPasswordformat = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordInvalidPasswordformatentered));
		String Expectederrormsg_InvalidPasswordformat = "Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.";
		if(Actualerrormsg_InvalidPasswordformat.contentEquals(Expectederrormsg_InvalidPasswordformat))
		{
			System.out.println("ForgotPassword - Expected errormsg displayed when user entered password in Invalidformat");
		}
		else
		{
			System.out.println("ForgotPassword - Expected errormsg not displayed when user entered password in Invalidformat");
		}
		
		//User entered different data in Password & ConfirmPassword fields
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordPassword), Password, brandWebsitePageObjects.txt_ForgotPasswordPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordConfirmPassword), DifferntPassword, brandWebsitePageObjects.txt_ForgotPasswordConfirmPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordResetPassword), brandWebsitePageObjects.btn_ForgotPasswordResetPassword.getObjectname());
		Thread.sleep(4000);
		String Actualerrormsg_differntPasswordentered = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordDifferentPasswordentered));
		String Expectederrormsg_differntPasswordentered = "Passwords did not match";
		if(Actualerrormsg_differntPasswordentered.contentEquals(Expectederrormsg_differntPasswordentered))
		{
			System.out.println("ForgotPassword - Expected errormsg displayed when user entered differnt data in Password & ConfirmPassword fields");
		}
		else
		{
			System.out.println("ForgotPassword - Expected errormsg not displayed when user entered differnt data in Password & ConfirmPassword fields");
		}
		
		
	}
	
	public void forgotPassword_ValidDataResetPassword() throws InterruptedException, IOException
	{
		String Password = dataTable.getData("General_Data", "Password");
		String ConfirmPassword = dataTable.getData("General_Data", "Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordPassword), Password, brandWebsitePageObjects.txt_ForgotPasswordPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_ForgotPasswordConfirmPassword), ConfirmPassword, brandWebsitePageObjects.txt_ForgotPasswordConfirmPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_ForgotPasswordResetPassword), brandWebsitePageObjects.btn_ForgotPasswordResetPassword.getObjectname());
		Thread.sleep(4000);
	}
	
	
	public void forgotPassword_NegativeValidationsCongratsPage() throws IOException
	{
		String Email = dataTable.getData("General_Data", "Email");
		
		//User clicked on Login without any data on Congrats Page
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_CongratsPageLoginbutton), brandWebsitePageObjects.btn_CongratsPageLoginbutton.getObjectname());
		String Actualerrormsg_nodataenteredonCongratsPage = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordCongratsPageNoDataEntered));
		String Expectederrormsg_nodataenteredonCongratsPage = "Please fix the errors above";
		if(Actualerrormsg_nodataenteredonCongratsPage.contentEquals(Expectederrormsg_nodataenteredonCongratsPage))
		{
			System.out.println("ForgotPassword - CongratsPage - Expected erromsg displayed when user clicked Login without any data");
		}
		else
		{
			System.out.println("ForgotPassword - CongratsPage - Expected erromsg not displayed when user clicked Login without any data");
		}
		
		//User clicked on Login without Password
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_CongratsPageUsername), Email, brandWebsitePageObjects.txt_CongratsPageUsername.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_CongratsPageLoginbutton), brandWebsitePageObjects.btn_CongratsPageLoginbutton.getObjectname());
		String Actualerrormsg_NopasswordonCongratsPage = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ForgotPasswordCongratsPagePasswordNotentered));
		String Expectederrormsg_NopasswordonCongratsPage = "Please enter your password.";
		if(Actualerrormsg_NopasswordonCongratsPage.contentEquals(Expectederrormsg_NopasswordonCongratsPage))
		{
			System.out.println("ForgotPassword - CongratsPage - Expected erromsg displayed when user clicked Login without Password");
		}
		else
		{
			System.out.println("ForgotPassword - CongratsPage - Expected erromsg not displayed when user clicked Login without Password");
		}
	}
	
	
	public void forgotPassword_CongratsPage() throws IOException
	{
		String Email = dataTable.getData("General_Data", "Email");
		String Password = dataTable.getData("General_Data", "Password");
		
		commonFunction.clearAndEnterText(getPageElement(brandWebsitePageObjects.txt_CongratsPageUsername),Email, brandWebsitePageObjects.txt_CongratsPageUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_CongratsPagePassword), Password,brandWebsitePageObjects.txt_CongratsPagePassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_CongratsPageLoginbutton), brandWebsitePageObjects.btn_CongratsPageLoginbutton.getObjectname());
		
	}
	
	
	
}
