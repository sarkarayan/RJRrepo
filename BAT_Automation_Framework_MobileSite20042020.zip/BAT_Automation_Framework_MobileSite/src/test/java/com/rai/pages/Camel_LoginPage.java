package com.rai.pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;


import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.pageObjects.*;
import com.rai.framework.GenericLib;
@Listeners(ExtentITestListenerClassAdapter.class)
public class Camel_LoginPage extends BaseClass {
	GenericLib gl = new GenericLib(this.getClass().getSimpleName());
	Properties config = new Properties();
	SoftAssert softAssert=new SoftAssert();
	// AS_HomePage homePage=new AS_HomePage();

	@BeforeMethod
	public void beforemethod(String TestCaseName,String TestCaseObjective,String TestEnvironmentUrl) {
		gl.start_report(TestCaseName, TestCaseObjective, TestEnvironmentUrl);
		//extent = ExtentManager.GetExtent();	
		//extent = ExtentManager.createTest(test, description)
	}
	@Test
	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	//  @Test
	//Test Case :  Camel_Redesign_Menu_Navigation_001 
	//Objectives: Validate Menu Navigation
	//Verify the contents of the navigation menu 
	//--Beast icon 
	//--Menu items 
	//-- Profile item
	//Pre requisites :
	//User should have valid username and password
	//Author - Suneel Kaushik Subramanya
	//********************************************************************************************************************************************************
	public void Camel_Redesign_Menu_Navigation_001(String UN, String pwd, 
			String browserName, String url) throws Exception
	{

		//Launch Browser
				gl.launchApplication(browserName, url);

				//Verify login page is displayed
				//	gl.VerifyPageDisplayed(Camel_Login.txtUsername, "Login");

				//Login to application
				//	gl.fnLogin(UN, pwd);
				//Enter Valid Username
				gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
				//Enter Valid Password
				gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd);
				//Click on Login button
				gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
				Thread.sleep(9000);
				//Verify HomePage is displayed
				//gl.VerifyPageDisplayed(Camel_Home.weHomePage, "Home");

				//****************************************************************************
				//Home Page
				//****************************************************************************

				/*//Verify crush now and dashboard link is displayed
				gl.VerifyLinkExistence(Camel_Common.lnkCrushNowAndDashboard, "Crush Now and Dashboard");*/

				//Verify Buildout link is displayed
				//gl.VerifyLinkExistence(Camel_Common.lnkBuildOut, "Buildout");

				//verify soundboard link is displayed
				//gl.VerifyLinkExistence(Camel_Common.lnkSoundBoard, "Soudboard");
				//Verify the  crush rich link 
				gl.VerifyLinkExistence(Camel_Common.lnkCrushRich, "Crush Rich");
				//Verify hump link is displayed
				gl.VerifyLinkExistence(Camel_Common.lnkTheHump, "Hump");

				//Verify arteffect link is displayed
				gl.VerifyLinkExistence(Camel_Common.lnkTheArtAffect, "Artaffect");

				//Verify Products link is dipslayed
				gl.VerifyLinkExistence(Camel_Common.lnkProducts, "Products");

				//Verify Offers link is displayed
				gl.VerifyLinkExistence(Camel_Common.lnkCoupons, "Offers");

				//Verify profile link is dipslayed
				gl.VerifyLinkExistence(Camel_Common.lnkProfile, "Profile");

				//****************************************************************************
				//Crush Now and Dashboard Page
				//****************************************************************************

				/*//Click the Crush Now and Dashboard link
				gl.clickLink(Camel_Common.lnkCrushNowAndDashboard, "Crush Now and Dashboard");*/

				/*//Verify Crush Now and Dashboard page is displayed
				gl.VerifyPageDisplayed(Camel_CrushNowAndDashboard.weCrushNowPage, "Crush Now and Dashboard");
				 */
				//****************************************************************************
				//SoundBoard Page
				//****************************************************************************
				//
				//		//Click the Soundboard link
				//		gl.clickLink(Camel_Common.lnkSoundBoard, "Soundboard Link");
				//
				//		//Verify Soundboard page
				//		gl.VerifyPageDisplayed(Camel_SoundBoard.weSoundBoardLogoImg, "Soundboard");
				//****************************************************************************
				//Crush Rich Page
				//****************************************************************************

				//Click the Crush rich link
				gl.clickLink(Camel_Common.lnkCrushRich, "Crush rich Link");

				//Verify Crush rich page is displayed
				gl.VerifyPageDisplayedUsingPageTitle("Crush Rich | Camel");

				//****************************************************************************
				//Hump Page
				//****************************************************************************

				//Click the hump link
				gl.clickLink(Camel_Common.lnkTheHump, "Hump Link");

				//Verify hump page is displayed
				gl.VerifyPageDisplayed(Camel_Hump.weImgSeasonLogo, "Hump");

				//****************************************************************************
				//Arteffect Page
				//****************************************************************************

				//Click the Arteffect link
				gl.clickLink(Camel_Common.lnkTheArtAffect, "Arteffect Link");

				//Verify arteffect page
				gl.VerifyPageDisplayedUsingPageTitle("artAffect | Camel");

				//****************************************************************************
				//Product Page
				//****************************************************************************

				//Click the Products link
				gl.clickLink(Camel_Common.lnkProducts, "Products Link");

				//Verify products page
				gl.VerifyPageDisplayed(Camel_ProductPages.weProductsPage, "Products");

				//****************************************************************************
				//Offer Page
				//****************************************************************************

				//Click the offers link
				gl.clickLink(Camel_Common.lnkCoupons, "Offers Link");

				//Verify Offers Page
				gl.VerifyPageDisplayed(Camel_Offers.weOffersPage, "Offers");

				//****************************************************************************
				//Profile Page
				//****************************************************************************

				//Click the profile link
				gl.clickLink(Camel_Common.lnkProfile, "Profile Link");

				//Verify Profile page is displayed
				gl.VerifyPageDisplayed(Camel_Profile.weAddressField, "Profile");

				//Click the browser back
				gl.browserBack();

				//Verify navigation link is displayed
				gl.VerifyLinkExistence(Camel_Home.lnkNavigation, "Navigation");

				//****************************************************************************
				//Logout
				//****************************************************************************

				//Click the logout link
				gl.clickLink(Camel_Common.lnkLogout, "Logout Link");

				//Manage Alert Window
				/*L	if (browserName.equalsIgnoreCase("Firefox"))
				{
					gl.confirmAlert("rjrws\\fzrf7v", "1@reynolds");
				}*/
				//Verify Login page is displayed
				gl.VerifyPageDisplayed(Camel_Login.txtUsername, "Login");
		//****************************************************************************
	}
	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	//  @Test
	//Test Case :  Camel_Redesign_Login_001 
	//Objectives: This test Verifies the text fields, check boxes, buttons and links present on login page.

	//Validates below aspects on login page:
	//- "USERNAME" text field 
	//- "PASSWORD" text field 
	//- "Remember Me" check box

	//- "Login" button
	//- "REGISTER" link
	//- Forgot "USER ID" or "Password" Links
	//Author : Vikram T Date: 17.10.2018

	public void Camel_Redesign_Login_001 (String UN,String pwd,String url,String browserName) throws Exception{




		//****************************************************************************************************************
		//Launch application
		gl.launchApplication(browserName, url);
		Thread.sleep(5000);

		//Camel Login page is displayed.
		//gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");

		//Click on "Log In" button without entering Username and Password

		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");

		//Verify the below Error message"Please Provide a Username. and Please enter your Password." should be displayed
		gl.VerifyElementVisible(Camel_Login.weUsername, "Please Provide a Username.");
		gl.VerifyElementVisible(Camel_Login.wePassword, "Please enter your Password.");

		//Enter invalid email id and leave the password field blank and then click on Login button
		gl.inputText(Camel_Login.txtUsername,"txtUsername", "Invalid Email ID") ;

		gl.clickUsingJs(Camel_Login.lnkLogin,"lnkLogin");

		//Verify the below Error message"Please enter your Password." should be displayed
		gl.VerifyElementVisible(Camel_Login.wePassword, "Please enter your Password.");

		//Empty the edit fields
		gl.refresh();

		//Enter invalid password and leave the email id field blank,and then click on Login button
		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", "Invalid Password") ;

		gl.clickUsingJs(Camel_Login.lnkLogin,"lnkLogin");

		//Verify the below Error message"Please Provide a Username." should be displayed
		gl.VerifyElementVisible(Camel_Login.weUsername, "Please Provide a Username.");


		//Empty the edit fields
		gl.refresh();

		//Enter valid email id and leave the password field blank and then click on Login button
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;

		gl.clickUsingJs(Camel_Login.lnkLogin,"lnkLogin");

		//Verify the below Error message"Please enter your Password." should be displayed
		gl.VerifyElementVisible(Camel_Login.wePassword, "Please enter your Password.");
		//Empty the edit fields
		gl.refresh();


		//Enter Valid password and leave the email id field blank,and then click on Login button
		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword",pwd) ;

		gl.clickUsingJs(Camel_Login.lnkLogin,"lnkLogin");

		//Verify the below Error message"Please Provide a Username." should be displayed
		gl.VerifyElementVisible(Camel_Login.weUsername, "Please Provide a Username.");

		//Click on "Remember Me" check box
		gl.selectCheckbox(Camel_Login.weCheckboxRememberme , "checkboxRememberme ") ;
		//Verify Check box status should be changed to selected state
		gl.VerifyIsCheckboxSelected(Camel_Login.weCheckboxRememberme, "checkboxRememberme ");
		//Unclick on "Remember Me" check box
		gl.unselectCheckbox(Camel_Login.weCheckboxRememberme, "checkboxRememberme ") ;

		//Verify Check box status should be changed to Unselected state
		gl.VerifyIsCheckboxUnSelected(Camel_Login.weCheckboxRememberme, "checkboxRememberme ");
		//Refresh the page to empty all input fields
		gl.refresh();
		//Enter format error username
		gl.inputText(Camel_Login.txtUsername,"txtUsername", "Space   No") ;
		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword",pwd) ;
		//Click on "Login" button
		gl.clickUsingJs(Camel_Login.lnkLogin,"lnkLogin");
		//Verify the format error message is displayed
		gl.VerifyElementVisible(Camel_Login.weUsernameFormatError, "Username must be a combination of 8-30 letters and numbers.");
		
		//Click on "Register" link
		gl.clickbutton(Camel_Login.btnRegister,"btnRegister");
		Thread.sleep(4000);
		//Verify Registration page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("Registration","Camel Registration");
		//Click Browser back button
		gl.browserBack();
		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Click on "Forgot User ID" link
		gl.clickUsingJs(Camel_Login.lnkForgotUserId, "lnkForgotUserId");
		Thread.sleep(4000);
		//Verify Forgot user ID page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Forgot Your User Name");
		//Click Browser back button
		gl.browserBack();
		Thread.sleep(4000);
		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Click on "Forgot Password" link
		gl.clickUsingJs(Camel_Login.lnkForgotPassword, "lnkForgotPassword");
		Thread.sleep(4000);
		//Verify Forgot Password page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Forgot Your Password");
		//Click Browser back button
		gl.browserBack();
		Thread.sleep(4000);
		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Enter valid credentials and Click on "Log In" button
		//gl.fnLogin(config.getProperty("userName"), config.getProperty("password"));
		//gl.fnLogin(UN, pwd);
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd);
		gl.clickUsingJs(Camel_Login.lnkLogin,"lnkLogin");
		Thread.sleep(11000);
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "HomePage");
		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//****************************************************************************************************************


		gl.closeAllBrowser();


	}	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	//  @Test
	//Test Case :  Camel_Redesign_Login_002
	//Objectives: Verify the functionality for remember me feature present on login page.

	//- "Remember Me" check box
	// "Login" button
	//Pre-Requisites: 
	//User should have the Valid Username and Password
	//Author : Vikram T Date: 24.11.2018
	public void Camel_Redesign_Login_002 (String UN,String pwd,String url,String browserName) throws Exception
	{



		//****************************************************************************************************************
		//Launch application
		gl.launchApplication(browserName,url);
		Thread.sleep(5000);

		//Camel Login page is displayed.
		//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Enter valid credentials and Click on "Log In" button
		//gl.fnLogin(config.getProperty("userName"), config.getProperty("password"));
		//gl.fnLogin(UN, pwd);

		//Enter Valid Username
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter Valid Password
		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd);
		//Click on "Remember Me" check box
		//gl.selectCheckbox(Camel_Login.weCheckboxRememberme , "checkboxRememberme ") ;
		gl.clickbutton(Camel_Login.weCheckboxRememberme , "checkboxRememberme ") ;
		//Verify Check box status should be changed to selected state
		gl.VerifyIsCheckboxSelected(Camel_Login.weCheckboxRememberme, "checkboxRememberme ");

		//Click on Login button
		gl.clickUsingJs(Camel_Login.lnkLogin,"lnkLogin");
		Thread.sleep(11000);
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "HomePage");
		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Verify Check box status should be in selected state
		gl.VerifyIsCheckboxSelected(Camel_Login.weCheckboxRememberme, "checkboxRememberme ");
		//Verify that the user entered user id is pre-populated under user id field.
		gl.getExtractAttributeValue(Camel_Login.txtUsername,UN,"value");

		//Verify that the Password edit field is empty

		gl.getExtractAttributeValue(Camel_Login.txtPassword,"","value");


		gl.launchUrl(url);
		Thread.sleep(5000);


		//Camel Login page is displayed.
		//gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Verify Check box status should be in selected state
		gl.VerifyIsCheckboxSelected(Camel_Login.weCheckboxRememberme, "checkboxRememberme ");
		//Verify that the user entered user id is pre-populated under user id field.
		gl.getExtractAttributeValue(Camel_Login.txtUsername,UN,"value");

		//Verify that the Password edit field is empty
		gl.getExtractAttributeValue(Camel_Login.txtPassword,"","value");


		//Unclick on "Remember Me" check box
		//	gl.unselectCheckbox(Camel_Login.weCheckboxRememberme, "checkboxRememberme ") ;
		gl.clickUsingJs(Camel_Login.weCheckboxRememberme, "checkboxRememberme ") ;

		//Verify Check box status should be changed to Unselected state
		gl.VerifyIsCheckboxUnSelected(Camel_Login.weCheckboxRememberme, "checkboxRememberme ");
		//Enter Valid Username
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter Valid Password
		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd);
		//Click on Login button
		gl.clickUsingJs(Camel_Login.lnkLogin,"lnkLogin");
		Thread.sleep(11000);
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "HomePage");
		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Verify Check box status should be changed to Unselected state
		gl.VerifyIsCheckboxUnSelected(Camel_Login.weCheckboxRememberme, "checkboxRememberme ");
		//Verify that the user id is empty under user id field.
		gl.getExtractAttributeValue(Camel_Login.txtUsername,"","value");

		//Verify that the Password edit field is empty
		gl.getExtractAttributeValue(Camel_Login.txtPassword,"","value");


		gl.launchUrl(url);
		Thread.sleep(5000);

		//Camel Login page is displayed.
		//gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Verify Check box status should be changed to Unselected state
		gl.VerifyIsCheckboxUnSelected(Camel_Login.weCheckboxRememberme, "checkboxRememberme ");
		//Verify that the user id is empty under user id field.
		gl.getExtractAttributeValue(Camel_Login.txtUsername,"","value");
		//Verify that the Password edit field is empty
		gl.getExtractAttributeValue(Camel_Login.txtPassword,"","value");
		//Close all browsers
		gl.closeAllBrowser();
	}
	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Camel_Redesign_FooterLinks_001
	//Objectives: Verify the footer link navigations on Login page.

	//Pre-Requisites: 
	//User should have the Valid Username and Password
	//Author : Vikram T Date: 29.10.2018
	public void Camel_Redesign_FooterLinks_001 (String UN,String pwd,String url,String browserName,String faqtxt,String contactustxt,String sitetxt,String aftxt) throws Exception
	{
		//****************************************************************************************************************
		//Launch application
		gl.launchApplication(browserName,url);
		Thread.sleep(5000);

		//Camel Login page is displayed.
		//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//****************************************************************************************************************
		//Click FAQ link
		gl.clickUsingJs(Camel_FooterLinks.lnkFAQs,"FAQs");
		//Navigate to FAQ tab
		gl.fnSwitchToSucceedingTab();
		Thread.sleep(5000);
		// FAQs page is displayed.
		gl.VerifyPageDisplayedUsingPageTitle("Frequently Asked Questions");
		Thread.sleep(8000);
		//****************************************************************************************************************

		//FAQs Content verification        
		gl.fnContentValidation(faqtxt,By.xpath(".//*[@class='container mainContainer']"));

		//****************************************************************************************************************
		//Click on Site Requirement link On FAQ page.
		gl.clickLink(Camel_FooterLinks.lnkFAQsiterequirements, "hlinkFAQsiterequirements");
		Thread.sleep(4000);
		//Navigate to SiteReq tab
		gl.fnSwitchToSucceedingTab();
		// Site Requirement page is displayed.
		gl.VerifyPageDisplayedUsingPageTitle("Site Requirements");
		Thread.sleep(8000);
		//Close the browser opened.
		gl.fnCloseCurrentTab();
		Thread.sleep(4000);
		gl.fnSwitchToTab(1);
		//FAQs page is displayed.
		gl.VerifyPageDisplayedUsingPageTitle("Frequently Asked Questions");
		Thread.sleep(8000);
		//Click on Privacy Policy hyperlink On FAQ page.
		gl.clickLink(Camel_FooterLinks.linkFAQPP1,"hlinkFAQprivacypolicy[1]");
		Thread.sleep(4000);
		gl.fnSwitchToSucceedingTab();

		Thread.sleep(5000);
		//Privacy Policy is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Privacy Policy and Your California Privacy Rights");
		Thread.sleep(8000);
		//Close the browser opened.
		gl.fnCloseCurrentTab();
		Thread.sleep(4000);
		gl.fnSwitchToTab(1);
		gl.VerifyPageDisplayedUsingPageTitle("Frequently Asked Questions");
		Thread.sleep(8000);
		//Click on Privacy Policy hyperlink2 On FAQ page.
		gl.clickLink(Camel_FooterLinks.linkFAQPP2,"hlinkFAQprivacypolicy[2]");
		Thread.sleep(4000);
		gl.fnSwitchToSucceedingTab();
		Thread.sleep(5000);
		//Privacy Policy is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Privacy Policy and Your California Privacy Rights");
		Thread.sleep(8000);
		//Close the browser opened.
		gl.fnCloseCurrentTab();
		Thread.sleep(4000);
		gl.fnSwitchToTab(1);
		gl.VerifyPageDisplayedUsingPageTitle("Frequently Asked Questions");
		//Close the browser opened.
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel_Login");
		//***************************************************************************************************************
		// Click on ContactUS link on Login Page
		gl.clickUsingJs(Camel_FooterLinks.lnkContactUs, "Camel Login Contact us");
		gl.fnSwitchToSucceedingTab();
		Thread.sleep(8000);
		//ContactUS page is displayed.
		gl.VerifyPageDisplayedUsingPageTitle("Contact us");
		Thread.sleep(8000);
		//Content Validation
		gl.fnContentValidation(contactustxt,By.xpath(".//*[@class='container mainContainer']"));	  
		//         //Close tab
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();
		////***************************************************************************************************************
		//         //Click on TobaccoRights link on Login Page
		gl.clickUsingJs(Camel_FooterLinks.lnkTobaccoRights,"Camel Login Tobacco rights");
		Thread.sleep(4000);
		gl.fnSwitchToSucceedingTab();
		//TobaccoRights page is displayed. 
		gl.VerifyPageDisplayedUsingPageTitle("Own It Voice It - Make Your Voice Heard");
		Thread.sleep(8000);
		//Close tab
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		////************************************************************************************************************               
		////Click on Site Requirement link on Login Page
		gl.clickUsingJs(Camel_FooterLinks.lnkSiteRequirements, "Site Requirements");
		Thread.sleep(4000);
		gl.fnSwitchToSucceedingTab();
		Thread.sleep(8000);
		//         //Site Requirement page is displayed.
		gl.VerifyPageDisplayedUsingPageTitle("Site Requirements");
		Thread.sleep(8000);
		////Site Requirement content validation.
		//Content Validation
	//	gl.fnContentValidation(By.xpath(".//*[@class='container mainContainer']"),sitetxt);
		//Click site requirement link
		gl.clickLink(Camel_FooterLinks.linkSRPP, "Site Requirement");
		gl.fnSwitchToSucceedingTab();
		Thread.sleep(5000);
		//// Privacy Policy displayed.
		gl.VerifyPageDisplayedUsingPageTitle("Privacy Policy and Your California Privacy Rights");
		gl.fnCloseCurrentTab();
		gl.fnSwitchToTab(1);
		//Site Requirement page is displayed.
		gl.VerifyPageDisplayedUsingPageTitle("Site Requirements");
		Thread.sleep(5000);
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		////************************************************************************************************************
		////Click on Age Filtering link on Login Page
		gl.clickUsingJs(Camel_FooterLinks.lnkAgeFiltering, "AgeFiltering");
		gl.fnSwitchToSucceedingTab();
		Thread.sleep(5000);
		//           //AgeFiltering page is displayed.
		gl.VerifyPageDisplayedUsingPageTitle("Age Filtering Software:");
		Thread.sleep(5000);
		//Content verification
		gl.fnContentValidation(aftxt,By.xpath(".//*[@class='container mainContainer']"));
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();
		//AgeFiltering content validation
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel_Login");
		//         //***********************************************************************************************************
		//                        //Click on TermsofUse link on Login Page
		gl.clickUsingJs(Camel_FooterLinks.lnkTermsofUse, "Terms of Use");
		gl.fnSwitchToSucceedingTab();
		Thread.sleep(5000);
		//Terms of Use page is displayed.
		gl.VerifyPageDisplayedUsingPageTitle("Terms of use");
		Thread.sleep(5000);
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();
		//           //Terms of Use content validation
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel_Login");
		////***************************************************************************************** 
		//                        //Click on Privacy Policy link on Login Page.
		gl.clickUsingJs(Camel_FooterLinks.lnkPrivacyPolicyandYourCaliforniaPrivacyRights, "Privacy Policy and Your California Privacy Rights");
		gl.fnSwitchToSucceedingTab();
		Thread.sleep(5000);
		//PrivacyPage is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Privacy Policy and Your California Privacy Rights");
		Thread.sleep(5000);
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();
		//Verify Login page is displayed
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel_Login");

		gl.closeAllBrowser();

	}

	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Camel_PrivacyPolicy_001
	//Objectives: Verify updated content of Privacy Policy page on pre login to website/app and also verify navigation functionality on Privacy Policy page such as 

	//    1.Sidebar navigation for Policy Sub-headers
	//    2.Back to Top� link that navigates user to top of web page

	//Pre-Requisites: 
	//User should have the Valid Username and Password
	//Author : Vikram T Date: 31.10.2018
	//********************************************************************************************************************


	public void  Camel_PrivacyPolicy_001(String UN,String PW, String url, String browserName, String txtrestrict,String txtwhyweCollect,
			String txtwhatweCollect,String txtShareInfo, String txtWeProtect, String txtCanControl, 
			String txtThirdParty,String txtChangesToPP, String txtNoticeToCalifornia)throws Exception
	{
		// Launch Application
		gl.launchApplication(browserName, url);
		Thread.sleep(2000);

		//*********************************************************************************************************************      
		//Camel Login page is displayed.
		//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//*********************************************************************************************************************          
		//                        //Click on Privacy Policy link on Login Page.
		gl.clickUsingJs(Camel_FooterLinks.lnkPrivacyPolicyandYourCaliforniaPrivacyRights, "Privacy Policy and Your California Privacy Rights");
		gl.fnSwitchToSucceedingTab();
		Thread.sleep(5000);
		//PrivacyPage is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Privacy Policy and Your California Privacy Rights");
		Thread.sleep(5000);
		//Verify Sidebar navigation for Policy Sub-headers
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weSidebar);
		Thread.sleep(1000);
		//*********************************************************************************************************************      
		//Click "Restrictions on Access & Use " link 
		gl.clickLink(Camel_PrivacyPolicy.lnkrestrict,"Restrictions on Access");

		//Verify "Restrictions on Access & Use"  content text is displayed
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weRestrict);

		//Validate Restrictions on Access and Use text content
		gl.fnContentValidation( txtrestrict,Camel_PrivacyPolicy.weRestrict);
		//*********************************************************************************************************************            
		//Click "Why We Collect " link 
		gl.clickLink(Camel_PrivacyPolicy.lnkwhyweCollect,"WhyWeCollect");

		//Verify "Why We Collect"  content text is displayed
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weWhyWeCollect);

		//Validate Why We Collect and Use text content
		gl.fnContentValidation(txtwhyweCollect,Camel_PrivacyPolicy.weWhyWeCollect);  
		//*********************************************************************************************************************      
		//Click "What We Collect " link 
		gl.clickLink(Camel_PrivacyPolicy.lnkwhatweCollect,"WhatWeCollect");

		//Verify "What We Collect"  content text is displayed
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weWhatWeCollect);

		//Validate What We Collect and Use text content
		gl.fnContentValidation(txtwhatweCollect,Camel_PrivacyPolicy.weWhatWeCollect); 


		//Click "Here " link from Flash cookies content
		gl.clickLink(Camel_PrivacyPolicy.lnkherewwc,"WhatWeCollect-LnkHere");
		Thread.sleep(4000);

		//Switch Tab
		gl.fnSwitchToSucceedingTab();

		gl.VerifyPageDisplayedUsingPageTitle("Manage local shared objects in Flash Player");
		Thread.sleep(3000);
		//Close current tab
		gl.fnCloseCurrentTab();
		Thread.sleep(4000);
		//switch to currrent tab
		gl.fnSwitchToTab(1);

		//*********************************************************************************************************************      
		//Click "Who We May Share Information With" link 
		gl.clickLink(Camel_PrivacyPolicy.lnkShareInfo,"Who We May Share Information With-Link");

		//Verify "Who We May Share Information With"  content text is displayed
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weShareInfo);

		//Validate Who We May Share Information With text content
		gl.fnContentValidation( txtShareInfo,Camel_PrivacyPolicy.weShareInfo);
		//*********************************************************************************************************************            
		//Click "How We Protect Your Privacy" link 
		gl.clickLink(Camel_PrivacyPolicy.lnkWeProtect,"How We Protect Your Privacy-Link");

		//Verify "How We Protect Your Privacy"  content text is displayed
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weWeProtect);

		//Validate How We Protect Your Privacy and Use text content
		gl.fnContentValidation(txtWeProtect,Camel_PrivacyPolicy.weWeProtect);     
		//*********************************************************************************************************************      
		//Click "How You Can Control Your Privacy" link 
		gl.clickLink(Camel_PrivacyPolicy.lnkCanControl,"How You Can Control Your Privacy-Link");

		//Verify "How You Can Control Your Privacy"  content text is displayed
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weCanControl);

		//Validate How You Can Control Your Privacy text content
		gl.fnContentValidation( txtCanControl,Camel_PrivacyPolicy.weCanControl); 

		//Click "http://www.ftc.gov/bcp/edu/microsites/idtheft/" link 
		gl.clickLink(Camel_PrivacyPolicy.lnkCanControlPP, "How You Can Control Your Privacy-link");
		Thread.sleep(10000);
		//Switch to new tab
		gl.fnSwitchToSucceedingTab();

		//Verify "FTC ConsumerInformation" Page
		gl.VerifyPageDisplayedUsingPageTitle("Identity Theft | Consumer Information");


		//Close current tab
		gl.fnCloseCurrentTab();
		Thread.sleep(4000);
		//Switch to native tab
		gl.fnSwitchToTab(1);


		//*********************************************************************************************************************
		//Click "Notice to California Residents � Your California Privacy Rights" link 
		gl.clickLink(Camel_PrivacyPolicy.lnkNoticeToCalifornia,"Notice to California Residents � Your California Privacy Rights-Link");

		//Verify "Notice to California Residents � Your California Privacy Rights"  content text is displayed
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weNoticeToCalifornia);

		//Validate Notice to California Residents � Your California Privacy Rights text content
		gl.fnContentValidation(txtNoticeToCalifornia,Camel_PrivacyPolicy.weNoticeToCalifornia);
		//*********************************************************************************************************************            
		//Click "Links to Third-Party Websites" link 
		gl.clickLink(Camel_PrivacyPolicy.lnkThirdParty,"Links to Third-Party Websites-Link");

		//Verify "Links to Third-Party Websites"  content text is displayed
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weThirdParty);

		//Validate Links to Third-Party Websites text content
		gl.fnContentValidation(txtThirdParty,Camel_PrivacyPolicy.weThirdParty);     
		//*********************************************************************************************************************      
		//Click "Changes To This Privacy Policy" link 
		gl.clickLink(Camel_PrivacyPolicy.lnkChangesToPP,"Changes To This Privacy Policy-Link");

		//Verify "Changes To This Privacy Policy"  content text is displayed
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weChangesToPP);

		//Validate Changes To This Privacy Policy text content
		gl.fnContentValidation(txtChangesToPP,Camel_PrivacyPolicy.weChangesToPP); 

		//Click on "Back To Top" link
		gl.clickLink(Camel_PrivacyPolicy.lnkBackToTop, "Back to Top");

		//Verify "Appropriate Privacy Policy content is displayed properly
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weSidebar);
		//*********************************************************************************************************************
		//close current tab
		gl.fnCloseCurrentTab();

		//Switch to native tab
		gl.fnSwitchToDefaultTab();

		//Verify Login page is displayed
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		Thread.sleep(2000);
		//*********************************************************************************************************************
		//Click the Forgot User Id link from Login page
		gl.clickLink(Camel_Login.lnkForgotUserId, "Forget UserId");
		Thread.sleep(3000);

		//Verify Forget User Id Page is displayed.
		gl.VerifyPageDisplayedUsingPageTitle("Forgot Your User Name");

		//Scroll the page
		gl.fnScrollToView(Camel_PrivacyPolicy.weScrollFUpg);
		Thread.sleep(5000);
		//Click on  <<<Privacy Policy Link>>> 
		gl.clickLink(Camel_FooterLinks.lnkPrivacyPolicyandYourCaliforniaPrivacyRights, "Privacypolicy-Forget UserId");
		Thread.sleep(5000);

		//Switch to current tab
		gl.fnSwitchToSucceedingTab();

		//Verify "Privacy Policy" Page is displayed successfully
		gl.VerifyPageDisplayedUsingPageTitle("Privacy Policy and Your California Privacy Rights");
		Thread.sleep(2000);
		//close current tab
		gl.fnCloseCurrentTab();

		//Switch to Default tab
		gl.fnSwitchToDefaultTab();

		//Browser back
		gl.browserBack();
		Thread.sleep(2000);

		//Verify Login page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Camel.com � Camel Cigarettes Official Website");

		//*********************************************************************************************************************
		//Click the Forgot Password link from Login page
		gl.clickLink(Camel_Login.lnkForgotPassword, "Forget Password");
		Thread.sleep(3000);

		//Verify Forget password Page is displayed.
		gl.VerifyPageDisplayedUsingPageTitle("Forgot Your Password");

		//Scroll the page
		gl.fnScrollToView(Camel_PrivacyPolicy.weScrollFPpg);
		Thread.sleep(5000);
		//Click on  <<<Privacy Policy Link>>> 
		gl.clickLink(Camel_FooterLinks.lnkPrivacyPolicyandYourCaliforniaPrivacyRights, "Privacypolicy-Forget UserId");
		Thread.sleep(5000);


		//Switch to current tab
		gl.fnSwitchToSucceedingTab();

		//PrivacyPage is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Privacy Policy and Your California Privacy Rights");
		Thread.sleep(5000);
		//close current tab
		gl.fnCloseCurrentTab();
		Thread.sleep(4000);
		//Switch to Default tab
		gl.fnSwitchToDefaultTab();

		//Browser back
		gl.browserBack();
		Thread.sleep(2000);

		//Verify Login page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Camel.com � Camel Cigarettes Official Website");

		//**********************************************************************************************  
		//Click on <Register> button from Login Page
		gl.clickLink(Camel_Login.btnRegister, "Registration");
		Thread.sleep(3000);

		//Verify Register Page is displayed.
		gl.VerifyPageDisplayedUsingPageTitle("Registration");

		//Scroll fn
		gl.fnScrollToView(Camel_PrivacyPolicy.weScrollReg);
		Thread.sleep(5000);

		//Click on  <<<Privacy Policy Link>>> 
		gl.clickLink(Camel_FooterLinks.lnkPrivacyPolicyandYourCaliforniaPrivacyRights, "Privacypolicy-Forget UserId");
		Thread.sleep(5000);

		//Switch to current tab
		gl.fnSwitchToSucceedingTab();

		//Verify "Register" Page is displayed successfully
		gl.VerifyPageDisplayedUsingPageTitle("Privacy Policy and Your California Privacy Rights");
		Thread.sleep(2000);
		//close current tab
		gl.fnCloseCurrentTab();

		//Switch to Default tab
		gl.fnSwitchToDefaultTab();

		//Browser back
		gl.browserBack();
		Thread.sleep(2000);

		//Verify Login page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Camel.com � Camel Cigarettes Official Website");


		//Close all browser
		gl.closeAllBrowser();
	}
	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  CommonRegistration_GetPassword_005
	//Objectives:   To verify the following functionality for Get Password on login page with Challenge Question set for the user.
	//1. Error message is displayed after proving wrong answer to challenge question three times


	//Prerequisite:
	//1. Challenge question is set for the user.
	//2. All the information used while registering the user is available: answer of challenge question.
	//3.Tester should have access to the email address to validate the email sent by the system.

	//Author : Vikram T Date: 08.11.2018
	public void  CommonRegistartion_GetPassword_005(String UN,String pwd,String url, String browserName,String forgotPasswordContent,String userNotFoundContent )throws Exception
	{

		// Launch Application
		gl.launchApplication(browserName, url);
		Thread.sleep(2000);

		//*********************************************************************************************************************      
		//Camel Login page is displayed.
		//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//*********************************************************************************************************************       
		//Click on "Forgot Password" link
		gl.clickLink(Camel_Login.lnkForgotPassword, "lnkForgotPassword");
		//Verify Forgot Password page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Forgot Your Password");
		//Verify the content of the page

		gl.fnContentValidation(forgotPasswordContent,Camel_Profile.weForgotPasswordContent); 
		//Enter User ID
		gl.inputText(Camel_Profile.txtUserID, "User ID",UN);
		//Click continue
		gl.clickLink(Camel_Profile.btnContinue, "Continue Button");
		//Verify Verify your identity page is displayed

		//Commented beacause of change in the GC process
		/*	gl.VerifyPageDisplayedUsingPageTitle("Verify Your Identity");
		//Enter wrong answer
		gl.inputText(Camel_Profile.txtChallengeAnswer1, "wrong challenge answer","wrong");
		//Click continue
		gl.clickLink(Camel_Profile.btnContinue1, "Continue Button");
		//Verify error message is displayed
		gl.VerifyElementVisible(Camel_Profile.weMsgError,"Error message");

		//Click continue
		gl.clickLink(Camel_Profile.btnContinue1, "Continue Button");
		//Verify error message is displayed
		gl.VerifyElementVisible(Camel_Profile.weMsgError,"Error message");

		//Click continue
		gl.clickLink(Camel_Profile.btnContinue1, "Continue Button");
		//Verify that User Not found page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("User Not Found");
		//Verify the content of the page
		gl.fnContentValidation(Camel_Registration.weUserNotFoundContent,userNotFoundContent); 
		//Click the go to registration button
		gl.clickLink(Camel_Registration.btnGoToRegistration,"Go to Registration button");
		//Verify Registration page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Registration");*/
	}
	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Camel_Redesign_TermsOfUse_001
	//Objectives: Verify the Terms of Use page pre login.

	//Pre-Requisites: 
	//User should have the Valid Username and Password
	//Author : Vikram T Date: 24.11.2018
	public void Camel_Redesign_TermsOfUse_001 (String UN,String pwd,String url,String browserName,String txtTermsAndConditions,String txtRestriction,String txtYourAccount,String txtYourStuff,String txtYourConduct,String txtContentOnSite,String txtOurPrivacyPolicy,String txtIntellectualPropertyIssues,String txtSiteAvailability,String txtChoiceOfLaw,String txtDisclaimer,String txtIndemnity,String txtResolvingDisputes,String txtSpecialNotice,String txtElectronicSignature,String txtMiscellaneous) throws Exception
	{
		//****************************************************************************************************************
		//Launch application
		gl.launchApplication(browserName,url);
		Thread.sleep(5000);

		//Camel Login page is displayed.
		//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Click on Terms of Use
		gl.clickUsingJs(Camel_FooterLinks.lnkTermsofUse, "Terms of Use link");
		//switch to terms of use 
		//gl.fnSwitchTonewwindow();
		//switch to previous tab
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();
		Thread.sleep(4000);
		//Verify that Terms of use page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Terms of use");
		//verify the Terms and conditions content
		gl.fnContentValidation( txtTermsAndConditions,Camel_TermsOfUse.weTxtTermsAndConditions); 


		//Click on Restriction link
		gl.clickLink(Camel_TermsOfUse.lnkRestriction,"Restriction on access and use link");
		//verify the Restriction content
		gl.fnContentValidation( txtRestriction,Camel_TermsOfUse.weTxtRestriction); 


		//Click on your account link
		gl.clickLink(Camel_TermsOfUse.lnkYourAccount,"Your account link");
		//verify the your account content
		gl.fnContentValidation( txtYourAccount,Camel_TermsOfUse.weTxtYourAccount); 



		//Click on your stuff link
		gl.clickLink(Camel_TermsOfUse.lnkYourStuff,"Your stuff link");
		//verify the your stuff content
		gl.fnContentValidation( txtYourStuff,Camel_TermsOfUse.weTxtYourStuff); 


		//Click on your conduct link
		gl.clickLink(Camel_TermsOfUse.lnkYourConduct,"Your conduct link");
		//verify the your conduct content
		gl.fnContentValidation( txtYourConduct,Camel_TermsOfUse.weTxtYourConduct); 


		//Click on Content on site link
		gl.clickLink(Camel_TermsOfUse.lnkContentOnSite,"Content on site link");
		//verify the Content on site content
		gl.fnContentValidation( txtContentOnSite,Camel_TermsOfUse.weTxtContentOnSite); 



		//Click on Our privacy policy link
		gl.clickLink(Camel_TermsOfUse.lnkOurPrivacyPolicy,"Our privacy policy link");
		//verify the Our privacy policy content
		gl.fnContentValidation( txtOurPrivacyPolicy,Camel_TermsOfUse.weTxtOurPrivacyPolicy); 
		Thread.sleep(4000);
		//Click on privacy policy link
		gl.clickLink(Camel_TermsOfUse.lnkPrivacyPolicy," privacy policy link");
		//Navigate to new tab
		gl.fnSwitchToSucceedingTab();
		//verify page displayed
		gl.VerifyPageDisplayedUsingPageTitle("Privacy Policy and Your California Privacy Rights");
		Thread.sleep(6000);
		//switch to previous tab
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();


		//Click on Intellectual property issues link
		gl.clickLink(Camel_TermsOfUse.lnkIntellectualPropertyIssues,"Intellectual property issues link");
		//verify the intellectual property issue's content
		gl.fnContentValidation( txtIntellectualPropertyIssues,Camel_TermsOfUse.weTxtIntellectualPropertyIssues); 


		//Click on Site availabitlity link
		gl.clickLink(Camel_TermsOfUse.lnkSiteAvailability,"Site availability link");
		//verify the site availability content
		gl.fnContentValidation( txtSiteAvailability,Camel_TermsOfUse.weTxtSiteAvailability); 


		//Click on Choice of law link
		gl.clickLink(Camel_TermsOfUse.lnkChoiceOfLaw,"Choice of  link");
		//verify the Choice of law content
		gl.fnContentValidation( txtChoiceOfLaw,Camel_TermsOfUse.weTxtChoiceOfLaw); 


		//Click on Disclaimer link
		gl.clickLink(Camel_TermsOfUse.lnkDisclaimer,"Disclaimer link");
		//verify the Disclaimer content
		gl.fnContentValidation( txtDisclaimer,Camel_TermsOfUse.weTxtDisclaimer); 


		//Click on Indemnity link
		gl.clickLink(Camel_TermsOfUse.lnkIndemnity,"Indemnity link");
		//verify the Indemnity content
		gl.fnContentValidation( txtIndemnity,Camel_TermsOfUse.weTxtIndemnity); 


		//Click on Resolving disputes link
		gl.clickLink(Camel_TermsOfUse.lnkResolvingDisputes,"Resolving disputes link");
		//verify the Resolving content
		gl.fnContentValidation( txtResolvingDisputes,Camel_TermsOfUse.weTxtResolvingDisputes); 
		Thread.sleep(4000);
		//Click on contact us link
		gl.clickLink(Camel_TermsOfUse.lnkContactUs,"Contact us link");
		//switch to contact us
		gl.fnSwitchToSucceedingTab();
		//verify page displayed
		gl.VerifyPageDisplayedUsingPageTitle("Contact us");
		Thread.sleep(4000);
		//back to previous tab
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();
		//Click on here link
		gl.clickLink(Camel_TermsOfUse.lnkHere,"here link");



		//Click on Special Notice link
		gl.clickLink(Camel_TermsOfUse.lnkSpecialNotice," Special notice link");
		//verify the special notice content
		gl.fnContentValidation( txtSpecialNotice,Camel_TermsOfUse.weTxtSpecialNotice); 


		//Click on Electronic signature link
		gl.clickLink(Camel_TermsOfUse.lnkElectronicSignature,"Electronic signature link");
		//verify the electronic signature content
		gl.fnContentValidation( txtElectronicSignature,Camel_TermsOfUse.weTxtElectronicSignature); 


		//Click on Miscellaneous link
		gl.clickLink(Camel_TermsOfUse.lnkMiscellaneous,"Miscellaneous link");
		//verify the miscellaneous content
		gl.fnContentValidation( txtMiscellaneous,Camel_TermsOfUse.weTxtMiscellaneous);

	}
	//****************************************************************************************************************


	public void afterMethod() {
		//extent.flush();
		driver.quit();
		gl.endReport();
	}
}
