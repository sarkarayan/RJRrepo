package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.brandWebsitePageObjects;

public class BrandWebsite_VUSEPrePostLoginFooterLinksValidation extends BaseClass {

	String testcaseName;
	public BrandWebsite_VUSEPrePostLoginFooterLinksValidation(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(brandWebsitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("FooterLinks Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	public void invokeApplication_brandwebsite()
	{
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
		
	public void loginPage_AppToVUSEWebsiteLogin() throws InterruptedException, IOException
	{
		
		String Username = dataTable.getData("General_Data", "Username");
		String Password = dataTable.getData("General_Data", "Password");
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.loginLnk_VUSECertifyAgePage), brandWebsitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		
		//commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.header_VUSELogin), brandWebsitePageObjects.header_VUSELogin.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginUsername),Username,brandWebsitePageObjects.txt_VUSELoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginPassword),Password, brandWebsitePageObjects.txt_VUSELoginPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_VUSELogin), brandWebsitePageObjects.btn_VUSELogin.getObjectname());
		Thread.sleep(5000);
	}
	
	
	public void homePage_VUSEPostLoginFooterLinksValidation() throws Exception
	{
		
		//PostLogin - StoreLocator footerlink
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_StoreLocator));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_StoreLocator),brandWebsitePageObjects.PostLoginVUSEfooterlnk_StoreLocator.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginStoreLocatorTitle = driver.getTitle();
		String ExpectedPostLoginStoreLocatorTitle = "Retail Locator";
		if(ActualPostLoginStoreLocatorTitle.contains(ExpectedPostLoginStoreLocatorTitle))
		{
			System.out.println("PostLogin - StoreLocator footerlink page displayed");
		}
		else
		{
		    System.out.println("PostLogin - StoreLocator footerlink page was not displayed");
		}
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
	
		
		//PostLogin - ContactUs footer link
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_ContactUs));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_ContactUs),brandWebsitePageObjects.PostLoginVUSEfooterlnk_ContactUs.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginContactUsTitle = driver.getTitle();
		String ExpectedPostLoginContactUsTitle = "Contact us";
		if(ActualPostLoginContactUsTitle.contains(ExpectedPostLoginContactUsTitle))
		{
		    System.out.println("PostLogin - ContactUs footerlink page displayed");
		}
		else
		{
			System.out.println("PostLogin - ContactUs footerlink page was not displayed");
		}
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		
		
		//PostLogin - FAQs footerlink
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_FAQs));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_FAQs),brandWebsitePageObjects.PostLoginVUSEfooterlnk_FAQs.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginFAQsTitle = driver.getTitle();
		String ExpectedPostLoginFAQsTitle = "FAQs";
		if(ActualPostLoginFAQsTitle.contains(ExpectedPostLoginFAQsTitle))
		{
			System.out.println("PostLogin - FAQs footerlink page displayed");
		}
		else
		{
		    System.out.println("PostLogin - FAQs footerlink page was not displayed");
		}
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		
		
		//PostLogin - Patents footer link
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_Patents));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_Patents),brandWebsitePageObjects.PostLoginVUSEfooterlnk_Patents.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginPatentsTitle = driver.getTitle();
		String ExpectedPostLoginPatentsTitle = "VUSE Patents";
		if(ActualPostLoginPatentsTitle.contains(ExpectedPostLoginPatentsTitle))
		{
		     System.out.println("PostLogin - Patents footerlink page displayed");
		}
		else
		{
			System.out.println("PostLogin - Patents footerlink page was not displayed");
		}
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		
		
		//PostLogin - TobaccoRights
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_TobaccoRights));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_TobaccoRights),brandWebsitePageObjects.PostLoginVUSEfooterlnk_TobaccoRights.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginTobaccoRightsTitle = driver.getTitle();
		String ExpectedPostLoginTobaccoRightsTitle = "Own It Voice It";
		if(ActualPostLoginTobaccoRightsTitle.contains(ExpectedPostLoginTobaccoRightsTitle))
		{
			System.out.println("PostLogin - TobaccoRights footerlink page displayed");
		}
		else
		{
		    System.out.println("PostLogin - TobaccoRights footerlink page was not displayed");
		}
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		
		
		//PostLogin - AgeFiltering
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_AgeFiltering));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_AgeFiltering),brandWebsitePageObjects.PostLoginVUSEfooterlnk_AgeFiltering.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginAgeFilteringTitle = driver.getTitle();
		String ExpectedPostLoginAgeFilteringTitle = "Age Filtering Software:";
		if(ActualPostLoginAgeFilteringTitle.contains(ExpectedPostLoginAgeFilteringTitle))
		{
			System.out.println("PostLogin - AgeFiltering footerlink page displayed");
		}
		else
		{
		    System.out.println("PostLogin - AgeFiltering footerlink page was not displayed");
		}
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		
		
		//PostLogin - SiteMap
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_SiteMap));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_SiteMap),brandWebsitePageObjects.PostLoginVUSEfooterlnk_SiteMap.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginSiteMapTitle = driver.getTitle();
		String ExpectedPostLoginSiteMapTitle = "SiteMap";
		if(ActualPostLoginSiteMapTitle.contains(ExpectedPostLoginSiteMapTitle))
		{
		    System.out.println("PostLogin - SiteMap footerlink page displayed");
		}
		else
	    {
		    System.out.println("PostLogin - SiteMap footerlink page was not displayed");
		}
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
					
		
		//PostLogin - TermsOfUse
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_TermsOfUse));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_TermsOfUse),brandWebsitePageObjects.PostLoginVUSEfooterlnk_TermsOfUse.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginTermsOfUseTitle = driver.getTitle();
		String ExpectedPostLoginTermsOfUseTitle = "Terms of use";
		if(ActualPostLoginTermsOfUseTitle.contains(ExpectedPostLoginTermsOfUseTitle))
		{
			System.out.println("PostLogin - TermsOfUse footerlink page displayed");
		}
		else
		{
		    System.out.println("PostLogin - TermsOfUse footerlink page was not displayed");
		}
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions), brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions_backtoTop), brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff), brandWebsitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff_backtoTop), brandWebsitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_ChoiceOfLaw), brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_ChoiceOfLaw.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.Preloginfooterlnk_TermsOfUse_ChoiceOfLaw_backtoTop), brandWebsitePageObjects.Preloginfooterlnk_TermsOfUse_ChoiceOfLaw_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes), brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes_backtoTop), brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous), brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous_backtoTop), brandWebsitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous_backtoTop.getObjectname());
		
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		
		
		//PostLogin - TermsOfSale
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_TermsOfSale));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_TermsOfSale),brandWebsitePageObjects.PostLoginVUSEfooterlnk_TermsOfSale.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginTermsOfSaleTitle = driver.getTitle();
		String ExpectedPostLoginTermsOfSaleTitle = "Terms of Sale";
		if(ActualPostLoginTermsOfSaleTitle.contains(ExpectedPostLoginTermsOfSaleTitle))
		{
			System.out.println("PostLogin - TermsOfSale footerlink page displayed");
		}
		else
		{
		    System.out.println("PostLogin - TermsOfSale footerlink page was not displayed");
		}
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		
		
		//PostLogin - SiteRequirements
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_SiteRequirements));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_SiteRequirements),brandWebsitePageObjects.PostLoginVUSEfooterlnk_SiteRequirements.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginSiteRequirementsTitle = driver.getTitle();
		String ExpectedPostLoginSiteRequirementsTitle = "Site Requirements";
		if(ActualPostLoginSiteRequirementsTitle.contains(ExpectedPostLoginSiteRequirementsTitle))
		{
			System.out.println("PostLogin - SiteRequirements footerlink page displayed");
		}
		else
		{
		    System.out.println("PostLogin - SiteRequirements footerlink page was not displayed");
		}
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
		
		
		//PostLogin - PrivacyPolicy
		commonFunction.scrollIntoView(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy));		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy),brandWebsitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginPrivacyPolicyTitle = driver.getTitle();
		String ExpectedPostLoginPrivacyPolicyTitle = "Privacy Policy";
		if(ActualPostLoginPrivacyPolicyTitle.contains(ExpectedPostLoginPrivacyPolicyTitle))
		{
			System.out.println("PostLogin - PrivacyPolicy footerlink page displayed");
		}
		else
		{
		    System.out.println("PostLogin - PrivacyPolicy footerlink page was not displayed");
		}
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_Whatwecollect), brandWebsitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_Whatwecollect.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_Whatwecollect_backtoTop), brandWebsitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_Whatwecollect_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_LinktoWebsites), brandWebsitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_LinktoWebsites.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_LinktoWebsites_backtoTop), brandWebsitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_LinktoWebsites_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_CaliforniaRights), brandWebsitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_CaliforniaRights.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_CaliforniaRights_backtoTop), brandWebsitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_CaliforniaRights_backtoTop.getObjectname());
		
		commonFunction.closeChildTab();
		commonFunction.SwitchControlToParentTab();
				
	}
	
	public void vuseHomePage_Logout() throws IOException
	{
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSE_MyAccount), brandWebsitePageObjects.PostLoginVUSE_MyAccount.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.PostLoginVUSE_LogOut), brandWebsitePageObjects.PostLoginVUSE_LogOut.getObjectname());
		
	}
		
	
}
