package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.MobileSiteLoginPageObjects;
import com.rai.pageObjects.MobileSiteResetPageObjects;
import com.rai.pageObjects.MobilesitePageObjects;
import com.rai.pageObjects.MobilesitePageObjects;

public class Mobilesite_Registration_LoginResetUandY extends BaseClass {

	String testcaseName;
	public Mobilesite_Registration_LoginResetUandY(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(MobileSiteLoginPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	private WebElement getPageElement(MobileSiteResetPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	private WebElement getPageElement(MobilesitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	public void invokeApplication_brandMobilesite()
	{
		String WebsiteURL = dataTable.getData("General_Data","URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
		
	public void registration_ValidDataonStep1Page() throws InterruptedException, IOException
	{
	    String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
		String Email = dataTable.getData("General_Data", "Email");
		
		String date = dataTable.getData("General_Data","DOB");
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btn_Registration), MobilesitePageObjects.btn_Registration.getObjectname());
		Thread.sleep(5000);
		commonFunction.selectAnyElement(getPageElement(MobileSiteResetPageObjects.drpdwn_BirthMonth), month, MobilesitePageObjects.drpdwn_BirthMonth.getObjectname());
		Thread.sleep(6000);
		commonFunction.selectAnyElement(getPageElement(MobileSiteResetPageObjects.drpdwn_BirthDay),day,MobilesitePageObjects.drpdwn_BirthDay.getObjectname());
		commonFunction.selectAnyElement(getPageElement(MobileSiteResetPageObjects.drpdwn_BirthYear),year,MobilesitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_FirstName), FirstName, MobilesitePageObjects.txt_FirstName.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_LastName),LastName, MobilesitePageObjects.txt_LastName.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_Address),Address, MobilesitePageObjects.txt_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_Zipcode), Zipcode,MobilesitePageObjects.txt_Zipcode.getObjectname());
		Thread.sleep(6000);
				
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_Email),Email,MobilesitePageObjects.txt_Email.getObjectname());	
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.Chkbx_Certify),MobilesitePageObjects.Chkbx_Certify.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_City), City, MobilesitePageObjects.txt_City.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteResetPageObjects.drpdwn_State),State, MobilesitePageObjects.drpdwn_State.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.btn_Step1Next), MobilesitePageObjects.btn_Step1Next.getObjectname());
		
	}
	
	public void resetflow_NegativeValidationsAccountInfoPage() throws IOException, InterruptedException
	{
		
		String InActiveEmail = dataTable.getData("General_Data","NonExistUserId");
		String ExistingEmail = dataTable.getData("General_Data","ExistingUserId");
		String InvalidEmail = dataTable.getData("General_Data","InvalidUserIDformat");
		String Password = dataTable.getData("General_Data","Password");
		String InvalidPasswordformat = dataTable.getData("General_Data","InvalidPasswordformat");
		String DifferentPassword = dataTable.getData("General_Data","InvalidPassword");
		
		
		String Errormsg_NoDataEntered = "Please fix the errors above";
		String Errormsg_NoEmailEntered = "Please enter a valid email address";
		String Errormsg_InvalidEmailEntered = "Please enter a valid email address";
		String Errormsg_InActiveEmailEntered = "This is not an active email address. Please provide an active email address.";
		String Errormsg_ExistingEmailEntered = "Username already taken. Please try a different one.";
		String Errormsg_NoPasswordEntered = "Please provide a password";
		String Errormsg_InvalidPasswordformatEntered = "Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.";
		String Errormsg_DifferentPasswordEntered = "Passwords did not match";
		String Errormsg_NoChallengeQuestion = "Please select a account recovery question";
		String Errormsg_NoChallengeAnswerEntered = "Please provide an answer to account recovery question";
		
		
		//User clicked on Save without any data
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.btn_LoginResetAccntInfoSave), MobilesitePageObjects.btn_LoginResetAccntInfoSave.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoNoDataEntered), MobilesitePageObjects.errormsg_LoginResetAccntInfoNoDataEntered.getObjectname(), Errormsg_NoDataEntered);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAcctInfoNoEmailEntered), MobilesitePageObjects.errormsg_LoginResetAcctInfoNoEmailEntered.getObjectname(), Errormsg_NoEmailEntered);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoNoPassword), MobilesitePageObjects.errormsg_LoginResetAccntInfoNoPassword.getObjectname(), Errormsg_NoPasswordEntered);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoNoChallengeQuestion), MobilesitePageObjects.errormsg_LoginResetAccntInfoNoChallengeQuestion.getObjectname(), Errormsg_NoChallengeQuestion);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoNoChallengeAnswer), MobilesitePageObjects.errormsg_LoginResetAccntInfoNoChallengeAnswer.getObjectname(), Errormsg_NoChallengeAnswerEntered);
		
		//User entered InvalidEmail
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoEmail),InvalidEmail, MobilesitePageObjects.txt_LoginResetAccntInfoEmail.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoInvalidEmail), MobilesitePageObjects.errormsg_LoginResetAccntInfoInvalidEmail.getObjectname(), Errormsg_InvalidEmailEntered);
		
		//User entered InactiveEmail
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoEmail),InActiveEmail, MobilesitePageObjects.txt_LoginResetAccntInfoEmail.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoInactiveEmail), MobilesitePageObjects.errormsg_LoginResetAccntInfoInactiveEmail.getObjectname(), Errormsg_InActiveEmailEntered);
		
		//User entered ExistingEmail
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoEmail),ExistingEmail, MobilesitePageObjects.txt_LoginResetAccntInfoEmail.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoExistingEmail), MobilesitePageObjects.errormsg_LoginResetAccntInfoExistingEmail.getObjectname(), Errormsg_ExistingEmailEntered);
		
		
		//User entered InvalidPassword format
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoPassword),InvalidPasswordformat, MobilesitePageObjects.txt_LoginResetAccntInfoPassword.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoInvalidPasswordFormat), MobilesitePageObjects.errormsg_LoginResetAccntInfoInvalidPasswordFormat.getObjectname(), Errormsg_InvalidPasswordformatEntered);
		
		//User entered Differntdata in password & Confirm password fields
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoPassword),Password, MobilesitePageObjects.txt_LoginResetAccntInfoPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoConfirmPassword),DifferentPassword, MobilesitePageObjects.txt_LoginResetAccntInfoConfirmPassword.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoDifferentPasswordEntered), MobilesitePageObjects.errormsg_LoginResetAccntInfoDifferentPasswordEntered.getObjectname(), Errormsg_DifferentPasswordEntered);
	}
	
		
	public void resetflow_AccountInfoPage() throws Exception
	{
		String Email = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data","Password");
		String ConfirmPassword = dataTable.getData("General_Data","Password");
		String Question = dataTable.getData("General_Data","ChallengeQuestion");
		String Answer = dataTable.getData("General_Data","ChallengeAnswer");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoEmail),Email, MobilesitePageObjects.txt_LoginResetAccntInfoEmail.getObjectname());
		Thread.sleep(5000);
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoPassword),Password,MobilesitePageObjects.txt_LoginResetAccntInfoPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoConfirmPassword),ConfirmPassword,MobilesitePageObjects.txt_LoginResetAccntInfoConfirmPassword.getObjectname());
		
		commonFunction.selectAnyElement(getPageElement(MobileSiteResetPageObjects.drpdnw_LoginResetAccntInfoChallengeQuestion), Question,MobilesitePageObjects.drpdnw_LoginResetAccntInfoChallengeQuestion.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoChallengeAnswer), Answer, MobilesitePageObjects.txt_LoginResetAccntInfoChallengeAnswer.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.btn_LoginResetAccntInfoSave), MobilesitePageObjects.btn_LoginResetAccntInfoSave.getObjectname());
	}
	
	public void resetflow_CongratsPage() throws IOException
	{
		
		String Email = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data", "Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetCongratsPageEmail), Email,MobilesitePageObjects.txt_LoginResetCongratsPageEmail.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetCongratsPagePassword),Password,MobilesitePageObjects.txt_LoginResetCongratsPagePassword.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.btn_LoginResetCongratsPageLogin), MobilesitePageObjects.btn_LoginResetCongratsPageLogin.getObjectname());
	}
	
	
	public void registration_RevelValidDetailsonStep1Page() throws InterruptedException, IOException
	{
		
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String Email = dataTable.getData("General_Data", "Email");
		String PhoneNumber = dataTable.getData("General_Data", "Phone");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
        String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btn_Registration),MobilesitePageObjects.btn_Registration.getObjectname());
		commonFunction.selectAnyElement(getPageElement(MobileSiteResetPageObjects.drpdwn_BirthMonth), month, MobilesitePageObjects.drpdwn_BirthMonth.getObjectname());
		Thread.sleep(6000);
		commonFunction.selectAnyElement(getPageElement(MobileSiteResetPageObjects.drpdwn_BirthDay),day,MobilesitePageObjects.drpdwn_BirthDay.getObjectname());
		//commonFunction.selectAnyElementByValue(getPageElement(MobilesitePageObjects.drpdwn_BirthYear), "1938", MobilesitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.selectAnyElement(getPageElement(MobileSiteResetPageObjects.drpdwn_BirthYear),year,MobilesitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_FirstName), FirstName, MobilesitePageObjects.txt_FirstName.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_LastName),LastName, MobilesitePageObjects.txt_LastName.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_Address),Address, MobilesitePageObjects.txt_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_Zipcode), Zipcode,MobilesitePageObjects.txt_Zipcode.getObjectname());
		Thread.sleep(4000);
					
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_Email),Email, MobilesitePageObjects.txt_Email.getObjectname());
		Thread.sleep(5000);
		commonFunction.clickIfElementPresentJavaScript(getPageElement(MobileSiteResetPageObjects.txt_PhoneRevelVelo),MobilesitePageObjects.txt_PhoneRevelVelo.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_PhoneRevelVelo),PhoneNumber, MobilesitePageObjects.txt_PhoneRevelVelo.getObjectname());
		commonFunction.clickIfElementPresentJavaScript(getPageElement(MobileSiteResetPageObjects.radiobtn_GenderMaleRevel),MobilesitePageObjects.radiobtn_GenderMaleRevel.getObjectname());
		//commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.radiobtn_GenderMaleRevel),MobilesitePageObjects.radiobtn_GenderMaleRevel.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.chkbx_CertifyRevelVelo),MobilesitePageObjects.chkbx_CertifyRevelVelo.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_City), City, MobilesitePageObjects.txt_City.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteResetPageObjects.drpdwn_State),State, MobilesitePageObjects.drpdwn_State.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.btn_Step1Next), MobilesitePageObjects.btn_Step1Next.getObjectname());
		Thread.sleep(4000);
	}
	public void registration_VUSEValidDetailsonStep1Page() throws InterruptedException, IOException
	{
		
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String Email = dataTable.getData("General_Data", "Email");
		String PhoneNumber = dataTable.getData("General_Data", "Phone");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
        String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.header_VUSECreateAccount),MobilesitePageObjects.header_VUSECreateAccount.getObjectname());
		commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.drpdwn_BirthMonth), month, MobilesitePageObjects.drpdwn_BirthMonth.getObjectname());
		Thread.sleep(6000);
		commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.drpdwn_BirthDay),day,MobilesitePageObjects.drpdwn_BirthDay.getObjectname());
		commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.drpdwn_BirthYear),year,MobilesitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.enterText(getPageElement(MobilesitePageObjects.txt_FirstName), FirstName, MobilesitePageObjects.txt_FirstName.getObjectname());
		commonFunction.enterText(getPageElement(MobilesitePageObjects.txt_LastName),LastName, MobilesitePageObjects.txt_LastName.getObjectname());
		commonFunction.enterText(getPageElement(MobilesitePageObjects.txt_Address),Address, MobilesitePageObjects.txt_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_Zipcode), Zipcode,MobilesitePageObjects.txt_Zipcode.getObjectname());
		Thread.sleep(4000);
					
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_Email),Email, MobilesitePageObjects.txt_Email.getObjectname());
		Thread.sleep(5000);
		commonFunction.clickIfElementPresentJavaScript(getPageElement(MobilesitePageObjects.txt_PhoneRevelVelo),MobilesitePageObjects.txt_PhoneRevelVelo.getObjectname());
		commonFunction.enterText(getPageElement(MobilesitePageObjects.txt_PhoneRevelVelo),PhoneNumber, MobilesitePageObjects.txt_PhoneRevelVelo.getObjectname());
		Thread.sleep(3000);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.chkbx_CertifyRevelVelo),MobilesitePageObjects.chkbx_CertifyRevelVelo.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_City), City, MobilesitePageObjects.txt_City.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobilesitePageObjects.drpdwn_State),State, MobilesitePageObjects.drpdwn_State.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Step1Next), MobilesitePageObjects.btn_Step1Next.getObjectname());
		//Thread.sleep(4000);
	}
	
	public void registration_VeloValidDetailsonStep1Page() throws InterruptedException, IOException
	{
		
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String Email = dataTable.getData("General_Data", "Email");
		String PhoneNumber = dataTable.getData("General_Data", "Phone");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
        String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btn_Registration),MobilesitePageObjects.btn_Registration.getObjectname());
		commonFunction.selectAnyElement(getPageElement(MobileSiteResetPageObjects.drpdwn_BirthMonth), month, MobilesitePageObjects.drpdwn_BirthMonth.getObjectname());
		Thread.sleep(6000);
		commonFunction.selectAnyElement(getPageElement(MobileSiteResetPageObjects.drpdwn_BirthDay),day,MobilesitePageObjects.drpdwn_BirthDay.getObjectname());
		commonFunction.selectAnyElement(getPageElement(MobileSiteResetPageObjects.drpdwn_BirthYear),year,MobilesitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_FirstName), FirstName, MobilesitePageObjects.txt_FirstName.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_LastName),LastName, MobilesitePageObjects.txt_LastName.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_Address),Address, MobilesitePageObjects.txt_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_Zipcode), Zipcode,MobilesitePageObjects.txt_Zipcode.getObjectname());
		Thread.sleep(4000);
					
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_Email),Email, MobilesitePageObjects.txt_Email.getObjectname());
		Thread.sleep(5000);
		commonFunction.clickIfElementPresentJavaScript(getPageElement(MobileSiteResetPageObjects.txt_PhoneRevelVelo),MobilesitePageObjects.txt_PhoneRevelVelo.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_PhoneRevelVelo),PhoneNumber, MobilesitePageObjects.txt_PhoneRevelVelo.getObjectname());
		Thread.sleep(3000);
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.chkbx_CertifyRevelVelo),MobilesitePageObjects.chkbx_CertifyRevelVelo.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_City), City, MobilesitePageObjects.txt_City.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteResetPageObjects.drpdwn_State),State, MobilesitePageObjects.drpdwn_State.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.btn_Step1Next), MobilesitePageObjects.btn_Step1Next.getObjectname());
		Thread.sleep(4000);
	}
	

	
	
	
}

