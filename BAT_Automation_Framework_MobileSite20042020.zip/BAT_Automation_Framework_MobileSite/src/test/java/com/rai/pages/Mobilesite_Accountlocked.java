package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.framework.Status;
import com.rai.pageObjects.MobileSiteLoginPageObjects;
import com.rai.pageObjects.MobileSite_Accountlock_validationPageObjects;
import com.rai.pageObjects.MobileSite_MyprofilePageObjects;
import com.rai.pageObjects.MobilesitePageObjects;
import com.rai.pageObjects.MobilesitePageObjects;
import com.rai.pageObjects.MobilesitePageObjects;
import com.rai.pageObjects.MobilesitePageObjects;

public class Mobilesite_Accountlocked extends BaseClass {
	
	String testcaseName;
	public Mobilesite_Accountlocked(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);
	
	private WebElement getPageElement(MobileSite_Accountlock_validationPageObjects postlogincamelfooterlnkLogout) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(postlogincamelfooterlnkLogout.getProperty(), postlogincamelfooterlnkLogout.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + postlogincamelfooterlnkLogout.getObjectname());
			else
				System.out.println("Element Not Found: " + postlogincamelfooterlnkLogout.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Login Page - get page element",
					postlogincamelfooterlnkLogout.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	private WebElement getPageElement(MobilesitePageObjects postlogincamelfooterlnkLogout) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(postlogincamelfooterlnkLogout.getProperty(), postlogincamelfooterlnkLogout.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + postlogincamelfooterlnkLogout.getObjectname());
			else
				System.out.println("Element Not Found: " + postlogincamelfooterlnkLogout.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Login Page - get page element",
					postlogincamelfooterlnkLogout.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	private WebElement getPageElement(MobileSite_MyprofilePageObjects postlogincamelfooterlnkLogout) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(postlogincamelfooterlnkLogout.getProperty(), postlogincamelfooterlnkLogout.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + postlogincamelfooterlnkLogout.getObjectname());
			else
				System.out.println("Element Not Found: " + postlogincamelfooterlnkLogout.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Login Page - get page element",
					postlogincamelfooterlnkLogout.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	
	private WebElement getPageElement(MobileSiteLoginPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Mobile Site Login Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	public void invokeApplication_mobilesite()
	{
	    String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);	
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
	}
	
	
	public void loginPage_fieldValidations() throws IOException, Exception 
	{
          try {
			String NonExistUserId = dataTable.getData("General_Data","NonExistUserId");
			  String ValidPassword = dataTable.getData("General_Data","Password");
			  String InvalidUserIdformat = dataTable.getData("General_Data","InvalidUserIDformat");
			
			//Login without any data
			try {
				commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btnSignInTab),MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
				commonFunction.clickIfElementPresent(getPageElement(MobileSite_Accountlock_validationPageObjects.btn_Login), MobilesitePageObjects.btn_Login.getObjectname());
				Thread.sleep(7000);
				;
				try {
					String Actualerrormsg_LoginwithoutanyData = commonFunction.getTextFromElement(getPageElement(MobileSite_Accountlock_validationPageObjects.errormsg_LoginwithoutanyData));
					String Expectederrormsg_LoginwithoutanyData = "Please Provide a Username / Email Address.";
					commonFunction.compareStrings(Expectederrormsg_LoginwithoutanyData, Actualerrormsg_LoginwithoutanyData);
				} catch (Exception e) {
					
				}
				
			} catch (InterruptedException e) {
				
			}
			
			//Login with Username not exists in DB
			//commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btnSignInTab),MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_LoginUsername),NonExistUserId,MobilesitePageObjects.txt_LoginUsername.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_LoginPassword),ValidPassword, MobilesitePageObjects.txt_LoginPassword.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_Accountlock_validationPageObjects.btn_Login), MobilesitePageObjects.btn_Login.getObjectname());
			Thread.sleep(5000);
			String Actualerrormsg_LoginwithNonExistUserId = commonFunction.getTextFromElement(getPageElement(MobileSite_Accountlock_validationPageObjects.errormsg_LoginwithNonExistingUserId));
			String Expectederrormsg_LoginwithNonExistUserId = "Username Does Not Exist.";
			commonFunction.compareStrings(Expectederrormsg_LoginwithNonExistUserId, Actualerrormsg_LoginwithNonExistUserId);
			
			//Login with UserId(having unaccepted characters)
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_LoginUsername),InvalidUserIdformat,MobilesitePageObjects.txt_LoginUsername.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_LoginPassword),ValidPassword, MobilesitePageObjects.txt_LoginPassword.getObjectname());
			//commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login), MobilesitePageObjects.btn_Login.getObjectname());
			Thread.sleep(3000);
			String Actualerrormsg_LoginwithUserIdwithunacceptedcharacters = commonFunction.getTextFromElement(getPageElement(MobileSite_Accountlock_validationPageObjects.errormsg_Usernamefieldformaterror));
			String Expectederrormsg_LoginwithUserIdwithunacceptedcharacters = "Username must be a combination of 8-30 letters and numbers.";
			commonFunction.compareStrings(Expectederrormsg_LoginwithUserIdwithunacceptedcharacters , Actualerrormsg_LoginwithUserIdwithunacceptedcharacters);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	public void vuse_loginPage_fieldValidations() throws IOException, Exception 
	{
          try {
			String NonExistUserId = dataTable.getData("General_Data","NonExistUserId");
			  String ValidPassword = dataTable.getData("General_Data","Password");
			  String InvalidUserIdformat = dataTable.getData("General_Data","InvalidUserIDformat");
			
			//Login without any data
			try {
				commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.loginLnk_VUSECertifyAgePage), MobilesitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
				Thread.sleep(2000);
				//commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btnSignInTab),MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
				commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_VUSELogin), MobilesitePageObjects.btn_VUSELogin.getObjectname());
				Thread.sleep(7000);
				;
				try {
					String Actualerrormsg_LoginwithoutanyData = commonFunction.getTextFromElement(getPageElement(MobileSite_Accountlock_validationPageObjects.errormsg_LoginwithoutanyData));
					String Expectederrormsg_LoginwithoutanyData = "Please enter your username";
					commonFunction.compareStrings(Expectederrormsg_LoginwithoutanyData, Actualerrormsg_LoginwithoutanyData);
				} catch (Exception e) {
					
				}
				
			} catch (InterruptedException e) {
				
			}
			
			//Login with Username not exists in DB
			//commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btnSignInTab),MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_LoginUsername),NonExistUserId,MobilesitePageObjects.txt_LoginUsername.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_LoginPassword),ValidPassword, MobilesitePageObjects.txt_LoginPassword.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_VUSELogin), MobilesitePageObjects.btn_VUSELogin.getObjectname());
			Thread.sleep(2000);
			commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_VUSELogin), MobilesitePageObjects.btn_VUSELogin.getObjectname());
			Thread.sleep(5000);
			String Actualerrormsg_LoginwithNonExistUserId = commonFunction.getTextFromElement(getPageElement(MobileSite_Accountlock_validationPageObjects.errormsg_LoginwithoutanyData_vuse));
			String Expectederrormsg_LoginwithNonExistUserId = "Username Does Not Exist.";
			commonFunction.compareStrings(Expectederrormsg_LoginwithNonExistUserId, Actualerrormsg_LoginwithNonExistUserId);
			
			//Login with UserId(having unaccepted characters)
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_LoginUsername),InvalidUserIdformat,MobilesitePageObjects.txt_LoginUsername.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_LoginPassword),ValidPassword, MobilesitePageObjects.txt_LoginPassword.getObjectname());
			//commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login), MobilesitePageObjects.btn_Login.getObjectname());
			Thread.sleep(3000);
			String Actualerrormsg_LoginwithUserIdwithunacceptedcharacters = commonFunction.getTextFromElement(getPageElement(MobileSite_Accountlock_validationPageObjects.errormsg_Usernamefieldformaterror));
			String Expectederrormsg_LoginwithUserIdwithunacceptedcharacters = "Username must be a combination of 8-30 letters and numbers.";
			commonFunction.compareStrings(Expectederrormsg_LoginwithUserIdwithunacceptedcharacters , Actualerrormsg_LoginwithUserIdwithunacceptedcharacters);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	public void loginPage_Loginwith128characters() throws IOException, InterruptedException
	{
		String ValidUserId = dataTable.getData("General_Data","Username");
		String ValidPassword = dataTable.getData("General_Data","Password");
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btnSignInTab),MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_LoginUsername),ValidUserId,MobilesitePageObjects.txt_LoginUsername.getObjectname());
        commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_LoginPassword),ValidPassword,MobilesitePageObjects.txt_LoginPassword.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(MobileSite_Accountlock_validationPageObjects.btn_Login), MobilesitePageObjects.btn_Login.getObjectname());
		Thread.sleep(5000);
        //commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginCamelfooterlnk_Logout), MobilesitePageObjects.PostLoginCamelfooterlnk_Logout.getObjectname());

	}
	public void loginPage_VUSELoginwith128characters() throws IOException, InterruptedException
	{
		String ValidUserId = dataTable.getData("General_Data","Username");
		String ValidPassword = dataTable.getData("General_Data","Password");
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.loginLnk_VUSECertifyAgePage), MobilesitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginUsername),ValidUserId,MobilesitePageObjects.txt_VUSELoginUsername.getObjectname());
        commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginPassword),ValidUserId,MobilesitePageObjects.txt_VUSELoginPassword.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_VUSELogin), MobilesitePageObjects.btn_VUSELogin.getObjectname());

	}
	
	
	public void loginPage_ValidateErrormsg_AccountLock() throws IOException, Exception
	{
		String ValidUserId = dataTable.getData("General_Data","Username");
        String InvalidPassword = dataTable.getData("General_Data","InvalidPassword");
        
        //User entered Invalid password for 1st time
        try {
			commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btnSignInTab),MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_LoginUsername),ValidUserId,MobilesitePageObjects.txt_LoginUsername.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_LoginPassword),InvalidPassword,MobilesitePageObjects.txt_LoginPassword.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_Accountlock_validationPageObjects.btn_Login), MobilesitePageObjects.btn_Login.getObjectname());
			//commonFunction.scrollIntoView(getPageElement(MobileSite_Accountlock_validationPageObjects.errormsg_WrongPasswrd));		
			Thread.sleep(6000);
			String Actualerrormsg_invalidPassword1sttime = commonFunction.getTextFromElement(getPageElement(MobileSite_Accountlock_validationPageObjects.errormsg_WrongPasswrd));
			String Expectederrormsg_invalidPassword1sttime = "Username and Password do not match.";
			commonFunction.compareStrings(Expectederrormsg_invalidPassword1sttime , Actualerrormsg_invalidPassword1sttime);
			
			//User entered Invalid password for 2nd time
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_LoginPassword),InvalidPassword,MobilesitePageObjects.txt_LoginPassword.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_Accountlock_validationPageObjects.btn_Login), MobilesitePageObjects.btn_Login.getObjectname());
			Thread.sleep(6000);
			String Actualerrormsg_invalidPassword2ndtime = commonFunction.getTextFromElement(getPageElement(MobileSite_Accountlock_validationPageObjects.errormsg_WrongPasswrd));
			String Expectederrormsg_invalidPassword2ndtime = "Username and Password do not match.";
			commonFunction.compareStrings(Expectederrormsg_invalidPassword2ndtime , Actualerrormsg_invalidPassword2ndtime);
			
			//User entered Invalid password for 3rd time
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_LoginPassword),InvalidPassword,MobilesitePageObjects.txt_LoginPassword.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_Accountlock_validationPageObjects.btn_Login), MobilesitePageObjects.btn_Login.getObjectname());
			Thread.sleep(6000);
			String Actualerrormsg_invalidPassword3rdtime = commonFunction.getTextFromElement(getPageElement(MobileSite_Accountlock_validationPageObjects.errormsg_WrongPasswrd));
			String Expectederrormsg_invalidPassword3rdtime = "Username and Password do not match.";
			
			commonFunction.compareStrings(Expectederrormsg_invalidPassword3rdtime , Actualerrormsg_invalidPassword3rdtime);
			//User entered Invalid password for 4th time
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_LoginPassword),InvalidPassword,MobilesitePageObjects.txt_LoginPassword.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_Accountlock_validationPageObjects.btn_Login), MobilesitePageObjects.btn_Login.getObjectname());
			Thread.sleep(6000);
			String Actualerrormsg_invalidPassword4thtime = commonFunction.getTextFromElement(getPageElement(MobileSite_Accountlock_validationPageObjects.errormsg_WrongPasswrd));
			String Expectederrormsg_invalidPassword4thtime = "Username and Password do not match.";
			commonFunction.compareStrings(Expectederrormsg_invalidPassword4thtime , Actualerrormsg_invalidPassword4thtime);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
                
	}
	
	public void loginPage_ResetLockedAccount() throws InterruptedException, IOException
	{
		String Email = dataTable.getData("General_Data", "Email");
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
		String ChallengeAnswer = dataTable.getData("General_Data", "ChallengeAnswer");
		String Password = dataTable.getData("General_Data", "Password");
		String ConfirmPassword = dataTable.getData("General_Data", "Password");
				
		String date = dataTable.getData("General_Data","DOB");
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_Accountlock_validationPageObjects.lnk_LockedAccntResetlink),MobilesitePageObjects.lnk_LockedAccntResetlink.getObjectname());
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_ForgotPasswordUsername), Email, MobilesitePageObjects.txt_ForgotPasswordUsername.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_Accountlock_validationPageObjects.btn_ForgotPasswordUsernameContinue), MobilesitePageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
		
		commonFunction.selectAnyElement(getPageElement(MobileSite_Accountlock_validationPageObjects.drpdwn_ForgotPasswordBirthMonth), month, MobilesitePageObjects.drpdwn_ForgotPasswordBirthMonth.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSite_Accountlock_validationPageObjects.drpdwn_ForgotPasswordBirthDay), day, MobilesitePageObjects.drpdwn_ForgotPasswordBirthDay.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSite_Accountlock_validationPageObjects.drpdwn_ForgotPasswordBirthYear), year,MobilesitePageObjects.drpdwn_ForgotPasswordBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_ForgotPasswordFirstName), FirstName, MobilesitePageObjects.txt_ForgotPasswordFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_ForgotPasswordLastName), LastName, MobilesitePageObjects.txt_ForgotPasswordLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_ForgotPasswordAddress), Address, MobilesitePageObjects.txt_ForgotPasswordAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_ForgotPasswordZipcode), Zipcode, MobilesitePageObjects.txt_ForgotPasswordZipcode.getObjectname());
		Thread.sleep(2000);
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_ForgotPasswordCity), City, MobilesitePageObjects.txt_ForgotPasswordCity.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSite_Accountlock_validationPageObjects.drpdwn_ForgotPasswordState),State, MobilesitePageObjects.drpdwn_ForgotPasswordState.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_Accountlock_validationPageObjects.btn_ForgotPasswordGeneralInformation), MobilesitePageObjects.btn_ForgotPasswordGeneralInformation.getObjectname());
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_ForgotPasswordChallengeAnswer), ChallengeAnswer, MobilesitePageObjects.txt_ForgotPasswordChallengeAnswer.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_Accountlock_validationPageObjects.btn_ForgotPasswordVerifyIdentity), MobilesitePageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
		//Thread.sleep(4000);
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_ForgotPasswordPassword), Password, MobilesitePageObjects.txt_ForgotPasswordPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_ForgotPasswordConfirmPassword), ConfirmPassword, MobilesitePageObjects.txt_ForgotPasswordConfirmPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_Accountlock_validationPageObjects.btn_ForgotPasswordResetPassword), MobilesitePageObjects.btn_ForgotPasswordResetPassword.getObjectname());
		//Thread.sleep(4000);
		
		commonFunction.clearAndEnterText(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_CongratsPageUsername),Email, MobilesitePageObjects.txt_CongratsPageUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_CongratsPagePassword), Password,MobilesitePageObjects.txt_CongratsPagePassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_Accountlock_validationPageObjects.btn_CongratsPageLoginbutton), MobilesitePageObjects.btn_CongratsPageLoginbutton.getObjectname());
		Thread.sleep(6000);	
	}
	public void vuseloginPage_fieldValidations() throws IOException 
	{
          String NonExistUserId = dataTable.getData("General_Data","NonExistUserId");
          String ValidPassword = dataTable.getData("General_Data","Password");
          String InvalidUserIdformat = dataTable.getData("General_Data","InvalidUserIDformat");
          
        commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.loginLnk_VUSECertifyAgePage), MobilesitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		
        //Login without any data
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_VUSELogin), MobilesitePageObjects.btn_VUSELogin.getObjectname());
		String Errormsg_LoginwithoutanyData = "Please enter your username";
		commonFunction.isElementPresentContainsText(getPageElement(MobilesitePageObjects.errormsg_VUSELoginwithoutanyDataUsername), MobilesitePageObjects.errormsg_VUSELoginwithoutanyDataUsername.getObjectname(), Errormsg_LoginwithoutanyData);
		
		
		//Login with Username not exists in DB
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginUsername),NonExistUserId,MobilesitePageObjects.txt_VUSELoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginPassword),ValidPassword, MobilesitePageObjects.txt_VUSELoginPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_VUSELogin), MobilesitePageObjects.btn_VUSELogin.getObjectname());
		
		String Errormsg_LoginwithNonExistUserId = "Username does not exist.";
		commonFunction.isElementPresentContainsText(getPageElement(MobilesitePageObjects.errormsg_VUSELoginwithNonExistingUserId), MobilesitePageObjects.errormsg_VUSELoginwithNonExistingUserId.getObjectname(), Errormsg_LoginwithNonExistUserId);
		
		
		//Login with UserId(having unaccepted characters)
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginUsername),InvalidUserIdformat,MobilesitePageObjects.txt_VUSELoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginPassword),ValidPassword, MobilesitePageObjects.txt_VUSELoginPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_VUSELogin), MobilesitePageObjects.btn_VUSELogin.getObjectname());
		
		String Errormsg_LoginwithUserIdwithunacceptedcharacters = "Username does not exist.";
		commonFunction.isElementPresentContainsText(getPageElement(MobilesitePageObjects.errormsg_VUSEUsernamefieldformaterror), MobilesitePageObjects.errormsg_VUSEUsernamefieldformaterror.getObjectname(), Errormsg_LoginwithUserIdwithunacceptedcharacters);	
		
	}
	
	public void vuseloginPage_ValidateErrormsg_AccountLock() throws IOException, Exception
	{
		
		try {
			String ValidUserId = dataTable.getData("General_Data","Username");
			String InvalidPassword = dataTable.getData("General_Data","InvalidPassword");
			
			commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.loginLnk_VUSECertifyAgePage), MobilesitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
			    
			//User entered Invalid password for 1st time
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginUsername),ValidUserId,MobilesitePageObjects.txt_VUSELoginUsername.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginPassword),InvalidPassword,MobilesitePageObjects.txt_VUSELoginPassword.getObjectname());
			try {
				commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_VUSELogin), MobilesitePageObjects.btn_VUSELogin.getObjectname());
			} catch (Exception e) {
				
				e.printStackTrace();
			}
			    
			String Errormsg_invalidPassword1sttime = "Login or Password incorrect";
			commonFunction.isElementPresentContainsText(getPageElement(MobilesitePageObjects.errormsg_VUSELoginWrongPassword), MobilesitePageObjects.errormsg_VUSELoginWrongPassword.getObjectname(), Errormsg_invalidPassword1sttime);
   
			    
			//User entered Invalid password for 2nd time
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginUsername),ValidUserId,MobilesitePageObjects.txt_VUSELoginUsername.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginPassword),InvalidPassword,MobilesitePageObjects.txt_VUSELoginPassword.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_VUSELogin), MobilesitePageObjects.btn_VUSELogin.getObjectname());
			    
			String Errormsg_invalidPassword2ndtime = "Login or Password incorrect";
			commonFunction.isElementPresentContainsText(getPageElement(MobilesitePageObjects.errormsg_VUSELoginWrongPassword), MobilesitePageObjects.errormsg_VUSELoginWrongPassword.getObjectname(), Errormsg_invalidPassword2ndtime);
   
			Thread.sleep(3000);  
			//User entered Invalid password for 3rd time
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginUsername),ValidUserId,MobilesitePageObjects.txt_VUSELoginUsername.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginPassword),InvalidPassword,MobilesitePageObjects.txt_VUSELoginPassword.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_VUSELogin), MobilesitePageObjects.btn_VUSELogin.getObjectname());
			    
			String Errormsg_invalidPassword3rdtime = "Login or Password incorrect";
			commonFunction.isElementPresentContainsText(getPageElement(MobilesitePageObjects.errormsg_VUSELoginWrongPassword), MobilesitePageObjects.errormsg_VUSELoginWrongPassword.getObjectname(), Errormsg_invalidPassword3rdtime);
   
			Thread.sleep(3000);   
			//User entered Invalid password for 4th time
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginUsername),ValidUserId,MobilesitePageObjects.txt_VUSELoginUsername.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginPassword),InvalidPassword,MobilesitePageObjects.txt_VUSELoginPassword.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_VUSELogin), MobilesitePageObjects.btn_VUSELogin.getObjectname());
			    
			String Errormsg_AccountLocked = "Username or password incorrect, account now locked. Click";
			commonFunction.isElementPresentContainsText(getPageElement(MobilesitePageObjects.errormsg_VUSEAccountLocked), MobilesitePageObjects.errormsg_VUSEAccountLocked.getObjectname(), Errormsg_AccountLocked);
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_Accountlock_validationPageObjects.lnk_VuseLockedAccntResetlink),MobileSite_Accountlock_validationPageObjects.lnk_VuseLockedAccntResetlink.getObjectname());
			//commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.lnk_VUSEAccntResetlink),MobilesitePageObjects.lnk_VUSEAccntResetlink.getObjectname());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	  
	}
	
	
	
	public void Vuse_loginPage_ResetLockedAccount() throws InterruptedException, IOException
	{
		String Email = dataTable.getData("General_Data", "Email");
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
		String ChallengeAnswer = dataTable.getData("General_Data", "ChallengeAnswer");
		String Password = dataTable.getData("General_Data", "Password");
		String ConfirmPassword = dataTable.getData("General_Data", "Password");
				
		String date = dataTable.getData("General_Data","DOB");
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		//commonFunction.clickIfElementPresent(getPageElement(MobileSite_Accountlock_validationPageObjects.lnk_LockedAccntResetlink),MobilesitePageObjects.lnk_LockedAccntResetlink.getObjectname());
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_ForgotPasswordUsername), Email, MobilesitePageObjects.txt_ForgotPasswordUsername.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_Accountlock_validationPageObjects.btn_ForgotPasswordUsernameContinue), MobilesitePageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
		
		commonFunction.selectAnyElement(getPageElement(MobileSite_Accountlock_validationPageObjects.drpdwn_ForgotPasswordBirthMonth), month, MobilesitePageObjects.drpdwn_ForgotPasswordBirthMonth.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSite_Accountlock_validationPageObjects.drpdwn_ForgotPasswordBirthDay), day, MobilesitePageObjects.drpdwn_ForgotPasswordBirthDay.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSite_Accountlock_validationPageObjects.drpdwn_ForgotPasswordBirthYear), year,MobilesitePageObjects.drpdwn_ForgotPasswordBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_ForgotPasswordFirstName), FirstName, MobilesitePageObjects.txt_ForgotPasswordFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_ForgotPasswordLastName), LastName, MobilesitePageObjects.txt_ForgotPasswordLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_ForgotPasswordAddress), Address, MobilesitePageObjects.txt_ForgotPasswordAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_ForgotPasswordZipcode), Zipcode, MobilesitePageObjects.txt_ForgotPasswordZipcode.getObjectname());
		Thread.sleep(2000);
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_ForgotPasswordCity), City, MobilesitePageObjects.txt_ForgotPasswordCity.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSite_Accountlock_validationPageObjects.drpdwn_ForgotPasswordState),State, MobilesitePageObjects.drpdwn_ForgotPasswordState.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_Accountlock_validationPageObjects.btn_ForgotPasswordGeneralInformation), MobilesitePageObjects.btn_ForgotPasswordGeneralInformation.getObjectname());
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_ForgotPasswordChallengeAnswer), ChallengeAnswer, MobilesitePageObjects.txt_ForgotPasswordChallengeAnswer.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_Accountlock_validationPageObjects.btn_ForgotPasswordVerifyIdentity), MobilesitePageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
		//Thread.sleep(4000);
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_ForgotPasswordPassword), Password, MobilesitePageObjects.txt_ForgotPasswordPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_ForgotPasswordConfirmPassword), ConfirmPassword, MobilesitePageObjects.txt_ForgotPasswordConfirmPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_Accountlock_validationPageObjects.btn_ForgotPasswordResetPassword), MobilesitePageObjects.btn_ForgotPasswordResetPassword.getObjectname());
		//Thread.sleep(4000);
		
		//commonFunction.clearAndEnterText(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_CongratsPageUsername),Email, MobilesitePageObjects.txt_CongratsPageUsername.getObjectname());
		//commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_Accountlock_validationPageObjects.txt_CongratsPagePassword), Password,MobilesitePageObjects.txt_CongratsPagePassword.getObjectname());
		//commonFunction.clickIfElementPresent(getPageElement(MobileSite_Accountlock_validationPageObjects.btn_CongratsPageLoginbutton), MobilesitePageObjects.btn_CongratsPageLoginbutton.getObjectname());
		Thread.sleep(6000);	
	}
		
	
	
	
	
	
	
	
}
