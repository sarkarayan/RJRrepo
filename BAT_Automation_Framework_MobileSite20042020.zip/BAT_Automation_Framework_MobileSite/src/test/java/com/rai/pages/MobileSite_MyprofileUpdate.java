package com.rai.pages;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.framework.Status;
import com.rai.pageObjects.MobileSiteForgotPasswordPageObjects;
import com.rai.pageObjects.MobileSiteForgotusernamePageObjects;
import com.rai.pageObjects.MobileSiteLoginPageObjects;
import com.rai.pageObjects.MobileSite_MyprofilePageObjects;
import com.rai.pageObjects.MobilesitePageObjects;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;



public class MobileSite_MyprofileUpdate extends BaseClass {
	
	String testcaseName;
	public MobileSite_MyprofileUpdate(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(MobileSite_MyprofilePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("ForgotUsername Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	private WebElement getPageElement(MobileSiteForgotPasswordPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Forgot Password Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	private WebElement getPageElement(MobileSiteLoginPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Mobile Site Login Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	private WebElement getPageElement(MobilesitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Mobile Site Login Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	
	public void invokeApplication_MobileSite()
	{
		String websiteURL = dataTable.getData("General_Data","URL");
		driver.get(websiteURL);
		driver.manage().deleteAllCookies();
		driver.get(websiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
	public void loginPage_AppToWebsiteLogin() throws InterruptedException, IOException {

		String Username = dataTable.getData("General_Data", "Username");
		String Password = dataTable.getData("General_Data", "Password");
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btnSignInTab),MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteLoginPageObjects.txt_LoginUsername), Username,MobileSiteLoginPageObjects.txt_LoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteLoginPageObjects.txt_LoginPassword), Password,MobileSiteLoginPageObjects.txt_LoginPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
		//Thread.sleep(5000);
	}
	
	public void camelProfile_NavigatetoMyProfile() throws Exception {
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_menu),MobileSite_MyprofilePageObjects.btn_menu.getObjectname());
		Thread.sleep(2000);
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.lnk_CamelMyAccount),MobilesitePageObjects.lnk_CamelMyAccount.getObjectname());
		//Thread.sleep(5000);
	}
	
	public void grizzlyProfile_NavigatetoMyProfile() throws Exception {
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.lnk_GrizzlyMyAccount),MobilesitePageObjects.lnk_GrizzlyMyAccount.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_GrizzlyUpdateInfo),MobilesitePageObjects.btn_GrizzlyUpdateInfo.getObjectname());
		//Thread.sleep(5000);
	}
	public void veloProfile_NavigatetoMyProfile() throws IOException
	{
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVelo_AccountMenu),MobilesitePageObjects.PostLoginVelo_AccountMenu.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVelo_Profile),MobilesitePageObjects.PostLoginVelo_Profile.getObjectname());
		
	}
	
	public void newportProfile_NavigatetoMyProfile() throws Exception {
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_Newportmenu),MobileSite_MyprofilePageObjects.btn_Newportmenu.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.lnk_NewportMyAccount),MobileSite_MyprofilePageObjects.lnk_NewportMyAccount.getObjectname());
		//Thread.sleep(5000);
	}
	
	public void nascigsProfile_NavigatetoMyProfile() throws Exception {
		try {
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.ham_menu),MobileSite_MyprofilePageObjects.ham_menu.getObjectname());
			
			//commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_menu),MobilesitePageObjects.lnk_CamelMyAccount.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.lnk_NASCIGSProfile),MobileSite_MyprofilePageObjects.lnk_NASCIGSProfile.getObjectname());
			//Thread.sleep(5000);
			//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.btn_Profilesetting));	
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_Profilesetting),MobileSite_MyprofilePageObjects.btn_Profilesetting.getObjectname());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		} 

	public void pallmallProfile_NavigatetoMyProfile() throws Exception {
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_pallmallmenu),MobileSite_MyprofilePageObjects.btn_pallmallmenu.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.link_pallmallprofilee),MobileSite_MyprofilePageObjects.link_pallmallprofilee.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_profilesetting),MobileSite_MyprofilePageObjects.btn_profilesetting.getObjectname());
		//commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.lnk_PallmallProfile),MobilesitePageObjects.lnk_PallmallProfile.getObjectname());
		//Thread.sleep(5000);
	}
	
	public void profileUpdate_UserInfoValidations() throws IOException {

		String ProfileAddress = dataTable.getData("General_Data", "Address");
		String ProfileCity = dataTable.getData("General_Data", "City");
		String ProfileZipcode = dataTable.getData("General_Data", "Zipcode");

		// MyProfile - Address field validation
		commonFunction.clearText(getPageElement(MobileSite_MyprofilePageObjects.txt_ProfileAddressLine1),MobilesitePageObjects.txt_ProfileAddressLine1.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileUpdateInfo),MobilesitePageObjects.btn_ProfileUpdateInfo.getObjectname());
		//String ActualErrormsg_ProfileNoAddress = commonFunction.getTextFromElement(getPageElement(MobilesitePageObjects.errormsg_ProfileNoAddress));
		String ExpectedErrormsg_ProfileNoAddress = "The Address Line 1 field is required.";
		commonFunction.isElementPresentContainsText(getPageElement(MobileSite_MyprofilePageObjects.errormsg_ProfileNoAddress), MobilesitePageObjects.errormsg_ProfileNoAddress.getObjectname(), ExpectedErrormsg_ProfileNoAddress);

		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_MyprofilePageObjects.txt_ProfileAddressLine1),ProfileAddress, MobilesitePageObjects.txt_ProfileAddressLine1.getObjectname());

		// MyProfile - City field validation
		commonFunction.clearText(getPageElement(MobileSite_MyprofilePageObjects.txt_ProfileCity),MobilesitePageObjects.txt_ProfileCity.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileUpdateInfo),MobilesitePageObjects.btn_ProfileUpdateInfo.getObjectname());
		String ActualErrormsg_ProfileNoCity = commonFunction.getTextFromElement(getPageElement(MobileSite_MyprofilePageObjects.errormsg_ProfileNoCity));
		String ExpectedErrormsg_ProfileNoCity = "The City field is required.";
		commonFunction.compareStringsContains(ExpectedErrormsg_ProfileNoCity, ActualErrormsg_ProfileNoCity);
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_MyprofilePageObjects.txt_ProfileCity), ProfileCity,MobilesitePageObjects.txt_ProfileCity.getObjectname());

		// MyProfile - Zipcode field validation
		commonFunction.clearText(getPageElement(MobileSite_MyprofilePageObjects.txt_ProfileZipcode),MobilesitePageObjects.txt_ProfileZipcode.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileUpdateInfo),MobilesitePageObjects.btn_ProfileUpdateInfo.getObjectname());
		//String ActualErrormsg_ProfileNoZipcode = commonFunction.getTextFromElement(getPageElement(MobilesitePageObjects.errormsg_ProfileNoZipcode));
		String ExpectedErrormsg_ProfileNoZipcode = "The Zip Code field is required.";
		commonFunction.isElementPresentContainsText(getPageElement(MobileSite_MyprofilePageObjects.errormsg_ProfileNoZipcode), MobilesitePageObjects.errormsg_ProfileNoZipcode.getObjectname(), ExpectedErrormsg_ProfileNoZipcode);

		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_MyprofilePageObjects.txt_ProfileZipcode),ProfileZipcode, MobilesitePageObjects.txt_ProfileZipcode.getObjectname());

	}

	public void profileUpdate_NegativeValidationsUpdateEmail() throws IOException {
		try {
			String InvalidEmail = dataTable.getData("General_Data", "InvalidUserIDformat");
			String NonExistingEmail = dataTable.getData("General_Data", "NonExistUserId");
			String ExistingEmail = dataTable.getData("General_Data", "ExistingUserId");

			// MyProfile - User entered InvalidEmail
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_MyprofilePageObjects.txt_ProfileNewEmail),InvalidEmail, MobilesitePageObjects.txt_ProfileNewEmail.getObjectname());
			driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
			//String Actualerrormsg_ProfileInvalidEmail = commonFunction.getTextFromElement(getPageElement(MobilesitePageObjects.errormsg_ProfileInValidEmail));
			String Expectederrormsg_ProfileInvalidEmail = "Please enter a valid email address";
			commonFunction.isElementPresentContainsText(getPageElement(MobileSite_MyprofilePageObjects.errormsg_ProfileInValidEmail), MobilesitePageObjects.errormsg_ProfileInValidEmail.getObjectname(), Expectederrormsg_ProfileInvalidEmail);

			// MyProfile - User entered NonExistingEmail
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_MyprofilePageObjects.txt_ProfileNewEmail),NonExistingEmail, MobilesitePageObjects.txt_ProfileNewEmail.getObjectname());
			//String Actualerrormsg_ProfileNonExistingEmail = commonFunction.getTextFromElement(getPageElement(MobilesitePageObjects.errormsg_ProfileInactiveEmail));
			String Expectederrormsg_ProfileNonExistingEmail = "This is not an active email address. Please provide an active email address.";
			commonFunction.isElementPresentContainsText(getPageElement(MobileSite_MyprofilePageObjects.errormsg_ProfileInactiveEmail), MobilesitePageObjects.errormsg_ProfileInactiveEmail.getObjectname(), Expectederrormsg_ProfileNonExistingEmail);

			// MyProfile - User entered already ExistingEmail
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_MyprofilePageObjects.txt_ProfileNewEmail),ExistingEmail, MobilesitePageObjects.txt_ProfileNewEmail.getObjectname());
			//String Actualerrormsg_ProfileExistingEmail = commonFunction.getTextFromElement(getPageElement(MobilesitePageObjects.errormsg_ProfileEnteredExistingEmail));
			String Expectederrormsg_ProfileExistingEmail = "User Name already taken. Please try a different one.";
			commonFunction.isElementPresentContainsText(getPageElement(MobileSite_MyprofilePageObjects.errormsg_ProfileEnteredExistingEmail), MobilesitePageObjects.errormsg_ProfileEnteredExistingEmail.getObjectname(), Expectederrormsg_ProfileExistingEmail);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

public void profileUpdate_NegativeValidationsUpdatePassword() throws InterruptedException, IOException {
		
		String CurrentPassword = dataTable.getData("General_Data", "Password");
		String InvalidPasswordformat = dataTable.getData("General_Data", "InvalidPasswordformat");
		String NewPassword = dataTable.getData("General_Data", "Password");
		String DifferentPassword = dataTable.getData("General_Data", "InvalidPassword");
		
		String Errormsg_InvalidPasswordformat = "Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.";
		String Errormsg_DifferentPassword = "The New Password and Confirm New Password fields do not match.";

		// MyProfile - User not entered CurrentPassword
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileUpdatePassword),MobilesitePageObjects.btn_ProfileUpdatePassword.getObjectname());
		//String Actualerrormsg_CurrentPasswordnotEntered = commonFunction.getTextFromElement(getPageElement(MobilesitePageObjects.errormsg_ProfileNoCurrentPassword));
		String Expectederrormsg_CurrentPasswordnotEntered = "The Current Password field is required.";
		commonFunction.isElementPresentContainsText(getPageElement(MobileSite_MyprofilePageObjects.errormsg_ProfileNoCurrentPassword), MobilesitePageObjects.errormsg_ProfileNoCurrentPassword.getObjectname(), Expectederrormsg_CurrentPasswordnotEntered);
		
		//MyProfile - User entered Invalid Password format in NewPassword field
		commonFunction.clearAndEnterText(getPageElement(MobileSite_MyprofilePageObjects.txt_ProfileCurrentPassword),CurrentPassword, MobilesitePageObjects.txt_ProfileCurrentPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_MyprofilePageObjects.txt_ProfileNewPassword),InvalidPasswordformat, MobilesitePageObjects.txt_ProfileNewPassword.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(MobileSite_MyprofilePageObjects.errormsg_ProfileInvalidPasswordformatinNewPassword), MobilesitePageObjects.errormsg_ProfileInvalidPasswordformatinNewPassword.getObjectname(), Errormsg_InvalidPasswordformat);
		
		//MyProfile - User entered different data in NewPassword & ConfirmNewPassword fields
		commonFunction.clearAndEnterText(getPageElement(MobileSite_MyprofilePageObjects.txt_ProfileCurrentPassword),CurrentPassword, MobilesitePageObjects.txt_ProfileCurrentPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_MyprofilePageObjects.txt_ProfileNewPassword),NewPassword, MobilesitePageObjects.txt_ProfileNewPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_MyprofilePageObjects.txt_ProfileConfirmNewPassword),DifferentPassword, MobilesitePageObjects.txt_ProfileConfirmNewPassword.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(MobileSite_MyprofilePageObjects.errormsg_ProfileDifferentPassword), MobilesitePageObjects.errormsg_ProfileDifferentPassword.getObjectname(), Errormsg_DifferentPassword);
		
  }
    
public void profileUpdate_UpdatePassword() throws IOException, Exception {
	try {
		String CurrentPassword = dataTable.getData("General_Data", "Password");
		String NewPassword = dataTable.getData("General_Data", "Password");
		String ConfirmNewPassword = dataTable.getData("General_Data", "Password");

		// MyProfile - User updated NewPassword
		commonFunction.clearAndEnterText(getPageElement(MobileSite_MyprofilePageObjects.txt_ProfileCurrentPassword),CurrentPassword, MobilesitePageObjects.txt_ProfileCurrentPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_MyprofilePageObjects.txt_ProfileNewPassword),NewPassword, MobilesitePageObjects.txt_ProfileNewPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSite_MyprofilePageObjects.txt_ProfileConfirmNewPassword),ConfirmNewPassword, MobilesitePageObjects.txt_ProfileConfirmNewPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileUpdatePassword),MobilesitePageObjects.btn_ProfileUpdatePassword.getObjectname());
		//WebDriverWait wait = new WebDriverWait(driver, 5);
		
		//wait.until(ExpectedConditions.alertIsPresent());
		//driver.switchTo().alert().dismiss();
		//ChromeOptions options = new ChromeOptions();
		//Map<String, Object> contentSettings = new HashMap<String, Object>();
		//contentSettings.put("notifications", "OK");
		 //DesiredCapabilities caps = new DesiredCapabilities();
		 //caps.setCapability("autoAcceptAlerts", "true");
		clickOkOnAlert();
			/*
			 * Thread.sleep(5000); ((AndroidDriver) driver).pressKey(new
			 * KeyEvent(AndroidKey.ENTER)); Thread.sleep(5000); ((AndroidDriver)
			 * driver).pressKey(new KeyEvent(AndroidKey.ENTER)); Thread.sleep(6000);
			 */
	} catch (IOException e) {
		
		e.printStackTrace();
	} 
}

public void profileUpdate_NegativevalidationsUpdateChallegeAnswer() throws IOException {

	// User clicked on Update without ChallengeAnswer
	try {
		commonFunction.scrolldownToEndOfWebPage();
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileUpdateChallengeQuestion),MobilesitePageObjects.btn_ProfileUpdateChallengeQuestion.getObjectname());
	//String Actualerrormsg_NoChallengeAnswerProfile = commonFunction.getTextFromElement(getPageElement(MobilesitePageObjects.errormsg_ProfileNoChallengeAnswer));
	String Expectederrormsg_NoChallengeAnswerProfile = "The Challenge Answer field is required.";
	commonFunction.isElementPresentContainsText(getPageElement(MobileSite_MyprofilePageObjects.errormsg_ProfileNoChallengeAnswer), MobilesitePageObjects.errormsg_ProfileNoChallengeAnswer.getObjectname(), Expectederrormsg_NoChallengeAnswerProfile);
	commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileBacktoSite),MobilesitePageObjects.btn_ProfileBacktoSite.getObjectname());
}

public void profileUpdate_UpdateChallegeAnswer() throws IOException, InterruptedException {
	try {
		String ValidChallengeAnswer = dataTable.getData("General_Data", "ChallengeAnswer");
		Thread.sleep(5000);
		((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.ENTER));
		// User updated the ChallengeAnswer
		Thread.sleep(3000);
		commonFunction.clearAndEnterText(getPageElement(MobileSite_MyprofilePageObjects.txt_ProfileChallengeAnswer),ValidChallengeAnswer, MobilesitePageObjects.txt_ProfileChallengeAnswer.getObjectname());
		Thread.sleep(3000);
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileUpdateChallengeQuestion),MobilesitePageObjects.btn_ProfileUpdateChallengeQuestion.getObjectname());
		
		Thread.sleep(3000);
		((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.ENTER));
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileBacktoSite),MobilesitePageObjects.btn_ProfileBacktoSite.getObjectname());
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}

public void profileUpdate_NegativevalidationsTobaccoPreferences() throws InterruptedException, IOException {
	try {
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileTobaccoPreferences),MobilesitePageObjects.btn_ProfileTobaccoPreferences.getObjectname());

		// User clicked on Update without selecting TobaccoPreferences
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_TobaccoPreferencesUpdate),MobilesitePageObjects.btn_TobaccoPreferencesUpdate.getObjectname());
		//String Actualerrormsg_NoTobaccoReferences = commonFunction.getTextFromElement(getPageElement(MobilesitePageObjects.errormsg_ProfileNoTobaccoPreferencesUpdate));
		String Expectederrormsg_NoTobaccoReferences = "Answering the question above is required to continue";
		commonFunction.isElementPresentContainsText(getPageElement(MobileSite_MyprofilePageObjects.errormsg_ProfileNoTobaccoPreferencesUpdate), MobilesitePageObjects.errormsg_ProfileNoTobaccoPreferencesUpdate.getObjectname(), Expectederrormsg_NoTobaccoReferences);

		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileUserInfo),MobilesitePageObjects.btn_ProfileUserInfo.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileBacktoSite),MobilesitePageObjects.btn_ProfileBacktoSite.getObjectname());
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}

public void profileUpdate_TobaccoPreferencesUpdate() throws IOException, InterruptedException {
	try {
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileTobaccoPreferences),MobilesitePageObjects.btn_ProfileTobaccoPreferences.getObjectname());

		// User selected type of TobaccoProduct (Dissolvable Tobacco)
		if(!(getPageElement(MobileSite_MyprofilePageObjects.chckbox_TobaccoPreferencesDissolvableTobacco)).isSelected()){
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.chckbox_TobaccoPreferencesDissolvableTobacco),MobilesitePageObjects.chckbox_TobaccoPreferencesDissolvableTobacco.getObjectname());
		}
		
		//Thread.sleep(2000);

		commonFunction.selectAnyElement(getPageElement(MobileSite_MyprofilePageObjects.drpdwn_TobaccoPreferencesDissolvable1),"STONEWALL",MobilesitePageObjects.drpdwn_TobaccoPreferencesDissolvable1.getObjectname());
		//commonFunction.selectAnyElementByValue(getPageElement(MobileSite_MyprofilePageObjects.drpdwn_TobaccoPreferencesDissolvable2),"10001|DISSOLVABLE|1000011|10131",MobilesitePageObjects.drpdwn_TobaccoPreferencesDissolvable2.getObjectname());
		if(!(getPageElement(MobileSite_MyprofilePageObjects.chckbox_TobaccoPreferencesDissolvable3)).isSelected()){
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.chckbox_TobaccoPreferencesDissolvable3),MobilesitePageObjects.chckbox_TobaccoPreferencesDissolvable3.getObjectname());
		}
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_TobaccoPreferencesUpdate),MobilesitePageObjects.btn_TobaccoPreferencesUpdate.getObjectname());
		//WebDriverWait wait = new WebDriverWait(driver, 5);
		//wait.until(ExpectedConditions.alertIsPresent());
		//driver.switchTo().alert().accept();
		((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.ENTER));
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileUserInfo),MobilesitePageObjects.btn_ProfileUserInfo.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileBacktoSite),MobilesitePageObjects.btn_ProfileBacktoSite.getObjectname());
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}
public void Camel_profileUpdate_TobaccoPreferencesUpdate() throws IOException, InterruptedException {
	try {
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileTobaccoPreferences),MobileSite_MyprofilePageObjects.btn_ProfileTobaccoPreferences.getObjectname());

		// User selected type of TobaccoProduct (Dissolvable Tobacco)
		if(!(getPageElement(MobileSite_MyprofilePageObjects.chckbox_TobaccoPreferencesDissolvableTobacco_camel)).isSelected()){
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.chckbox_TobaccoPreferencesDissolvableTobacco_camel),MobileSite_MyprofilePageObjects.chckbox_TobaccoPreferencesDissolvableTobacco_camel.getObjectname());
		}
		
		//Thread.sleep(2000);

		commonFunction.selectAnyElement(getPageElement(MobileSite_MyprofilePageObjects.drpdwn_TobaccoPreferencesDissolvable1),"STONEWALL",MobilesitePageObjects.drpdwn_TobaccoPreferencesDissolvable1.getObjectname());
		//commonFunction.selectAnyElementByValue(getPageElement(MobileSite_MyprofilePageObjects.drpdwn_TobaccoPreferencesDissolvable2),"10001|DISSOLVABLE|1000011|10131",MobilesitePageObjects.drpdwn_TobaccoPreferencesDissolvable2.getObjectname());
		if(!(getPageElement(MobileSite_MyprofilePageObjects.chckbox_TobaccoPreferencesDissolvable3_camel)).isSelected()){
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.chckbox_TobaccoPreferencesDissolvable3_camel),MobileSite_MyprofilePageObjects.chckbox_TobaccoPreferencesDissolvable3_camel.getObjectname());
		}
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_TobaccoPreferencesUpdate),MobilesitePageObjects.btn_TobaccoPreferencesUpdate.getObjectname());
		//WebDriverWait wait = new WebDriverWait(driver, 5);
		//wait.until(ExpectedConditions.alertIsPresent());
		//driver.switchTo().alert().accept();
		((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.ENTER));
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileUserInfo),MobilesitePageObjects.btn_ProfileUserInfo.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileBacktoSite),MobilesitePageObjects.btn_ProfileBacktoSite.getObjectname());
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}
public void Newport_profileUpdate_TobaccoPreferencesUpdate() throws IOException, InterruptedException {
	try {
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileTobaccoPreferences),MobilesitePageObjects.btn_ProfileTobaccoPreferences.getObjectname());

		// User selected type of TobaccoProduct (Dissolvable Tobacco)
		if(!(getPageElement(MobileSite_MyprofilePageObjects. chckbox_TobaccoPreferencesDissolvableTobacco_NP)).isSelected()){
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects. chckbox_TobaccoPreferencesDissolvableTobacco_NP),MobileSite_MyprofilePageObjects.chckbox_TobaccoPreferencesDissolvableTobacco_NP.getObjectname());
		}
		
		//Thread.sleep(2000);

		commonFunction.selectAnyElement(getPageElement(MobileSite_MyprofilePageObjects.drpdwn_TobaccoPreferencesDissolvable1),"STONEWALL",MobilesitePageObjects.drpdwn_TobaccoPreferencesDissolvable1.getObjectname());
		//commonFunction.selectAnyElementByValue(getPageElement(MobileSite_MyprofilePageObjects.drpdwn_TobaccoPreferencesDissolvable2),"10001|DISSOLVABLE|1000011|10131",MobilesitePageObjects.drpdwn_TobaccoPreferencesDissolvable2.getObjectname());
		if(!(getPageElement(MobileSite_MyprofilePageObjects.chckbox_TobaccoPreferencesDissolvable3_NP)).isSelected()){
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.chckbox_TobaccoPreferencesDissolvable3_NP),MobileSite_MyprofilePageObjects.chckbox_TobaccoPreferencesDissolvable3_NP.getObjectname());
		}
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_TobaccoPreferencesUpdate),MobilesitePageObjects.btn_TobaccoPreferencesUpdate.getObjectname());
		//WebDriverWait wait = new WebDriverWait(driver, 5);
		//wait.until(ExpectedConditions.alertIsPresent());
		//driver.switchTo().alert().accept();
		((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.ENTER));
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileUserInfo),MobilesitePageObjects.btn_ProfileUserInfo.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileBacktoSite),MobilesitePageObjects.btn_ProfileBacktoSite.getObjectname());
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}
public void Pallmall_profileUpdate_TobaccoPreferencesUpdate() throws IOException, InterruptedException {
	try {
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileTobaccoPreferences),MobilesitePageObjects.btn_ProfileTobaccoPreferences.getObjectname());

		// User selected type of TobaccoProduct (Dissolvable Tobacco)
		if(!(getPageElement(MobileSite_MyprofilePageObjects. chckbox_TobaccoPreferencesDissolvableTobacco_pallmall)).isSelected()){
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects. chckbox_TobaccoPreferencesDissolvableTobacco_pallmall),MobileSite_MyprofilePageObjects.chckbox_TobaccoPreferencesDissolvableTobacco_pallmall.getObjectname());
		}
		
		//Thread.sleep(2000);

		commonFunction.selectAnyElement(getPageElement(MobileSite_MyprofilePageObjects.drpdwn_TobaccoPreferencesDissolvable1),"STONEWALL",MobilesitePageObjects.drpdwn_TobaccoPreferencesDissolvable1.getObjectname());
		//commonFunction.selectAnyElementByValue(getPageElement(MobileSite_MyprofilePageObjects.drpdwn_TobaccoPreferencesDissolvable2),"10001|DISSOLVABLE|1000011|10131",MobilesitePageObjects.drpdwn_TobaccoPreferencesDissolvable2.getObjectname());
		if(!(getPageElement(MobileSite_MyprofilePageObjects. chckbox_TobaccoPreferencesDissolvable3_Pallmall)).isSelected()){
			commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects. chckbox_TobaccoPreferencesDissolvable3_Pallmall),MobileSite_MyprofilePageObjects. chckbox_TobaccoPreferencesDissolvable3_Pallmall.getObjectname());
		}
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_TobaccoPreferencesUpdate),MobilesitePageObjects.btn_TobaccoPreferencesUpdate.getObjectname());
		//WebDriverWait wait = new WebDriverWait(driver, 5);
		//wait.until(ExpectedConditions.alertIsPresent());
		//driver.switchTo().alert().accept();
		((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.ENTER));
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileUserInfo),MobilesitePageObjects.btn_ProfileUserInfo.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_ProfileBacktoSite),MobilesitePageObjects.btn_ProfileBacktoSite.getObjectname());
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}

public void Camel_logout() throws Exception {
	
	    commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_menu),MobileSite_MyprofilePageObjects.btn_menu.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginCamelfooterlnk_Logout),MobilesitePageObjects.PostLoginCamelfooterlnk_Logout.getObjectname());

}

public void americanSpiritHomePage_Logout() throws IOException 
{
	commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.ham_menu),MobileSite_MyprofilePageObjects.ham_menu.getObjectname());
	commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginNASfooterlnk_LogOut), MobileSite_MyprofilePageObjects.PostLoginNASfooterlnk_LogOut.getObjectname());

}
public void nascigHomePage_Logout() throws IOException 
{
	
	commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginNASfooterlnk_LogOut), MobileSite_MyprofilePageObjects.PostLoginNASfooterlnk_LogOut.getObjectname());

}

public void grizzlyHomePage_Logout() throws IOException
{
	commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLogin_Menu), MobilesitePageObjects.PostLogin_Menu.getObjectname());
	commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLogin_Menu_Logout), MobilesitePageObjects.PostLogin_Menu_Logout.getObjectname());
	
}

public void newportHomePage_Logout() throws IOException
{
	commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_Newportmenu),MobileSite_MyprofilePageObjects.btn_Newportmenu.getObjectname());
	commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginNewportfooterlnk_Logout), MobilesitePageObjects.PostLoginNewportfooterlnk_Logout.getObjectname());
	
}

public void pallmallHomePage_Logout() throws IOException
{
	commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.btn_pallmallmenu),MobileSite_MyprofilePageObjects.btn_pallmallmenu.getObjectname());
	commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginPallmallfooterlnk_Logout), MobilesitePageObjects.PostLoginPallmallfooterlnk_Logout.getObjectname());
	
}

public void veloHomePage_Logout() throws IOException
{
	
	commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVelo_AccountMenu),MobilesitePageObjects.PostLoginVelo_AccountMenu.getObjectname());
	commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVelo_LogOut),MobilesitePageObjects.PostLoginVelo_LogOut.getObjectname());
	
}

public void clickOkOnAlert() throws IOException {
	
	Set<String> views = null;
	try {
		
		if(driver instanceof AndroidDriver)
		{
			((AndroidDriver) driver).context("NATIVE_APP");
		}
		
		
		if (driver instanceof AndroidDriver
				&& driver.findElement(By.id("com.android.chrome:id/positive_button")).isDisplayed()) {

			views = ((AndroidDriver<MobileElement>) driver).getContextHandles();
			
			
			/*
			 * MobileElement neverBtn = ((AndroidDriver<MobileElement>)driver).
			 * findElementByAndroidUIAutomator("new UiSelector().text(\"Never\")");
			 * neverBtn.click();
			 */
			commonFunction.clickIfElementPresent(
					getPageElement(MobileSiteForgotPasswordPageObjects.alertOkButton),
					MobileSiteForgotPasswordPageObjects.alertOkButton.getObjectname());
			for (String view : views) {
				if (view.contains("WEBVIEW")) {
					((AndroidDriver) driver).context(view);
				}
			}
		}

	} catch (NoSuchElementException e) {
		for (String view : views) {
			if (view.contains("WEBVIEW")) {
				((AndroidDriver) driver).context(view);
			}
		}
	}
}



	
	
}
