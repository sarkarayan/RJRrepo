package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.MobilesitePageObjects;
import com.rai.pageObjects.brandWebsitePageObjects;

public class BrandWebsite_LoginFlow_LoginResetPandY_PrimaryUandN extends BaseClass {

	String testcaseName;
	public BrandWebsite_LoginFlow_LoginResetPandY_PrimaryUandN(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(MobilesitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
		
		private WebElement getPageElement(brandWebsitePageObjects pageEnum) throws IOException {
			WebElement element;
			try {
				element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
						true);
				if (element != null)
					System.out.println("Found the element: " + pageEnum.getObjectname());
				else
					System.out.println("Element Not Found: " + pageEnum.getObjectname());
				return element;
			} catch (Exception e) {
				GenericLib.updateExtentStatus("Registration Page - get page element",
						pageEnum.toString() + " object is not defined or found.", Status.FAIL);
				return null;
			}
	}
	
	
	public void invokeApplication_brandwebsite()
	{
		String WebsiteURL = dataTable.getData("General_Data","URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
	public void login_EnterValidDataPandY() throws IOException
	{
		
		String Email = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data","Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_LoginUsername),Email,MobilesitePageObjects.txt_LoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_LoginPassword),Password,MobilesitePageObjects.txt_LoginPassword.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
	}
	
		
	public void resetflow_GeneralInfoPageviaLogin() throws InterruptedException, IOException
	{
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
		String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
				
		commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.drpdwn_ForgotUsernameBirthMonth), month, MobilesitePageObjects.drpdwn_ForgotUsernameBirthMonth.getObjectname());
		Thread.sleep(5000);
		commonFunction.selectAnyElementByValue(getPageElement(MobilesitePageObjects.drpdwn_ForgotUsernameBirthDay),day,MobilesitePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobilesitePageObjects.drpdwn_ForgotUsernameBirthYear), year, MobilesitePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobilesitePageObjects.txt_ForgotUsernameFirstName), FirstName, MobilesitePageObjects.txt_ForgotUsernameFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobilesitePageObjects.txt_ForgotUsernameLastName), LastName, MobilesitePageObjects.txt_ForgotUsernameLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobilesitePageObjects.txt_ForgotUsernameAddress), Address, MobilesitePageObjects.txt_ForgotUsernameAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_ForgotUsernameZipcode), Zipcode,MobilesitePageObjects.txt_ForgotUsernameZipcode.getObjectname());
		Thread.sleep(4000);
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_ForgotUsernameCity), City, MobilesitePageObjects.txt_ForgotUsernameCity.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobilesitePageObjects.drpdwn_ForgotUsernameState),State, MobilesitePageObjects.drpdwn_ForgotUsernameState.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.Continuebtn_LoginResetviaLoginonGeneralInfo),MobilesitePageObjects.Continuebtn_LoginResetviaLoginonGeneralInfo.getObjectname());
				
	}
	
	public void vuselogin_EnterValidDataPandY() throws IOException
	{
		
		String Email = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data","Password");
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.loginLnk_VUSECertifyAgePage),brandWebsitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		
		//commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.header_VUSELogin),brandWebsitePageObjects.header_VUSELogin.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginUsername),Email,brandWebsitePageObjects.txt_VUSELoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(brandWebsitePageObjects.txt_VUSELoginPassword),Password,brandWebsitePageObjects.txt_VUSELoginPassword.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(brandWebsitePageObjects.btn_VUSELogin),brandWebsitePageObjects.btn_VUSELogin.getObjectname());
	}
	
	
	public void resetflow_AnotherBrandAlreadyRegisteredPage() throws Exception 
	{
		
		String ExpectedErrormsg_diffBrandAlreadyRegistered = "It looks like you are already registered with another Reynolds American operating company's brand website.";
		
		commonFunction.isElementPresentContainsText(getPageElement(MobilesitePageObjects.errmsg_AlreadyRegisteredPage), MobilesitePageObjects.errmsg_AlreadyRegisteredPage.getObjectname(), ExpectedErrormsg_diffBrandAlreadyRegistered);
		
		//String ActualErrormsg_diffBrandAlreadyRegistered = commonFunction.getTextFromElement(getPageElement(MobilesitePageObjects.errmsg_AlreadyRegisteredPage));
		
//		if(ActualErrormsg_diffBrandAlreadyRegistered.contains(ExpectedErrormsg_diffBrandAlreadyRegistered))
//		{
//			System.out.println("Registration - Directed to Expected page when user try to register the same user in another brand");
//		}
//		else
//		{
//			System.out.println("Registration - Directed to Expected page displayed when user try to register the same user in another brand");
//		}
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_AlreadyRegisteredLogin), MobilesitePageObjects.btn_AlreadyRegisteredLogin.getObjectname());
	}

	
	
	
}

