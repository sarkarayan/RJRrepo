package com.rai.pages;

import java.util.Properties;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;


import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.pageObjects.*;
import com.rai.framework.GenericLib;

@Listeners(ExtentITestListenerClassAdapter.class)
public class Camel_HomePage extends BaseClass {
	GenericLib gl = new GenericLib(this.getClass().getSimpleName());
	Properties config = new Properties();
	SoftAssert softAssert=new SoftAssert();
	// AS_HomePage homePage=new AS_HomePage();

	@BeforeMethod
	public void beforemethod(String TestCaseName, String TestCaseObjective,String TestEnvironmentUrl) {
		gl.start_report(TestCaseName, TestCaseObjective, TestEnvironmentUrl);
		//extent = ExtentManager.GetExtent();	
		//extent = ExtentManager.createTest(test, description)
	}

	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Camel_Redesign_FooterLinks_002
	//Objectives: Verify the footer link navigations on Home page.

	//Pre-Requisites: 
	//User should have the Valid Username and Password
	//Author : Vikram T Date: 22.11.2018
	public void Camel_Redesign_FooterLinks_002 (String UN,String pwd,String url,String browserName,String faqtxt,String faqtxt1,String faqtxt2,String faqtxt3,String faqtxt4,String faqtxt5,String contactustxt,String sitetxt,String aftxt) throws Exception
	{
		//****************************************************************************************************************
		//Launch application
		gl.launchApplication(browserName,url);
		Thread.sleep(5000);

		//Camel Login page is displayed.
		//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Enter Valid Username
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter Valid Password
		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd);
		//Click on Login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
		Thread.sleep(10000);
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "HomePage");
		//****************************************************************************************************************
		//Click FAQ link
		gl.clickbutton(Camel_FooterLinks.lnkFAQsHomePage,"FAQs");
		//Navigate to FAQ tab
		gl.fnSwitchToSucceedingTab();
		Thread.sleep(5000);
		// FAQs page is displayed.
		gl.VerifyPageDisplayedUsingPageTitle("Frequently Asked Questions");
		Thread.sleep(8000);
		//****************************************************************************************************************

		//FAQs Content verification        
		gl.fnContentValidation(faqtxt,Camel_FooterLinks.weTxtFAQ);

		//FAQ question 4 answer content validation 
		gl.clickbutton(Camel_FooterLinks.lnkFAQ5,"FAQ page's fourth question");
		Thread.sleep(8000);
		//Veirfy the content of answer for Q4 
		gl.fnContentValidation(faqtxt4,Camel_FooterLinks.weFAQ5);

		//FAQ question 1 answer content validation 
		gl.clickbutton(Camel_FooterLinks.lnkFAQ1,"FAQ page's first question");
		Thread.sleep(8000);
		//Veirfy the content of answer for Q1 
		gl.fnContentValidation(faqtxt1,Camel_FooterLinks.weFAQ1);
		gl.clickbutton(Camel_FooterLinks.lnkFAQ1,"FAQ page's first question");
		//FAQ question 3 answer content validation 
		gl.clickbutton(Camel_FooterLinks.lnkFAQ3,"FAQ page's third question");
		Thread.sleep(8000);
		//Veirfy the content of answer for 3
		gl.fnContentValidation(faqtxt3,Camel_FooterLinks.weFAQ3);

		//****************************************************************************************************************
		//FAQ question 2 answer content validation 
		gl.clickbutton(Camel_FooterLinks.lnkFAQ2,"FAQ page's second question");
		Thread.sleep(8000);
		//Veirfy the content of answer for Q2 
		gl.fnContentValidation(faqtxt2,Camel_FooterLinks.weFAQ2);
		/*	gl.clickbutton(Camel_FooterLinks.lnkFAQ2,"FAQ page's second question");





		//FAQ question 4 answer content validation 
		gl.clickbutton(Camel_FooterLinks.lnkFAQ4,"FAQ page's fourth question");
		Thread.sleep(8000);
		//Veirfy the content of answer for Q4 
		gl.fnContentValidation(Camel_FooterLinks.weFAQ4,faqtxt4);*/





		//Close the browser opened.
		//FAQ question 5 answer content validation 
				gl.clickbutton(Camel_FooterLinks.lnkFAQ5,"FAQ page's fifth question");
				Thread.sleep(8000);
				//Veirfy the content of answer for Q2 
				gl.fnContentValidation(faqtxt5,Camel_FooterLinks.weFAQ6);
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();


		//****************************************************************************************************************

		//Camel Home page is displayed
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "HomePage");
		//***************************************************************************************************************


		// Click on ContactUS link on Home Page
		gl.clickbutton(Camel_FooterLinks.lnkContactUsHomePage, "Camel Login Contact us");
		gl.fnSwitchToSucceedingTab();
		Thread.sleep(8000);
		//ContactUS page is displayed.
		gl.VerifyPageDisplayedUsingPageTitle("Contact us");
		Thread.sleep(8000);
		//Content Validation
		gl.fnContentValidation(contactustxt,Camel_FooterLinks.weContactUs);	  
		//         //Close tab
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "HomePage");
		////***************************************************************************************************************
		//         //Click on TobaccoRights link on Home Page
		gl.clickbutton(Camel_FooterLinks.lnkTobaccoRightsHomePage,"Camel Login Tobacco rights");
		gl.fnSwitchToSucceedingTab();
		Thread.sleep(8000);
		//TobaccoRights page is displayed. 
		gl.VerifyPageDisplayedUsingPageTitle("Own It Voice It - Make Your Voice Heard");
		Thread.sleep(8000);
		//Close tab
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "HomePage");
		////************************************************************************************************************               
		////Click on Site Requirement link on Home Page
		gl.clickbutton(Camel_FooterLinks.lnkSiteRequirementsHomePage, "Site Requirements");
		Thread.sleep(4000);
		gl.fnSwitchToSucceedingTab();
		Thread.sleep(8000);
		//         //Site Requirement page is displayed.
		gl.VerifyPageDisplayedUsingPageTitle("Site Requirements");
		Thread.sleep(8000);
		////Site Requirement content validation.
		//Content Validation
		gl.fnContentValidation(sitetxt,Camel_FooterLinks.weSiteReq);
		//Click site requirement link
		gl.clickLink(Camel_FooterLinks.linkSRPPHomePage, "Site Requirement");
		Thread.sleep(4000);
		gl.fnSwitchToSucceedingTab();
		gl.VerifyPageDisplayedUsingPageTitle("Privacy Policy and Your California Privacy Rights");

		Thread.sleep(5000);
		//// Privacy Policy displayed.
		gl.fnCloseCurrentTab();
		Thread.sleep(4000);
		gl.fnSwitchToTab(1);
		//Site Requirement page is displayed.
		gl.VerifyPageDisplayedUsingPageTitle("Site Requirements");
		Thread.sleep(5000);
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "HomePage");
		////************************************************************************************************************
		////Click on Age Filtering link on Home Page
		gl.clickbutton(Camel_FooterLinks.lnkAgeFilteringHomePage, "AgeFiltering");
		gl.fnSwitchToSucceedingTab();
		Thread.sleep(5000);
		//           //AgeFiltering page is displayed.
		gl.VerifyPageDisplayedUsingPageTitle("Age Filtering Software:");
		Thread.sleep(5000);
		//AgeFiltering content validation
		gl.fnContentValidation(aftxt,Camel_FooterLinks.weAgeFiltering);
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();

		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "HomePage");
		//         //***********************************************************************************************************
		//                        //Click on TermsofUse link on Home Page
		gl.clickbutton(Camel_FooterLinks.lnkTermsofUseHomePage, "Home Page Terms of Use");
		Thread.sleep(4000);
		gl.fnSwitchToSucceedingTab();
		Thread.sleep(5000);
		//Terms of Use page is displayed.
		gl.VerifyPageDisplayedUsingPageTitle("Terms of use");
		Thread.sleep(5000);
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();
		//           //Terms of Use content validation
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "HomePage");
		////***************************************************************************************** 
		//                        //Click on Privacy Policy link on Login Page.
		gl.clickbutton(Camel_FooterLinks.lnkPrivacyPolicyandYourCaliforniaPrivacyRightsHomePage, "Privacy Policy and Your California Privacy Rights");
		Thread.sleep(4000);
		gl.fnSwitchToSucceedingTab();
		Thread.sleep(5000);
		//PrivacyPage is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Privacy Policy and Your California Privacy Rights");
		Thread.sleep(5000);
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "HomePage");

		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//                        //Close tab
		gl.closeAllBrowser();

	}
	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Camel_PrivacyPolicy_002
	//Objectives: Verify updated content of Privacy Policy page on post login to website/app and also verify navigation functionality on Privacy Policy page such as 

	//    1.Sidebar navigation for Policy Sub-headers
	//    2.Back to Top� link that navigates user to top of web page

	//Pre-Requisites: 
	//User should have the Valid Username and Password
	//Author : Vikram T Date: 31.10.2018
	//*********************************************************************************************************************
	public void  Camel_PrivacyPolicy_002(String UN,String pwd, String url, String browserName, String txtrestrict,String txtwhyweCollect,
			String txtwhatweCollect,String txtShareInfo, String txtWeProtect, String txtCanControl, 
			String txtThirdParty,String txtChangesToPP, String txtNoticeToCalifornia)throws Exception
	{
		// Launch Application
		gl.launchApplication(browserName, url);
		Thread.sleep(2000);

		//*********************************************************************************************************************      

		//Camel Login page is displayed.
		//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//ENTER username 
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter Valid Password
		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd);
		//Click on Login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
		Thread.sleep(10000);
		//Camel Home page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("Home | Camel","Camel Home");
		//*********************************************************************************************************************          
		//	                        //Click on Privacy Policy link on Login Page.
		gl.clickLink(Camel_FooterLinks.lnkPrivacyPolicyPostLogin, "Privacy Policy and Your California Privacy Rights");
		Thread.sleep(3000);
		gl.fnSwitchToSucceedingTab();
		Thread.sleep(5000);
		//PrivacyPage is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Privacy Policy and Your California Privacy Rights");
		Thread.sleep(5000);
		//Verify Sidebar navigation for Policy Sub-headers
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weSidebar);
		Thread.sleep(1000);
		//*********************************************************************************************************************      
		//Click "Restrictions on Access & Use " link 
		gl.clickLink(Camel_PrivacyPolicy.lnkrestrict,"Restrictions on Access");

		//Verify "Restrictions on Access & Use"  content text is displayed
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weRestrict);

		//Validate Restrictions on Access and Use text content
		gl.fnContentValidation( txtrestrict,Camel_PrivacyPolicy.weRestrict);
		//*********************************************************************************************************************            
		//Click "Why We Collect " link 
		gl.clickLink(Camel_PrivacyPolicy.lnkwhyweCollect,"WhyWeCollect");

		//Verify "Why We Collect"  content text is displayed
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weWhyWeCollect);

		//Validate Why We Collect and Use text content
		gl.fnContentValidation(txtwhyweCollect,Camel_PrivacyPolicy.weWhyWeCollect);  
		//*********************************************************************************************************************      
		//Click "What We Collect " link 
		gl.clickLink(Camel_PrivacyPolicy.lnkwhatweCollect,"WhatWeCollect");

		//Verify "What We Collect"  content text is displayed
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weWhatWeCollect);

		//Validate What We Collect and Use text content
		gl.fnContentValidation(txtwhatweCollect,Camel_PrivacyPolicy.weWhatWeCollect); 


		//Click "Here " link from Flash cookies content
		gl.clickLink(Camel_PrivacyPolicy.lnkherewwc,"WhatWeCollect-LnkHere");
		Thread.sleep(2000);

		//Switch Tab
		gl.fnSwitchToSucceedingTab();

		gl.VerifyPageDisplayedUsingPageTitle("Manage local shared objects in Flash Player");
		Thread.sleep(3000);
		//Close current tab
		gl.fnCloseCurrentTab();

		//switch to currrent tab
		gl.fnSwitchToTab(1);

		//*********************************************************************************************************************      
		//Click "Who We May Share Information With" link 
		gl.clickLink(Camel_PrivacyPolicy.lnkShareInfo,"Who We May Share Information With-Link");

		//Verify "Who We May Share Information With"  content text is displayed
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weShareInfo);

		//Validate Who We May Share Information With text content
		gl.fnContentValidation(txtShareInfo,Camel_PrivacyPolicy.weShareInfo);
		//*********************************************************************************************************************            
		//Click "How We Protect Your Privacy" link 
		gl.clickLink(Camel_PrivacyPolicy.lnkWeProtect,"How We Protect Your Privacy-Link");

		//Verify "How We Protect Your Privacy"  content text is displayed
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weWeProtect);

		//Validate How We Protect Your Privacy and Use text content
		gl.fnContentValidation(txtWeProtect,Camel_PrivacyPolicy.weWeProtect);     
		//*********************************************************************************************************************      
		//Click "How You Can Control Your Privacy" link 
		gl.clickLink(Camel_PrivacyPolicy.lnkCanControl,"How You Can Control Your Privacy-Link");

		//Verify "How You Can Control Your Privacy"  content text is displayed
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weCanControl);

		//Validate How You Can Control Your Privacy text content
		gl.fnContentValidation(txtCanControl,Camel_PrivacyPolicy.weCanControl); 

		//Click "http://www.ftc.gov/bcp/edu/microsites/idtheft/" link 
		gl.clickLink(Camel_PrivacyPolicy.lnkCanControlPP, "How You Can Control Your Privacy-link");
		Thread.sleep(10000);
		//Switch to new tab
		gl.fnSwitchToSucceedingTab();

		//Verify "FTC ConsumerInformation" Page
		gl.VerifyPageDisplayedUsingPageTitle("Identity Theft | Consumer Information");


		//Close current tab
		gl.fnCloseCurrentTab();
		Thread.sleep(4000);
		//Switch to native tab
		gl.fnSwitchToTab(1);


		//*********************************************************************************************************************
		//Click "Notice to California Residents � Your California Privacy Rights" link 
		gl.clickLink(Camel_PrivacyPolicy.lnkNoticeToCalifornia,"Notice to California Residents � Your California Privacy Rights-Link");

		//Verify "Notice to California Residents � Your California Privacy Rights"  content text is displayed
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weNoticeToCalifornia);

		//Validate Notice to California Residents � Your California Privacy Rights text content
		gl.fnContentValidation( txtNoticeToCalifornia,Camel_PrivacyPolicy.weNoticeToCalifornia);
		//*********************************************************************************************************************            
		//Click "Links to Third-Party Websites" link 
		gl.clickLink(Camel_PrivacyPolicy.lnkThirdParty,"Links to Third-Party Websites-Link");

		//Verify "Links to Third-Party Websites"  content text is displayed
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weThirdParty);

		//Validate Links to Third-Party Websites text content
		gl.fnContentValidation( txtThirdParty,Camel_PrivacyPolicy.weThirdParty);     
		//*********************************************************************************************************************      
		//Click "Changes To This Privacy Policy" link 
		gl.clickLink(Camel_PrivacyPolicy.lnkChangesToPP,"Changes To This Privacy Policy-Link");

		//Verify "Changes To This Privacy Policy"  content text is displayed
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weChangesToPP);

		//Validate Changes To This Privacy Policy text content
		gl.fnContentValidation( txtChangesToPP,Camel_PrivacyPolicy.weChangesToPP); 

		//Click on "Back To Top" link
		gl.clickLink(Camel_PrivacyPolicy.lnkBackToTop, "Back to Top");

		//Verify "Appropriate Privacy Policy content is displayed properly
		gl.VerifyObjectDisplayed(Camel_PrivacyPolicy.weSidebar);
		//*********************************************************************************************************************
		//close current tab
		gl.fnCloseCurrentTab();

		//Switch to native tab
		gl.fnSwitchToDefaultTab();
		//Camel Home page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("Home | Camel","Camel Home");

		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//                        //Close tab
		gl.closeAllBrowser();
	}
	//****************************************************************************************************************************	
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Camel_ContactUs_001
	//Objectives: Validate Contact Form. User should able to submit a questions from contact us page
	//Pre-Requisites: 
	//User should have the Valid Username and Password

	//Author : Vikram T Date: 02.11.2018



	public void Camel_ContactUs_001 (String UN,String pwd,String url,String browserName,String txtContactUs ,String txtAfter)  throws Exception
	{	
		// Launch Application
		gl.launchApplication(browserName, url);
		Thread.sleep(5000);
		//	Thread.sleep(2000);

		//*********************************************************************************************************************      
		//Camel Login page is displayed.
		//gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");

		//Enter Valid Username
		gl.inputText(Camel_Login.txtUsername,"txtUsername", UN) ;
		//Enter Valid Password
		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd);
		//Click on Login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");
		Thread.sleep(11000);
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "Homepage");
		//*********************************************************************************************************************          
		//	                        //Click on Privacy Policy link on Login Page.
		gl.clickLink(Camel_FooterLinks.lnkContactUsHomePage, "Camel Login Contact us");
		Thread.sleep(3000);
		gl.fnSwitchToSucceedingTab();
		Thread.sleep(5000);
		//PrivacyPage is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Contact us");
		Thread.sleep(5000);
		//Verify "Contact Us"  content text is displayed
		gl.VerifyObjectDisplayed(Camel_ContactUs.weContactUs);

		//Validate Restrictions on Access and Use text content
		gl.fnContentValidation(txtContactUs,Camel_ContactUs.weContactUs );
		//Click on submit button
		gl.clickLink(Camel_ContactUs.lnkSubmit,"Contact Us submit button");


		//Select "other" option from dropdown
		gl.SelectByOption(Camel_ContactUs.lnkDropDown, "Other");
		//Click "others" from the drop down list
		//gl.clickLink(Camel_ContactUs.lnkDropitem, "Drop down item others");
		//Click on submit button
		gl.clickLink(Camel_ContactUs.lnkSubmit,"Contact Us submit button");
		//Enter Username in comment section

		gl.inputText(Camel_ContactUs.weComment,"Comment", UN) ;
		//Get text from comment section


		gl.getExtractAttributeValue(Camel_ContactUs.weComment,UN,"value");

		String empty=" ";
		gl.clearElementText(Camel_ContactUs.weComment,"Clear comments");
		//Get text from comment section verify its cleared
		gl.getExtractAttributeValue(Camel_ContactUs.weComment,empty,"value");



		//Select "Coupons" option from dropdown
		gl.SelectByOption(Camel_ContactUs.lnkDropDown, "Coupons");

		//Enter Valid text in comment section

		gl.inputText(Camel_ContactUs.weComment,"Comment", UN) ;
		//Click on submit button
		gl.clickbutton(Camel_ContactUs.lnkSubmit,"Contact Us submit button");
		//Verify "Contact Us"  content text is displayed
		gl.VerifyObjectDisplayed(Camel_ContactUs.weAfter);
		Thread.sleep(3000);
		//Validate Restrictions on Access and Use text content
		gl.fnContentValidation(txtAfter,Camel_ContactUs.weAfter);
		//close current tab
		gl.fnCloseCurrentTab();

		//Switch to native tab
		gl.fnSwitchToDefaultTab();
		//Camel Home page is displayed
		gl.VerifyPageDisplayed(Camel_Home.pghome, "Homepage");

		//Click on Logout button
		gl.clickLink(Camel_Home.lnkLogOut, "lnkLogout");

		//Camel Login page is displayed.
		gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//                        //Close tab
		gl.closeAllBrowser();




	}
	//********************************************************************************************************************************************************
	//********************************************************************************************************************************************************    
	@Test
	//Test Case :  Camel_Redesign_TermsOfUse_001
	//Objectives: Verify the Terms of use page.

	//Pre-Requisites: 
	//User should have the Valid Username and Password
	//Author : Vikram T Date: 24.11.2018
	public void Camel_Redesign_TermsOfUse_002 (String UN,String pwd,String url,String browserName,String txtTermsAndConditions,String txtRestriction,String txtYourAccount,String txtYourStuff,String txtYourConduct,String txtContentOnSite,String txtOurPrivacyPolicy,String txtIntellectualPropertyIssues,String txtSiteAvailability,String txtChoiceOfLaw,String txtDisclaimer,String txtIndemnity,String txtResolvingDisputes,String txtSpecialNotice,String txtElectronicSignature,String txtMiscellaneous) throws Exception
	{
		//****************************************************************************************************************
		//Launch application
		gl.launchApplication(browserName,url);
		Thread.sleep(5000);

		//Camel Login page is displayed.
		//	gl.VerifyPageDisplayed(Camel_Login.txtUsername,"Camel Login");
		//Enter Valid Username
		gl.inputText(Camel_Login.txtUsername,"txtUsername",UN) ;
		//Enter Valid Password
		gl.inputPasswordEncrypted(Camel_Login.txtPassword,"txtPassword", pwd);
		//Click on Login button
		gl.clickbutton(Camel_Login.lnkLogin,"lnkLogin");

		//Camel Home page is displayed
		gl.fnVerifyPageDisplayedUsingPageTitle("Home | Camel","Camel Home");
		//Click on Terms of Use
		gl.clickUsingJs(Camel_FooterLinks.lnkTermsofUseHomePage, "Terms of Use link");
		//switch to terms of use 
		//gl.fnSwitchToSucceedingTab();
		//switch to previous tab
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();
		//Verify that Terms of use page is displayed
		gl.VerifyPageDisplayedUsingPageTitle("Terms of use");
		//verify the Terms and conditions content
		gl.fnContentValidation( txtTermsAndConditions,Camel_TermsOfUse.weTxtTermsAndConditions); 


		//Click on Restriction link
		gl.clickLink(Camel_TermsOfUse.lnkRestriction,"Restriction on access and use link");
		//verify the Restriction content
		gl.fnContentValidation( txtRestriction,Camel_TermsOfUse.weTxtRestriction); 


		//Click on your account link
		gl.clickLink(Camel_TermsOfUse.lnkYourAccount,"Your account link");
		//verify the your account content
		gl.fnContentValidation( txtYourAccount,Camel_TermsOfUse.weTxtYourAccount); 



		//Click on your stuff link
		gl.clickLink(Camel_TermsOfUse.lnkYourStuff,"Your stuff link");
		//verify the your stuff content
		gl.fnContentValidation( txtYourStuff,Camel_TermsOfUse.weTxtYourStuff); 


		//Click on your conduct link
		gl.clickLink(Camel_TermsOfUse.lnkYourConduct,"Your conduct link");
		//verify the your conduct content
		gl.fnContentValidation( txtYourConduct,Camel_TermsOfUse.weTxtYourConduct); 


		//Click on Content on site link
		gl.clickLink(Camel_TermsOfUse.lnkContentOnSite,"Content on site link");
		//verify the Content on site content
		gl.fnContentValidation( txtContentOnSite,Camel_TermsOfUse.weTxtContentOnSite); 



		//Click on Our privacy policy link
		gl.clickLink(Camel_TermsOfUse.lnkOurPrivacyPolicy,"Our privacy policy link");
		//verify the Our privacy policy content
		gl.fnContentValidation( txtOurPrivacyPolicy,Camel_TermsOfUse.weTxtOurPrivacyPolicy); 
		Thread.sleep(4000);
		//Click on privacy policy link
		gl.clickLink(Camel_TermsOfUse.lnkPrivacyPolicy," privacy policy link");
		//Navigate to new tab
		gl.fnSwitchToSucceedingTab();
		//verify page displayed
		gl.VerifyPageDisplayedUsingPageTitle("Privacy Policy and Your California Privacy Rights");
		Thread.sleep(6000);
		//switch to previous tab
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();


		//Click on Intellectual property issues link
		gl.clickLink(Camel_TermsOfUse.lnkIntellectualPropertyIssues,"Intellectual property issues link");
		//verify the intellectual property issue's content
		gl.fnContentValidation( txtIntellectualPropertyIssues,Camel_TermsOfUse.weTxtIntellectualPropertyIssues); 


		//Click on Site availabitlity link
		gl.clickLink(Camel_TermsOfUse.lnkSiteAvailability,"Site availability link");
		//verify the site availability content
		gl.fnContentValidation( txtSiteAvailability,Camel_TermsOfUse.weTxtSiteAvailability); 


		//Click on Choice of law link
		gl.clickLink(Camel_TermsOfUse.lnkChoiceOfLaw,"Choice of  link");
		//verify the Choice of law content
		gl.fnContentValidation( txtChoiceOfLaw,Camel_TermsOfUse.weTxtChoiceOfLaw); 


		//Click on Disclaimer link
		gl.clickLink(Camel_TermsOfUse.lnkDisclaimer,"Disclaimer link");
		//verify the Disclaimer content
		gl.fnContentValidation( txtDisclaimer,Camel_TermsOfUse.weTxtDisclaimer); 


		//Click on Indemnity link
		gl.clickLink(Camel_TermsOfUse.lnkIndemnity,"Indemnity link");
		//verify the Indemnity content
		gl.fnContentValidation( txtIndemnity,Camel_TermsOfUse.weTxtIndemnity); 


		//Click on Resolving disputes link
		gl.clickLink(Camel_TermsOfUse.lnkResolvingDisputes,"Resolving disputes link");
		//verify the Resolving content
		gl.fnContentValidation( txtResolvingDisputes,Camel_TermsOfUse.weTxtResolvingDisputes); 
		Thread.sleep(4000);
		//Click on contact us link
		gl.clickLink(Camel_TermsOfUse.lnkContactUs,"Contact us link");
		//switch to contact us
		gl.fnSwitchToSucceedingTab();
		//verify page displayed
		gl.VerifyPageDisplayedUsingPageTitle("Contact us");
		Thread.sleep(4000);
		//back to previous tab
		gl.fnCloseCurrentTab();
		gl.fnSwitchToDefaultTab();
		//Click on here link
		gl.clickLink(Camel_TermsOfUse.lnkHere,"here link");



		//Click on Special Notice link
		gl.clickLink(Camel_TermsOfUse.lnkSpecialNotice," Special notice link");
		//verify the special notice content
		gl.fnContentValidation( txtSpecialNotice,Camel_TermsOfUse.weTxtSpecialNotice); 


		//Click on Electronic signature link
		gl.clickLink(Camel_TermsOfUse.lnkElectronicSignature,"Electronic signature link");
		//verify the electronic signature content
		gl.fnContentValidation( txtElectronicSignature,Camel_TermsOfUse.weTxtElectronicSignature); 


		//Click on Miscellaneous link
		gl.clickLink(Camel_TermsOfUse.lnkMiscellaneous,"Miscellaneous link");
		//verify the miscellaneous content
		gl.fnContentValidation( txtMiscellaneous,Camel_TermsOfUse.weTxtMiscellaneous); 










	}






	public void afterMethod() {
		driver.quit();
		gl.endReport();
		//extent.flush();
	}



}
