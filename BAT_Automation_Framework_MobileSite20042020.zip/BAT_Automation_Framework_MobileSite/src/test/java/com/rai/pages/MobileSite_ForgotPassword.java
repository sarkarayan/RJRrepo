package com.rai.pages;

import java.io.IOException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.framework.Status;
import com.rai.pageObjects.MobileSiteForgotPasswordPageObjects;
import com.rai.pageObjects.MobileSiteLoginPageObjects;
import com.rai.pageObjects.MobilesitePageObjects;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;

public class MobileSite_ForgotPassword extends BaseClass {

	String testcaseName;

	public MobileSite_ForgotPassword(String testcaseName) {
		this.testcaseName = testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper The {@link ScriptHelper} object passed from the
	 *                     {@link DriverScript}
	 */

	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	private WebElement getPageElement(MobileSiteForgotPasswordPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("ForgotUsername Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}

	private WebElement getPageElement(MobileSiteLoginPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Mobile Site Login Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}

	private WebElement getPageElement(MobilesitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Mobile Site Login Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}

	}

	public void invokeApplication_MobileSite() {
		String websiteURL = dataTable.getData("General_Data", "URL");
		driver.get(websiteURL);
		driver.manage().deleteAllCookies();
		driver.get(websiteURL);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
	}

	public void navigateToForgotPasswordPage() throws IOException {
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btnSignInTab),MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.lnktxt_Forgotpassword),MobileSiteLoginPageObjects.lnktxt_Forgotpassword.getObjectname());
	}

	public void forgotPassword_NegativeValidationsUsernamePage() throws Exception {
		String InvalidUserIdformat = dataTable.getData("General_Data", "InvalidUserIDformat");
		String InvalidUserId = dataTable.getData("General_Data", "NonExistUserId");

		String Errormsg_NoUserId = "Please enter your Username / Email Address.";
		String Errormsg_UserIdInvalidformat = "Username must be a combination of 8-30 letters and numbers.";
		String Errormsg_InvalidUserId = "We could not locate your Login ID, please try again.";

		// Clicking on Continue without UserId data
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordUsernameContinue),MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordNoUsername),MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordNoUsername.getObjectname(),Errormsg_NoUserId);
		Thread.sleep(2000);
		// User entered Invalid UserID format
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordUsername), InvalidUserIdformat,MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordUsername.getObjectname());
		Thread.sleep(2000);
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordUsernameContinue),MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
		Thread.sleep(2000);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordInvalidUserIdformat),MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordInvalidUserIdformat.getObjectname(),
				Errormsg_UserIdInvalidformat);
		Thread.sleep(2000);
		// User enters Invalid/Inactive UserId
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordUsername), InvalidUserId,MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordUsername.getObjectname());
		Thread.sleep(3000);
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordUsernameContinue),MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
		Thread.sleep(5000);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordInvalidUserId),MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordInvalidUserId.getObjectname(),
				Errormsg_InvalidUserId);

	}

	public void forgotPassword_EnterValidUsername() throws IOException {
		String Email = dataTable.getData("General_Data", "Email");

		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordUsername), Email,
				MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordUsername.getObjectname());
		// //Thread.sleep(2000);
		commonFunction.clickIfElementPresentJavaScript(getPageElement(MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordUsernameContinue),
				MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
		// commonFunction.sendKeyENTER(getPageElement(MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordUsernameContinue),MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
	}

	public void forgotPassword_NegativeValidationsGeneralInfoPage() throws InterruptedException, IOException {
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String InvalidLastName = dataTable.getData("General_Data", "InvalidLastName");
		String InvalidAddress = dataTable.getData("General_Data", "InvalidAddress");
		String InvalidZipcode = dataTable.getData("General_Data", "InvalidZipcode");
		String City = dataTable.getData("General_Data", "City");
		String State = dataTable.getData("General_Data", "State");

		String date = dataTable.getData("General_Data", "DOB");
		String dateParts[] = date.split("/");
		String month = dateParts[0];
		String day = dateParts[1];
		String year = dateParts[2];

		String Errormessage_ForgotPasswordNoDOB = "Please provide a Date Of Birth";
		String Errormessage_ForgotPasswordNoDataonGeneralInfo = "Please fix the errors above";
		String Errormessage_ForgotPasswordNoLegalName = "Please enter your legal name";
		String Errormessage_ForgotPasswordNoAddress = "Please provide a street address";
		String Errormessage_ForgotPasswordNoZipcode = "Please provide a ZIP Code";
		String Errormessage_ForgotPasswordNoCity = "Please Provide City";
		String Errormessage_ForgotPasswordNoState = "Please Provide State";
		String Errormessage_ForgotPasswordInvalidUserInfo = "We were not able to find your information. Please check and try again.";

		// Clicking on Continue without any data on GeneralInfo page
		//// Thread.sleep(6000);
		// commonFunction.scrollIntoView(getPageElement(MobileSiteForgotPasswordPageObjects.lnk_ForgotPasswordGeneralInfoLogin));
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordFirstName), FirstName,
				MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordFirstName.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordGeneralInformation),
				MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordGeneralInformation.getObjectname());
		// commonFunction.clickIfElementPresentJavaScript(getPageElement(MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordGeneralInformation),
		// MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordGeneralInformation.getObjectname());
		
			//commonFunction.scrollIntoView(getPageElement(MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordNoDataonGeneralInfo));
		
          Thread.sleep(4000);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordNoDataonGeneralInfo),
				MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordNoDataonGeneralInfo.getObjectname(),
				Errormessage_ForgotPasswordNoDataonGeneralInfo);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordNoDOB),
				MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordNoDOB.getObjectname(),
				Errormessage_ForgotPasswordNoDOB);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordNoLegalName),
				MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordNoLegalName.getObjectname(),
				Errormessage_ForgotPasswordNoLegalName);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordNoAddress),
				MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordNoAddress.getObjectname(),
				Errormessage_ForgotPasswordNoAddress);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordNoZipcode),
				MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordNoZipcode.getObjectname(),
				Errormessage_ForgotPasswordNoZipcode);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordNoCity),
				MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordNoCity.getObjectname(),
				Errormessage_ForgotPasswordNoCity);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordNoState),
				MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordNoState.getObjectname(),
				Errormessage_ForgotPasswordNoState);

		// User entered Invalid user info on GeneralInfo page
		commonFunction.selectAnyElement(getPageElement(MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordBirthMonth), month,
				MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordBirthMonth.getObjectname());
		// Thread.sleep(5000);
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordBirthDay), day,
				MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordBirthDay.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordBirthYear), year,
				MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordFirstName), FirstName,
				MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordLastName),
				InvalidLastName, MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordAddress),
				InvalidAddress, MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordZipcode), InvalidZipcode,
				MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordZipcode.getObjectname());
		// Thread.sleep(4000);
		if (getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordCity).getText().contains("")) {
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordCity), City,
					MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordCity.getObjectname());
			commonFunction.selectAnyElementByValue(getPageElement(MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordState), State,
					MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordState.getObjectname());
		}

		commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordGeneralInformation),
				MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordGeneralInformation.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordUsernotfound),
				MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordUsernotfound.getObjectname(),
				Errormessage_ForgotPasswordInvalidUserInfo);

	}
	

	public void forgotPassword_ValidDataOnGeneralInformationPage() throws InterruptedException, IOException {
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data", "City");
		String State = dataTable.getData("General_Data", "State");
		String DOB = dataTable.getData("General_Data", "DOB");

		String date = DOB;
		String dateParts[] = date.split("/");
		String month = dateParts[0];
		String day = dateParts[1];
		String year = dateParts[2];

		commonFunction.selectAnyElement(getPageElement(MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordBirthMonth), month,
				MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordBirthMonth.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordBirthDay), day,
				MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordBirthDay.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordBirthYear), year,
				MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordFirstName), FirstName,
				MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordLastName),
				LastName, MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordAddress),
				Address, MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordZipcode), Zipcode,
				MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordZipcode.getObjectname());
		// Thread.sleep(2000);
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordCity), City,
				MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordCity.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordState), State,
				MobileSiteForgotPasswordPageObjects.drpdwn_ForgotPasswordState.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordGeneralInformation),
				MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordGeneralInformation.getObjectname());

	}

	public void forgotPassword_NegativeValidationsVerifyIdentity() throws InterruptedException, IOException {
		try {
			String InvalidChallengeAnswer = dataTable.getData("General_Data", "InvalidChallengeAnswer");

			String Errormessage_ForgotPasswordNoChallengeAnswer = "Please provide an answer to account recovery question";
			String Errormessage_ForgotPasswordIncorrectChallengeAnswer = "The answer does not match our records. Please re-enter your answer to the challenge question";

			// ChallengeAnswer not entered on VerifyIdentity Page
			// Thread.sleep(4000);
			//commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordVerifyIdentity),
					//MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
			 //Thread.sleep(5000);
			//commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordNoChallengeAnswer),
					//MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordNoChallengeAnswer.getObjectname(),
					//Errormessage_ForgotPasswordNoChallengeAnswer);

			// User entered Incorrect ChallengeAnswer on VerifyIdentity page
			
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordChallengeAnswer),
					InvalidChallengeAnswer,
					MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordChallengeAnswer.getObjectname());
			 Thread.sleep(2000);
			commonFunction.clickIfElementPresentJavaScript(getPageElement(MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordVerifyIdentity), MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
			
			Thread.sleep(5000);
			commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordInvalidChallengeAnswer),
					MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordInvalidChallengeAnswer.getObjectname(),
					Errormessage_ForgotPasswordIncorrectChallengeAnswer);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 

	}

	public void forgotPassword_ValidDataVerifyIdentity() throws InterruptedException, IOException {
		try {
			String ChallengeAnswer = dataTable.getData("General_Data", "ChallengeAnswer");

			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordChallengeAnswer), ChallengeAnswer,
					MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordChallengeAnswer.getObjectname());
			// Thread.sleep(2000);
			commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordVerifyIdentity),
					MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 Thread.sleep(4000);

	}

	public void forgotPassword_NegativeValidationsResetPassword() throws InterruptedException, IOException {
		try {
			String InvalidPasswordformat = dataTable.getData("General_Data", "InvalidPasswordformat");
			String DifferntPassword = dataTable.getData("General_Data", "InvalidPassword");
			String Password = dataTable.getData("General_Data", "Password");

			String Errormessage_ForgotPasswordNoPassword = "Please provide a password";
			String Errormessage_ForgotPasswordInvalidPasswordformat = "Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.";
			String Errormessage_ForgotPasswordDiffPassword = "Passwords did not match";
			Thread.sleep(5000);
			// User clicked Continue without entering Password on ResetPassword page
			commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordResetPassword),
					MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordResetPassword.getObjectname());
			Thread.sleep(5000);
			//commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordNoPasswordentered),
					//MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordNoPasswordentered.getObjectname(),
					//Errormessage_ForgotPasswordNoPassword);

			// User entered Invalid format in Password field
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordPassword), InvalidPasswordformat,
					MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordPassword.getObjectname());
			commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordInvalidPasswordformatentered),
					MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordInvalidPasswordformatentered.getObjectname(),
					Errormessage_ForgotPasswordInvalidPasswordformat);

			// User entered different data in Password & ConfirmPassword fields
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordPassword), Password,
					MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordPassword.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordConfirmPassword), DifferntPassword,
					MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordConfirmPassword.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordResetPassword),
					MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordResetPassword.getObjectname());
			// Thread.sleep(4000);
			commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordDifferentPasswordentered),
					MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordDifferentPasswordentered.getObjectname(),
					Errormessage_ForgotPasswordDiffPassword);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}

	public void forgotPassword_ValidDataResetPassword() throws InterruptedException, IOException {
		String Password = dataTable.getData("General_Data", "Password");
		String ConfirmPassword = dataTable.getData("General_Data", "Password");

		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordPassword), Password,MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordConfirmPassword), ConfirmPassword,MobileSiteForgotPasswordPageObjects.txt_ForgotPasswordConfirmPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordResetPassword),MobileSiteForgotPasswordPageObjects.btn_ForgotPasswordResetPassword.getObjectname());
		// Thread.sleep(4000);
	}

	public void closeSavePasswordPopUp() throws IOException {
		
		Set<String> views = null;
		try {
			
			if(driver instanceof AndroidDriver)
			{
				((AndroidDriver) driver).context("NATIVE_APP");
			}
			
			if (driver instanceof AndroidDriver
					&& driver.findElement(By.id("com.android.chrome:id/infobar_close_button")).isDisplayed()) {

				views = ((AndroidDriver<MobileElement>) driver).getContextHandles();
				
				
				/*
				 * MobileElement neverBtn = ((AndroidDriver<MobileElement>)driver).
				 * findElementByAndroidUIAutomator("new UiSelector().text(\"Never\")");
				 * neverBtn.click();
				 */
				commonFunction.clickIfElementPresent(
						getPageElement(MobileSiteForgotPasswordPageObjects.close_SavePassword),
						MobileSiteForgotPasswordPageObjects.close_SavePassword.getObjectname());
				for (String view : views) {
					if (view.contains("WEBVIEW")) {
						((AndroidDriver) driver).context(view);
					}
				}
			}

		} catch (NoSuchElementException e) {
			for (String view : views) {
				if (view.contains("WEBVIEW")) {
					((AndroidDriver) driver).context(view);
				}
			}
		}
	}

	public void forgotPassword_NegativeValidationsCongratsPage() throws IOException {
		String Email = dataTable.getData("General_Data", "Email");

		String Errormessage_ForgotPasswordNoDataonCongratspage = "Please fix the errors above";
		String Errormessage_ForgotPasswordNoPasswordonCongratspage = "Please enter your password.";

		// User clicked on Login without any data on Congrats Page
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotPasswordPageObjects.btn_CongratsPageLoginbutton),
				MobileSiteForgotPasswordPageObjects.btn_CongratsPageLoginbutton.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordCongratsPageNoDataEntered),
				MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordCongratsPageNoDataEntered.getObjectname(),
				Errormessage_ForgotPasswordNoDataonCongratspage);

		// User clicked on Login without Password
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotPasswordPageObjects.txt_CongratsPageUsername), Email,
				MobileSiteForgotPasswordPageObjects.txt_CongratsPageUsername.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotPasswordPageObjects.btn_CongratsPageLoginbutton),
				MobileSiteForgotPasswordPageObjects.btn_CongratsPageLoginbutton.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordCongratsPagePasswordNotentered),
				MobileSiteForgotPasswordPageObjects.errormsg_ForgotPasswordCongratsPagePasswordNotentered.getObjectname(),Errormessage_ForgotPasswordNoPasswordonCongratspage);

	}

	public void forgotPassword_CongratsPage() throws IOException {
		String Email = dataTable.getData("General_Data", "Email");
		String Password = dataTable.getData("General_Data", "Password");

		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotPasswordPageObjects.txt_CongratsPageUsername),Email, MobileSiteForgotPasswordPageObjects.txt_CongratsPageUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotPasswordPageObjects.txt_CongratsPagePassword), Password,
				MobileSiteForgotPasswordPageObjects.txt_CongratsPagePassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotPasswordPageObjects.btn_CongratsPageLoginbutton),
				MobileSiteForgotPasswordPageObjects.btn_CongratsPageLoginbutton.getObjectname());

	}

	public void navigateToRevelVeloForgotPasswordPage() throws IOException {
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.lnktxt_RevelVeloForgotPassword),MobilesitePageObjects.lnktxt_RevelVeloForgotPassword.getObjectname());
	}

	public void navigateToVUSEForgotPasswordPage() throws IOException {
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.loginLnk_VUSECertifyAgePage),
				MobilesitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.lnk_VUSELoginForgotPassword),
				MobilesitePageObjects.lnk_VUSELoginForgotPassword.getObjectname());
	}

}
