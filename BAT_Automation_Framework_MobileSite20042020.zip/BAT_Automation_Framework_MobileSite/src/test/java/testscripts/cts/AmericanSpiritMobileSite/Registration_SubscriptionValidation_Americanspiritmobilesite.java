package testscripts.cts.AmericanSpiritMobileSite;

import java.sql.ResultSet;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.MobileSiteHomePageComponents;
import com.rai.pages.MobileSite_Newuser_RegistrationSSN;
import com.rai.pages.Mobilesite_DatabaseValidations;



@Listeners(ExtentITestListenerClassAdapter.class)
public class Registration_SubscriptionValidation_Americanspiritmobilesite extends BaseClass{


	Mobilesite_DatabaseValidations mobilesiteSubscription;
	
	public Registration_SubscriptionValidation_Americanspiritmobilesite() {
		super();
		
	}
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("WEB_ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("ZY224ZZNBC")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		mobilesiteSubscription = new Mobilesite_DatabaseValidations(this.getClass().getSimpleName());
		//gl= new GenericLib(this.getClass().getSimpleName());
		//gl.start_report(this.getClass().getSimpleName(), "Verify the forgot username flow", properties.getProperty("ApplicationUrl"));
	}
	
	@Test
	public void verifyUserSubscriptionafterRegistration_AmericanSpiritMobilesite(ResultSet SubscriptionResults, String DNE_GRIZZLY, String DNE_CAMEL, String DNE_NEWPORT, String DNE_PALLMALL, String DNE_NAS, String DNE_VUSE, String DNE_REVEL, String DNE_VELO) throws Exception
	{
		
		mobilesiteSubscription.results_SubscriptionsValidation();
		mobilesiteSubscription.validation_CamelSubscription(SubscriptionResults, DNE_CAMEL);    
		mobilesiteSubscription.validation_GrizzlySubscription(SubscriptionResults, DNE_GRIZZLY);
		mobilesiteSubscription.validation_NewportSubscription(SubscriptionResults, DNE_NEWPORT);
		mobilesiteSubscription.validation_PallmallSubscription(SubscriptionResults, DNE_PALLMALL);
		mobilesiteSubscription.validation_NASCIGSSubscription(SubscriptionResults, DNE_NAS);
		mobilesiteSubscription.validation_VUSESubscription(SubscriptionResults, DNE_VUSE);
		mobilesiteSubscription.validation_RevelSubscription(SubscriptionResults, DNE_REVEL);
		mobilesiteSubscription.validation_VeloSubscription(SubscriptionResults, DNE_VELO);
	     		
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		//gl.endReport();
		
	}

}
