package testscripts.cts.CamelMobileSiteAndSPA;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.BrandWebsite_ValidationsForgotUsername;
import com.rai.pages.MobileSiteHomePageComponents;
import com.rai.pages.Mobilesite_Accountlocked;

public class Loginwith128Characters_mobilesite extends BaseClass{
	
	Mobilesite_Accountlocked accountlocked;
	MobileSiteHomePageComponents mobileSiteHomePageComponents;
	public Loginwith128Characters_mobilesite() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("WEB_ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("98892A4144365A334C")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		accountlocked = new Mobilesite_Accountlocked(this.getClass().getSimpleName());
		mobileSiteHomePageComponents = new MobileSiteHomePageComponents(this.getClass().getSimpleName());
		gl= new GenericLib(this.getClass().getSimpleName());
	}
	
	@Test
	public void verifyLoginwith128Characters_mobilesite() throws Exception {
		
		
		accountlocked.invokeApplication_mobilesite();
		accountlocked.loginPage_Loginwith128characters();
		
		
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		//gl.endReport();
		
	}

	
	

}
