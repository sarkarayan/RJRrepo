package testscripts.cts.CamelMobileSiteAndSPA;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.Mobilesite_Login_OtherbrandUserwithLoginResetN;
import com.rai.pages.Mobilesite_Login_OtherbrandUserwithLoginResetY;

@Listeners(ExtentITestListenerClassAdapter.class)
public class Login_OtherBrandSUserandResetY_Mobilesite extends BaseClass{

	Mobilesite_Login_OtherbrandUserwithLoginResetY mobilesiteresetY;
	
	
	public Login_OtherBrandSUserandResetY_Mobilesite() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("WEB_ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("ZY224ZZNBC")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		mobilesiteresetY = new Mobilesite_Login_OtherbrandUserwithLoginResetY(this.getClass().getSimpleName());
		gl= new GenericLib(this.getClass().getSimpleName());
		//gl.start_report(this.getClass().getSimpleName(), "Verify the forgot username flow", properties.getProperty("ApplicationUrl"));
	}
	
	@Test
	public void usernameNotExists_OtherbrandSUserwithResetY() throws Exception {
		
		mobilesiteresetY.invokeApplication_brandwebsite();
		mobilesiteresetY.login_EnterValidData();
		mobilesiteresetY.loginPage_OtherBrandHandSUserwithResetY();
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		//gl.endReport();
		
	}

}
