package testscripts.cts.NewportWebsite;

import java.sql.ResultSet;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.MobileSite_Newuser_RegistrationSSN;
import com.rai.pages.Mobilesite_DatabaseValidations;
import com.rai.pages.Mobilesite_SGWImageandTextValidation;



@Listeners(ExtentITestListenerClassAdapter.class)
public class Registration_ConsumerSourceValidation_Newportmobilesite extends BaseClass{


	Mobilesite_DatabaseValidations mobilesiteConsumerSource;
	 
	public Registration_ConsumerSourceValidation_Newportmobilesite() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("WEB_ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("ZY224ZZNBC")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		mobilesiteConsumerSource= new Mobilesite_DatabaseValidations(this.getClass().getSimpleName());
		gl= new GenericLib(this.getClass().getSimpleName());
		//gl.start_report(this.getClass().getSimpleName(), "Verify the forgot username flow", properties.getProperty("ApplicationUrl"));
	}
	
	
	@Test
	public void verifyConsumerSourceafterRegistration(ResultSet AcctnoResults, String CONSUMER_SOURCE, String SOURCESYSTEM) throws Exception {
		
		mobilesiteConsumerSource.results_ConsumerAcctNo();
		mobilesiteConsumerSource.results_ConsumerAcctNo_SourceSystemValidation(AcctnoResults, SOURCESYSTEM);
		mobilesiteConsumerSource.results_ConsumerAcctNo_ConsumerSourceValidation(AcctnoResults, CONSUMER_SOURCE);    
	     
		
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		//gl.endReport();
		
	}

}
