package testscripts.cts.CamelWebsite;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.BrandWebsite_MyProfileValidations;


@Listeners(ExtentITestListenerClassAdapter.class)
public class ProfilePage_UserProfileNegativeValidations_CamelWebsite extends BaseClass{


	BrandWebsite_MyProfileValidations brandwebsiteProfileValidations;
	
	
	public ProfilePage_UserProfileNegativeValidations_CamelWebsite() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("LOCAL")String executionMode  , @Optional("")String toolName, @Optional("")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		
		brandwebsiteProfileValidations = new BrandWebsite_MyProfileValidations(this.getClass().getSimpleName());
		
		
		gl= new GenericLib(this.getClass().getSimpleName());
		gl.start_report(this.getClass().getSimpleName(), "Verify UserProfile Validations", properties.getProperty("ApplicationUrl"));
	}
	
	@Test
	public void verifyProfile_UserProfileValidations() throws Exception {
		
		brandwebsiteProfileValidations.invokeApplication_brandwebsite();
		brandwebsiteProfileValidations.loginPage_AppToWebsiteLogin();
		brandwebsiteProfileValidations.camelProfile_NavigatetoMyProfile();
		brandwebsiteProfileValidations.profileUpdate_UserInfoValidations();
		brandwebsiteProfileValidations.profileUpdate_NegativeValidationsUpdateEmail();
		brandwebsiteProfileValidations.profileUpdate_NegativeValidationsUpdatePassword();
		brandwebsiteProfileValidations.profileUpdate_NegativevalidationsUpdateChallegeAnswer();
		brandwebsiteProfileValidations.Camel_logout();
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		gl.endReport();
		
	}

}
