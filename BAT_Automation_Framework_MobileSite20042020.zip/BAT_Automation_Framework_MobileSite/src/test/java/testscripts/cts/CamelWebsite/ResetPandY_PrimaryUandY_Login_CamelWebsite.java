package testscripts.cts.CamelWebsite;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.BrandWebsite_LoginFlow_LoginResetPandY_PrimaryUandY;

@Listeners(ExtentITestListenerClassAdapter.class)
public class ResetPandY_PrimaryUandY_Login_CamelWebsite extends BaseClass {

	BrandWebsite_LoginFlow_LoginResetPandY_PrimaryUandY brandwebsiteRegistrationLoginReset;

	public ResetPandY_PrimaryUandY_Login_CamelWebsite() {
		super();
	}

	@BeforeMethod
	@Parameters({ "executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser",
			"browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("LOCAL") String executionMode, @Optional("") String toolName,
			@Optional("") String mobileExecutionPlatform, @Optional("") String mobileOsVersion,
			@Optional("") String deviceName, @Optional("CHROME") String browser, @Optional("") String browserVersion,
			@Optional("") String platform, @Optional("") String platformVersion) {
		initializeWebDriver(executionMode, toolName, mobileExecutionPlatform, mobileOsVersion, deviceName, browser,
				browserVersion, platform, platformVersion);

		brandwebsiteRegistrationLoginReset = new BrandWebsite_LoginFlow_LoginResetPandY_PrimaryUandY(
				this.getClass().getSimpleName());
		gl = new GenericLib(this.getClass().getSimpleName());
		gl.start_report(this.getClass().getSimpleName(),
				"Verify Login reset flow if Webaccess'U' and LoginReset 'Y' & Primary is 'U' and 'Y'",
				properties.getProperty("ApplicationUrl"));
	}

	@Test
	public void verifyLoginResetFlow_PandY_PrimaryUandY() throws Exception {
		brandwebsiteRegistrationLoginReset.invokeApplication_brandwebsite();
		brandwebsiteRegistrationLoginReset.login_EnterValidDataPandY();
		brandwebsiteRegistrationLoginReset.resetflow_GeneralInfoPageviaLogin();
		brandwebsiteRegistrationLoginReset.resetflow_NegativeValidationsAccountInfoPage();
		brandwebsiteRegistrationLoginReset.resetflow_AccountInfoPage();
		brandwebsiteRegistrationLoginReset.resetflow_CongratsPage();
	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
		gl.endReport();

	}

}
