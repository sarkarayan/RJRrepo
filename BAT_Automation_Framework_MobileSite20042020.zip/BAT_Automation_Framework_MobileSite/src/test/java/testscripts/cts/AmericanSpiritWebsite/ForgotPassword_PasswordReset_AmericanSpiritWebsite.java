package testscripts.cts.AmericanSpiritWebsite;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.BrandWebsite_ValidationsForgotPassword;

@Listeners(ExtentITestListenerClassAdapter.class)
public class ForgotPassword_PasswordReset_AmericanSpiritWebsite extends BaseClass {
	BrandWebsite_ValidationsForgotPassword brandwebsiteValidationsForgotPassword;
	public ForgotPassword_PasswordReset_AmericanSpiritWebsite() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("LOCAL")String executionMode  , @Optional("")String toolName, @Optional("")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		brandwebsiteValidationsForgotPassword = new BrandWebsite_ValidationsForgotPassword(this.getClass().getSimpleName());
		gl= new GenericLib(this.getClass().getSimpleName());
		gl.start_report(this.getClass().getSimpleName(), "Verify ForgotPassword flow", properties.getProperty("ApplicationUrl"));
	}
	
	@Test
	public void verifyForgotPasswordFlow_CamelWebsite() throws Exception {
		brandwebsiteValidationsForgotPassword.invokeApplication_brandwebsite();
		brandwebsiteValidationsForgotPassword.navigateToForgotPasswordPage();
		brandwebsiteValidationsForgotPassword.forgotPassword_EnterValidUsername();
		brandwebsiteValidationsForgotPassword.forgotPassword_ValidDataOnGeneralInformationPage();
		brandwebsiteValidationsForgotPassword.forgotPassword_ValidDataVerifyIdentity();
		brandwebsiteValidationsForgotPassword.forgotPassword_ValidDataResetPassword();
		brandwebsiteValidationsForgotPassword.forgotPassword_NegativeValidationsCongratsPage();
		brandwebsiteValidationsForgotPassword.forgotPassword_CongratsPage();
		
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		//gl.endReport();
		
	}
}
