package testscripts.cts.AmericanSpiritWebsite;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.BrandWebsite_ForgotPassword_LoginResetUandY;


@Listeners(ExtentITestListenerClassAdapter.class)
public class ResetUandY_ForgotPassword_AmericanSpiritWebsite extends BaseClass{


	BrandWebsite_ForgotPassword_LoginResetUandY brandwebsiteForgotPasswordLoginReset;
	
	public ResetUandY_ForgotPassword_AmericanSpiritWebsite() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("LOCAL")String executionMode  , @Optional("")String toolName, @Optional("")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		
		brandwebsiteForgotPasswordLoginReset = new BrandWebsite_ForgotPassword_LoginResetUandY(this.getClass().getSimpleName());
		gl= new GenericLib(this.getClass().getSimpleName());
		gl.start_report(this.getClass().getSimpleName(), "Verify Login reset flow if Webaccess'U' and LoginReset 'Y' in ForgotPassword flow", properties.getProperty("ApplicationUrl"));
	}
	
	@Test
	public void verifyForgotPassword_LoginResetFlow() throws Exception {
		
		
		brandwebsiteForgotPasswordLoginReset.invokeApplication_brandwebsite();
		brandwebsiteForgotPasswordLoginReset.forgotPassword_EnterValidUsername();
		brandwebsiteForgotPasswordLoginReset.forgotPassword_ValidDataOnGeneralInformationPage();
		brandwebsiteForgotPasswordLoginReset.resetflow_NegativeValidationsAccountInfoPage();
		brandwebsiteForgotPasswordLoginReset.resetflow_AccountInfoPage();
		brandwebsiteForgotPasswordLoginReset.resetflow_CongratsPage();
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		gl.endReport();
		
	}

}
