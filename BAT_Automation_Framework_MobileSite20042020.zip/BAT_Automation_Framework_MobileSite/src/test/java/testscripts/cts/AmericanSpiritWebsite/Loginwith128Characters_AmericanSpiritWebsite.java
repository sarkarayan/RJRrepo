package testscripts.cts.AmericanSpiritWebsite;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.BrandWebsite_LoginPageValidationsandAccountLock;


@Listeners(ExtentITestListenerClassAdapter.class)
public class Loginwith128Characters_AmericanSpiritWebsite extends BaseClass{


	BrandWebsite_LoginPageValidationsandAccountLock brandwebsiteLoginPageValidations;
	
	public Loginwith128Characters_AmericanSpiritWebsite() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("LOCAL")String executionMode  , @Optional("")String toolName, @Optional("")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		
		brandwebsiteLoginPageValidations = new BrandWebsite_LoginPageValidationsandAccountLock(this.getClass().getSimpleName());
		gl= new GenericLib(this.getClass().getSimpleName());
		gl.start_report(this.getClass().getSimpleName(), "Verify if user can login with max.128 characters", properties.getProperty("ApplicationUrl"));
	}
	
	@Test
	public void verifyLoginwith128Characters() throws Exception {
		
		
		brandwebsiteLoginPageValidations.invokeApplication_brandwebsite();
		brandwebsiteLoginPageValidations.loginPage_Loginwith128characters();
		
		
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		gl.endReport();
		
	}

}
