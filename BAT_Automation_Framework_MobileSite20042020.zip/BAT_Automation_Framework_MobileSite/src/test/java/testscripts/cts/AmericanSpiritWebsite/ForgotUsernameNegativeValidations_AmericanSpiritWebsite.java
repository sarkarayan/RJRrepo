package testscripts.cts.AmericanSpiritWebsite;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.BrandWebsite_ValidationsForgotUsername;

@Listeners(ExtentITestListenerClassAdapter.class)
public class ForgotUsernameNegativeValidations_AmericanSpiritWebsite extends BaseClass {
	BrandWebsite_ValidationsForgotUsername brandwebsiteValidationsForgotUsername;
	public ForgotUsernameNegativeValidations_AmericanSpiritWebsite() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("LOCAL")String executionMode  , @Optional("")String toolName, @Optional("")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		
		brandwebsiteValidationsForgotUsername = new BrandWebsite_ValidationsForgotUsername(this.getClass().getSimpleName());
		gl= new GenericLib(this.getClass().getSimpleName());
		gl.start_report(this.getClass().getSimpleName(), "Verify the validations in ForgotUsername flow", properties.getProperty("ApplicationUrl"));
	}
	
	@Test
	public void verifyForgotUserNameFlowNegativeValidations_CamelWebsite() throws Exception {
		brandwebsiteValidationsForgotUsername.invokeApplication_brandwebsite();
		brandwebsiteValidationsForgotUsername.navigateToForgotUsernamePage();
		brandwebsiteValidationsForgotUsername.forgotUsername_NegativeValidationsAccountInformation();
		brandwebsiteValidationsForgotUsername.forgotUsername_ValidDataAccountInformation();
		brandwebsiteValidationsForgotUsername.forgotUsername_NegativeValidationsVerifyIdentity();
		
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		//gl.endReport();
		
	}
}
