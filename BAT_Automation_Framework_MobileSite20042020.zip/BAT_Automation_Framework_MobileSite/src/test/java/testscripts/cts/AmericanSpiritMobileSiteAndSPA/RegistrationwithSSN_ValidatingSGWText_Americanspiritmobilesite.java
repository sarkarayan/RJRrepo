package testscripts.cts.AmericanSpiritMobileSiteAndSPA;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.BrandWebsite_RegistrationSSN;
import com.rai.pages.MobileSiteHomePageComponents;
import com.rai.pages.MobileSite_Newuser_RegistrationSSN;
import com.rai.pages.Mobilesite_SGWImageandTextValidation;


@Listeners(ExtentITestListenerClassAdapter.class)
public class RegistrationwithSSN_ValidatingSGWText_Americanspiritmobilesite extends BaseClass{


	MobileSite_Newuser_RegistrationSSN mobileSiteSSNRegesterCamel;
	Mobilesite_SGWImageandTextValidation mobilesiteRegistrationSGWText;
	
	
	public RegistrationwithSSN_ValidatingSGWText_Americanspiritmobilesite() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("WEB_ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("ZY224ZZNBC")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		mobileSiteSSNRegesterCamel = new MobileSite_Newuser_RegistrationSSN(this.getClass().getSimpleName());
		mobilesiteRegistrationSGWText = new Mobilesite_SGWImageandTextValidation(this.getClass().getSimpleName());
		//gl= new GenericLib(this.getClass().getSimpleName());
		//gl.start_report(this.getClass().getSimpleName(), "Verify the forgot username flow", properties.getProperty("ApplicationUrl"));
	}
	
	@Test
	public void verifySGWtextinRegistrationwithSSN() throws Exception {
		
		mobileSiteSSNRegesterCamel.invokeApplication_brandwebsite();
		mobileSiteSSNRegesterCamel.navigateToRegistrationPage();
		mobilesiteRegistrationSGWText.validatingSGWtext();
		mobileSiteSSNRegesterCamel.registration_EnterValidDataonStep1();
		mobilesiteRegistrationSGWText.validatingSGWtext();
		mobileSiteSSNRegesterCamel.registration_EnterValidDataonStep2();
		mobilesiteRegistrationSGWText.validatingSGWtext();
		mobileSiteSSNRegesterCamel.registration_ValidateAgeBySSN();
		//brandwebsiteRegistrationSGWText.validatingSGWtext();
		//brandwebsiteRegistrationSSN.registration_NavigatetoHomePage();
		
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		//gl.endReport();
		
	}

}
