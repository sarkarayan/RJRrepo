package testscripts.cts.AmericanSpiritMobileSiteAndSPA;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.MobileSiteHomePageComponents;
import com.rai.pages.MobileSite_ForgotPassword;
import com.rai.pages.MobileSite_Newuser_RegistrationSSN;

@Listeners(ExtentITestListenerClassAdapter.class)
public class Registration_New_User_With_SSN_AmericanSpiritMobilesite extends BaseClass {

	MobileSite_Newuser_RegistrationSSN mobileSiteSSNRegesterCamel;
	MobileSiteHomePageComponents mobileSiteHomePageComponents;
	public Registration_New_User_With_SSN_AmericanSpiritMobilesite() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("WEB_ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("ZY224ZZNBC")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		mobileSiteSSNRegesterCamel = new MobileSite_Newuser_RegistrationSSN(this.getClass().getSimpleName());
		mobileSiteHomePageComponents = new MobileSiteHomePageComponents(this.getClass().getSimpleName());
		gl= new GenericLib(this.getClass().getSimpleName());
		//gl.start_report(this.getClass().getSimpleName(), "Verify the forgot username flow", properties.getProperty("ApplicationUrl"));
	}
	
	@Test
	public void Registration_newuser_ssn_camelmobilesite() throws Exception {
		
		mobileSiteSSNRegesterCamel.invokeApplication_brandwebsite();
		mobileSiteSSNRegesterCamel.navigateToRegistrationPage();
		mobileSiteSSNRegesterCamel.registration_EnterValidDataonStep1();
		mobileSiteSSNRegesterCamel.registration_EnterValidDataonStep2();
		mobileSiteSSNRegesterCamel.registration_ValidateAgeBySSN();
		mobileSiteHomePageComponents.logoutOfMobileSite();
		
		
	}
	
	@AfterMethod
	public void tearDown() {
		driver.close();
		driver.quit();
		//gl.endReport();
		
	}
	
	
	
}
