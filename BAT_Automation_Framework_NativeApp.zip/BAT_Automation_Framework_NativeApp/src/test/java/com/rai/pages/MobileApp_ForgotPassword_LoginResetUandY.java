package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;

import com.rai.pageObjects.AppLoginPageObjects;

import io.appium.java_client.android.AndroidDriver;

public class MobileApp_ForgotPassword_LoginResetUandY extends BaseClass {

	String testcaseName;
	public MobileApp_ForgotPassword_LoginResetUandY(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(AppLoginPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Forgot Password Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	
	public void navigatetoForgotPasswordPage() throws IOException
	{
		commonFunction.scrollDown();  
		WebDriverWait wait = new WebDriverWait(driver, 30);
    	commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.lnk_GrizzlyAPPLoginForgotPassword), AppLoginPageObjects.lnk_GrizzlyAPPLoginForgotPassword.getObjectname());
	}
		
	public void forgotPassword_EnterValidUsername() throws IOException
	{
		String Email = dataTable.getData("General_Data", "Email");
		
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_ForgotPasswordUsername), Email, AppLoginPageObjects.txt_ForgotPasswordUsername.getObjectname());
		//Thread.sleep(2000);
		commonFunction.clickIfElementPresentJavaScript(getPageElement(AppLoginPageObjects.btn_ForgotPasswordUsernameContinue), AppLoginPageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
	    //commonFunction.sendKeyENTER(getPageElement(AppLoginPageObjects.btn_ForgotPasswordUsernameContinue),AppLoginPageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
	}
	
	@SuppressWarnings("rawtypes")
	public void forgotPassword_ValidDataOnGeneralInformationPage() throws InterruptedException, IOException
	{
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
        String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		commonFunction.selectValueMobileDropDown(getPageElement(AppLoginPageObjects.drpdwn_ForgotUsernameBirthMonth), month, AppLoginPageObjects.drpdwn_ForgotUsernameBirthMonth.getObjectname());
		commonFunction.selectValueMobileDropDown(getPageElement(AppLoginPageObjects.drpdwn_ForgotUsernameBirthDay),day,AppLoginPageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.selectValueMobileDropDown(getPageElement(AppLoginPageObjects.drpdwn_ForgotUsernameBirthYear), year, AppLoginPageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		((AndroidDriver)driver).hideKeyboard();
		//commonFunction.scrollToMobileElement("Legal Name");
		//commonFunction.scrollToMobileElement("LEGAL NAME");
		commonFunction.clearAndEnterText(getPageElement(AppLoginPageObjects.txt_ForgotUsernameFirstName), FirstName, AppLoginPageObjects.txt_ForgotUsernameFirstName.getObjectname());
		((AndroidDriver)driver).hideKeyboard();
		commonFunction.clearAndEnterText(getPageElement(AppLoginPageObjects.txt_ForgotUsernameLastName), LastName, AppLoginPageObjects.txt_ForgotUsernameLastName.getObjectname());
		((AndroidDriver)driver).hideKeyboard();
		//commonFunction.scrollToMobileElement("Address");
		//commonFunction.scrollToMobileElement("ADDRESS");
		commonFunction.scrollDown(); 
		commonFunction.clearAndEnterText(getPageElement(AppLoginPageObjects.txt_ForgotUsernameAddress), Address, AppLoginPageObjects.txt_ForgotUsernameAddress.getObjectname());
		((AndroidDriver)driver).hideKeyboard();
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_ForgotUsernameZipcode), Zipcode,AppLoginPageObjects.txt_ForgotUsernameZipcode.getObjectname());
		((AndroidDriver)driver).hideKeyboard();
		commonFunction.scrollDown();  
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_ForgotUsernameCity), City, AppLoginPageObjects.txt_ForgotUsernameCity.getObjectname());
		commonFunction.selectValueMobileDropDown(getPageElement(AppLoginPageObjects.drpdwn_ForgotUsernameState),State, AppLoginPageObjects.drpdwn_ForgotUsernameState.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.Continuebtn),AppLoginPageObjects.Continuebtn.getObjectname());

				
	}
	
	@SuppressWarnings("rawtypes")
	public void resetflow_NegativeValidationsAccountInfoPage() throws IOException, InterruptedException
	{
		
		String InActiveEmail = dataTable.getData("General_Data","NonExistUserId");
		String ExistingEmail = dataTable.getData("General_Data","ExistingUserId");
		String InvalidEmail = dataTable.getData("General_Data","InvalidUserIDformat");
		String Password = dataTable.getData("General_Data","Password");
		String InvalidPasswordformat = dataTable.getData("General_Data","InvalidPasswordformat");
		String DifferentPassword = dataTable.getData("General_Data","InvalidPassword");
		
		
		String Errormsg_NoDataEntered = "Please fix the errors above";
		String Errormsg_NoEmailEntered = "Please enter a valid email address";
		String Errormsg_InvalidEmailEntered = "Please enter a valid email address";
		String Errormsg_InActiveEmailEntered = "This is not an active email address. Please provide an active email address.";
		String Errormsg_ExistingEmailEntered = "Username already taken. Please try a different one.";
		String Errormsg_NoPasswordEntered = "Please provide a password";
		String Errormsg_InvalidPasswordformatEntered = "Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.";
		String Errormsg_DifferentPasswordEntered = "Passwords did not match";
		String Errormsg_NoChallengeQuestion = "Please select a account recovery question";
		String Errormsg_NoChallengeAnswerEntered = "Please provide an answer to account recovery question";
		
		//User clicked on Save without any data
		commonFunction.scrollDown();
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_ForgotPasswordVerifyIdentity), AppLoginPageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
		commonFunction.scrollDown();
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.errormsg_LoginResetAccntInfoNoDataEntered), AppLoginPageObjects.errormsg_LoginResetAccntInfoNoDataEntered.getObjectname(), Errormsg_NoDataEntered);
		commonFunction.scrollUp();
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.errormsg_LoginResetAcctInfoNoEmailEntered), AppLoginPageObjects.errormsg_LoginResetAcctInfoNoEmailEntered.getObjectname(), Errormsg_NoEmailEntered);
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.errormsg_LoginResetAccntInfoNoPassword), AppLoginPageObjects.errormsg_LoginResetAccntInfoNoPassword.getObjectname(), Errormsg_NoPasswordEntered);
		//commonFunction.scrollToMobileElement("Account Recovery Question");
		//commonFunction.scrollToMobileElement("ACCOUNT RECOVERY QUESTION");
		commonFunction.scrollDown();
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.errormsg_LoginResetAccntInfoNoChallengeQuestion), AppLoginPageObjects.errormsg_LoginResetAccntInfoNoChallengeQuestion.getObjectname(), Errormsg_NoChallengeQuestion);
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.errormsg_LoginResetAccntInfoNoChallengeAnswer), AppLoginPageObjects.errormsg_LoginResetAccntInfoNoChallengeAnswer.getObjectname(), Errormsg_NoChallengeAnswerEntered);
		commonFunction.scrollUp();
		//User entered InvalidEmail
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_LoginResetAccntInfoEmail),InvalidEmail, AppLoginPageObjects.txt_LoginResetAccntInfoEmail.getObjectname());
		//Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.errormsg_LoginResetAccntInfoInvalidEmail), AppLoginPageObjects.errormsg_LoginResetAccntInfoInvalidEmail.getObjectname(), Errormsg_InvalidEmailEntered);
		
		//User entered InactiveEmail
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_LoginResetAccntInfoEmail),InActiveEmail, AppLoginPageObjects.txt_LoginResetAccntInfoEmail.getObjectname());
		//Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.errormsg_LoginResetAccntInfoInactiveEmail), AppLoginPageObjects.errormsg_LoginResetAccntInfoInactiveEmail.getObjectname(), Errormsg_InActiveEmailEntered);
		
		//User entered ExistingEmail
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_LoginResetAccntInfoEmail),ExistingEmail, AppLoginPageObjects.txt_LoginResetAccntInfoEmail.getObjectname());
		//Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.errormsg_LoginResetAccntInfoExistingEmail), AppLoginPageObjects.errormsg_LoginResetAccntInfoExistingEmail.getObjectname(), Errormsg_ExistingEmailEntered);
		
		((AndroidDriver)driver).hideKeyboard();
		commonFunction.scrollDown();
		//User entered InvalidPassword format
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_Password),InvalidPasswordformat, AppLoginPageObjects.txt_Password.getObjectname());
		//Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.errormsg_LoginResetAccntInfoInvalidPasswordFormat), AppLoginPageObjects.errormsg_LoginResetAccntInfoInvalidPasswordFormat.getObjectname(), Errormsg_InvalidPasswordformatEntered);
		
		//User entered Differntdata in password & Confirm password fields
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_Password),Password, AppLoginPageObjects.txt_Password.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_ConfirmPassword),DifferentPassword, AppLoginPageObjects.txt_ConfirmPassword.getObjectname());
		//Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.errormsg_LoginResetAccntInfoDifferentPasswordEntered), AppLoginPageObjects.errormsg_LoginResetAccntInfoDifferentPasswordEntered.getObjectname(), Errormsg_DifferentPasswordEntered);
	}
	
	
	@SuppressWarnings("rawtypes")
	public void resetflow_AccountInfoPage() throws Exception
	{
		String Email = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data","Password");
		String ConfirmPassword = dataTable.getData("General_Data","Password");
		String Question = dataTable.getData("General_Data","ChallengeQuestion");
		String Answer = dataTable.getData("General_Data","ChallengeAnswer");
		
		commonFunction.scrollUp();
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_LoginResetAccntInfoEmail),Email, AppLoginPageObjects.txt_LoginResetAccntInfoEmail.getObjectname());
		Thread.sleep(5000);
		((AndroidDriver)driver).hideKeyboard();
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_Password),Password,AppLoginPageObjects.txt_Password.getObjectname());
		((AndroidDriver)driver).hideKeyboard();
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_ConfirmPassword),ConfirmPassword,AppLoginPageObjects.txt_ConfirmPassword.getObjectname());
		((AndroidDriver)driver).hideKeyboard();
		commonFunction.scrollDown();
		commonFunction.selectValueMobileDropDown(getPageElement(AppLoginPageObjects.drpdnw_LoginResetAccntInfoChallengeQuestion), Question,AppLoginPageObjects.drpdnw_LoginResetAccntInfoChallengeQuestion.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_ChallengeAnswer), Answer, AppLoginPageObjects.txt_ChallengeAnswer.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_ForgotPasswordVerifyIdentity), AppLoginPageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
	}
	
	public void resetflow_CongratsPage() throws IOException
	{
		
		String Email = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data", "Password");
		String Congrats = "Congratulations!";
		
		//commonFunction.clearAndEnterText(getPageElement(AppLoginPageObjects.txt_CongratsPageUsername),Email, AppLoginPageObjects.txt_CongratsPageUsername.getObjectname());
		//commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_CongratsPagePassword), Password,AppLoginPageObjects.txt_CongratsPagePassword.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.txt_CongratsPage), AppLoginPageObjects.txt_CongratsPage.getObjectname(), Congrats);
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_CongratsPageReturnToLogin), AppLoginPageObjects.btn_CongratsPageReturnToLogin.getObjectname());
	}
	
	
	

	
	
	
}

