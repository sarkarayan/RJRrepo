package com.rai.framework;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import com.rai.framework.FrameworkException;
import com.rai.framework.drivers.MobileExecutionPlatform;
import com.rai.framework.drivers.AppiumDriverFactory;
import com.rai.framework.drivers.BrowserStackDriverFactory;
import com.rai.framework.drivers.PerfectoDriverFactory;
import com.rai.framework.drivers.SauceLabsDriverFactory;
import com.rai.framework.drivers.ToolName;
import com.rai.framework.drivers.WebDriverFactory;
import com.rai.framework.Browser;

import io.appium.java_client.AppiumDriver;

public class BaseClass {

	public static WebDriver driver;
	public static Properties properties;
	public static Properties mobileProperties;
	Browser browser;
	public static GenericLib gl;
	public DataTable dataTable;
	public com.aventstack.extentreports.ExtentReports extent;
	public com.aventstack.extentreports.ExtentTest test;

	// public ObjectRepo repo = new ObjectRepo();
	public BaseClass() {
		properties = Settings.getInstance();
		mobileProperties = Settings.getMobilePropertiesInstance();
		dataTable = new DataTable(System.getProperty("user.dir")+"\\src\\test\\resources\\Datatables",
				properties.getProperty("DataTableName"));
	}

	public static void intialization() {

		String browserstr = properties.getProperty("Browser");
		System.out.println(browserstr);
		driver = WebDriverFactory.getWebDriver(Browser.CHROME);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Long.parseLong(properties.getProperty("ImplicitWait")),
				TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(Long.parseLong(properties.getProperty("PageLoadTimeOut")),
				TimeUnit.SECONDS);

	}
	
	@SuppressWarnings("rawtypes")
	public static void initializeWebDriver(String executionMode, String toolName, String mobileExecutionPlatform, String mobileOsVersion, String deviceName, String browser, String browserVersion, String platform, String platformVersion) {
		
		switch (executionMode.replace("\"","")) {
		
		case "API":
			break;

		case "LOCAL":
			WebDriver webDriver = WebDriverFactory.getWebDriver(Browser.browserValue(browser.replace("\"","")));
			driver =webDriver;
			driver.manage().window().maximize();
			break;

		case "GRID":
			WebDriver remoteGridDriver = WebDriverFactory.getRemoteWebDriver(Browser.browserValue(browser.replace("\"","")),
					browserVersion, Platform.fromString(platform),
					properties.getProperty("RemoteUrl"));
			driver = remoteGridDriver;
			
			driver.manage().window().maximize();
			break;

		case "MOBILE":
			WebDriver appiumDriver = AppiumDriverFactory.getAppiumDriver(MobileExecutionPlatform.fromString(mobileExecutionPlatform.replace("\"","")),
					deviceName.replace("\"",""), mobileOsVersion.replace("\"",""),
					Boolean.parseBoolean(mobileProperties.getProperty("ShouldInstallApplication")), mobileProperties.getProperty("AppiumURL"));
			driver = appiumDriver;
			break;

		case "PERFECTO":
			if (ToolName.fromString(toolName.replace("\"","")).equals(ToolName.APPIUM)) {
				WebDriver appiumPerfectoDriver = PerfectoDriverFactory.getPerfectoAppiumDriver(
						MobileExecutionPlatform.fromString(mobileExecutionPlatform.replace("\"","")), deviceName.replace("\"",""),
						mobileProperties.getProperty("PerfectoMobileHost"));
				driver = appiumPerfectoDriver;
				driver.manage().timeouts().implicitlyWait(Long.parseLong(properties.getProperty("ImplicitWait")), TimeUnit.SECONDS);
				driver.manage().timeouts().pageLoadTimeout(Long.parseLong(properties.getProperty("PageLoadTimeOut")), TimeUnit.SECONDS);

			} else if (ToolName.fromString(toolName.replace("\"","")).equals(ToolName.REMOTE_WEBDRIVER)) {
				WebDriver remotePerfectoDriver = PerfectoDriverFactory
						.getPerfectoRemoteWebDriverForDesktop(browser.replace("\"",""),  platformVersion.replace("\"",""),  browserVersion.replace("\"",""));
				driver = remotePerfectoDriver;
				driver.manage().timeouts().implicitlyWait(Long.parseLong(properties.getProperty("ImplicitWait")), TimeUnit.SECONDS);
				driver.manage().timeouts().pageLoadTimeout(Long.parseLong(properties.getProperty("PageLoadTimeOut")), TimeUnit.SECONDS);
			}

			break;

		case "SAUCELABS":
			if (ToolName.fromString(toolName.replace("\"","")).equals(ToolName.APPIUM)) {
				AppiumDriver appiumSauceDriver = SauceLabsDriverFactory.getSauceAppiumDriver(
						MobileExecutionPlatform.fromString(mobileExecutionPlatform.replace("\"","")), deviceName.replace("\"",""),
						mobileProperties.getProperty("SauceHost"),mobileOsVersion.replace("\"",""));
				driver = appiumSauceDriver;
			} else if (ToolName.fromString(toolName.replace("\"","")).equals(ToolName.REMOTE_WEBDRIVER)) {
				WebDriver remoteSauceDriver = SauceLabsDriverFactory.getSauceRemoteWebDriver(
						mobileProperties.getProperty("SauceHost"), Browser.browserValue(browser.replace("\"","")),
						browserVersion.replace("\"",""), Platform.fromString(platform.replace("\"","")));
				driver = remoteSauceDriver;
			}

			break;

		case "BROWSERSTACK":
			if (ToolName.fromString(toolName.replace("\"","")).equals(ToolName.REMOTE_WEBDRIVER)) {
				WebDriver browserstackRemoteDrivermobile = BrowserStackDriverFactory
						.getBrowserStackRemoteWebDriverMobile(MobileExecutionPlatform.fromString(mobileExecutionPlatform.replace("\"","")),
								deviceName.replace("\"",""), mobileProperties.getProperty("BrowserStackHost"));
				driver = browserstackRemoteDrivermobile;
			} else if (ToolName.fromString(toolName.replace("\"","")).equals(ToolName.DEFAULT)) {
				WebDriver browserstackRemoteDriver = BrowserStackDriverFactory.getBrowserStackRemoteWebDriver(
						mobileProperties.getProperty("BrowserStackHost"), Browser.browserValue(browser.replace("\"","")),
						browserVersion.replace("\"",""), Platform.fromString(platform.replace("\"","")));

				driver = browserstackRemoteDriver;
			}

			break;

		default:
			throw new FrameworkException("Unhandled Execution Mode!");
		}
	}


}