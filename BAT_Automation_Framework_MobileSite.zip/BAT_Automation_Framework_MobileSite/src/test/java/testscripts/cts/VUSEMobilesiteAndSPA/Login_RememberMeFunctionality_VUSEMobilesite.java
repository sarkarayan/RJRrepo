package testscripts.cts.VUSEMobilesiteAndSPA;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.Mobilesite_LoginPage_RememberMeFunctionality;
import com.rai.pages.Mobilesite_VUSE_MyProfileValidations;

@Listeners(ExtentITestListenerClassAdapter.class)
public class Login_RememberMeFunctionality_VUSEMobilesite extends BaseClass{

	Mobilesite_LoginPage_RememberMeFunctionality mobilesiteRememberMe;
	Mobilesite_VUSE_MyProfileValidations mobilesitesiteLogout;
	
	public Login_RememberMeFunctionality_VUSEMobilesite() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("WEB_ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("520041CF4833954B")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		mobilesiteRememberMe = new Mobilesite_LoginPage_RememberMeFunctionality(this.getClass().getSimpleName());
		mobilesitesiteLogout = new Mobilesite_VUSE_MyProfileValidations(this.getClass().getSimpleName());
		//gl= new GenericLib(this.getClass().getSimpleName());
		//gl.start_report(this.getClass().getSimpleName(), "Verify the forgot username flow", properties.getProperty("ApplicationUrl"));
	}
	
	@Test
	public void verifyRememberMeFunctionality_VUSEMobilesite() throws Exception {
		
		mobilesiteRememberMe.invokeApplication_brandMobilesite();
		mobilesiteRememberMe.vuseloginPage_RememberMeValidation();
		mobilesitesiteLogout.vuse_Logout();
		mobilesiteRememberMe.vuseloginPage_ValidatedisplayedUserId();
		mobilesiteRememberMe.vuselogout_RememberMeValidation();
		
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		//gl.endReport();
		
	}

}
