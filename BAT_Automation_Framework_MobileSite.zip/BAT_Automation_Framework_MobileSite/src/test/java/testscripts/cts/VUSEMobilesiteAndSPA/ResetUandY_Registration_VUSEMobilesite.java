package testscripts.cts.VUSEMobilesiteAndSPA;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.Mobilesite_Registration_LoginResetUandY;


@Listeners(ExtentITestListenerClassAdapter.class)
public class ResetUandY_Registration_VUSEMobilesite extends BaseClass{


	Mobilesite_Registration_LoginResetUandY mobilsiteRegistrationLoginReset;
	
	public ResetUandY_Registration_VUSEMobilesite() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("WEB_ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("ZY224ZZNBC")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		mobilsiteRegistrationLoginReset = new Mobilesite_Registration_LoginResetUandY(this.getClass().getSimpleName());
		//mobileSiteHomePageComponents = new MobileSiteHomePageComponents(this.getClass().getSimpleName());
		gl= new GenericLib(this.getClass().getSimpleName());
		//gl.start_report(this.getClass().getSimpleName(), "Verify the forgot username flow", properties.getProperty("ApplicationUrl"));
	}
	
	
	@Test
	public void verifyRegistration_LoginResetFlow_VUSEMobilesite() throws Exception {
		
		mobilsiteRegistrationLoginReset.invokeApplication_brandMobilesite();
		mobilsiteRegistrationLoginReset.registration_VUSEValidDetailsonStep1Page();
		mobilsiteRegistrationLoginReset.resetflow_NegativeValidationsAccountInfoPage();
		mobilsiteRegistrationLoginReset.resetflow_AccountInfoPage();
		mobilsiteRegistrationLoginReset.resetflow_CongratsPage();
		
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		//gl.endReport();
		
	}

}
