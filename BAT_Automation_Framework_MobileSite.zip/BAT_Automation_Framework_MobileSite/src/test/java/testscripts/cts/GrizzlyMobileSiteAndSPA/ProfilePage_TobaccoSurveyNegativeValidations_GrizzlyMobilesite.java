package testscripts.cts.GrizzlyMobileSiteAndSPA;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.MobileSiteHomePageComponents;
import com.rai.pages.MobileSite_MyprofileUpdate;


@Listeners(ExtentITestListenerClassAdapter.class)
public class ProfilePage_TobaccoSurveyNegativeValidations_GrizzlyMobilesite extends BaseClass{


	MobileSite_MyprofileUpdate mobileprofileupdate;
	MobileSiteHomePageComponents mobileSiteHomePageComponents;
	
	public ProfilePage_TobaccoSurveyNegativeValidations_GrizzlyMobilesite() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("WEB_ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("98892A4144365A334C")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		mobileprofileupdate = new MobileSite_MyprofileUpdate(this.getClass().getSimpleName());
		mobileSiteHomePageComponents = new MobileSiteHomePageComponents(this.getClass().getSimpleName());
		gl= new GenericLib(this.getClass().getSimpleName());
		//gl.start_report(this.getClass().getSimpleName(), "Verify the forgot username flow", properties.getProperty("ApplicationUrl"));
	}

	
	@Test
	public void verifyProfile_TobaccoSurveyValidations() throws Exception {
		
		mobileprofileupdate.invokeApplication_MobileSite();
		mobileprofileupdate.loginPage_AppToWebsiteLogin();
		mobileprofileupdate.camelProfile_NavigatetoMyProfile();
		mobileprofileupdate.profileUpdate_NegativevalidationsTobaccoPreferences();
		mobileprofileupdate.Camel_logout();
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		//gl.endReport();
		
	}

}
