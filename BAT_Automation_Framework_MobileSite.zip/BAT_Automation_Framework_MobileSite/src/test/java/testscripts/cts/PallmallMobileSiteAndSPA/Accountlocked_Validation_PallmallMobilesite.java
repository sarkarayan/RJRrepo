package testscripts.cts.PallmallMobileSiteAndSPA;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.MobileSiteHomePageComponents;
import com.rai.pages.MobileSite_MyprofileUpdate;
import com.rai.pages.Mobilesite_Accountlocked;


@Listeners(ExtentITestListenerClassAdapter.class)
public class Accountlocked_Validation_PallmallMobilesite  extends BaseClass {

	Mobilesite_Accountlocked accountlocked;
	MobileSite_MyprofileUpdate mobileSiteHomePageComponents;
	public Accountlocked_Validation_PallmallMobilesite() {
		super();

}
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("WEB_ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("ZY224ZZNBC")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		accountlocked = new Mobilesite_Accountlocked(this.getClass().getSimpleName());
		mobileSiteHomePageComponents = new MobileSite_MyprofileUpdate(this.getClass().getSimpleName());
		gl= new GenericLib(this.getClass().getSimpleName());
		//gl.start_report(this.getClass().getSimpleName(), "Verify the forgot username flow", properties.getProperty("ApplicationUrl"));
	}
	
	
	@Test
	public void verifyAccountLockFlow_PallmallMobilesite() throws Exception {
		
		accountlocked.invokeApplication_mobilesite();
		accountlocked.loginPage_ValidateErrormsg_AccountLock();
		accountlocked.loginPage_ResetLockedAccount();
		mobileSiteHomePageComponents.pallmallHomePage_Logout();
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		//gl.endReport();
		
	}
	
}
