package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.MobilesitePageObjects;
import com.rai.pageObjects.MobilesitePageObjects;

public class Mobilesite_VUSE_MyProfileValidations extends BaseClass {

	String testcaseName;

	public Mobilesite_VUSE_MyProfileValidations(String testcaseName) {
		this.testcaseName = testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper The {@link ScriptHelper} object passed from the
	 *                     {@link DriverScript}
	 */

	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	private WebElement getPageElement(MobilesitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}

	public void invokeApplication_brandMobilesite() {
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	}

	public void loginPage_VUSELogin() throws InterruptedException, IOException {

		String Username = dataTable.getData("General_Data", "Username");
		String Password = dataTable.getData("General_Data", "Password");

		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.loginLnk_VUSECertifyAgePage),MobilesitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginUsername), Username,MobilesitePageObjects.txt_VUSELoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginPassword), Password,MobilesitePageObjects.txt_VUSELoginPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_VUSELogin),MobilesitePageObjects.btn_VUSELogin.getObjectname());
		//Thread.sleep(5000);
	}

	
	public void vuseProfile_NavigatetoMyProfile() throws IOException, Exception
	{
		Thread.sleep(7000);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSE_Menu),MobilesitePageObjects.PostLoginVUSE_Menu.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSE_MyAccount),MobilesitePageObjects.PostLoginVUSE_MyAccount.getObjectname());
		
	}	
	
	public void vuseProfile_navigatetoBillingAddress() throws IOException
	{
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSE_AddressBook),MobilesitePageObjects.PostLoginVUSE_AddressBook.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btnEdit_ProfileVUSE_BillingAddress),MobilesitePageObjects.btnEdit_ProfileVUSE_BillingAddress.getObjectname());
		
	}
	
	public void vuseProfile_BillingAddress_negativevalidations() throws IOException, Exception
	{
		
		
		commonFunction.clearText(getPageElement(MobilesitePageObjects.txt_VUSEProfile_BillingAddress_Telephone), MobilesitePageObjects.txt_VUSEProfile_BillingAddress_Telephone.getObjectname());
		commonFunction.clearText(getPageElement(MobilesitePageObjects.txt_VUSEProfile_BillingAddress_Address), MobilesitePageObjects.txt_VUSEProfile_BillingAddress_Address.getObjectname());
		commonFunction.clearText(getPageElement(MobilesitePageObjects.txt_VUSEProfile_BillingAddress_Zipcode), MobilesitePageObjects.txt_VUSEProfile_BillingAddress_Zipcode.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_VUSEProfile_BillingAddress_Save), MobilesitePageObjects.btn_VUSEProfile_BillingAddress_Save.getObjectname());
		
		String ExpectedErrormsg = "This is a required field.";
			
		commonFunction.isElementPresentContainsText(getPageElement(MobilesitePageObjects.errormsg_VUSE_BillingAddress_NoTelephone), MobilesitePageObjects.errormsg_VUSE_BillingAddress_NoTelephone.getObjectname(), ExpectedErrormsg);
		commonFunction.isElementPresentContainsText(getPageElement(MobilesitePageObjects.errormsg_VUSE_BillingAddress_NoAddress1), MobilesitePageObjects.errormsg_VUSE_BillingAddress_NoAddress1.getObjectname(), ExpectedErrormsg);
		commonFunction.isElementPresentContainsText(getPageElement(MobilesitePageObjects.errormsg_VUSE_BillingAddress_NoZipcode), MobilesitePageObjects.errormsg_VUSE_BillingAddress_NoZipcode.getObjectname(), ExpectedErrormsg);
		//commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.errormsg_VUSE_BillingAddress_NoCity));
		//commonFunction.isElementPresentContainsText(getPageElement(MobilesitePageObjects.errormsg_VUSE_BillingAddress_NoCity), MobilesitePageObjects.errormsg_VUSE_BillingAddress_NoCity.getObjectname(), ExpectedErrormsg);
		
	}
	
	
	public void vuseProfile_BillingAddress_UpdateUserData() throws IOException, InterruptedException
	{
		
		String Phone = dataTable.getData("General_Data", "Phone");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSEProfile_BillingAddress_Telephone),Phone, MobilesitePageObjects.txt_VUSEProfile_BillingAddress_Telephone.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSEProfile_BillingAddress_Address),Address, MobilesitePageObjects.txt_VUSEProfile_BillingAddress_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSEProfile_BillingAddress_Zipcode),Zipcode, MobilesitePageObjects.txt_VUSEProfile_BillingAddress_Zipcode.getObjectname());
		Thread.sleep(4000);
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_VUSEProfile_BillingAddress_Save),MobilesitePageObjects.btn_VUSEProfile_BillingAddress_Save.getObjectname());
		
	}
	
	
	public void vuse_Logout() throws IOException
	{
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVuse_LogOutlink),MobilesitePageObjects.PostLoginVuse_LogOutlink.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.MobilesiteVuse_LogOut),MobilesitePageObjects.MobilesiteVuse_LogOut.getObjectname());
		
	}

}
