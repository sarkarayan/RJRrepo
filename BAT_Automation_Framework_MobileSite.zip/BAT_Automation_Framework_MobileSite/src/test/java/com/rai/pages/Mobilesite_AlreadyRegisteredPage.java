package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.componentgroups.*;
import com.rai.pageObjects.MobileSiteLoginPageObjects;
import com.rai.pageObjects.MobileSiteResetPageObjects;
import com.rai.pageObjects.MobilesitePageObjects;





public class Mobilesite_AlreadyRegisteredPage extends BaseClass {
	
	String testcaseName;
	
		public Mobilesite_AlreadyRegisteredPage(String testcaseName) {
			this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(MobileSiteLoginPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	private WebElement getPageElement(MobileSiteResetPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	private WebElement getPageElement(MobilesitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	public void invokeApplication_brandMobilesite()
	{
		String WebsiteURL = dataTable.getData("General_Data","URL");
		driver.manage().window().maximize();
		//driver.manage().deleteAllCookies();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
		
	public void registration_ValidDetailsonStep1Page() throws Exception
	{
		
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String Email = dataTable.getData("General_Data", "Email");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
		String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		System.out.println(year);
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btn_Registration),MobilesitePageObjects.btn_Registration.getObjectname());
		
		commonFunction.selectAnyElement(getPageElement(MobileSiteResetPageObjects.drpdwn_BirthMonth), month, MobilesitePageObjects.drpdwn_BirthMonth.getObjectname());
		Thread.sleep(3000);
		commonFunction.selectAnyElement(getPageElement(MobileSiteResetPageObjects.drpdwn_BirthDay),day,MobilesitePageObjects.drpdwn_BirthDay.getObjectname());
		commonFunction.selectAnyElement(getPageElement(MobileSiteResetPageObjects.drpdwn_BirthYear),year, MobilesitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_FirstName), FirstName, MobilesitePageObjects.txt_FirstName.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_LastName),LastName, MobilesitePageObjects.txt_LastName.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_Address),Address, MobilesitePageObjects.txt_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_Zipcode), Zipcode,MobilesitePageObjects.txt_Zipcode.getObjectname());
		Thread.sleep(4000);
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_City), City, MobilesitePageObjects.txt_City.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteResetPageObjects.drpdwn_State),State, MobilesitePageObjects.drpdwn_State.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_Email),Email,MobilesitePageObjects.txt_Email.getObjectname());	
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.Chkbx_Certify),MobilesitePageObjects.Chkbx_Certify.getObjectname());
		
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.btn_Step1Next), MobilesitePageObjects.btn_Step1Next.getObjectname());
		//Thread.sleep(4000);
	}
	
	public void registration_sameBrandAlreadyRegisteredPage() throws IOException
	{
		String UserId = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data","Password");
		System.out.println("Userid:"+UserId);
		String ActualErrormsg_AlreadyRegistered = driver.getTitle();
		String ExpectedErrormsg_AlreadyRegistered = "Registration";
		commonFunction.compareStringsContains(ExpectedErrormsg_AlreadyRegistered, ActualErrormsg_AlreadyRegistered);
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_AlreadyRegisteredUsername), UserId, MobileSiteResetPageObjects.txt_AlreadyRegisteredUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_AlreadyRegisteredPassword), Password, MobileSiteResetPageObjects.txt_AlreadyRegisteredPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.btn_AlreadyRegisteredLogin), MobilesitePageObjects.btn_AlreadyRegisteredLogin.getObjectname());
	}
	public void vuse_registration_sameBrandAlreadyRegisteredPage() throws IOException
	{
		String UserId = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data","Password");
		System.out.println("Userid:"+UserId);
		String ActualErrormsg_AlreadyRegistered = driver.getTitle();
		String ExpectedErrormsg_AlreadyRegistered = "Registration";
		commonFunction.compareStringsContains(ExpectedErrormsg_AlreadyRegistered, ActualErrormsg_AlreadyRegistered);
		
		//commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_AlreadyRegisteredUsername), UserId, MobileSiteResetPageObjects.txt_AlreadyRegisteredUsername.getObjectname());
		//commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_AlreadyRegisteredPassword), Password, MobileSiteResetPageObjects.txt_AlreadyRegisteredPassword.getObjectname());
		//commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.btn_AlreadyRegisteredLogin), MobilesitePageObjects.btn_AlreadyRegisteredLogin.getObjectname());
	}
	
	public void registration_anotherBrand_AccountExistsPage() throws Exception 
	{
		String UserId = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data","Password");
		
		String ExpectedErrormsg_diffBrandAlreadyRegistered = "It looks like you are already registered with another Reynolds American operating company's brand website.";
		
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errmsg_AlreadyRegisteredPage), MobileSiteResetPageObjects.errmsg_AlreadyRegisteredPage.getObjectname(), ExpectedErrormsg_diffBrandAlreadyRegistered);
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_AlreadyRegisteredUsername), UserId, MobileSiteResetPageObjects.txt_AlreadyRegisteredUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_AlreadyRegisteredPassword), Password, MobilesitePageObjects.txt_AlreadyRegisteredPassword.getObjectname());
		commonFunction.scrollDown();
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.btn_AlreadyRegisteredLogin), MobileSiteResetPageObjects.btn_AlreadyRegisteredLogin.getObjectname());
	}
	
	public void vuse_registration_anotherBrand_AccountExistsPage() throws Exception 
	{
		String UserId = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data","Password");
		
		String ExpectedErrormsg_diffBrandAlreadyRegistered = "It looks like you are already registered with another Reynolds American operating company's brand website.";
		
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errmsg_AlreadyRegisteredPage), MobileSiteResetPageObjects.errmsg_AlreadyRegisteredPage.getObjectname(), ExpectedErrormsg_diffBrandAlreadyRegistered);
		
		//commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_AlreadyRegisteredUsername), UserId, MobileSiteResetPageObjects.txt_AlreadyRegisteredUsername.getObjectname());
		//commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_AlreadyRegisteredPassword), Password, MobilesitePageObjects.txt_AlreadyRegisteredPassword.getObjectname());
		//commonFunction.scrollDown();
		//commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.btn_AlreadyRegisteredLogin), MobileSiteResetPageObjects.btn_AlreadyRegisteredLogin.getObjectname());
	}
	
	
	public void registration_RevelValidDetailsonStep1Page() throws InterruptedException, IOException
	{
		
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String Email = dataTable.getData("General_Data", "Email");
		String PhoneNumber = dataTable.getData("General_Data", "Phone");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
        String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btn_RegistrationRevel),MobileSiteLoginPageObjects.btn_RegistrationRevel.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btn_Registration),MobileSiteLoginPageObjects.btn_Registration.getObjectname());
		commonFunction.selectAnyElement(getPageElement(MobileSiteResetPageObjects.drpdwn_BirthMonth), month, MobileSiteResetPageObjects.drpdwn_BirthMonth.getObjectname());
		Thread.sleep(6000);
		commonFunction.selectAnyElement(getPageElement(MobileSiteResetPageObjects.drpdwn_BirthDay),day,MobileSiteResetPageObjects.drpdwn_BirthDay.getObjectname());
		//commonFunction.selectAnyElementByValue(getPageElement(MobilesitePageObjects.drpdwn_BirthYear), "1938", MobilesitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.selectAnyElement(getPageElement(MobileSiteResetPageObjects.drpdwn_BirthYear),year,MobileSiteResetPageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_FirstName), FirstName, MobileSiteResetPageObjects.txt_FirstName.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_LastName),LastName, MobileSiteResetPageObjects.txt_LastName.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_Address),Address, MobileSiteResetPageObjects.txt_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_Zipcode), Zipcode,MobileSiteResetPageObjects.txt_Zipcode.getObjectname());
		Thread.sleep(4000);
					
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_Email),Email, MobilesitePageObjects.txt_Email.getObjectname());
		Thread.sleep(5000);
		commonFunction.clickIfElementPresentJavaScript(getPageElement(MobileSiteResetPageObjects.txt_PhoneRevelVelo),MobilesitePageObjects.txt_PhoneRevelVelo.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_PhoneRevelVelo),PhoneNumber, MobilesitePageObjects.txt_PhoneRevelVelo.getObjectname());
		commonFunction.clickIfElementPresentJavaScript(getPageElement(MobileSiteResetPageObjects.radiobtn_GenderMaleRevel),MobilesitePageObjects.radiobtn_GenderMaleRevel.getObjectname());
		//commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.radiobtn_GenderMaleRevel),MobilesitePageObjects.radiobtn_GenderMaleRevel.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.chkbx_CertifyRevelVelo),MobilesitePageObjects.chkbx_CertifyRevelVelo.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_City), City, MobilesitePageObjects.txt_City.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteResetPageObjects.drpdwn_State),State, MobilesitePageObjects.drpdwn_State.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.btn_Step1Next), MobilesitePageObjects.btn_Step1Next.getObjectname());
		Thread.sleep(4000);
	}
	
	public void registration_VeloValidDetailsonStep1Page() throws InterruptedException, IOException
	{
		
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String Email = dataTable.getData("General_Data", "Email");
		String PhoneNumber = dataTable.getData("General_Data", "Phone");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
        String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btn_Registration),MobilesitePageObjects.btn_Registration.getObjectname());
		commonFunction.selectAnyElement(getPageElement(MobileSiteResetPageObjects.drpdwn_BirthMonth), month, MobilesitePageObjects.drpdwn_BirthMonth.getObjectname());
		Thread.sleep(6000);
		commonFunction.selectAnyElement(getPageElement(MobileSiteResetPageObjects.drpdwn_BirthDay),day,MobilesitePageObjects.drpdwn_BirthDay.getObjectname());
		commonFunction.selectAnyElement(getPageElement(MobileSiteResetPageObjects.drpdwn_BirthYear),year,MobilesitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_FirstName), FirstName, MobilesitePageObjects.txt_FirstName.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_LastName),LastName, MobilesitePageObjects.txt_LastName.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_Address),Address, MobilesitePageObjects.txt_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_Zipcode), Zipcode,MobilesitePageObjects.txt_Zipcode.getObjectname());
		Thread.sleep(4000);
					
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_Email),Email, MobilesitePageObjects.txt_Email.getObjectname());
		Thread.sleep(5000);
		commonFunction.clickIfElementPresentJavaScript(getPageElement(MobileSiteResetPageObjects.txt_PhoneRevelVelo),MobilesitePageObjects.txt_PhoneRevelVelo.getObjectname());
		commonFunction.enterText(getPageElement(MobileSiteResetPageObjects.txt_PhoneRevelVelo),PhoneNumber, MobilesitePageObjects.txt_PhoneRevelVelo.getObjectname());
		Thread.sleep(3000);
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.chkbx_CertifyRevelVelo),MobilesitePageObjects.chkbx_CertifyRevelVelo.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_City), City, MobilesitePageObjects.txt_City.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteResetPageObjects.drpdwn_State),State, MobilesitePageObjects.drpdwn_State.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.btn_Step1Next), MobilesitePageObjects.btn_Step1Next.getObjectname());
		Thread.sleep(4000);
	}
	
	public void registration_VUSEValidDetailsonStep1Page() throws InterruptedException, IOException
	{
		
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String Email = dataTable.getData("General_Data", "Email");
		String PhoneNumber = dataTable.getData("General_Data", "Phone");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
        String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.loginLnk_VUSECertifyAgePage),MobilesitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.header_VUSECreateAccount),MobilesitePageObjects.header_VUSECreateAccount.getObjectname());
		commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.drpdwn_BirthMonth), month, MobilesitePageObjects.drpdwn_BirthMonth.getObjectname());
		Thread.sleep(6000);
		commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.drpdwn_BirthDay),day,MobilesitePageObjects.drpdwn_BirthDay.getObjectname());
		commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.drpdwn_BirthYear),year,MobilesitePageObjects.drpdwn_BirthYear.getObjectname());
		commonFunction.enterText(getPageElement(MobilesitePageObjects.txt_FirstName), FirstName, MobilesitePageObjects.txt_FirstName.getObjectname());
		commonFunction.enterText(getPageElement(MobilesitePageObjects.txt_LastName),LastName, MobilesitePageObjects.txt_LastName.getObjectname());
		commonFunction.enterText(getPageElement(MobilesitePageObjects.txt_Address),Address, MobilesitePageObjects.txt_Address.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_Zipcode), Zipcode,MobilesitePageObjects.txt_Zipcode.getObjectname());
		Thread.sleep(4000);
					
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_Email),Email, MobilesitePageObjects.txt_Email.getObjectname());
		Thread.sleep(5000);
		commonFunction.clickIfElementPresentJavaScript(getPageElement(MobilesitePageObjects.txt_PhoneRevelVelo),MobilesitePageObjects.txt_PhoneRevelVelo.getObjectname());
		commonFunction.enterText(getPageElement(MobilesitePageObjects.txt_PhoneRevelVelo),PhoneNumber, MobilesitePageObjects.txt_PhoneRevelVelo.getObjectname());
		Thread.sleep(3000);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.chkbx_CertifyRevelVelo),MobilesitePageObjects.chkbx_CertifyRevelVelo.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_City), City, MobilesitePageObjects.txt_City.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobilesitePageObjects.drpdwn_State),State, MobilesitePageObjects.drpdwn_State.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Step1Next), MobilesitePageObjects.btn_Step1Next.getObjectname());
		//Thread.sleep(4000);
	}
	
}

