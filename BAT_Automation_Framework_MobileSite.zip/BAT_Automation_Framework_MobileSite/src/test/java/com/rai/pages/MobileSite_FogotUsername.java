package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.framework.Status;
import com.rai.pageObjects.MobileSiteForgotusernamePageObjects;
import com.rai.pageObjects.MobileSiteLoginPageObjects;
import com.rai.pageObjects.MobilesitePageObjects;

public class MobileSite_FogotUsername extends BaseClass {
	
	String testcaseName;
	public MobileSite_FogotUsername(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(MobileSiteForgotusernamePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("ForgotUsername Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
		private WebElement getPageElement(MobilesitePageObjects pageEnum) throws IOException {
			WebElement element;
			try {
				element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
						true);
				if (element != null)
					System.out.println("Found the element: " + pageEnum.getObjectname());
				else
					System.out.println("Element Not Found: " + pageEnum.getObjectname());
				return element;
			} catch (Exception e) {
				GenericLib.updateExtentStatus("ForgotUsername Page - get page element",
						pageEnum.toString() + " object is not defined or found.", Status.FAIL);
				return null;
			}
	}
	
	private WebElement getPageElement(MobileSiteLoginPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Mobile Site Login Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	public void invokeApplication_MobileSite()
	{
		String websiteURL = dataTable.getData("General_Data","URL");
		driver.get(websiteURL);
		driver.manage().deleteAllCookies();
		driver.get(websiteURL);
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);		
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
	}
	
	public void navigateToForgotusernamePage() throws IOException {
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btnSignInTab), MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.lnktxt_Forgetusername), MobileSiteLoginPageObjects.lnktxt_Forgetusername.getObjectname());
	}
	
	public void forgotUsername_NegativeValidationsAccountInformation() throws InterruptedException, IOException
	{
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String InvalidAddress = dataTable.getData("General_Data", "InvalidAddress");
		String InvalidZipcode = dataTable.getData("General_Data", "InvalidZipcode");
		String InvalidLastName = dataTable.getData("General_Data","InvalidLastName");
		String DOB = dataTable.getData("General_Data","DOB");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
		
		String Errormessage_forgotUsernameNoDOB = "Please provide a Date Of Birth";
		String Errormessage_forgotUsernameNoLegalName = "Please enter your legal name";
		String Errormessage_forgotUsernameNoAddress = "Please provide a street address";
		String Errormessage_forgotUsernameNoZipcode = "Please provide a ZIP Code";
		String Errormessage_forgotUsernameNoCity = "Please Provide City";
		String Errormessage_forgotUsernameNoState = "Please Provide State";
		String Errormessage_forgotUsernameNoDataonGeneralInfo = "Please fix the errors above";
		//Clicking on Continue button without any data on AccountInfo. Page
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotusernamePageObjects.btn_ForgotUsernameAccountInformation),MobileSiteForgotusernamePageObjects.btn_ForgotUsernameAccountInformation.getObjectname());
		
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotusernamePageObjects.errormsg_ForgotUsernameNoDOB), MobileSiteForgotusernamePageObjects.errormsg_ForgotUsernameNoDOB.getObjectname(), Errormessage_forgotUsernameNoDOB);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotusernamePageObjects.errormsg_ForgotUsernameNoLegalName), MobileSiteForgotusernamePageObjects.errormsg_ForgotUsernameNoLegalName.getObjectname(), Errormessage_forgotUsernameNoLegalName);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotusernamePageObjects.errormsg_ForgotUsernameNoAddress), MobileSiteForgotusernamePageObjects.errormsg_ForgotUsernameNoAddress.getObjectname(), Errormessage_forgotUsernameNoAddress);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotusernamePageObjects.errormsg_ForgotUsernameNoZipcode), MobileSiteForgotusernamePageObjects.errormsg_ForgotUsernameNoZipcode.getObjectname(), Errormessage_forgotUsernameNoZipcode);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotusernamePageObjects.errormsg_ForgotUsernameNoCity), MobileSiteForgotusernamePageObjects.errormsg_ForgotUsernameNoCity.getObjectname(), Errormessage_forgotUsernameNoCity);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotusernamePageObjects.errormsg_ForgotUsernameNoState), MobileSiteForgotusernamePageObjects.errormsg_ForgotUsernameNoState.getObjectname(), Errormessage_forgotUsernameNoState);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotusernamePageObjects.errormsg_ForgotUsernameNoDataonGeneralInfo), MobileSiteForgotusernamePageObjects.errormsg_ForgotUsernameNoDataonGeneralInfo.getObjectname(), Errormessage_forgotUsernameNoDataonGeneralInfo);
						
		
		//UserInformation not found
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		String Errormessage_UserInfonotfound = "We were not able to find your information. Please check and try again.";
	
		commonFunction.selectAnyElement(getPageElement(MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameBirthMonth), month, MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameBirthMonth.getObjectname());
		Thread.sleep(2000);
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameBirthDay),day,MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		System.out.println(year);
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameBirthYear),year, MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameFirstName), FirstName, MobileSiteForgotusernamePageObjects.txt_ForgotUsernameFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameLastName), InvalidLastName, MobileSiteForgotusernamePageObjects.txt_ForgotUsernameLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameAddress), InvalidAddress, MobileSiteForgotusernamePageObjects.txt_ForgotUsernameAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameZipcode), InvalidZipcode,MobileSiteForgotusernamePageObjects.txt_ForgotUsernameZipcode.getObjectname());
		Thread.sleep(3000);
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameCity), City, MobileSiteForgotusernamePageObjects.txt_ForgotUsernameCity.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameState),State, MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameState.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotusernamePageObjects.btn_ForgotUsernameAccountInformation),MobileSiteForgotusernamePageObjects.btn_ForgotUsernameAccountInformation.getObjectname());
		
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteForgotusernamePageObjects.errormsg_ForgotUsernameUsernotfound), MobileSiteForgotusernamePageObjects.errormsg_ForgotUsernameUsernotfound.getObjectname(), Errormessage_UserInfonotfound);
	
	}
	
	public void forgotUsername_ValidDataAccountInformation() throws InterruptedException, IOException
	{
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
		String date = dataTable.getData("General_Data","DOB");
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		commonFunction.selectAnyElement(getPageElement(MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameBirthMonth), month, MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameBirthMonth.getObjectname());
		Thread.sleep(2000);
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameBirthDay),day,MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameBirthYear), year, MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameFirstName), FirstName, MobileSiteForgotusernamePageObjects.txt_ForgotUsernameFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameLastName), LastName, MobileSiteForgotusernamePageObjects.txt_ForgotUsernameLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameAddress), Address, MobileSiteForgotusernamePageObjects.txt_ForgotUsernameAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameZipcode), Zipcode,MobileSiteForgotusernamePageObjects.txt_ForgotUsernameZipcode.getObjectname());
		Thread.sleep(3000);
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameCity), City, MobileSiteForgotusernamePageObjects.txt_ForgotUsernameCity.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameState),State,MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameState.getObjectname());
		Thread.sleep(3000);
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotusernamePageObjects.btn_ForgotUsernameAccountInformation),MobileSiteForgotusernamePageObjects.btn_ForgotUsernameAccountInformation.getObjectname());
	}
		
	     public void forgotUsername_NegativeValidationsVerifyIdentity() throws Exception
		
		{
			String InvalidChallengeAnswer = dataTable.getData("General_Data", "InvalidChallengeAnswer");
			
			//Clicking on Continue button without any data on Verify Identity Page
			Thread.sleep(4000);
			commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotusernamePageObjects.btn_ForgotUsernameVerifyIdentity), MobileSiteForgotusernamePageObjects.btn_ForgotUsernameVerifyIdentity.getObjectname());
			Thread.sleep(2000);
			String ActualErrormsg_NoAnswerEntered = commonFunction.getTextFromElement(getPageElement(MobileSiteForgotusernamePageObjects.errormsg_ForgotUsernamenoChallengeAnswer));
			String ExpectedErrormsg_NoAnswerEntered = "Please provide an answer to account recovery question";
			commonFunction.compareStringsContains(ExpectedErrormsg_NoAnswerEntered, ActualErrormsg_NoAnswerEntered );
			
			//User entered Incorrect Challenge Answer
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameChallengeAnswer), InvalidChallengeAnswer,MobileSiteForgotusernamePageObjects.txt_ForgotUsernameChallengeAnswer.getObjectname());
			Thread.sleep(2000);
			commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotusernamePageObjects.btn_ForgotUsernameVerifyIdentity), MobileSiteForgotusernamePageObjects.btn_ForgotUsernameVerifyIdentity.getObjectname());
			Thread.sleep(3000);
			String ActualErrormsg_IncorrectChallengeAnswer = commonFunction.getTextFromElement(getPageElement(MobileSiteForgotusernamePageObjects.errormsg_ForgotUsernameInvalidAnswer));
			String ExpectedErrormsg_IncorrectChallengeAnswer = "The answer does not match our records. Please re-enter your answer to the account recovery question";
			commonFunction.compareStringsContains(ExpectedErrormsg_IncorrectChallengeAnswer,ActualErrormsg_IncorrectChallengeAnswer);
			
		}
		
		
	     public void forgotUsername_ValidDataVerifyIdentity() throws InterruptedException, IOException
	 	{
	 		String ChallengeAnswer = dataTable.getData("General_Data", "ChallengeAnswer");
	 		Thread.sleep(2000);
	 		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameChallengeAnswer), ChallengeAnswer,MobileSiteForgotusernamePageObjects.txt_ForgotUsernameChallengeAnswer.getObjectname());
	 		//Thread.sleep(2000);
	 		commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotusernamePageObjects.btn_ForgotUsernameVerifyIdentity),MobileSiteForgotusernamePageObjects.btn_ForgotUsernameVerifyIdentity.getObjectname());
	 		//Thread.sleep(4000);
	 	}
	 	
	     
	     public void navigateToVUSEForgotUsernamePage() throws IOException
	     {
	     	commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.loginLnk_VUSECertifyAgePage), MobilesitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
	 		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.lnk_VUSELoginForgotUsername), MobilesitePageObjects.lnk_VUSELoginForgotUsername.getObjectname());	
	 	}
	 	
	 	
	 	
	 	public void forgotUsername_NegativeValidationsWelcomeback() throws IOException, Exception
	 	{
	 		String InvalidPassword = dataTable.getData("General_Data", "InvalidPassword");
	 		
	 		//Clicking on Login button without any data on Welcome Back Page
	 		commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotusernamePageObjects.btn_WelcomBackLogin),MobileSiteForgotusernamePageObjects.btn_WelcomBackLogin.getObjectname());
	 		String ActualErrormsg_NoPasswordentered = commonFunction.getTextFromElement(getPageElement(MobileSiteForgotusernamePageObjects.errormsg_WelcomeBackNoPassword));
	 		String ExpectedErrormsg_NoPasswordentered = "Please enter your password.";
	 		commonFunction.compareStringsContains(ExpectedErrormsg_NoPasswordentered,ActualErrormsg_NoPasswordentered);
	 		 		
	 		//User entered incorrect password on Welcome Back page
	 		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotusernamePageObjects.txt_WelcomeBackPassword),InvalidPassword,MobileSiteForgotusernamePageObjects.txt_WelcomeBackPassword.getObjectname());
	 		commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotusernamePageObjects.btn_WelcomBackLogin),MobileSiteForgotusernamePageObjects.btn_WelcomBackLogin.getObjectname());
	 		Thread.sleep(5000);
	 		String ActualErrormsg_InvalidPasswordentered = commonFunction.getTextFromElement(getPageElement(MobileSiteForgotusernamePageObjects.errormsg_WelcomeBackInvalidPassword));
	 		String ExpectedErrormsg_InvalidPasswordentered = "Username and password do not match.";
	 		commonFunction.compareStringsContains(ExpectedErrormsg_InvalidPasswordentered,ActualErrormsg_InvalidPasswordentered);
	 		
	 	}
	 	 	
	 	
	 	public void forgotUsername_ValidDataWelcomeback() throws IOException
	 	{
	 		String Password = dataTable.getData("General_Data", "Password");
	 		
	 		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotusernamePageObjects.txt_WelcomeBackPassword),Password, MobileSiteForgotusernamePageObjects.txt_WelcomeBackPassword.getObjectname());
	 		commonFunction.clickIfElementPresent(getPageElement(MobileSiteForgotusernamePageObjects.btn_WelcomBackLogin),MobileSiteForgotusernamePageObjects.btn_WelcomBackLogin.getObjectname());
	 	}	
		
	 	public void navigateToRevelVeloForgotUsernamePage() throws IOException {
			
			commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.lnktxt_RevelVeloForgotUsername), MobilesitePageObjects.lnktxt_RevelVeloForgotUsername.getObjectname());	
		}
		
	
	
	
	
	}
	
	
	
	


