package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.MobilesitePageObjects;
import com.rai.pageObjects.MobilesitePageObjects;

public class Mobilesite_NewportPrePostLoginFooterLinksValidation extends BaseClass {

	String testcaseName;
	public Mobilesite_NewportPrePostLoginFooterLinksValidation(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(MobilesitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("FooterLinks Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	public void invokeApplication_brandwebsite()
	{
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
	
	public void loginPage_NewportPreLoginFooterLinksValidation() throws Exception
	{ 
		//PreLogin - FAQs footerlink
		
		String CurrentUrl= driver.getCurrentUrl();
		//commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginfooterlnkNewport_FAQs));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnkNewport_FAQs),MobilesitePageObjects.PreLoginfooterlnkNewport_FAQs.getObjectname());
		Thread.sleep(4000);
		String ActualFAQsTitle = driver.getTitle();
		String ExpectedFAQsTitle = "Frequently Asked Questions";
		commonFunction.compareStringsContains(ExpectedFAQsTitle, ActualFAQsTitle);
		Thread.sleep(5000);
		driver.navigate().to(CurrentUrl);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btnSignInTab), MobilesitePageObjects.btnSignInTab.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
	
		//PreLogin - ContactUs
		//commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginfooterlnkNewport_ContactUs));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnkNewport_ContactUs),MobilesitePageObjects.PreLoginfooterlnkNewport_ContactUs.getObjectname());
		Thread.sleep(4000);
		String ActualContactUsTitle = driver.getTitle();
		String ExpectedContactUsTitle = "Contact us";
		commonFunction.compareStringsContains(ExpectedContactUsTitle, ActualContactUsTitle);
		Thread.sleep(5000);
		driver.navigate().to(CurrentUrl);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btnSignInTab), MobilesitePageObjects.btnSignInTab.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - TobaccoRights
		//commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginfooterlnkNewport_TobaccoRights));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnkNewport_TobaccoRights),MobilesitePageObjects.PreLoginfooterlnkNewport_TobaccoRights.getObjectname());
		Thread.sleep(4000);
		String ActualTobaccoRightsTitle = driver.getTitle();
		String ExpectedTobaccoRightsTitle = "Own It Voice It - Make Your Voice Heard";
		commonFunction.compareStringsContains(ExpectedTobaccoRightsTitle, ActualTobaccoRightsTitle);
		Thread.sleep(5000);
		driver.navigate().to(CurrentUrl);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btnSignInTab), MobilesitePageObjects.btnSignInTab.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - SiteRequirements
		//commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginfooterlnkNewport_SiteRequrmnts));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnkNewport_SiteRequrmnts),MobilesitePageObjects.PreLoginfooterlnkNewport_SiteRequrmnts.getObjectname());
		Thread.sleep(4000);
		String ActualSiteRequrmntsTitle = driver.getTitle();
		String ExpectedSiteRequrmntsTitle = "Site Requirements";
		commonFunction.compareStringsContains(ExpectedSiteRequrmntsTitle, ActualSiteRequrmntsTitle);
		Thread.sleep(5000);
		driver.navigate().to(CurrentUrl);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btnSignInTab), MobilesitePageObjects.btnSignInTab.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
		Thread.sleep(5000);
		//PreLogin - AgeFiltering
		//commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginfooterlnkNewport_AgeFiltering));		
		//commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnkNewport_AgeFiltering),MobilesitePageObjects.PreLoginfooterlnkNewport_AgeFiltering.getObjectname());
		
		//String ActualAgeFilteringTitle = driver.getTitle();
		//String ExpectedAgeFilteringTitle = "Age Filtering Software:";
		//commonFunction.compareStringsContains(ExpectedAgeFilteringTitle, ActualAgeFilteringTitle);
		//Thread.sleep(5000);
		//driver.navigate().to(CurrentUrl);
		//commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btnSignInTab), MobilesitePageObjects.btnSignInTab.getObjectname());
		//commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - TermsOfUse
		//commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginfooterlnkNewport_TermsOfUse));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnkNewport_TermsOfUse),MobilesitePageObjects.PreLoginfooterlnkNewport_TermsOfUse.getObjectname());
		Thread.sleep(4000);
		String ActualTermsofUseTitle = driver.getTitle();
		String ExpectedTermsofUseTitle = "Terms of use";
		commonFunction.compareStringsContains(ExpectedTermsofUseTitle, ActualTermsofUseTitle);
		Thread.sleep(5000);
		driver.navigate().to(CurrentUrl);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btnSignInTab), MobilesitePageObjects.btnSignInTab.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - PrivacyPolicy
		//commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginfooterlnkNewport_PrivacyPolicy));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnkNewport_PrivacyPolicy),MobilesitePageObjects.PreLoginfooterlnkNewport_PrivacyPolicy.getObjectname());
		Thread.sleep(4000);
		String ActualPrivacyPolicyTitle = driver.getTitle();
		String ExpectedPrivacyPolicyTitle = "Privacy Policy and Your California Privacy Rights";
		commonFunction.compareStringsContains(ExpectedPrivacyPolicyTitle, ActualPrivacyPolicyTitle);
		Thread.sleep(5000);
		driver.navigate().to(CurrentUrl);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btnSignInTab), MobilesitePageObjects.btnSignInTab.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
	}
	
	
	public void loginPage_AppToWebsiteLogin() throws InterruptedException, IOException
	{
		
		String Username = dataTable.getData("General_Data", "Username");
		String Password = dataTable.getData("General_Data", "Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_LoginUsername),Username,MobilesitePageObjects.txt_LoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_LoginPassword),Password, MobilesitePageObjects.txt_LoginPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login), MobilesitePageObjects.btn_Login.getObjectname());
		Thread.sleep(5000);
	}
	
	
	public void homePage_NewportPostLoginFooterLinksValidation() throws Exception
	{
		Thread.sleep(4000);
		//PostLogin - FAQs footerlink
		String CurrentUrl = driver.getCurrentUrl();
		//commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_FAQs));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_FAQs),MobilesitePageObjects.PostLoginfooterlnk_FAQs.getObjectname());
		Thread.sleep(4000);
		String ActualPostLoginFAQsTitle = driver.getTitle();
		String ExpectedPostLoginFAQsTitle = "Frequently Asked Questions";
		commonFunction.compareStringsContains(ExpectedPostLoginFAQsTitle, ActualPostLoginFAQsTitle );
		Thread.sleep(5000);
		driver.navigate().to(CurrentUrl);
		Thread.sleep(2000);
		//PostLogin - ContactUs footer link
		//commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_ContactUs));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_ContactUs),MobilesitePageObjects.PostLoginfooterlnk_ContactUs.getObjectname());
		Thread.sleep(3000);
		String ActualPostLoginContactUsTitle = driver.getTitle();
		String ExpectedPostLoginContactUsTitle = "Contact us";
		commonFunction.compareStringsContains(ExpectedPostLoginContactUsTitle, ActualPostLoginContactUsTitle);
		Thread.sleep(5000);
		
		commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_ContactUsQuestion),2 ,MobilesitePageObjects.PostLoginfooterlnk_ContactUsQuestion.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_ContactUsAnswer),"Validate",MobilesitePageObjects.PostLoginfooterlnk_ContactUsAnswer.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_ContactUsSubmit),MobilesitePageObjects.PostLoginfooterlnk_ContactUsSubmit.getObjectname());
		
		driver.navigate().to(CurrentUrl);
		Thread.sleep(3000);
		//PostLogin - TobaccoRights
		//commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_TobaccoRights));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_TobaccoRights),MobilesitePageObjects.PostLoginfooterlnk_TobaccoRights.getObjectname());
		Thread.sleep(4000);
		String ActualPostLoginTobaccoRightsTitle = driver.getTitle();
		String ExpectedPostLoginTobaccoRightsTitle = "Own It Voice It - Make Your Voice Heard";
		commonFunction.compareStringsContains(ExpectedPostLoginTobaccoRightsTitle, ActualPostLoginTobaccoRightsTitle );
		Thread.sleep(5000);
		driver.navigate().to(CurrentUrl);
		Thread.sleep(3000);
		//PostLogin - SiteRequirements
		//commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_SiteRequirements));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_SiteRequirements),MobilesitePageObjects.PostLoginfooterlnk_SiteRequirements.getObjectname());
		Thread.sleep(4000);
		String ActualPostLoginSiteRequirementsTitle = driver.getTitle();
		String ExpectedPostLoginSiteRequirementsTitle = "Site Requirements";
		commonFunction.compareStringsContains(ExpectedPostLoginSiteRequirementsTitle, ActualPostLoginSiteRequirementsTitle);
		Thread.sleep(5000);
		driver.navigate().to(CurrentUrl);
		Thread.sleep(3000);
		//PostLogin - AgeFiltering
		//commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_AgeFiltering));		
		//commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_AgeFiltering),MobilesitePageObjects.PostLoginfooterlnk_AgeFiltering.getObjectname());
		
		//String ActualPostLoginAgeFilteringTitle = driver.getTitle();
		//String ExpectedPostLoginAgeFilteringTitle = "Age Filtering Software:";
		//commonFunction.compareStringsContains(ExpectedPostLoginAgeFilteringTitle, ActualPostLoginAgeFilteringTitle);
		//Thread.sleep(5000);
		//driver.navigate().to(CurrentUrl);
		
		//PostLogin - TermsOfUse
		//commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_TermsOfUse));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_TermsOfUse),MobilesitePageObjects.PostLoginfooterlnk_TermsOfUse.getObjectname());
		Thread.sleep(4000);
		String ActualPostLoginTermsOfUseTitle = driver.getTitle();
		String ExpectedPostLoginTermsOfUseTitle = "Terms of use";
		commonFunction.compareStringsContains(ExpectedPostLoginTermsOfUseTitle , ActualPostLoginTermsOfUseTitle);
		Thread.sleep(5000);
		driver.navigate().to(CurrentUrl);
		Thread.sleep(5000);
		//PostLogin - PrivacyPolicy
		//commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_PrivacyPolicy));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_PrivacyPolicy),MobilesitePageObjects.PostLoginfooterlnk_PrivacyPolicy.getObjectname());
		Thread.sleep(6000);
		String ActualPostLoginPrivacyPolicyTitle = driver.getTitle();
		String ExpectedPostLoginPrivacyPolicyTitle = "Privacy Policy and Your California Privacy Rights";
		commonFunction.compareStringsContains(ExpectedPostLoginPrivacyPolicyTitle, ActualPostLoginPrivacyPolicyTitle);
		Thread.sleep(5000);
		driver.navigate().to(CurrentUrl);
		
	}
	
	public void newportHomePage_Logout() throws IOException
	{
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginNewportfooterlnk_Logout), MobilesitePageObjects.PostLoginNewportfooterlnk_Logout.getObjectname());
		
	}
		
	
}
