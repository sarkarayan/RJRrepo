package com.rai.pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.framework.Status;
import com.rai.pageObjects.MobileSiteHomePageObjects;

public class MobileSiteHomePageComponents extends BaseClass {

	String testcaseName;
	public MobileSiteHomePageComponents(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(MobileSiteHomePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("ForgotUsername Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	

	
	public void logoutOfMobileSite() throws IOException {
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteHomePageObjects.btnHamburgerMenu), MobileSiteHomePageObjects.btnHamburgerMenu.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteHomePageObjects.lnkLogout), MobileSiteHomePageObjects.lnkLogout.getObjectname());
	}
}
