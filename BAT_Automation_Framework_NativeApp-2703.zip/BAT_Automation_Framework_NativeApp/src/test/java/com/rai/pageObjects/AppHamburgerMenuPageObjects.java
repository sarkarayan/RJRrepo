package com.rai.pageObjects;

import static com.rai.pageObjects.ObjectLocator.*;

public enum AppHamburgerMenuPageObjects implements PageObjects {

	//Login
	txt_LoginUsername("//android.widget.EditText[@text='Username / Email Address']",XPATH,"Input - APP LoginUsername"),
	txt_LoginPassword("//android.widget.EditText[@text='Password']",XPATH,"Input - APP LoginPassword"),
	btn_Login("//android.widget.TextView[@text='LOG IN']",XPATH,"Button - APP Login"),

	
	//HamburgerMenu
	menu_AltHomePage("//android.view.ViewGroup[@index=1 and @instance=2]",XPATH,"Hamburger Menu - AltHomePage"),
	menu_HomeLink("//android.widget.TextView[@text='HOME']",XPATH,"Hamburger Menu - HomeLink"),
	menu_SavingsLink("//android.widget.TextView[@text='SAVINGS']",XPATH,"Hamburger Menu - SavingsLink"),
	menu_SavingsOKbtn("//android.widget.Button[@text='OK']",XPATH,"Hamburger Menu - SavingsOK button"),
	menu_StoreLocatorLink("//android.widget.TextView[@text='STORE LOCATOR']",XPATH,"Hamburger Menu - StoreLocatorLink"),
	menu_PromoCodeLink("//android.widget.TextView[@text='PROMO CODE']",XPATH,"Hamburger Menu - PromoCodeLink"),
	menu_PromoCodeSubmitbtn("//android.widget.TextView[@text='SUBMIT']",XPATH,"Hamburger Menu - PromoCode SubmitButton"),
	menu_MySettingsLink("//android.widget.TextView[@text='MY SETTINGS']",XPATH,"Hamburger Menu - MySettings Link"),
	menu_HelpLink("//android.widget.TextView[@text='HELP']",XPATH,"Hamburger Menu - HelpLink"),
	menu_MyGrizzly("//android.widget.TextView[@text='MYGRIZZLY.COM']",XPATH,"Hamburger Menu - MY GRIZZLY Link"),
	menu_LogoutLink("//android.widget.TextView[@text='LOG OUT']",XPATH,"Hamburger Menu - LogoutLink"),
	menu_ChangePassword("//android.widget.TextView[@text='Change Password']",XPATH,"Hamburger Menu - Change Password Link"),
	menu_ChangePIN("//android.widget.TextView[@text='Change PIN']",XPATH,"Hamburger Menu - Change PIN Link"),
	
	menu_TobPref("//android.widget.TextView[@text='Tobacco Preferences']",XPATH,"Hamburger Menu - Tobacco Preferences Link"),
	chckbox_TobaccoPreferencesCombustible("//android.widget.CheckBox[@text='COMBUSTIBLE']",XPATH,"Tobacco Preferences - COMBUSTIBLE checkbox"),
	drpdwn_TobaccoPreferencesSurveyQ1("//android.widget.Spinner[@resource-id='edit-surveyquestion1']",XPATH,"Tobacco Preferences - Survey Question 1"),
	drpdwn_TobaccoPreferencesSurveyQ2("//android.widget.Spinner[@resource-id='edit-surveyquestion2']",XPATH,"Tobacco Preferences - Survey Question 2"),
	btn_TobaccoPreferencesSubmit("//android.widget.Button[@text='Submit']",XPATH,"Button - Submit"),

	txt_ProfileNewPassword("//android.widget.EditText[@text='Enter Password']",XPATH,"Hamburger Menu - Enter Password text"),
	txt_ProfileConfirmNewPassword("//android.widget.EditText[@text='Confirm Password']",XPATH,"Hamburger Menu - Confirm Password text"),
	btn_ProfileUpdatePassword("//android.widget.TextView[@text='COMPLETE']",XPATH,"Hamburger Menu - COMPLETE button"),
	
	//Offers
	btn_RedeemNow("//android.widget.Button[@text='REDEEM NOW']",XPATH,"Offers - REDEEM NOW button"),
	btn_NotNow("//android.widget.Button[@text='NOT NOW']",XPATH,"Offers - NOT NOW button"),
	btn_LoadMore("//android.widget.Button[@text='LOAD MORE']",XPATH,"Offers - LOAD MORE button"),

	Offer("//android.widget.TextView[@text='$']",XPATH,"Offer"),
	btn_ChooseStore("//android.widget.Button[@text='CHOOSE A STORE']",XPATH,"Offers - CHOOSE A STORE button"),
	lnk_MapIt("//android.widget.TextView[@text='MAP IT']",XPATH,"Offers - MAP IT link"),
	lnk_Map("//android.widget.Button[@instance=1 and @index=2]",XPATH,"Offers - MAP link"),
	lnk_List("//android.widget.Button[@instance=0 and @index=0]",XPATH,"Offers - LIST link"),
	txt_Zipcode("//android.widget.EditText[@text='SEARCH BY ZIP']",XPATH,"Offers - MAP IT link"),
	errormsg_InvalidZipcode("//android.widget.TextView[@text='We are sorry but there are no participating stores in your area at this time. Please check back in the future.']",XPATH,"ErrorMessage - We are sorry but there are no participating stores in your area at this time. Please check back in the future."),
	btn_Close("//android.widget.Button[@text='Close']",XPATH,"Button - Close"),
	errormsg_RedeemNow("//android.widget.TextView[@text='You must be in the store to redeem this coupon offer.']",XPATH,"ErrorMessage - You must be in the store to redeem this coupon offer."),
	txt_StoreSection("//android.widget.TextView[@index=0 and @instance=3]",XPATH,"Hamburger Menu - HomeLink"),
	lnk_MapStoreSection("//android.view.View[@index=2 and @instance=20]",XPATH,"Hamburger Menu - HomeLink"),

	
	//PIN
	btn_OK("//android.widget.Button[@text='OK']",XPATH,"Button - OK"),
	btn_1("//android.widget.Button[@text='1']",XPATH,"Button - 1"),
	btn_2("//android.widget.Button[@text='2']",XPATH,"Button - 2"),
	btn_3("//android.widget.Button[@text='3']",XPATH,"Button - 3"),
	btn_4("//android.widget.Button[@text='4']",XPATH,"Button - 4"),
	btn_5("//android.widget.Button[@text='5']",XPATH,"Button - 5"),
	btn_6("//android.widget.Button[@text='6']",XPATH,"Button - 6"),
	btn_9("//android.widget.Button[@text='9']",XPATH,"Button - 9"),
	errormsg_InvalidPIN("//android.widget.TextView[@text='INVALID PIN.  PLEASE AVOID REPEAT AND SEQUENTIAL NUMBERS.']",XPATH,"ErrorMessage - INVALID PIN.  PLEASE AVOID REPEAT AND SEQUENTIAL NUMBERS."),
	errormsg_PINmismatch("//android.widget.TextView[@text='PIN DOES NOT MATCH.  PLEASE TRY AGAIN.']",XPATH,"ErrorMessage - PIN DOES NOT MATCH.  PLEASE TRY AGAIN."),
	
	errormsg_WrongPINLogin1("//android.widget.TextView[@text='INCORRECT PIN.  YOU HAVE 2 ATTEMPTS LEFT.']",XPATH,"ErrorMessage - INCORRECT PIN.  YOU HAVE 2 ATTEMPTS LEFT."),
	errormsg_WrongPINLogin2("//android.widget.TextView[@text='INCORRECT PIN.  YOU HAVE 1 ATTEMPT LEFT.']",XPATH,"ErrorMessage - INCORRECT PIN.  YOU HAVE 1 ATTEMPT LEFT."),
	errormsg_WrongPINLogin3("//android.widget.TextView[@text='INCORRECT PIN.  PLEASE LOG IN USING YOUR USERNAME AND PASSWORD']",XPATH,"ErrorMessage - INCORRECT PIN.  PLEASE LOG IN USING YOUR USERNAME AND PASSWORD"),

	
	//Footerlinks in Menu
	menu_PrivacyPolicylink("//android.widget.Button[@text='Privacy Policy']",XPATH,"Menu - PrivacyPolicyLink"),
	menu_TermsOfUselink("//android.widget.Button[@text='Terms of Use']",XPATH,"Menu - TermsOfUseLink"),
	menu_FAQslink("//android.widget.Button[@text='FAQs']",XPATH,"Menu - FAQsLink"),
	menu_ContactUslink("//android.widget.Button[@text='Contact Us']",XPATH,"Menu - ContactUsLink"),
	menu_AppRequirementslink("//android.widget.Button[@text='App Requirements']",XPATH,"Menu - AppRequirementsLink"),
	
	
	
	
	
	
	
	
	;
	
	
	
	
	String strProperty = "";
   	ObjectLocator locatorType = null;
   	String strObjName = "";
   	
	@Override
	public String getProperty() {
		// TODO Auto-generated method stub
		return strProperty;
	}

	@Override
	public ObjectLocator getLocatorType() {
		// TODO Auto-generated method stub
		return locatorType;
	}

	@Override
	public String getObjectname() {
		// TODO Auto-generated method stub
		return strObjName;
	}
	
	private AppHamburgerMenuPageObjects (String strPropertyValue, ObjectLocator locatorType, String strObjName) {
		// TODO Auto-generated method stub
		this.strProperty = strPropertyValue;
   		this.locatorType = locatorType;
   		this.strObjName = strObjName;
		
	}
}
