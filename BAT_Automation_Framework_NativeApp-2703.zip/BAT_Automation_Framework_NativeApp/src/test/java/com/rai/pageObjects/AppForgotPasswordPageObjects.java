package com.rai.pageObjects;

import static com.rai.pageObjects.ObjectLocator.*;

public enum AppForgotPasswordPageObjects implements PageObjects {

	//AllowPermission
		btn_AppAllowPermission("//android.widget.Switch[@resource-id='android:id/switch_widget']",XPATH,"APP Permission Allow"),
		
	//ForgotPassword - Email
	lnk_GrizzlyAPPLoginForgotPassword("//android.widget.Button[@text='Forgot Password?']",XPATH,"Link - APP Login ForgotPassword"),
	lnk_ForgotPasswordEnterUserEmailBacktoLogin("//android.widget.TextView[@text='Back to Login']",XPATH,"Link - ForgotPassword BacktoLogin text on EnterEmailPage"),
	txt_ForgotPasswordEnterEmail("//android.widget.EditText[@resource-id='userId']",XPATH,"Input - EnterUserIDEmail"),
	btn_ForgotPasswordEnterEmailContinue("//android.widget.Button[@resource-id='edit-submit']",XPATH,"Button - ForgotPassword EnterEmail Continue"),
	lnk_ForgotPasswordForgotUsername("//android.view.View[@text='username']",XPATH,"Link - ForgotPassword EnterEmail UsernameLink"),
	
	//ForgotPassword - GeneralInfo Page
	lnk_ForgotPasswordGeneralInforBacktoLogin("//android.widget.TextView[@text='Back to Login']",XPATH,"LInk - ForgotPassword BacktoLogin text on GeneralInfoPage"),
	drpdwn_ForgotPasswordGeneralInforBirthMonth("//android.widget.Spinner[@resource-id='BirthMonth']",XPATH,"Dropdown - ForgotPassword GeneralInfoBirthMonth"),
	drpDownBirthMonth("//android.widget.Spinner[@resource-id='BirthMonth']",XPATH,"Forgot Password Page - Month dropdown value"),
	drpdwn_ForgotPasswordGeneralInforBirthDay("//android.widget.Spinner[@resource-id='BirthDay']",XPATH,"Dropdown - ForgotPassword GeneralInforBirthDay"),
	drpdwn_ForgotPasswordGeneralInforBirthYear("//android.widget.Spinner[@resource-id='BirthYear']",XPATH,"Dropdown - ForgotPassword GeneralInfoBirthYear"),
	tooltip_ForgotPasswordGeneralInfo("//android.view.View[@text='i']",XPATH,"Tooltip - ForgotPassword GeneralInformation"),
	txt_ForgotPasswordGeneralInforFirstName("//android.widget.EditText[@resource-id='FirstName']",XPATH,"Input - ForgotPassword GeneralInfo FirstName"),
	txt_ForgotPasswordGeneralInfoLastName("//android.widget.EditText[@resource-id='LastName']",XPATH,"Input - ForgotPassword GeneralInfo LastName"),
	txt_ForgotPasswordGeneralInfoAddressLine("//android.widget.EditText[@resource-id='AddressLine1']",XPATH,"Input - ForgotPassword GeneralInfo AddressLine"),
	txt_ForgotPasswordGeneralInfoZipcode("//android.widget.EditText[@resource-id='ZipCode']",XPATH,"Input - ForgotPassword GeneralInfo Zipcode"),
	txt_ForgotPasswordGeneralInfoCity("//android.widget.EditText[@resource-id='City']",XPATH,"Input - ForgotPassword GeneralInfo City"),
	Drpdwn_ForgotPasswordGenralInfoState("//android.widget.Spinner[@resource-id='State']",XPATH,"Dropdown - ForgotPassword GeneralInfo State"),
	btn_ForgotPasswordGeneralInfoConitnue("//android.widget.Button[@resource-id='edit-submit' or @text='Continue']",XPATH,"Button - ForgotPassword GeneralInfo Continue"),
	
	//ForgotPassword - VerifyIdenity
	lnk_ForgotPasswordVerifyIdentityBacktoLogin("//android.widget.TextView[@text='Back to Login']",XPATH,"Link - ForgotPassword VerifyIdenity BacktoLogin text"),
	txt_ForgotPasswordVerifyIdentityChallengeAnswer("//android.widget.EditText[@resource-id='ChallengeAnswer']",XPATH,"Input - ForgotPassword VerifyIdentity ChallengeAnswer"),
	btn_ForgotPasswordVerifyIdentityContinue("//android.widget.Button[@resource-id='edit-submit']",XPATH,"Button - ForgotPassword VerifyIdentity Continue"),
	
	//ForgotPassword - ResetPasswordPage
	lnk_ForgotPasswordResetPasswordBacktoLogin("//android.widget.TextView[@text='Back to Login']",XPATH,"Link - ForgotPassword ResetPassword BacktoLogin text"),
	txt_ForgotPasswordResetPasswordPasswordfield("//android.widget.EditText[@resource-id='inputPassword']",XPATH,"Input - ForgotPassword ResetPassword Passwordfield"),
	txt_ForgotPasswordResetPasswordConfirmPasswordfield("//android.widget.EditText[@resource-id='inputPasswordConfirm']",XPATH,"Input - ForgotPassword ResetPassword ConfirmPasswordfield"),
	btn_ForgotPasswordResetPasswordNext("//android.widget.Button[@resource-id='edit-submit']",XPATH,"Button - ForgotPassword ResetPassword Next"),
	
	//ForgotPassword CongratulationsPage
	lnk_ForgotPasswordCongratsPageBacktoLogin("//android.widget.TextView[@text='Back to Login']",XPATH,"Link - ForgotPassword CongratsPage BacktoLogin text"),
	btn_ForgotPasswordCongratsPageReturntoLogin("//android.view.View[@text='RETURN TO LOGIN']",XPATH,"Button - ForgotPassword CongratsPage ReturntoLogin"),
	
	//Errormessages ForgotPassword EmailPage
	errormsg_ForgotPasswordEmailfieldvalidation("//android.view.View[@resource-id='userIdError']",XPATH,"Erromsg - Please enter your Username / Email Address."),
	errormsg_ForgotPasswordEmailpagewithoutanyData("//android.view.View[@text='Please fix the errors above']",XPATH,"Errormsg - Please fix the errors above"),
	
	errormsg_ForgotPasswordInvalidUserId("//android.view.View[@resource-id='answerMatchError']",XPATH,"Erromsg - We could not locate your Login ID, please try again."),
	errormsg_ForgotPasswordInvalidUserIdformat("//android.view.View[@resource-id='formatError']",XPATH,"Erromsg - Username must be a combination of 8-30 letters and numbers."),
	
	
	//Errormessages ForgotPassword GeneralInfoPage
	errormsg_ForgotPasswordGeneralInfowihtoutDOB("//android.view.View[@resource-id='dobError']",XPATH,"Errormsg - ForgotPassword GeneralInfo Please provide a DateOfBirth"),
	errormsg_ForgotPasswordGeneralInfowihtoutLegalName("//android.view.View[@resource-id='nameError']",XPATH,"Errormsg - ForgotPassword GenrealInfor Please enter your legalname"),
	errormsg_ForgotPasswordGeneralInfowithoutAddress("//android.view.View[@resource-id='streetAddressError']",XPATH,"Errormsg - Please provide a street address"),
	errormsg_ForgotPasswordGeneralInfowithoutZipcode("//android.view.View[@resource-id='zipCodeError']",XPATH,"Errormsg - ForgotPassword GeneralInfo Please provide a Zipcode"),
	errormsg_ForgotPasswordGeneralInfowithoutCity("//android.view.View[@resource-id='cityError']",XPATH,"Errormsg - ForgotPassword GeneralInfo Please provide City"),
	errormsg_ForgotPasswordGeneralInforwithoutState("//android.view.View[@resource-id='stateError']",XPATH,"Errormsg - ForgotPassword GeneralInfo Please provide State"),
	errormsg_ForgotPasswordGeneralInfowithoutanydata("//android.view.View[@text='Please fix the errors above']",XPATH,"Errormsg - ForgotPassword GeneralInfo Please fix the errors above"),
	errormsg_ForgotPasswordUsernotfound("//android.view.View[@resource-id='userNotFoundDiv']",XPATH,"Errormsg - We were not able to find your information. Please check and try again."),
	
	
	//Errormessages ForgotPassword VerifyIdentityPage
	errormsg_VerifyIdenityChallengeAnswer("//android.view.View[@resource-id='answerError']",XPATH,"Errormsg - Please provide an answer to account recovery question"),
	errormsg_VerifyIdentitywithoutanydata("//android.view.View[@text='Please fix the errors above']",XPATH,"Errormsg - Please fix the errors above"),
	errormsg_ForgotPasswordInvalidChallengeAnswer("//android.view.View[@resource-id='answerMatchError']",XPATH,"Errormsg - InvalidAnswer ForgotPassword"),
	
	
	//Errormessages ForgotPassword ResetPasswordPage
		errormsg_ForgotPasswordPagefieldvalidation("//android.view.View[@resource-id='passwordError']",XPATH,"Errormsg - ForgotPassword ResetPassword Please provide a password"),
		errormsg_ForgotPasswordResetPasswordpagewithoutanydata("//android.view.View[@text='Please fix the errors above']",XPATH,"Errormsg - ForgotPassword ResetPassword Please fix the errors above"),
		errormsg_ForgotPasswordInvalidPasswordformatentered("//android.view.View[@resource-id='passwordFormatError']",XPATH,"Errormsg - InvalidPasswordformatEntered"),
		errormsg_ForgotPasswordDifferentPasswordentered("//android.view.View[@resource-id='passwordConfirmError']",XPATH,"Errormsg - DifferentPasswordEntered"),
		
       ;
	

	
	String strProperty = "";
   	ObjectLocator locatorType = null;
   	String strObjName = "";
   	
	@Override
	public String getProperty() {
		// TODO Auto-generated method stub
		return strProperty;
	}

	@Override
	public ObjectLocator getLocatorType() {
		// TODO Auto-generated method stub
		return locatorType;
	}

	@Override
	public String getObjectname() {
		// TODO Auto-generated method stub
		return strObjName;
	}
	
	private AppForgotPasswordPageObjects (String strPropertyValue, ObjectLocator locatorType, String strObjName) {
		// TODO Auto-generated method stub
		this.strProperty = strPropertyValue;
   		this.locatorType = locatorType;
   		this.strObjName = strObjName;
		
	}
	
	
	
	

}
