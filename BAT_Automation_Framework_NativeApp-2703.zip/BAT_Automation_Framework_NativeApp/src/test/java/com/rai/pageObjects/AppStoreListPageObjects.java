package com.rai.pageObjects;

import static com.rai.pageObjects.ObjectLocator.*;

public enum AppStoreListPageObjects implements PageObjects {
    
	
	//StoreListPage
	btn_AltHomePageRedeemNow("//android.widget.Button[@text='REDEEM NOW']",XPATH,"Button - AltHomePage RedeemNow"),
	menu_AltHomePage("//android.view.ViewGroup[@index=1 and @instance=2]",XPATH,"Hamburger Menu - AltHomePage"),
	
	
	//Errormessages
	errormsg_nostores("//android.widget.TextView[@text='We are sorry but there are no participating stores in your area at this time. Please check back in the future.']",XPATH,"Errormsg - NoStores"),
	errormsg_nostoresclosebtn("//android.widget.Button[@text='Close']",XPATH,"Errormsg - NoStoresClosebutton"),
	
	
	
	
	
	
	;
	
	
	
	
	String strProperty = "";
   	ObjectLocator locatorType = null;
   	String strObjName = "";
   	
	@Override
	public String getProperty() {
		// TODO Auto-generated method stub
		return strProperty;
	}

	@Override
	public ObjectLocator getLocatorType() {
		// TODO Auto-generated method stub
		return locatorType;
	}

	@Override
	public String getObjectname() {
		// TODO Auto-generated method stub
		return strObjName;
	}
	
	private AppStoreListPageObjects (String strPropertyValue, ObjectLocator locatorType, String strObjName) {
		// TODO Auto-generated method stub
		this.strProperty = strPropertyValue;
   		this.locatorType = locatorType;
   		this.strObjName = strObjName;
		
	}
}
