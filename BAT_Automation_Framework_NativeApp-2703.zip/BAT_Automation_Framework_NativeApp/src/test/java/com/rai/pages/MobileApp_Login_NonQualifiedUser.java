package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.AppLoginPageObjects;

public class MobileApp_Login_NonQualifiedUser extends BaseClass {

	String testcaseName;
	public MobileApp_Login_NonQualifiedUser(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(AppLoginPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("NonQualifiedUser ContactUs Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	
	public void login_EnterValidDatawithQualifiedN() throws IOException
	{
		
		String Email = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data","Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginUsername),Email,AppLoginPageObjects.txt_GrizzlyAPPLoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginPassword),Password,AppLoginPageObjects.txt_GrizzlyAPPLoginPassword.getObjectname());
		commonFunction.scrollToMobileElement("LOG IN");
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_GrizzlyAPPLogin),AppLoginPageObjects.btn_GrizzlyAPPLogin.getObjectname());
	}
	
	
	public void contactUsPage_NonQualifiedUser() throws Exception 
	{
		
		String ExpectedTitle = "CONTACT US";		
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.txt_ContactUs), AppLoginPageObjects.txt_ContactUs.getObjectname(), ExpectedTitle);
				
	}

	
	
	
}

