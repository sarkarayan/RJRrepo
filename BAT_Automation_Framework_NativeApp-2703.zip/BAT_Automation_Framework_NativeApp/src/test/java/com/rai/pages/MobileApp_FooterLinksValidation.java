package com.rai.pages;

import java.io.IOException;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.AppLoginPageObjects;

public class MobileApp_FooterLinksValidation extends BaseClass {

	String testcaseName;
	public MobileApp_FooterLinksValidation(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(AppLoginPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("FooterLinks Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
		
	public void loginPage_GrizzlyPreLoginFooterLinksValidation() throws Exception
	{ 
		
		//PreLogin - PrivacyPolicy
		commonFunction.scrollDown();
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_FooterPrivacyPolicy),AppLoginPageObjects.btn_FooterPrivacyPolicy.getObjectname());
		String ExpectedText = "PRIVACY POLICY AND YOUR CALIFORNIA PRIVACY RIGHTS";
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.txt_PrivacyPolicy), AppLoginPageObjects.txt_PrivacyPolicy.getObjectname(), ExpectedText);
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.txt_Back),AppLoginPageObjects.txt_Back.getObjectname());

		//PreLogin - TermsOfUse
		commonFunction.scrollDown();	
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_FooterTermsofUse),AppLoginPageObjects.btn_FooterTermsofUse.getObjectname());
		ExpectedText = "TERMS AND CONDITIONS OF USE";
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.txt_TermsOfUse), AppLoginPageObjects.txt_TermsOfUse.getObjectname(), ExpectedText);
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.txt_Back),AppLoginPageObjects.txt_Back.getObjectname());
			
		//PreLogin - FAQs 
		commonFunction.scrollDown();		
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_FooterFAQs),AppLoginPageObjects.btn_FooterFAQs.getObjectname());
		ExpectedText = "FAQS";
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.txt_FAQS), AppLoginPageObjects.txt_FAQS.getObjectname(), ExpectedText);
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.txt_Back),AppLoginPageObjects.txt_Back.getObjectname());
		
		
		//PreLogin - ContactUs
		commonFunction.scrollDown();
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_FooterContactUs),AppLoginPageObjects.btn_FooterContactUs.getObjectname());
		ExpectedText = "CONTACT US";
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.txt_ContactUs), AppLoginPageObjects.txt_ContactUs.getObjectname(), ExpectedText);
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.txt_Back),AppLoginPageObjects.txt_Back.getObjectname());
		
		
		//PreLogin - AppRequirements
		commonFunction.scrollDown();	
		ExpectedText = "App Version: QA 3.2.3";
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.btn_FooterAppVersion),AppLoginPageObjects.btn_FooterAppVersion.getObjectname(),ExpectedText);

	}
	
	
	public void loginPage_AppToWebsiteLogin() throws InterruptedException, IOException
	{
		
		String Username = dataTable.getData("General_Data", "Username");
		String Password = dataTable.getData("General_Data", "Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginUsername),Username,AppLoginPageObjects.txt_GrizzlyAPPLoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginPassword),Password, AppLoginPageObjects.txt_GrizzlyAPPLoginPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_GrizzlyAPPLogin), AppLoginPageObjects.btn_GrizzlyAPPLogin.getObjectname());
		Thread.sleep(5000);
	}
	
	
	public void homePage_GrizzlyPostLoginFooterLinksValidation() throws Exception
	{
		
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.menu_AltHomePage), AppLoginPageObjects.menu_AltHomePage.getObjectname());

		//PreLogin - PrivacyPolicy
		commonFunction.scrollDown();
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_FooterPrivacyPolicy),AppLoginPageObjects.btn_FooterPrivacyPolicy.getObjectname());
		String ExpectedText = "PRIVACY POLICY AND YOUR CALIFORNIA PRIVACY RIGHTS";
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.txt_PrivacyPolicy), AppLoginPageObjects.txt_PrivacyPolicy.getObjectname(), ExpectedText);
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.menu_AltHomePageBack),AppLoginPageObjects.menu_AltHomePageBack.getObjectname());

		//PreLogin - TermsOfUse
		commonFunction.scrollDown();
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_FooterTermsofUse),AppLoginPageObjects.btn_FooterTermsofUse.getObjectname());
		ExpectedText = "TERMS AND CONDITIONS OF USE";
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.txt_TermsOfUse), AppLoginPageObjects.txt_TermsOfUse.getObjectname(), ExpectedText);
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.menu_AltHomePageBack),AppLoginPageObjects.menu_AltHomePageBack.getObjectname());
			
		//PreLogin - FAQs 
		commonFunction.scrollDown();		
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_FooterFAQs),AppLoginPageObjects.btn_FooterFAQs.getObjectname());
		ExpectedText = "FAQS";
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.txt_FAQS), AppLoginPageObjects.txt_FAQS.getObjectname(), ExpectedText);
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.menu_AltHomePageBack),AppLoginPageObjects.menu_AltHomePageBack.getObjectname());
				
		//PreLogin - ContactUs
		commonFunction.scrollDown();
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_FooterContactUs),AppLoginPageObjects.btn_FooterContactUs.getObjectname());
		ExpectedText = "CONTACT US";
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.txt_ContactUs), AppLoginPageObjects.txt_ContactUs.getObjectname(), ExpectedText);
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.menu_AltHomePageBack),AppLoginPageObjects.menu_AltHomePageBack.getObjectname());
				
		//PreLogin - AppRequirements
		commonFunction.scrollDown();
		ExpectedText = "App Version: QA 3.2.3";
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.btn_FooterAppVersion),AppLoginPageObjects.btn_FooterAppVersion.getObjectname(),ExpectedText);

		
	}
	
	public void grizzlyHomePage_Logout() throws IOException
	{
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.menu_AltHomePage), AppLoginPageObjects.menu_AltHomePage.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.menu_LogoutLink), AppLoginPageObjects.menu_LogoutLink.getObjectname());
		
	}
		
	
}
