package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.AppForgotPasswordPageObjects;
import com.rai.pageObjects.AppHamburgerMenuPageObjects;
import com.rai.pageObjects.AppLoginPageObjects;

public class MobileApp_MyProfileValidations extends BaseClass {

	String testcaseName;

	public MobileApp_MyProfileValidations(String testcaseName) {
		this.testcaseName = testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper The {@link ScriptHelper} object passed from the
	 *                     {@link DriverScript}
	 */

	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	private WebElement getPageElement(AppHamburgerMenuPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}


	public void loginPage_AppLogin() throws InterruptedException, IOException {

		String Username = dataTable.getData("General_Data", "Username");
		String Password = dataTable.getData("General_Data", "Password");

		commonFunction.clearAndEnterTextTabOut(getPageElement(AppHamburgerMenuPageObjects.txt_LoginUsername), Username,AppHamburgerMenuPageObjects.txt_LoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppHamburgerMenuPageObjects.txt_LoginPassword), Password,AppHamburgerMenuPageObjects.txt_LoginPassword.getObjectname());
		commonFunction.scrollToMobileElement("LOG IN");
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_Login),AppHamburgerMenuPageObjects.btn_Login.getObjectname());
	}

		
	public void NavigatetoMyProfile() throws Exception {	
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.menu_AltHomePage),AppHamburgerMenuPageObjects.menu_AltHomePage.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.menu_MySettingsLink),AppHamburgerMenuPageObjects.menu_MySettingsLink.getObjectname());
	}
	
	public void NavigatetoSavings() throws Exception {	
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.menu_AltHomePage),AppHamburgerMenuPageObjects.menu_AltHomePage.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.menu_SavingsLink),AppHamburgerMenuPageObjects.menu_SavingsLink.getObjectname());
	}
	
	public void NavigatetoCoupons() throws Exception {	
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_RedeemNow),AppHamburgerMenuPageObjects.btn_RedeemNow.getObjectname());
	}
	
	public void OpenCoupons() throws Exception {	
		commonFunction.scrollUp();
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.Offer),AppHamburgerMenuPageObjects.Offer.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_ChooseStore),AppHamburgerMenuPageObjects.btn_ChooseStore.getObjectname());
	}
	
	public void SearchByZipListView() throws Exception {
		String ZipCode = dataTable.getData("General_Data", "FirstName");
		String errmsg_InvalidZip = "We are sorry but there are no participating stores in your area at this time. Please check back in the future.";
		String errmsg_RedeemNow = "You must be in the store to redeem this coupon offer.";

		commonFunction.clearAndEnterText(getPageElement(AppHamburgerMenuPageObjects.txt_Zipcode), "11111", AppHamburgerMenuPageObjects.txt_Zipcode.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(AppHamburgerMenuPageObjects.errormsg_InvalidZipcode),AppHamburgerMenuPageObjects.errormsg_InvalidZipcode.getObjectname(),errmsg_InvalidZip);
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_Close),AppHamburgerMenuPageObjects.btn_Close.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(AppHamburgerMenuPageObjects.txt_Zipcode), ZipCode, AppHamburgerMenuPageObjects.txt_Zipcode.getObjectname());

		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_LoadMore),AppHamburgerMenuPageObjects.btn_LoadMore.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.txt_StoreSection),AppHamburgerMenuPageObjects.txt_StoreSection.getObjectname());

		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_RedeemNow),AppHamburgerMenuPageObjects.btn_RedeemNow.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(AppHamburgerMenuPageObjects.errormsg_RedeemNow),AppHamburgerMenuPageObjects.errormsg_RedeemNow.getObjectname(),errmsg_RedeemNow);
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_Close),AppHamburgerMenuPageObjects.btn_Close.getObjectname());

		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_NotNow),AppHamburgerMenuPageObjects.btn_NotNow.getObjectname());

	}

	public void SearchByZipMapView() throws Exception {
		String ZipCode = dataTable.getData("General_Data", "FirstName");
		String errmsg_InvalidZip = "We are sorry but there are no participating stores in your area at this time. Please check back in the future.";
		String errmsg_RedeemNow = "You must be in the store to redeem this coupon offer.";

		commonFunction.clearAndEnterText(getPageElement(AppHamburgerMenuPageObjects.txt_Zipcode), "11111", AppHamburgerMenuPageObjects.txt_Zipcode.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(AppHamburgerMenuPageObjects.errormsg_InvalidZipcode),AppHamburgerMenuPageObjects.errormsg_InvalidZipcode.getObjectname(),errmsg_InvalidZip);
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_Close),AppHamburgerMenuPageObjects.btn_Close.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(AppHamburgerMenuPageObjects.txt_Zipcode), ZipCode, AppHamburgerMenuPageObjects.txt_Zipcode.getObjectname());

		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.lnk_MapStoreSection),AppHamburgerMenuPageObjects.lnk_MapStoreSection.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.txt_StoreSection),AppHamburgerMenuPageObjects.txt_StoreSection.getObjectname());

		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_RedeemNow),AppHamburgerMenuPageObjects.btn_RedeemNow.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(AppHamburgerMenuPageObjects.errormsg_RedeemNow),AppHamburgerMenuPageObjects.errormsg_RedeemNow.getObjectname(),errmsg_RedeemNow);
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_Close),AppHamburgerMenuPageObjects.btn_Close.getObjectname());

		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_NotNow),AppHamburgerMenuPageObjects.btn_NotNow.getObjectname());

	}

	
	public void MapIt() throws Exception {	
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.lnk_MapIt),AppHamburgerMenuPageObjects.lnk_MapIt.getObjectname());
	}
	
	public void MapView() throws Exception {	
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.lnk_Map),AppHamburgerMenuPageObjects.lnk_Map.getObjectname());
	}
	
	public void ListView() throws Exception {	
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.lnk_List),AppHamburgerMenuPageObjects.lnk_List.getObjectname());
	}
	
	
	public void NavigatetoStoreLocator() throws Exception {	
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.menu_AltHomePage),AppHamburgerMenuPageObjects.menu_AltHomePage.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.menu_StoreLocatorLink),AppHamburgerMenuPageObjects.menu_StoreLocatorLink.getObjectname());
	}
	
	public void NavigatetoHelp() throws Exception {	
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.menu_AltHomePage),AppHamburgerMenuPageObjects.menu_AltHomePage.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.menu_HelpLink),AppHamburgerMenuPageObjects.menu_HelpLink.getObjectname());
	}
	
	public void NavigatetoHamburger() throws Exception {	
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.menu_AltHomePage),AppHamburgerMenuPageObjects.menu_AltHomePage.getObjectname());
	}
	

	public void profileUpdate_UpdatePassword() throws IOException {
		String CurrentPassword = dataTable.getData("General_Data", "Password");
		String NewPassword = dataTable.getData("General_Data", "Password");
		String ConfirmNewPassword = dataTable.getData("General_Data", "Password");

		// MyProfile - User updated NewPassword
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.menu_ChangePassword),AppHamburgerMenuPageObjects.menu_ChangePassword.getObjectname());
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppHamburgerMenuPageObjects.txt_ProfileNewPassword),NewPassword, AppHamburgerMenuPageObjects.txt_ProfileNewPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppHamburgerMenuPageObjects.txt_ProfileConfirmNewPassword),ConfirmNewPassword, AppHamburgerMenuPageObjects.txt_ProfileConfirmNewPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_ProfileUpdatePassword),AppHamburgerMenuPageObjects.btn_ProfileUpdatePassword.getObjectname());
	}
	
	public void profileUpdate_UpdatePin() throws IOException {
		String CurrentPassword = dataTable.getData("General_Data", "Password");
		String NewPassword = dataTable.getData("General_Data", "Password");
		String ConfirmNewPassword = dataTable.getData("General_Data", "Password");

		// MyProfile - User updated NewPassword
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.menu_ChangePassword),AppHamburgerMenuPageObjects.menu_ChangePassword.getObjectname());
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppHamburgerMenuPageObjects.txt_ProfileNewPassword),NewPassword, AppHamburgerMenuPageObjects.txt_ProfileNewPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppHamburgerMenuPageObjects.txt_ProfileConfirmNewPassword),ConfirmNewPassword, AppHamburgerMenuPageObjects.txt_ProfileConfirmNewPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_ProfileUpdatePassword),AppHamburgerMenuPageObjects.btn_ProfileUpdatePassword.getObjectname());
	}


	public void profileUpdate_TobaccoPreferencesUpdate() throws IOException, InterruptedException {
		String SurveyQ1 = dataTable.getData("General_Data", "TobaccoPreferencesSurveyQ1");
		String SurveyQ2 = dataTable.getData("General_Data", "TobaccoPreferencesSurveyQ2");
		commonFunction.scrollDown();
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.menu_TobPref),AppHamburgerMenuPageObjects.menu_TobPref.getObjectname());

		// User selected type of TobaccoProduct (Combustible Tobacco)
		if(!(getPageElement(AppHamburgerMenuPageObjects.chckbox_TobaccoPreferencesCombustible)).isSelected()){
			commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.chckbox_TobaccoPreferencesCombustible),AppHamburgerMenuPageObjects.chckbox_TobaccoPreferencesCombustible.getObjectname());
		}
		
		//Thread.sleep(2000);

		commonFunction.selectValueMobileDropDown(getPageElement(AppHamburgerMenuPageObjects.drpdwn_TobaccoPreferencesSurveyQ1),SurveyQ1,AppHamburgerMenuPageObjects.drpdwn_TobaccoPreferencesSurveyQ1.getObjectname());
		commonFunction.selectValueMobileDropDown(getPageElement(AppHamburgerMenuPageObjects.drpdwn_TobaccoPreferencesSurveyQ2),SurveyQ2,AppHamburgerMenuPageObjects.drpdwn_TobaccoPreferencesSurveyQ1.getObjectname());

		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_TobaccoPreferencesSubmit),AppHamburgerMenuPageObjects.btn_TobaccoPreferencesSubmit.getObjectname());
	}

	
	public void HomePage_Logout() throws IOException
	{
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.menu_AltHomePage), AppHamburgerMenuPageObjects.menu_AltHomePage.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.menu_LogoutLink), AppHamburgerMenuPageObjects.menu_LogoutLink.getObjectname());
		
	}
	
	public void LoginWithPIN() throws IOException
	{		
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_1), AppHamburgerMenuPageObjects.btn_1.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_2), AppHamburgerMenuPageObjects.btn_2.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_3), AppHamburgerMenuPageObjects.btn_3.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_6), AppHamburgerMenuPageObjects.btn_6.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_9), AppHamburgerMenuPageObjects.btn_9.getObjectname());
		
	}
	
	public void LoginWithInvalidPIN() throws IOException
	{		
		String InvalidPIN = "INVALID PIN.  PLEASE AVOID REPEAT AND SEQUENTIAL NUMBERS.";
		String InvalidPIN2 = "INVALID PIN.  PLEASE AVOID REPEAT AND SEQUENTIAL NUMBERS.";
		String InvalidPIN3 = "INVALID PIN.  PLEASE AVOID REPEAT AND SEQUENTIAL NUMBERS.";

		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_1), AppHamburgerMenuPageObjects.btn_1.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_2), AppHamburgerMenuPageObjects.btn_2.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_3), AppHamburgerMenuPageObjects.btn_3.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_6), AppHamburgerMenuPageObjects.btn_6.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_3), AppHamburgerMenuPageObjects.btn_3.getObjectname());

		commonFunction.isElementPresentContainsText(getPageElement(AppHamburgerMenuPageObjects.errormsg_WrongPINLogin1),AppHamburgerMenuPageObjects.errormsg_WrongPINLogin1.getObjectname(),InvalidPIN);
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_OK), AppHamburgerMenuPageObjects.btn_OK.getObjectname());

		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_1), AppHamburgerMenuPageObjects.btn_1.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_2), AppHamburgerMenuPageObjects.btn_2.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_3), AppHamburgerMenuPageObjects.btn_3.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_6), AppHamburgerMenuPageObjects.btn_6.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_3), AppHamburgerMenuPageObjects.btn_3.getObjectname());

		commonFunction.isElementPresentContainsText(getPageElement(AppHamburgerMenuPageObjects.errormsg_WrongPINLogin2),AppHamburgerMenuPageObjects.errormsg_WrongPINLogin2.getObjectname(),InvalidPIN2);
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_OK), AppHamburgerMenuPageObjects.btn_OK.getObjectname());

		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_1), AppHamburgerMenuPageObjects.btn_1.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_2), AppHamburgerMenuPageObjects.btn_2.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_3), AppHamburgerMenuPageObjects.btn_3.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_6), AppHamburgerMenuPageObjects.btn_6.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_3), AppHamburgerMenuPageObjects.btn_3.getObjectname());

		commonFunction.isElementPresentContainsText(getPageElement(AppHamburgerMenuPageObjects.errormsg_WrongPINLogin3),AppHamburgerMenuPageObjects.errormsg_WrongPINLogin3.getObjectname(),InvalidPIN3);
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_OK), AppHamburgerMenuPageObjects.btn_OK.getObjectname());

	}
	
	
	public void ChangePIN() throws IOException
	{
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.menu_ChangePIN), AppHamburgerMenuPageObjects.menu_ChangePIN.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_OK), AppHamburgerMenuPageObjects.btn_OK.getObjectname());
		
		String InvalidPIN = "INVALID PIN.  PLEASE AVOID REPEAT AND SEQUENTIAL NUMBERS.";
		String PINmismatch = "PIN DOES NOT MATCH.  PLEASE TRY AGAIN.";
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_1), AppHamburgerMenuPageObjects.btn_1.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_1), AppHamburgerMenuPageObjects.btn_1.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_1), AppHamburgerMenuPageObjects.btn_1.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_1), AppHamburgerMenuPageObjects.btn_1.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_1), AppHamburgerMenuPageObjects.btn_1.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(AppHamburgerMenuPageObjects.errormsg_InvalidPIN),AppHamburgerMenuPageObjects.errormsg_InvalidPIN.getObjectname(),InvalidPIN);
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_OK), AppHamburgerMenuPageObjects.btn_OK.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_1), AppHamburgerMenuPageObjects.btn_1.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_2), AppHamburgerMenuPageObjects.btn_2.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_3), AppHamburgerMenuPageObjects.btn_3.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_4), AppHamburgerMenuPageObjects.btn_4.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_5), AppHamburgerMenuPageObjects.btn_5.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(AppHamburgerMenuPageObjects.errormsg_InvalidPIN),AppHamburgerMenuPageObjects.errormsg_InvalidPIN.getObjectname(),InvalidPIN);
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_OK), AppHamburgerMenuPageObjects.btn_OK.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_1), AppHamburgerMenuPageObjects.btn_1.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_2), AppHamburgerMenuPageObjects.btn_2.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_3), AppHamburgerMenuPageObjects.btn_3.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_6), AppHamburgerMenuPageObjects.btn_6.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_9), AppHamburgerMenuPageObjects.btn_9.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_1), AppHamburgerMenuPageObjects.btn_1.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_2), AppHamburgerMenuPageObjects.btn_2.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_3), AppHamburgerMenuPageObjects.btn_3.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_6), AppHamburgerMenuPageObjects.btn_6.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_4), AppHamburgerMenuPageObjects.btn_4.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(AppHamburgerMenuPageObjects.errormsg_PINmismatch),AppHamburgerMenuPageObjects.errormsg_PINmismatch.getObjectname(),PINmismatch);
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_OK), AppHamburgerMenuPageObjects.btn_OK.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_1), AppHamburgerMenuPageObjects.btn_1.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_2), AppHamburgerMenuPageObjects.btn_2.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_3), AppHamburgerMenuPageObjects.btn_3.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_6), AppHamburgerMenuPageObjects.btn_6.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppHamburgerMenuPageObjects.btn_9), AppHamburgerMenuPageObjects.btn_9.getObjectname());
	
	}
	
	
}
