package com.rai.pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.AppForgotPasswordPageObjects;
import com.rai.pageObjects.AppForgotUsernamePageObjects;
import com.rai.pageObjects.AppRegistrationPageObjects;
import com.rai.pageObjects.AppRegistrationPageObjects;

import io.appium.java_client.android.AndroidDriver;


public class MobileApp_Registration extends BaseClass {

	String testcaseName;
	public MobileApp_Registration(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(AppRegistrationPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	public void allowAPPPermission() throws InterruptedException, IOException
	{
		Thread.sleep(5000);		
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_AppAllowPermission),AppForgotPasswordPageObjects.btn_AppAllowPermission.getObjectname());
				
	}
	
	public void navigateToRegistrationPage() throws IOException, InterruptedException {
		//WebDriverWait wait = new WebDriverWait(driver, 30);
		Thread.sleep(4000);
		commonFunction.scrollDown();
		Thread.sleep(4000);
					
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_GrizzlyAPPRegister), AppRegistrationPageObjects.btn_GrizzlyAPPRegister.getObjectname());
	}
	
	public void validateErrormessageonStep1() throws InterruptedException, IOException
	{
		
		String Errormessage_NoDOB = "Please provide your full date of birth";
		String Errormessage_NoData = "Please fix the errors above";
		String Errormessage_Acknowledge = "Please acknowledge.";
		String Errormessage_NoLegalName = "Please enter your legal name";
		String Errormessage_NoAddress = "Please provide a street address";
		String Errormessage_NoZipcode = "Please provide a ZIP Code";
		String Errormessage_NoCity = "Please Provide City";
		String Errormessage_NoState = "Please Provide State";
		String Errormessage_NoEmail = "Please enter a valid email address";		

		Thread.sleep(4000);
		commonFunction.scrollDown();
				
		//User clicked on Next without any data
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_RegistrationStep1Next), AppRegistrationPageObjects.btn_RegistrationStep1Next.getObjectname());
		commonFunction.scrollUp();
		commonFunction.scrollUp();
		commonFunction.isElementPresentContainsText(getPageElement(AppRegistrationPageObjects.errormsg_RegistrationNoDOB), AppRegistrationPageObjects.errormsg_RegistrationNoLegalName.getObjectname(), Errormessage_NoDOB);
		commonFunction.isElementPresentContainsText(getPageElement(AppRegistrationPageObjects.errormsg_RegistrationNoLegalName), AppRegistrationPageObjects.errormsg_RegistrationNoLegalName.getObjectname(), Errormessage_NoLegalName);
		commonFunction.isElementPresentContainsText(getPageElement(AppRegistrationPageObjects.errormsg_RegistrationNoAddress), AppRegistrationPageObjects.errormsg_RegistrationNoAddress.getObjectname(), Errormessage_NoAddress);
		commonFunction.scrollToMobileElement("Please provide a ZIP Code");
		commonFunction.isElementPresentContainsText(getPageElement(AppRegistrationPageObjects.errormsg_RegistrationNoZipcode), AppRegistrationPageObjects.errormsg_RegistrationNoZipcode.getObjectname(), Errormessage_NoZipcode);
		commonFunction.scrollToMobileElement("Please Provide City");
		commonFunction.isElementPresentContainsText(getPageElement(AppRegistrationPageObjects.errormsg_RegistrationNoCity), AppRegistrationPageObjects.errormsg_RegistrationNoCity.getObjectname(), Errormessage_NoCity);
		commonFunction.isElementPresentContainsText(getPageElement(AppRegistrationPageObjects.errormsg_RegistrationNoState), AppRegistrationPageObjects.errormsg_RegistrationNoState.getObjectname(), Errormessage_NoState);
		commonFunction.isElementPresentContainsText(getPageElement(AppRegistrationPageObjects.errormsg_RegistrationNoEmail), AppRegistrationPageObjects.errormsg_RegistrationNoEmail.getObjectname(), Errormessage_NoEmail);
		commonFunction.scrollToMobileElement("Please fix the errors above");		
		commonFunction.isElementPresentContainsText(getPageElement(AppRegistrationPageObjects.erromsg_RegistrationStep1), AppRegistrationPageObjects.erromsg_RegistrationStep1.getObjectname(), Errormessage_Acknowledge);
		commonFunction.isElementPresentContainsText(getPageElement(AppRegistrationPageObjects.errmsg_Step1), AppRegistrationPageObjects.errmsg_Step1.getObjectname(), Errormessage_NoData);
		
			
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.lnk_RegistrationStep1BacktoLogin),AppRegistrationPageObjects.lnk_RegistrationStep1BacktoLogin.getObjectname());
		Thread.sleep(4000);
		commonFunction.scrollDown();
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_GrizzlyAPPRegister),AppRegistrationPageObjects.btn_GrizzlyAPPRegister.getObjectname());
		Thread.sleep(4000);
		
	}
	
	@SuppressWarnings("rawtypes")
	public void enterValidDataStep1() throws InterruptedException, IOException
	{
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String date = dataTable.getData("General_Data","DOB");
		String city = dataTable.getData("General_Data","City");
		String state = dataTable.getData("General_Data","State");
		String email = dataTable.getData("General_Data","Email");
			String dateParts[] = date.split("/");
			String month  = dateParts[0];
			String day  = dateParts[1];
			String year = dateParts[2];
		
		commonFunction.selectValueMobileDropDown(getPageElement(AppRegistrationPageObjects.drpdwn_RegistrationStep1BirthMonth),month, AppRegistrationPageObjects.drpdwn_RegistrationStep1BirthMonth.getObjectname());
		commonFunction.selectValueMobileDropDown(getPageElement(AppRegistrationPageObjects.drpdwn_RegistrationStep1BirthDay),day,AppRegistrationPageObjects.drpdwn_RegistrationStep1BirthDay.getObjectname());
		commonFunction.selectValueMobileDropDown(getPageElement(AppRegistrationPageObjects.drpdwn_RegistrationStep1BirthYear),year,AppRegistrationPageObjects.drpdwn_RegistrationStep1BirthYear.getObjectname());
		((AndroidDriver)driver).hideKeyboard();
				
    			
		commonFunction.clearAndEnterText(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep1FirstName),FirstName, AppRegistrationPageObjects.txt_RegistrationStep1FirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep1LastName), LastName,AppRegistrationPageObjects.txt_RegistrationStep1LastName.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep1Address1), Address,AppRegistrationPageObjects.txt_RegistrationStep1Address1.getObjectname());
		
		((AndroidDriver)driver).hideKeyboard();
		commonFunction.scrollToMobileElement("Current Address");
			
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep1Zipcode),Zipcode,AppRegistrationPageObjects.txt_RegistrationStep1Zipcode.getObjectname());
		((AndroidDriver)driver).hideKeyboard();
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep1City),city,AppRegistrationPageObjects.txt_RegistrationStep1City.getObjectname());
		((AndroidDriver)driver).hideKeyboard();
		commonFunction.selectValueMobileDropDown(getPageElement(AppRegistrationPageObjects.drpdwn_RegistrationStep1State),state,AppRegistrationPageObjects.drpdwn_RegistrationStep1State.getObjectname());
		
		((AndroidDriver)driver).hideKeyboard();
		commonFunction.scrollDown();
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep1Email), email, AppRegistrationPageObjects.txt_RegistrationStep1Email.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.chkbox_RegistrationStep1), AppRegistrationPageObjects.chkbox_RegistrationStep1.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_RegistrationStep1Next), AppRegistrationPageObjects.btn_RegistrationStep1Next.getObjectname());
		
	}
	
	public void registration_ValidateErrormessageonStep2() throws IOException
	{
		
		String InvalidPasswordformat = dataTable.getData("General_Data", "InvalidPasswordformat");
		String Password = dataTable.getData("General_Data", "Password");
		String IncorrectPassword = dataTable.getData("General_Data", "InvalidPassword");
		
		String Errormessage_NoData = "Please fix the errors above";
		String Errormessage_NoPassword = "Please provide a password";
		String Errormessage_NoChallengeQuestion = "Please select a account recovery question";
		String Errormessage_NoChallengeAnswer = "Please provide an answer to account recovery question";
		String Errormessage_IncorrectPasswordformat = "Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.";
		String Errormessage_DiffPassword = "Passwords did not match";
		
		//User clicked on Next without any data
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_RegistrationStep2Next), AppRegistrationPageObjects.btn_RegistrationStep2Next.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(AppRegistrationPageObjects.errormsg_RegistrationNoPassword), AppRegistrationPageObjects.errormsg_RegistrationNoPassword.getObjectname(), Errormessage_NoPassword);
		commonFunction.isElementPresentContainsText(getPageElement(AppRegistrationPageObjects.errormsg_RegistrationNoChallengeQuestion), AppRegistrationPageObjects.errormsg_RegistrationNoChallengeQuestion.getObjectname(), Errormessage_NoChallengeQuestion);
		commonFunction.isElementPresentContainsText(getPageElement(AppRegistrationPageObjects.errormsg_RegistrationNoChallengeAnswer), AppRegistrationPageObjects.errormsg_RegistrationNoChallengeAnswer.getObjectname(), Errormessage_NoChallengeAnswer);
		commonFunction.isElementPresentContainsText(getPageElement(AppRegistrationPageObjects.errormsg_RegistrationNoDataonStep2Page), AppRegistrationPageObjects.errormsg_RegistrationNoDataonStep2Page.getObjectname(), Errormessage_NoData);
		
		//User entered Password in Invalid format
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep2Password), InvalidPasswordformat, AppRegistrationPageObjects.txt_RegistrationStep2Password.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(AppRegistrationPageObjects.errormsg_RegistrationIncorrectPasswordformat), AppRegistrationPageObjects.errormsg_RegistrationIncorrectPasswordformat.getObjectname(), Errormessage_IncorrectPasswordformat);
		
		//User entered different data in Password & ConfirmPassword fields
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep2Password),Password, AppRegistrationPageObjects.txt_RegistrationStep2Password.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep2NewPassword),IncorrectPassword, AppRegistrationPageObjects.txt_RegistrationStep2NewPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_RegistrationStep2Next), AppRegistrationPageObjects.btn_RegistrationStep2Next.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(AppRegistrationPageObjects.errormsg_RegistrationDifferentPasswordsentered), AppRegistrationPageObjects.errormsg_RegistrationDifferentPasswordsentered.getObjectname(), Errormessage_DiffPassword);
				
	}
	
	
	
	public void enterValidDataStep2() throws IOException
	{
		String Password = dataTable.getData("General_Data", "Password");
		String ChallengeAnswer = dataTable.getData("General_Data", "ChallengeAnswer");
		String ChallengeQuestion = "What was the name of your first school?";
		
		commonFunction.clearAndEnterText(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep2Password), Password, AppRegistrationPageObjects.txt_RegistrationStep2Password.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep2NewPassword), Password, AppRegistrationPageObjects.txt_RegistrationStep2NewPassword.getObjectname());
		commonFunction.selectValueMobileDropDown(getPageElement(AppRegistrationPageObjects.drpdwn_RegistrationStep2ChallengeQuestion),ChallengeQuestion ,AppRegistrationPageObjects.drpdwn_RegistrationStep2ChallengeQuestion.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep2ChallengeAnswer),ChallengeAnswer,AppRegistrationPageObjects.txt_RegistrationStep2ChallengeAnswer.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_RegistrationStep2Next), AppRegistrationPageObjects.btn_RegistrationStep2Next.getObjectname());
				
	}
	
	public void registration_ValidateErrormessageonStep3() throws Exception
	{
		
		String InvalidSSN= dataTable.getData("General_Data", "InvalidSSN");
		
		String Errormessage_InvalidSSN = "Your Social Security Number does not match your name and date of birth. Please try again.";
		
		try {
			
		if(getPageElement(AppRegistrationPageObjects.txt_onlySSNvisible).isDisplayed())
		{
			
			commonFunction.clearAndEnterTextTabOut(getPageElement(AppRegistrationPageObjects.txt_onlySSNvisible),InvalidSSN,AppRegistrationPageObjects.txt_onlySSNvisible.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_SubmitwhenonlySSNVisible), AppRegistrationPageObjects.btn_SubmitwhenonlySSNVisible.getObjectname());
			commonFunction.isElementPresentContainsText(getPageElement(AppRegistrationPageObjects.erroMsg_RegistrationInvaliSSNNoKBA), AppRegistrationPageObjects.erroMsg_RegistrationInvaliSSNNoKBA.getObjectname(), Errormessage_InvalidSSN);
						
		}
		}
		catch(Exception SSN){
		
					
			commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.radbtn_RegistrationStep3SSN), AppRegistrationPageObjects.radbtn_RegistrationStep3SSN.getObjectname());
			commonFunction.clearAndEnterTextTabOut(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep3SSN),InvalidSSN,AppRegistrationPageObjects.txt_RegistrationStep3SSN.getObjectname());
			commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_RegistrationStep3Submit), AppRegistrationPageObjects.btn_RegistrationStep3Submit.getObjectname());
			commonFunction.isElementPresentContainsText(getPageElement(AppRegistrationPageObjects.erroMsg_RegistrationInvaliSSNNoKBA), AppRegistrationPageObjects.erroMsg_RegistrationInvaliSSNNoKBA.getObjectname(), Errormessage_InvalidSSN);
			
			
		}
		
	}
	
	
	
	public void enterValidateAgebySSN() throws IOException
	{
		String SSN= dataTable.getData("General_Data", "SSN");
		
		try {
			if(getPageElement(AppRegistrationPageObjects.txt_onlySSNvisible).isDisplayed())
			{			
				commonFunction.clearAndEnterTextTabOut(getPageElement(AppRegistrationPageObjects.txt_onlySSNvisible),SSN,AppRegistrationPageObjects.txt_onlySSNvisible.getObjectname());
				//commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_SubmitwhenonlySSNVisible), AppRegistrationPageObjects.btn_SubmitwhenonlySSNVisible.getObjectname());
			}
			}
			catch(Exception SSN1)
			{
				commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.radbtn_RegistrationStep3SSN), AppRegistrationPageObjects.radbtn_RegistrationStep3SSN.getObjectname());
				commonFunction.clearAndEnterTextTabOut(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep3SSN),SSN,AppRegistrationPageObjects.txt_RegistrationStep3SSN.getObjectname());
				//commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_RegistrationStep3Submit), AppRegistrationPageObjects.btn_RegistrationStep3Submit.getObjectname());	
			}	
	}
	
	
	public void navigateTutorial() throws InterruptedException, IOException
	{
		
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.lnk_CreatePINSkip),AppRegistrationPageObjects.lnk_CreatePINSkip.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_AppTutorialStep1TurnON),AppRegistrationPageObjects.btn_AppTutorialStep1TurnON.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_AppTutorialStep2Allow),AppRegistrationPageObjects.btn_AppTutorialStep2Allow.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_AppTutorialStep3GotIt),AppRegistrationPageObjects.btn_AppTutorialStep3GotIt.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_AppTutorialStep4GotIt),AppRegistrationPageObjects.btn_AppTutorialStep4GotIt.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_AppTutorialStep5GotIt),AppRegistrationPageObjects.btn_AppTutorialStep5GotIt.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_DeviceLocationAllow),AppRegistrationPageObjects.btn_DeviceLocationAllow.getObjectname());
		Thread.sleep(4000);
			
	}
	
	

}
