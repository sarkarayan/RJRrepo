package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;

import com.rai.pageObjects.AppLoginPageObjects;
import com.rai.pageObjects.AppRegistrationPageObjects;

import io.appium.java_client.android.AndroidDriver;

public class MobileApp_LoginPageValidationsandAccountLock extends BaseClass {

	String testcaseName;
	public MobileApp_LoginPageValidationsandAccountLock(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(AppLoginPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Login Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	
	public void loginPage_fieldValidations() throws IOException 
	{
          String NonExistUserId = dataTable.getData("General_Data","NonExistUserId");
          String ValidPassword = dataTable.getData("General_Data","Password");
          String InvalidUserIdformat = dataTable.getData("General_Data","InvalidUserIDformat");
          String Expectederrormsg_LoginwithoutanyData = "PLEASE FILL IN ALL REQUIRED INFORMATION.";
          String Expectederrormsg_LoginwithNonExistUserId = "USERNAME OR PASSWORD INCORRECT.";
          String Expectederrormsg_LoginwithUserIdwithunacceptedcharacters = "USERNAME MUST BE A COMBINATION OF 8-30 LETTERS AND NUMBERS.";
  		
		
        //Login without any data
        commonFunction.scrollDown();
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_GrizzlyAPPLogin), AppLoginPageObjects.btn_GrizzlyAPPLogin.getObjectname());
		
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.errormsg_LoginwithoutanyData), AppLoginPageObjects.errormsg_LoginwithoutanyData.getObjectname(), Expectederrormsg_LoginwithoutanyData);
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_OK_LoginwithoutanyData), AppLoginPageObjects.btn_OK_LoginwithoutanyData.getObjectname());
		
		
		//Login with Username not exists in DB
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginUsername),NonExistUserId,AppLoginPageObjects.txt_GrizzlyAPPLoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginPassword),ValidPassword, AppLoginPageObjects.txt_GrizzlyAPPLoginPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_GrizzlyAPPLogin), AppLoginPageObjects.btn_GrizzlyAPPLogin.getObjectname());
		
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.errormsg_LoginwithNonExistingUserId), AppLoginPageObjects.errormsg_LoginwithNonExistingUserId.getObjectname(), Expectederrormsg_LoginwithNonExistUserId);
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_Close_LoginwithWrongData), AppLoginPageObjects.btn_Close_LoginwithWrongData.getObjectname());
		
		
		//Login with UserId(having unaccepted characters)
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginUsername),InvalidUserIdformat,AppLoginPageObjects.txt_GrizzlyAPPLoginUsername.getObjectname());
		//commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_Login), AppLoginPageObjects.btn_Login.getObjectname());
		
		commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.errormsg_Usernamefieldformaterror), AppLoginPageObjects.errormsg_Usernamefieldformaterror.getObjectname(), Expectederrormsg_LoginwithUserIdwithunacceptedcharacters);
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_OK_LoginwithoutanyData), AppLoginPageObjects.btn_OK_LoginwithoutanyData.getObjectname());	
		
	}
	
	public void loginPage_Loginwith128characters() throws IOException, InterruptedException
	{
		String ValidUserId = dataTable.getData("General_Data","Username");
		String ValidPassword = dataTable.getData("General_Data","Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginUsername),ValidUserId,AppLoginPageObjects.txt_GrizzlyAPPLoginUsername.getObjectname());
        commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginPassword),ValidPassword,AppLoginPageObjects.txt_GrizzlyAPPLoginPassword.getObjectname());
        commonFunction.scrollToMobileElement("LOG IN");
        commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_GrizzlyAPPLogin), AppLoginPageObjects.btn_GrizzlyAPPLogin.getObjectname());
		Thread.sleep(4000);
        commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_NotNowEasyLogIn), AppLoginPageObjects.btn_NotNowEasyLogIn.getObjectname());

	}
	
	
	public void loginPage_ValidateErrormsg_AccountLock() throws IOException
	{
		String ValidUserId = dataTable.getData("General_Data","Username");
        String InvalidPassword = dataTable.getData("General_Data","InvalidPassword");
        String Expectederrormsg_invalidPassword1sttime = "USERNAME OR PASSWORD INCORRECT.  YOU HAVE 2 ATTEMPTS LEFT.";
        String Expectederrormsg_invalidPassword2ndtime = "USERNAME OR PASSWORD INCORRECT.  YOU HAVE 1 ATTEMPT LEFT.";
        String Expectederrormsg_invalidPassword3rdtime = "We're sorry. We are unable to process your request. Please try again later.";
        
        //User entered Invalid password for 1st time
       /* commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginUsername),ValidUserId,AppLoginPageObjects.txt_GrizzlyAPPLoginUsername.getObjectname());
        commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginPassword),InvalidPassword,AppLoginPageObjects.txt_GrizzlyAPPLoginPassword.getObjectname());
        commonFunction.scrollToMobileElement("LOG IN");
        commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_GrizzlyAPPLogin), AppLoginPageObjects.btn_GrizzlyAPPLogin.getObjectname());
        
        commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.errormsg_WrongPasswrd), AppLoginPageObjects.errormsg_WrongPasswrd.getObjectname(), Expectederrormsg_invalidPassword1sttime);
        commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_OK_LoginwithoutanyData), AppLoginPageObjects.btn_OK_LoginwithoutanyData.getObjectname());
				
        
        //User entered Invalid password for 2nd time
        commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginUsername),ValidUserId,AppLoginPageObjects.txt_GrizzlyAPPLoginUsername.getObjectname());
        commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginPassword),InvalidPassword,AppLoginPageObjects.txt_GrizzlyAPPLoginPassword.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_GrizzlyAPPLogin), AppLoginPageObjects.btn_GrizzlyAPPLogin.getObjectname());
              
        commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.errormsg_WrongPasswrd2ndattempt), AppLoginPageObjects.errormsg_WrongPasswrd2ndattempt.getObjectname(), Expectederrormsg_invalidPassword2ndtime);
        commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_OK_LoginwithoutanyData), AppLoginPageObjects.btn_OK_LoginwithoutanyData.getObjectname());
	*/			
           
        //User entered Invalid password for 3rd time
        commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginUsername),ValidUserId,AppLoginPageObjects.txt_GrizzlyAPPLoginUsername.getObjectname());
        commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginPassword),InvalidPassword,AppLoginPageObjects.txt_GrizzlyAPPLoginPassword.getObjectname());
        commonFunction.scrollToMobileElement("LOG IN");
        commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_GrizzlyAPPLogin), AppLoginPageObjects.btn_GrizzlyAPPLogin.getObjectname());
        
        commonFunction.isElementPresentContainsText(getPageElement(AppLoginPageObjects.errormsg_WrongPasswrd3rdattempt), AppLoginPageObjects.errormsg_WrongPasswrd3rdattempt.getObjectname(), Expectederrormsg_invalidPassword3rdtime);
        commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_OK_LoginwithoutanyData), AppLoginPageObjects.btn_OK_LoginwithoutanyData.getObjectname());
		
	}
	
	
	@SuppressWarnings("rawtypes")
	public void loginPage_ResetLockedAccount() throws InterruptedException, IOException
	{
		String Email = dataTable.getData("General_Data", "Email");
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
		String ChallengeAnswer = dataTable.getData("General_Data", "ChallengeAnswer");
		String Password = dataTable.getData("General_Data", "Password");
		String ConfirmPassword = dataTable.getData("General_Data", "Password");
				
		String date = dataTable.getData("General_Data","DOB");
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
				
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_ForgotPasswordUsername), Email, AppLoginPageObjects.txt_ForgotPasswordUsername.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_ForgotPasswordUsernameContinue), AppLoginPageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
		
		commonFunction.selectValueMobileDropDown(getPageElement(AppLoginPageObjects.drpdwn_ForgotUsernameBirthMonth), month, AppLoginPageObjects.drpdwn_ForgotUsernameBirthMonth.getObjectname());
		commonFunction.selectValueMobileDropDown(getPageElement(AppLoginPageObjects.drpdwn_ForgotUsernameBirthDay),day,AppLoginPageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.selectValueMobileDropDown(getPageElement(AppLoginPageObjects.drpdwn_ForgotUsernameBirthYear), year, AppLoginPageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		((AndroidDriver)driver).hideKeyboard();
		commonFunction.scrollToMobileElement("Legal Name");
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_ForgotUsernameFirstName), FirstName, AppLoginPageObjects.txt_ForgotUsernameFirstName.getObjectname());
		((AndroidDriver)driver).hideKeyboard();
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_ForgotUsernameLastName), LastName, AppLoginPageObjects.txt_ForgotUsernameLastName.getObjectname());
		((AndroidDriver)driver).hideKeyboard();
		commonFunction.scrollToMobileElement("Address");
		commonFunction.clearAndEnterText(getPageElement(AppLoginPageObjects.txt_ForgotUsernameAddress), Address, AppLoginPageObjects.txt_ForgotUsernameAddress.getObjectname());
		commonFunction.scrollDown();
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_ForgotUsernameZipcode), Zipcode,AppLoginPageObjects.txt_ForgotUsernameZipcode.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_ForgotUsernameCity), City, AppLoginPageObjects.txt_ForgotUsernameCity.getObjectname());
		commonFunction.selectValueMobileDropDown(getPageElement(AppLoginPageObjects.drpdwn_ForgotUsernameState),State, AppLoginPageObjects.drpdwn_ForgotUsernameState.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.Continuebtn_LoginResetviaLoginonGeneralInfo),AppLoginPageObjects.Continuebtn_LoginResetviaLoginonGeneralInfo.getObjectname());
		
			
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_ForgotPasswordChallengeAnswer), ChallengeAnswer, AppLoginPageObjects.txt_ForgotPasswordChallengeAnswer.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_ForgotPasswordVerifyIdentity), AppLoginPageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
		//Thread.sleep(4000);
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_ForgotPasswordPassword), Password, AppLoginPageObjects.txt_ForgotPasswordPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_ForgotPasswordConfirmPassword), ConfirmPassword, AppLoginPageObjects.txt_ForgotPasswordConfirmPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_ForgotPasswordResetPassword), AppLoginPageObjects.btn_ForgotPasswordResetPassword.getObjectname());
		//Thread.sleep(4000);
		
		commonFunction.clearAndEnterText(getPageElement(AppLoginPageObjects.txt_CongratsPageUsername),Email, AppLoginPageObjects.txt_CongratsPageUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_CongratsPagePassword), Password,AppLoginPageObjects.txt_CongratsPagePassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_CongratsPageLoginbutton), AppLoginPageObjects.btn_CongratsPageLoginbutton.getObjectname());
			
	}
	
		
	
	
}

