package testscripts.cts.PallMallNativeApp;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.MobileApp_Registration;


@Listeners(ExtentITestListenerClassAdapter.class)
public class RegistrationwithSSN_NegativeValidations_PallMallNativeApp extends BaseClass{


	MobileApp_Registration grizzlyRegistrationApp;
	
	public RegistrationwithSSN_NegativeValidations_PallMallNativeApp() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("98892A4144365A334C")String deviceName, @Optional("")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		
		grizzlyRegistrationApp = new MobileApp_Registration(this.getClass().getSimpleName());
		gl= new GenericLib(this.getClass().getSimpleName());
		gl.start_report(this.getClass().getSimpleName(), "Verify NegativeValidations of Registration with SSN", properties.getProperty("ApplicationUrl"));
	}
	
	@Test
	public void verifyRegistrationwithSSN_NegativeValidations() throws Exception {
		
		grizzlyRegistrationApp.navigateToRegistrationPage();
		grizzlyRegistrationApp.validateErrormessageonStep1();
		grizzlyRegistrationApp.enterValidDataStep1();
		grizzlyRegistrationApp.registration_ValidateErrormessageonStep2();
		grizzlyRegistrationApp.enterValidDataStep2();
		grizzlyRegistrationApp.registration_ValidateErrormessageonStep3();
		
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		gl.endReport();
		
	}

}
