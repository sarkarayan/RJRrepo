package testscripts.cts.NPNativeApp;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.MobileAppForgotUsername;

@Listeners(ExtentITestListenerClassAdapter.class)
public class ForgotUsername_RetrieveUserId_NPNativeApp extends BaseClass {
	MobileAppForgotUsername grizzlyAppForgotUsername;
	public ForgotUsername_RetrieveUserId_NPNativeApp() {
		super();
	}
	
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion", "AppPackageName", "AppMainActivityName" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("CE071827327A2026037E")String deviceName, @Optional("")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion, @Optional("com.rjrt.NewPort")String appPackageName, @Optional("com.rjrt.NewPort.NewPort")String appMainActivityName) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion, appPackageName, appMainActivityName); 
		grizzlyAppForgotUsername = new MobileAppForgotUsername(this.getClass().getSimpleName());
		gl= new GenericLib(this.getClass().getSimpleName());
		//gl.start_report(this.getClass().getSimpleName(), "Verify the forgot username flow", properties.getProperty("ApplicationUrl"));
	}
	
	@Test
	public void verifyForgotUserNameFlow_NPNativeApp() throws Exception {
		grizzlyAppForgotUsername.enterdetailsonAccountInfoPage();
		grizzlyAppForgotUsername.verifyIdentityPage();
		grizzlyAppForgotUsername.navigatebackfromWelcomeBackPage();
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		//gl.endReport();
		
	}
}
