package testscripts.cts.NPNativeApp;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.MobileApp_LoginFlow_LoginResetPandY_PrimaryUandY;

@Listeners(ExtentITestListenerClassAdapter.class)
public class ResetPandY_PrimaryUandY_Login_NPNativeApp extends BaseClass {

	MobileApp_LoginFlow_LoginResetPandY_PrimaryUandY mobileAppRegistrationLoginReset;

	public ResetPandY_PrimaryUandY_Login_NPNativeApp() {
		super();
	}

	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion", "AppPackageName", "AppMainActivityName" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("CE071827327A2026037E")String deviceName, @Optional("")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion, @Optional("com.rjrt.NewPort")String appPackageName, @Optional("com.rjrt.NewPort.NewPort")String appMainActivityName) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion, appPackageName, appMainActivityName); 
		mobileAppRegistrationLoginReset = new MobileApp_LoginFlow_LoginResetPandY_PrimaryUandY(
				this.getClass().getSimpleName());
		gl = new GenericLib(this.getClass().getSimpleName());
		gl.start_report(this.getClass().getSimpleName(),
				"Verify Login reset flow if Webaccess'U' and LoginReset 'Y' & Primary is 'U' and 'Y'",
				properties.getProperty("ApplicationUrl"));
	}

	@Test
	public void verifyLoginResetFlow_PandY_PrimaryUandY() throws Exception {
		mobileAppRegistrationLoginReset.login_EnterValidDataPandY();
		mobileAppRegistrationLoginReset.resetflow_GeneralInfoPageviaLogin();
		mobileAppRegistrationLoginReset.resetflow_NegativeValidationsAccountInfoPage();
		mobileAppRegistrationLoginReset.resetflow_AccountInfoPage();
		mobileAppRegistrationLoginReset.resetflow_CongratsPage();
	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
		gl.endReport();

	}

}
