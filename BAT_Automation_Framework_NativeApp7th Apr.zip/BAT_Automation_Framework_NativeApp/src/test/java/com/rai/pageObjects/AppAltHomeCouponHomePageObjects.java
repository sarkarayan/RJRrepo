package com.rai.pageObjects;

import static com.rai.pageObjects.ObjectLocator.*;

public enum AppAltHomeCouponHomePageObjects implements PageObjects {
    
	
	//AltHomePage
	btn_AltHomePageRedeemNow("//android.widget.Button[@text='REDEEM NOW']",XPATH,"Button - AltHomePage RedeemNow"),
	menu_AltHomePage("//android.view.ViewGroup[@index=1 and @instance=2]",XPATH,"Hamburger Menu - AltHomePage"),
	grizzltext_AltHomePage("android.widget.ImageView[@index=0 and @instance=1]",XPATH,"The EXCHANGE text"),
	couponCount_AltHomePage("//android.widget.TextView[@index=0 and @instance=0]",XPATH,"CouponCount - AltHomePage"),
	tile1_AltHomePage("//android.view.View[@resource-id='klink1']",XPATH,"1st tile - AltHomePage"),
	tile2_AltHomePage("//android.view.View[@resource-id='klink2']",XPATH,"2nd tile - AltHomePage"),
	tile3_AltHomePage("//android.view.View[@resource-id='klink3']",XPATH,"3rd tile - AltHomePage"),
	sgwImage_AltHomePage("//android.widget.Image[@resource-id='sgwimg']",XPATH,"SGWImage - AltHomePage"),
	sgwTriggertxt_AltHomePage("//android.view.View[@text='MOIST SNUFF']",XPATH,"SGWTriggertext - AltHomePage"),
	
	//CouponHomePage
	welcometxt_CouponHomePage("//android.view.ViewGroup[@index=1]/android.widget.TextView[@index=0]",XPATH,"Welcometxt - CouponHomePage"),
	userFirstNametxt_CouponHomePage("//android.view.ViewGroup[@index=1]/android.widget.TextView[@index=1]",XPATH,"userFirstNametxt - CouponHomePage"),
	dollarsymbol1stoffer_CouponHomePage("//android.view.ViewGroup[@index=0 and @instance=13]/android.widget.TextView[@index=1 and @instance=4]",XPATH,"DollarSymbol 1stOffer - CouponHomePage"),
	dollarvalue1stoffer_CouponHomePage("//android.view.ViewGroup[@index=0 and @instance=12]/android.widget.TextView[@index=1 and @instance=5]",XPATH,"DollarValue 1stOffer - CouponHomePage"),
	offertext1stoffer_CouponHomePage("//android.view.ViewGroup[@index=0 and @instance=11]/android.widget.TextView[@index=2 and @instance=7]",XPATH,"Offertext 1stOffer - CouponHomePage"),
	goodOnAnyStyle1stoffer_CouponHomePage("//android.view.ViewGroup[@index=0 and @instance=11]/android.widget.TextView[@index=4 and @instance=9]",XPATH,"GoodOnAnyStyle 1stOffer - CouponHomePage"),
	offerExpirestext1stoffer_CouponHomePage("//android.view.ViewGroup[@index=0 and @instance=11]/android.widget.TextView[@index=5 and @instance=10]",XPATH,"OfferExpiresText 1stOffer - CouponHomePage"),
	couponvalidfortext1stoffer_CouponHomePage("//android.view.ViewGroup[@index=1 and @instance=14]/android.widget.TextView[@index=0 and @instance=11]",XPATH,"couponvalidtext 1stOffer - CouponHomePage"),
	validDayaforCoupon1stOffer_CouponHomePage("//android.view.ViewGroup[@index=1 and @instance=14]/android.widget.TextView[@index=1 and @instance=12]",XPATH,"CouponValidDays 1stOffer - CouponHomePage"),
	progressbar1stOffer_CouponHomePage("//android.view.ViewGroup[@index=1 and @instance=14]/android.view.ViewGroup[@index=2 and @instance=15]",XPATH,"Progressbar 1stOffer - CouponHomePage"),
	chooseStore1stOffer_CouponHomePage("//android.view.ViewGroup[@index=1 and @instance=14]/android.widget.Button[@text='CHOOSE A STORE']",XPATH,"ChooseStore 1stOffer - CouponHomePage"),
	sgwImage_CouponHomePage("//android.view.ViewGroup[@index=3 and @instance=16]/android.widget.ImageView",XPATH,"SGWImage - CouponHomePage"),
	sgwTriggertxt_CouponHomePage("//android.view.ViewGroup[@index=3 and @instance=16]/android.widget.TextView[@text='MOIST SNUFF']",XPATH,"SGWTriggertext - CouponHomePage"),
	
	
	
	
	;
	
	
	
	
	String strProperty = "";
   	ObjectLocator locatorType = null;
   	String strObjName = "";
   	
	@Override
	public String getProperty() {
		// TODO Auto-generated method stub
		return strProperty;
	}

	@Override
	public ObjectLocator getLocatorType() {
		// TODO Auto-generated method stub
		return locatorType;
	}

	@Override
	public String getObjectname() {
		// TODO Auto-generated method stub
		return strObjName;
	}
	
	private AppAltHomeCouponHomePageObjects (String strPropertyValue, ObjectLocator locatorType, String strObjName) {
		// TODO Auto-generated method stub
		this.strProperty = strPropertyValue;
   		this.locatorType = locatorType;
   		this.strObjName = strObjName;
		
	}
}
