package com.rai.framework;

import org.apache.commons.io.FileUtils;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static org.opencv.imgproc.Imgproc.COLOR_BGR2GRAY;
import static org.opencv.imgproc.Imgproc.MORPH_RECT;
import static org.opencv.imgcodecs.Imgcodecs.imwrite;
import static org.opencv.imgcodecs.Imgcodecs.imread;
import static org.opencv.imgproc.Imgproc.cvtColor;
import static org.opencv.imgproc.Imgproc.dilate;
import static org.opencv.imgproc.Imgproc.erode;
import static org.opencv.imgproc.Imgproc.getStructuringElement;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.coordinates.WebDriverCoordsProvider;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

public class RecogniseText extends BaseClass {

	static String SRC_PATH = properties.getProperty("SGWImagesPath");
	static Tesseract tesseract = new Tesseract();
	static {
		System.load(System.getProperty("user.dir") + properties.getProperty("OpenCvDllFilePath"));
		tesseract.setDatapath(properties.getProperty("tessDataPath"));

	}

	public static String dilateAndErode(Mat inputMat) {
		try {
			Mat grey = new Mat();
			cvtColor(inputMat, grey, COLOR_BGR2GRAY);
			imwrite(SRC_PATH + "grey.png", grey);
			Mat element = getStructuringElement(MORPH_RECT, new Size(2, 2), new Point(1, 1));
			dilate(grey, grey, element);
			erode(grey, grey, element);

			imwrite(SRC_PATH + "closeOpen.png", grey);
			element.release();
			return SRC_PATH + "closeOpen.png";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return SRC_PATH + "closeOpen.png";
	}

	public static String convertGrey(String filepath) {
		try {
			File input = new File(filepath);
			BufferedImage image = ImageIO.read(input);

			byte[] data = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
			Mat mat = new Mat(image.getHeight(), image.getWidth(), CvType.CV_8UC3);
			mat.put(0, 0, data);

			Mat mat1 = new Mat(image.getHeight(), image.getWidth(), CvType.CV_8UC1);
			Imgproc.cvtColor(mat, mat1, Imgproc.COLOR_RGB2GRAY);

			byte[] data1 = new byte[mat1.rows() * mat1.cols() * (int) (mat1.elemSize())];
			mat1.get(0, 0, data1);
			BufferedImage image1 = new BufferedImage(mat1.cols(), mat1.rows(), BufferedImage.TYPE_BYTE_GRAY);
			image1.getRaster().setDataElements(0, 0, mat1.cols(), mat1.rows(), data1);

			File ouptut = new File(SRC_PATH + "grayscale.png");
			ImageIO.write(image1, "png", ouptut);
			return ouptut.getAbsolutePath();

		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
		}
		return null;
	}

	public static String resizeImage(Mat inputImage) {
		Mat resizeImage = new Mat(300, 1100, inputImage.type());
		int interpolation = Imgproc.INTER_CUBIC;
		Imgproc.resize(inputImage, resizeImage, resizeImage.size(), 0, 0, interpolation);
		Mat destination = new Mat(inputImage.rows(), inputImage.cols(), inputImage.type());
		Imgproc.GaussianBlur(inputImage, destination, new Size(0, 0), 10);
		Core.addWeighted(inputImage, 1.5, destination, -0.5, 0, destination);
		boolean written = imwrite(SRC_PATH + "ResizedImage.png", resizeImage);
		System.out.println(written);
		return SRC_PATH + "ResizedImage.png";
	}

	public static String getScreenShotOfElement(WebElement ele) throws IOException, InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",
				wait.until(ExpectedConditions.visibilityOf(ele)));
		Screenshot screenshot = new AShot().coordsProvider(new WebDriverCoordsProvider())
				.shootingStrategy(ShootingStrategies.viewportPasting(100)).takeScreenshot(driver, ele);
		String path = System.getProperty("user.dir") + "\\src\\test\\resources\\SGW_Images\\test.png";
		ImageIO.write(screenshot.getImage(), "PNG", new File(path));
		return path;
	}

	/*
	 * public static String takeScreenshot() {
	 * 
	 * 
	 * String mPath = System.getProperty("user.dir") +
	 * "\\src\\test\\resources\\SGW_Images\\test.png";
	 * 
	 * try { // create bitmap screen capture View v1 =
	 * getActivity().getWindow().getDecorView().getRootView();
	 * v1.setDrawingCacheEnabled(true); Bitmap bitmap =
	 * Bitmap.createBitmap(v1.getDrawingCache()); v1.setDrawingCacheEnabled(false);
	 * 
	 * File imageFile = new File(mPath);
	 * 
	 * FileOutputStream outputStream = new FileOutputStream(imageFile); int quality
	 * = 100; bitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream);
	 * outputStream.flush(); outputStream.close();
	 * 
	 * } catch (Throwable e) { // Several error may come out with file handling or
	 * DOM e.printStackTrace(); } return mPath; }
	 */
	public static String extractImageText(WebElement element)
			throws TesseractException, IOException, InterruptedException {
		Mat orgin = imread(screenShotOfElement(element));

		String extractedText = tesseract.doOCR(new File(dilateAndErode(imread(convertGrey(resizeImage(orgin))))));
		System.out.println(extractedText);
		return extractedText;
	}

	public static String extractImageTextWithoutResize(WebElement element)
			throws TesseractException, IOException, InterruptedException {
		String extractedText = tesseract
				.doOCR(new File(dilateAndErode(imread(convertGrey(screenShotOfElement(element))))));
		System.out.println(extractedText);
		return extractedText;
	}

	public static String extractImageTextUsingScreenShot(WebElement element)
			throws TesseractException, IOException, InterruptedException {
		Mat orgin = imread(screenShotOfElement(element));
		String extractedText = tesseract.doOCR(new File(dilateAndErode(imread(convertGrey(resizeImage(orgin))))));
		System.out.println(extractedText);
		return extractedText;
	}

	public static String extractImageTextUsingScreenShotUsingScreenSize(WebElement element)
			throws TesseractException, IOException, InterruptedException {
		Mat orgin = imread(screenShotOfElementUsingScreenSize(element));
		String extractedText = tesseract.doOCR(new File(dilateAndErode(imread(convertGrey(resizeImage(orgin))))));
		System.out.println(extractedText);
		return extractedText;
	}

	public static String screenShotOfElement(WebElement element) {
		try {
			// Take screen shot of whole web page
			File screenShot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

			// Calculate the width and height of the drop down element
			org.openqa.selenium.Point p = element.getLocation();
			int width = element.getSize().getWidth();
			int height = element.getSize().getHeight();

			// Create Rectangle of same width as of drop down Web Element
			Rectangle rect = new Rectangle(width, height);

			BufferedImage img = null;
			img = ImageIO.read(screenShot);

			// Crop Image of drop down web element from the screen shot
			BufferedImage dest = img.getSubimage(p.getX(), p.getY(), rect.width, rect.height);

			// write cropped image into File Object
			ImageIO.write(dest, "png", screenShot);
			String path = System.getProperty("user.dir") + "\\src\\test\\resources\\SGW_Images\\test.png";
			// Copy Image into particular directory
			FileUtils.copyFile(screenShot, new File(path));
			return path;
		} catch (Exception e) {
			e.printStackTrace();
			return null;

		}

	}

	public static String screenShotOfElementUsingScreenSize(WebElement element) {
		try {
			// Take screen shot of whole web page
			File screenShot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenShot,
					new File(System.getProperty("user.dir") + "\\src\\test\\resources\\SGW_Images\\FullPage.png"));
			// Calculate the width and height of the drop down element
			org.openqa.selenium.Point p = element.getLocation();
			int width = element.getSize().getWidth();
			int height = element.getSize().getHeight();

			// Create Rectangle of same width as of drop down Web Element
			Rectangle rect = new Rectangle(width, height);

			BufferedImage img = null;
			BufferedImage dest = null;
			img = ImageIO.read(
					new File(System.getProperty("user.dir") + "\\src\\test\\resources\\SGW_Images\\FullPage.png"));
			Dimension windowSize = driver.manage().window().getSize();
			// Crop Image of drop down web element from the screen shot
			// BufferedImage dest = img.getSubimage(p.getX(), p.getY(), rect.width,
			// rect.height);
			System.out.println("Height:" + windowSize.getHeight());
			if (windowSize.getHeight() > 3000) {
				dest = img.getSubimage((int) (.18 * windowSize.width), (int) (windowSize.height * .857),
						(int) (.65 * windowSize.width), rect.height + 155);
			} else if (windowSize.getHeight() <= 3000 && windowSize.getHeight() >= 2800) {
				dest = img.getSubimage((int) (.18 * windowSize.width), (int) (windowSize.height * .850),
						(int) (.65 * windowSize.width), rect.height + 155);
			} else if (windowSize.getHeight() < 2800 && windowSize.getHeight() >= 2600) {
				dest = img.getSubimage((int) (.18 * windowSize.width), (int) (windowSize.height * .825),
						(int) (.65 * windowSize.width), rect.height + 130);
			} else if (windowSize.getHeight() < 2600 && windowSize.getHeight() > 2500) {
				dest = img.getSubimage((int) (.18 * windowSize.width), (int) (windowSize.height * .895),
						(int) (.64 * windowSize.width), rect.height + 140);
			} else if (windowSize.getHeight() <= 2500 && windowSize.getHeight() > 2160) {
				dest = img.getSubimage((int) (.18 * windowSize.width), (int) (windowSize.height * .822),
						(int) (.64 * windowSize.width), rect.height + 130);
			} else if ((windowSize.getHeight() <= 2160 && windowSize.getHeight() >= 2000)) {
				dest = img.getSubimage((int) (.18 * windowSize.width), (int) (windowSize.height * .830),
						(int) (.64 * windowSize.width), rect.height + 130);
			} else if ((windowSize.getHeight() < 2000 && windowSize.getHeight() >= 1500)) {
				dest = img.getSubimage((int) (.18 * windowSize.width), (int) (windowSize.height * .830),
						(int) (.64 * windowSize.width), rect.height + 100);
			} else {
				dest = img.getSubimage((int) (.18 * windowSize.width), (int) (windowSize.height * .827),
						(int) (.64 * windowSize.width), rect.height + 70);
			}

			// write cropped image into File Object
			ImageIO.write(dest, "png", screenShot);
			String path = System.getProperty("user.dir") + "\\src\\test\\resources\\SGW_Images\\test.png";
			// Copy Image into particular directory
			FileUtils.copyFile(screenShot, new File(path));
			return path;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}
}
