package com.rai.framework;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import com.rai.framework.FrameworkException;
import com.rai.framework.drivers.MobileExecutionPlatform;
import com.rai.framework.drivers.AppiumDriverFactory;
import com.rai.framework.drivers.BrowserStackDriverFactory;
import com.rai.framework.drivers.PerfectoDriverFactory;
import com.rai.framework.drivers.SauceLabsDriverFactory;
import com.rai.framework.drivers.ToolName;
import com.rai.framework.drivers.WebDriverFactory;
import com.rai.pageObjects.AppLoginPageObjects;
import com.rai.framework.Browser;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;

public class BaseClass {

	public static WebDriver driver;
	public static Properties properties;
	public static Properties mobileProperties;
	Browser browser;
	public static GenericLib gl;
	public DataTable dataTable;
	public com.aventstack.extentreports.ExtentReports extent;
	public com.aventstack.extentreports.ExtentTest test;
	public static String publicAppPackageName;
	public static String publicAppMainActivityName;

	static {
		final String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(Calendar.getInstance().getTime())
				.replaceAll(":", "-");
		final String reportFullPath = System.getProperty("user.dir") + "\\test-output\\HtmlReport\\ExtentHtml_"
				+ timestamp + ".html";
		System.setProperty("extent.reporter.avent.start", "false");
		System.setProperty("extent.reporter.bdd.start", "false");
		System.setProperty("extent.reporter.cards.start", "false");
		System.setProperty("extent.reporter.email.start", "false");
		System.setProperty("extent.reporter.html.start", "true");
		System.setProperty("extent.reporter.klov.start", "false");
		System.setProperty("extent.reporter.logger.start", "false");
		System.setProperty("extent.reporter.tabular.start", "false");
		System.setProperty("extent.reporter.html.config", "src/test/resources/html-config.xml");
		System.setProperty("extent.reporter.avent.out", "test-output/AventReport/");
		System.setProperty("extent.reporter.bdd.out", "test-output/BddReport/");
		System.setProperty("extent.reporter.cards.out", "test-output/CardsReport/");
		System.setProperty("extent.reporter.email.out", "test-output/EmailReport/ExtentEmail.html");
		System.setProperty("extent.reporter.html.out", reportFullPath);
		System.setProperty("extent.reporter.logger.out", "test-output/LoggerReport/");
		System.setProperty("extent.reporter.tabular.out", "test-output/TabularReport/");
	}

	// public ObjectRepo repo = new ObjectRepo();
	public BaseClass() {
		properties = Settings.getInstance();
		mobileProperties = Settings.getMobilePropertiesInstance();
		dataTable = new DataTable(System.getProperty("user.dir") + "\\src\\test\\resources\\Datatables",
				properties.getProperty("DataTableName"));
	}

	public static void intialization() {

		String browserstr = properties.getProperty("Browser");
		System.out.println(browserstr);
		driver = WebDriverFactory.getWebDriver(Browser.CHROME);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Long.parseLong(properties.getProperty("ImplicitWait")),
				TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(Long.parseLong(properties.getProperty("PageLoadTimeOut")),
				TimeUnit.SECONDS);

	}

	@SuppressWarnings("rawtypes")
	public static void initializeWebDriver(String executionMode, String toolName, String mobileExecutionPlatform,
			String mobileOsVersion, String deviceName, String browser, String browserVersion, String platform,
			String platformVersion, String appPackageName, String appMainActivityName) {

		publicAppPackageName = appPackageName.replace("\"", "");
		publicAppMainActivityName = appMainActivityName.replace("\"", "");
		switch (executionMode.replace("\"", "")) {

		case "API":
			break;

		case "LOCAL":
			WebDriver webDriver = WebDriverFactory.getWebDriver(Browser.browserValue(browser.replace("\"", "")));
			driver = webDriver;
			driver.manage().window().maximize();
			break;

		case "GRID":
			WebDriver remoteGridDriver = WebDriverFactory.getRemoteWebDriver(
					Browser.browserValue(browser.replace("\"", "")), browserVersion, Platform.fromString(platform),
					properties.getProperty("RemoteUrl"));
			driver = remoteGridDriver;

			driver.manage().window().maximize();
			break;

		case "MOBILE":
			WebDriver appiumDriver = AppiumDriverFactory.getAppiumDriver(
					MobileExecutionPlatform.fromString(mobileExecutionPlatform.replace("\"", "")),
					deviceName.replace("\"", ""), mobileOsVersion.replace("\"", ""),
					Boolean.parseBoolean(mobileProperties.getProperty("ShouldInstallApplication")),
					mobileProperties.getProperty("AppiumURL"));
			driver = appiumDriver;
			break;

		case "PERFECTO":
			if (ToolName.fromString(toolName.replace("\"", "")).equals(ToolName.APPIUM)) {
				WebDriver appiumPerfectoDriver = PerfectoDriverFactory.getPerfectoAppiumDriver(
						MobileExecutionPlatform.fromString(mobileExecutionPlatform.replace("\"", "")),
						deviceName.replace("\"", ""), mobileProperties.getProperty("PerfectoMobileHost"),
						appPackageName.replace("\"", ""), appMainActivityName.replace("\"", ""));
				driver = appiumPerfectoDriver;
				driver.manage().timeouts().implicitlyWait(Long.parseLong(properties.getProperty("ImplicitWait")),
						TimeUnit.SECONDS);
				driver.manage().timeouts().pageLoadTimeout(Long.parseLong(properties.getProperty("PageLoadTimeOut")),
						TimeUnit.SECONDS);
				try {
					allowPermission();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else if (ToolName.fromString(toolName.replace("\"", "")).equals(ToolName.REMOTE_WEBDRIVER)) {
				WebDriver remotePerfectoDriver = PerfectoDriverFactory.getPerfectoRemoteWebDriverForDesktop(
						browser.replace("\"", ""), platformVersion.replace("\"", ""), browserVersion.replace("\"", ""));
				driver = remotePerfectoDriver;
				driver.manage().timeouts().implicitlyWait(Long.parseLong(properties.getProperty("ImplicitWait")),
						TimeUnit.SECONDS);
				driver.manage().timeouts().pageLoadTimeout(Long.parseLong(properties.getProperty("PageLoadTimeOut")),
						TimeUnit.SECONDS);
			}

			break;

		case "SAUCELABS":
			if (ToolName.fromString(toolName.replace("\"", "")).equals(ToolName.APPIUM)) {
				AppiumDriver appiumSauceDriver = SauceLabsDriverFactory.getSauceAppiumDriver(
						MobileExecutionPlatform.fromString(mobileExecutionPlatform.replace("\"", "")),
						deviceName.replace("\"", ""), mobileProperties.getProperty("SauceHost"),
						mobileOsVersion.replace("\"", ""));
				driver = appiumSauceDriver;
			} else if (ToolName.fromString(toolName.replace("\"", "")).equals(ToolName.REMOTE_WEBDRIVER)) {
				WebDriver remoteSauceDriver = SauceLabsDriverFactory.getSauceRemoteWebDriver(
						mobileProperties.getProperty("SauceHost"), Browser.browserValue(browser.replace("\"", "")),
						browserVersion.replace("\"", ""), Platform.fromString(platform.replace("\"", "")));
				driver = remoteSauceDriver;
			}

			break;

		case "BROWSERSTACK":
			if (ToolName.fromString(toolName.replace("\"", "")).equals(ToolName.REMOTE_WEBDRIVER)) {
				WebDriver browserstackRemoteDrivermobile = BrowserStackDriverFactory
						.getBrowserStackRemoteWebDriverMobile(
								MobileExecutionPlatform.fromString(mobileExecutionPlatform.replace("\"", "")),
								deviceName.replace("\"", ""), mobileProperties.getProperty("BrowserStackHost"));
				driver = browserstackRemoteDrivermobile;
			} else if (ToolName.fromString(toolName.replace("\"", "")).equals(ToolName.DEFAULT)) {
				WebDriver browserstackRemoteDriver = BrowserStackDriverFactory.getBrowserStackRemoteWebDriver(
						mobileProperties.getProperty("BrowserStackHost"),
						Browser.browserValue(browser.replace("\"", "")), browserVersion.replace("\"", ""),
						Platform.fromString(platform.replace("\"", "")));

				driver = browserstackRemoteDriver;
			}

			break;

		default:
			throw new FrameworkException("Unhandled Execution Mode!");
		}
	}

	@SuppressWarnings("rawtypes")
	public static void allowPermission() throws IOException {
		try {
			if (driver.findElement(By.xpath("//*[@resource-id='android:id/switch_widget']")).isDisplayed()) {
				driver.findElement(By.xpath("//*[@resource-id='android:id/switch_widget']")).click();
				driver.findElement(By.xpath("//*[@content-desc=\"Navigate up\"]")).click();
				try {
					if (isElementPresent(By.xpath("//*[@resource-id=\"com.android.settings:id/collpasing_app_bar_extended_title\"]")) || isElementPresent(By.xpath("//*[@resource-id=\"com.android.settings:id/collpasing_app_bar_title_layout_parent\"]")) || isElementPresent(By.xpath("//*[@resource-id=\"com.android.settings:id/search_action_bar_title\"]"))) {
						((AndroidDriver) driver).startActivity(new Activity
						 (publicAppPackageName,publicAppMainActivityName));
						System.out.println("Relaunched the app");
					} 
					else {
						System.out.println("App is already launched.");
					}
				} catch (Exception ex) {

							System.out.println("App is already launched.");
				}
			}
		} catch (Exception e) {
			System.out.println("No permission asked for device settings");
			GenericLib.updateExtentStatus("App Permission",
					"Permissions for Device settings: No Permission asked for Device Settings", Status.DONE);
		}
	}
	
	protected static boolean isElementPresent(By by) {
		// Set implicit wait to 0
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		try {
			if (driver.findElements(by).size() > 0) {
				// Revert back to default value of implicit wait
				driver.manage().timeouts().implicitlyWait(Long.parseLong(properties.getProperty("ImplicitWait")),
						TimeUnit.SECONDS);
				return true;
			} else {
				// Revert back to default value of implicit wait
				driver.manage().timeouts().implicitlyWait(Long.parseLong(properties.getProperty("ImplicitWait")),
						TimeUnit.SECONDS);
				return false;
			}

		} catch (NoSuchElementException e) {
			// Revert back to default value of implicit wait
			driver.manage().timeouts().implicitlyWait(Long.parseLong(properties.getProperty("ImplicitWait")),
					TimeUnit.SECONDS);
			return false;
		}
	}

}