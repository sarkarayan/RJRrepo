package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;

import com.rai.pageObjects.AppLoginPageObjects;

public class MobileApp_LoginPage_RememberMeFunctionality extends BaseClass {

	String testcaseName;
	public MobileApp_LoginPage_RememberMeFunctionality(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(AppLoginPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Login Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	public void invokeApplication_brandwebsite()
	{
	    String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
	
   public void loginfields_ValidateInlinetext() throws Exception
   {
	   
	   String Expected_UsernameInlinetext = "Username / Email Address";
	   String Expected_PasswordInlinetext = "Password";
	   
	   String Actual_UsernameInlintext = commonFunction.getValueFromAttribute(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginUsername), AppLoginPageObjects.txt_GrizzlyAPPLoginUsername.getObjectname(), "text");
	   String Actual_PasswordInlinetext = commonFunction.getValueFromAttribute(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginPassword), AppLoginPageObjects.txt_GrizzlyAPPLoginPassword.getObjectname(), "text");
	   
	   Assert.assertEquals(Actual_UsernameInlintext, Expected_UsernameInlinetext, "Expected UsernameInlin text was not displayed on LoginPage");
	   Assert.assertEquals(Actual_PasswordInlinetext, Expected_PasswordInlinetext, "Expected PasswordInline text was not displayed on LoginPage");	   
	   
   }	
	
	public void loginPage_RememberMeValidation() throws IOException, InterruptedException
	{
		String ValidUserId = dataTable.getData("General_Data","Username");
		String ValidPassword = dataTable.getData("General_Data","Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginUsername),ValidUserId,AppLoginPageObjects.txt_GrizzlyAPPLoginUsername.getObjectname());
        commonFunction.clearAndEnterTextTabOut(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginPassword),ValidPassword,AppLoginPageObjects.txt_GrizzlyAPPLoginPassword.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.chkbx_RememberMe), AppLoginPageObjects.chkbx_RememberMe.getObjectname());
        commonFunction.scrollToMobileElement("LOG IN");
        commonFunction.clickIfElementPresent(getPageElement(AppLoginPageObjects.btn_GrizzlyAPPLogin), AppLoginPageObjects.btn_GrizzlyAPPLogin.getObjectname());

	}
	
	public void loginPage_ValidatedisplayedUserId() throws Exception
	{
		String Expected_UserId = dataTable.getData("General_Data", "Username");
		
		String Actual_UserId = commonFunction.getTextFromTextBox(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginUsername), AppLoginPageObjects.txt_GrizzlyAPPLoginUsername.getObjectname());
		
		Assert.assertEquals(Actual_UserId, Expected_UserId, "RememberMe - Entered User Id not displayed in Username field");
		
	}
	
	public void logout_RememberMeValidation() throws Exception
	{
		
		if((getPageElement(AppLoginPageObjects.chkbx_RememberMe)).isSelected())
		{
			System.out.println("RememberMe Checkbox was selected");
		}
		else
		{
			System.out.println("RememberMe Checkbox was not selected");
		}
		
	}
	
		
	
	
}

