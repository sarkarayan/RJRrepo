package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.AppForgotUsernamePageObjects;

import io.appium.java_client.android.AndroidDriver;

public class MobileApp_ValidationsForgotUsername extends BaseClass {

	String testcaseName;
	public MobileApp_ValidationsForgotUsername(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(AppForgotUsernamePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("ForgotUsername Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	public void invokeApplication_brandwebsite()
	{
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);	
		
		
	}
	public void navigateToForgotUsernamePage() throws IOException {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		commonFunction.scrollDown();
		commonFunction.clickIfElementPresent(getPageElement(AppForgotUsernamePageObjects.lnk_GrizzlyAPPLoginForgotUsername), AppForgotUsernamePageObjects.lnk_GrizzlyAPPLoginForgotUsername.getObjectname());
	}
	public void forgotUsername_NegativeValidationsAccountInformation() throws InterruptedException, IOException
	{
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String InvalidAddress = dataTable.getData("General_Data", "InvalidAddress");
		String InvalidZipcode = dataTable.getData("General_Data", "InvalidZipcode");
		String InvalidLastName = dataTable.getData("General_Data","InvalidLastName");
		String DOB = dataTable.getData("General_Data","DOB");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
		
		String Errormessage_forgotUsernameNoDOB = "Please provide a Date Of Birth";
		String Errormessage_forgotUsernameNoLegalName = "Please enter your legal name";
		String Errormessage_forgotUsernameNoAddress = "Please provide a street address";
		String Errormessage_forgotUsernameNoZipcode = "Please provide a ZIP Code";
		String Errormessage_forgotUsernameNoCity = "Please Provide City";
		String Errormessage_forgotUsernameNoState = "Please Provide State";
		String Errormessage_forgotUsernameNoDataonGeneralInfo = "Please fix the errors above";
		//Clicking on Continue button without any data on AccountInfo. Page
		commonFunction.scrollDown();
		commonFunction.clickIfElementPresent(getPageElement(AppForgotUsernamePageObjects.btn_ForgotUsernameAcctInfoConitnue),AppForgotUsernamePageObjects.btn_ForgotUsernameAcctInfoConitnue.getObjectname());
		Thread.sleep(2000);
		commonFunction.scrollUp();
		commonFunction.isElementPresentContainsText(getPageElement(AppForgotUsernamePageObjects.errormsg_AcctInfowihtoutDOB), AppForgotUsernamePageObjects.errormsg_AcctInfowihtoutDOB.getObjectname(), Errormessage_forgotUsernameNoDOB);
		commonFunction.isElementPresentContainsText(getPageElement(AppForgotUsernamePageObjects.errormsg_AcctInfowihtoutLegalName), AppForgotUsernamePageObjects.errormsg_AcctInfowihtoutLegalName.getObjectname(), Errormessage_forgotUsernameNoLegalName);
		commonFunction.isElementPresentContainsText(getPageElement(AppForgotUsernamePageObjects.errormsg_AcctInfowithoutAddress), AppForgotUsernamePageObjects.errormsg_AcctInfowithoutAddress.getObjectname(), Errormessage_forgotUsernameNoAddress);
		commonFunction.scrollDown();
		commonFunction.isElementPresentContainsText(getPageElement(AppForgotUsernamePageObjects.errormsg_AcctInfowithoutZipcode), AppForgotUsernamePageObjects.errormsg_AcctInfowithoutZipcode.getObjectname(), Errormessage_forgotUsernameNoZipcode);
		commonFunction.isElementPresentContainsText(getPageElement(AppForgotUsernamePageObjects.errormsg_AcctInfowithoutCity), AppForgotUsernamePageObjects.errormsg_AcctInfowithoutCity.getObjectname(), Errormessage_forgotUsernameNoCity);
		commonFunction.isElementPresentContainsText(getPageElement(AppForgotUsernamePageObjects.errormsg_AcctInforwithoutState), AppForgotUsernamePageObjects.errormsg_AcctInforwithoutState.getObjectname(), Errormessage_forgotUsernameNoState);
		commonFunction.isElementPresentContainsText(getPageElement(AppForgotUsernamePageObjects.errormsg_AcctInfowithoutanydata), AppForgotUsernamePageObjects.errormsg_AcctInfowithoutanydata.getObjectname(), Errormessage_forgotUsernameNoDataonGeneralInfo);
		
		
//		String ActualErrormsg_clickwithoutanydata = commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ForgotUsernameNoDataonGeneralInfo));
//		String ExpectedErrormsg_clickwithoutanydata = "Please fix the errors above";
//		if(ActualErrormsg_clickwithoutanydata.contentEquals(ExpectedErrormsg_clickwithoutanydata))
//		{
//			System.out.println("ForgotUsername - Expected error message displayed when user click Continue without any data on AccountInfo page");
//		}
//		else
//		{
//			System.out.println("ForgotUsername - Expected error message was not displayed when user click Continue without any data on AccountInfo page");
//		}
		
				
		
		//UserInformation not found
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		String Errormessage_UserInfonotfound = "We were not able to find your information. Please check and try again.";
		commonFunction.scrollUp();
		commonFunction.selectValueMobileDropDown(getPageElement(AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthMonth), month, AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthMonth.getObjectname());
		Thread.sleep(2000);
		commonFunction.selectValueMobileDropDown(getPageElement(AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthDay),day,AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		System.out.println(year);
		commonFunction.selectValueMobileDropDown(getPageElement(AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthYear),year, AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameFirstName), FirstName, AppForgotUsernamePageObjects.txt_ForgotUsernameFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameLastName), InvalidLastName, AppForgotUsernamePageObjects.txt_ForgotUsernameLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameAddressLine), InvalidAddress, AppForgotUsernamePageObjects.txt_ForgotUsernameAddressLine.getObjectname());
		commonFunction.scrollDown();
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameZipcode), InvalidZipcode,AppForgotUsernamePageObjects.txt_ForgotUsernameZipcode.getObjectname());
		Thread.sleep(3000);
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameCity), City, AppForgotUsernamePageObjects.txt_ForgotUsernameCity.getObjectname());
		commonFunction.selectValueMobileDropDown(getPageElement(AppForgotUsernamePageObjects.Drpdwn_ForgotUsernameState),State, AppForgotUsernamePageObjects.Drpdwn_ForgotUsernameState.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppForgotUsernamePageObjects.btn_ForgotUsernameAcctInfoConitnue),AppForgotUsernamePageObjects.btn_ForgotUsernameAcctInfoConitnue.getObjectname());
		commonFunction.scrollUp();
		commonFunction.isElementPresentContainsText(getPageElement(AppForgotUsernamePageObjects.errormsg_ForgotUsernameUsernotfound), AppForgotUsernamePageObjects.errormsg_ForgotUsernameUsernotfound.getObjectname(), Errormessage_UserInfonotfound);
		
//		String ActualErrormsg_EnteredInvalidUserInfo=commonFunction.getTextFromElement(getPageElement(brandWebsitePageObjects.errormsg_ForgotUsernameUsernotfound));
//		String ExpectedErrormsg_EnteredInvalidUserInfo="We were not able to find your information. Please check and try again.";
//		if(ActualErrormsg_EnteredInvalidUserInfo.contentEquals(ExpectedErrormsg_EnteredInvalidUserInfo))
//		{
//			System.out.println("ForgotUsername - Expected error message displayed for Invalid User Information");
//		}
//		else
//		{
//			System.out.println("ForgotUsername - Expected error message not displayed for Invalid User Information");
//		}
	
	}
	
	
	
	@SuppressWarnings("rawtypes")
	public void forgotUsername_ValidDataAccountInformation() throws InterruptedException, IOException
	{
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
		String date = dataTable.getData("General_Data","DOB");
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		commonFunction.selectValueMobileDropDown(getPageElement(AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthMonth), month, AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthMonth.getObjectname());
		Thread.sleep(2000);
		commonFunction.selectValueMobileDropDown(getPageElement(AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthDay),day,AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.selectValueMobileDropDown(getPageElement(AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthYear), year, AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameFirstName), FirstName, AppForgotUsernamePageObjects.txt_ForgotUsernameFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameLastName), LastName, AppForgotUsernamePageObjects.txt_ForgotUsernameLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameAddressLine), Address, AppForgotUsernamePageObjects.txt_ForgotUsernameAddressLine.getObjectname());
		commonFunction.scrollDown();
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameZipcode), Zipcode,AppForgotUsernamePageObjects.txt_ForgotUsernameZipcode.getObjectname());
		((AndroidDriver)driver).hideKeyboard();
		commonFunction.clearAndEnterText(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameZipcode), Zipcode,AppForgotUsernamePageObjects.txt_ForgotUsernameZipcode.getObjectname());

		Thread.sleep(3000);
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameCity), City, AppForgotUsernamePageObjects.txt_ForgotUsernameCity.getObjectname());
		commonFunction.selectValueMobileDropDown(getPageElement(AppForgotUsernamePageObjects.Drpdwn_ForgotUsernameState),State, AppForgotUsernamePageObjects.Drpdwn_ForgotUsernameState.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppForgotUsernamePageObjects.btn_ForgotUsernameAcctInfoConitnue),AppForgotUsernamePageObjects.btn_ForgotUsernameAcctInfoConitnue.getObjectname());
				
	}
	
	
	
	public void forgotUsername_NegativeValidationsVerifyIdentity() throws Exception
	{
		String InvalidChallengeAnswer = dataTable.getData("General_Data", "InvalidChallengeAnswer");
		
		//Clicking on Continue button without any data on Verify Identity Page
		commonFunction.clickIfElementPresent(getPageElement(AppForgotUsernamePageObjects.btn_ForgotUsernameVerifyIdentityContinue), AppForgotUsernamePageObjects.btn_ForgotUsernameVerifyIdentityContinue.getObjectname());
		String ActualErrormsg_NoAnswerEntered = commonFunction.getTextFromElement(getPageElement(AppForgotUsernamePageObjects.errormsg_VerifyIdenityChallengeAnswer));
		String ExpectedErrormsg_NoAnswerEntered = "Please provide an answer to account recovery question";
		if(ActualErrormsg_NoAnswerEntered.contentEquals(ExpectedErrormsg_NoAnswerEntered))
		{
			System.out.println("ForgotUsername - Expected error message displayed if user not provided answer for challenge question");
		}
		else
		{
			System.out.println("ForgotUsername - Expected error message was not displayed if user not provided answer for challenge question");
		}
		
		//User entered Incorrect Challenge Answer
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameVerifyIdentityChallengeAnswer), InvalidChallengeAnswer,AppForgotUsernamePageObjects.txt_ForgotUsernameVerifyIdentityChallengeAnswer.getObjectname());
		Thread.sleep(2000);
		commonFunction.clickIfElementPresent(getPageElement(AppForgotUsernamePageObjects.btn_ForgotUsernameVerifyIdentityContinue), AppForgotUsernamePageObjects.btn_ForgotUsernameVerifyIdentityContinue.getObjectname());
		String ActualErrormsg_IncorrectChallengeAnswer = commonFunction.getTextFromElement(getPageElement(AppForgotUsernamePageObjects.errormsg_VerifyAnswermatchError));
		String ExpectedErrormsg_IncorrectChallengeAnswer = "The answer does not match our records. Please re-enter your answer to the account recovery question";
		if(ActualErrormsg_IncorrectChallengeAnswer.contentEquals(ExpectedErrormsg_IncorrectChallengeAnswer))
		{
			System.out.println("ForgotUsername - Expected error message displayed if user enters invalid challenge answer");
		}
		else
		{
			System.out.println("ForgotUsername - Expected error message was not displayed if user enters invalid challenge answer");
		}
		
	}
	
}

