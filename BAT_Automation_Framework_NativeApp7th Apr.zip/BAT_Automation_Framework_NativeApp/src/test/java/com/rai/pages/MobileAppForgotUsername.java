package com.rai.pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.AppForgotPasswordPageObjects;
import com.rai.pageObjects.AppForgotUsernamePageObjects;

import io.appium.java_client.android.AndroidDriver;

public class MobileAppForgotUsername extends BaseClass {

	
	String testcaseName;
	public MobileAppForgotUsername(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
		}

		/**
		 * Constructor to initialize the component library
		 * 
		 * @param scriptHelper
		 *            The {@link ScriptHelper} object passed from the
		 *            {@link DriverScript}
		 */
		
		CommonFunctions commonFunction = new CommonFunctions(testcaseName);

		
	private WebElement getPageElement(AppForgotUsernamePageObjects pageEnum) throws IOException {
			WebElement element;
			try {
				element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
						true);
				if (element != null)
					System.out.println("Found the element: " + pageEnum.getObjectname());
				else
					System.out.println("Element Not Found: " + pageEnum.getObjectname());
				return element;
			} catch (Exception e) {
				GenericLib.updateExtentStatus("Registration Page - get page element",
						pageEnum.toString() + " object is not defined or found.", Status.FAIL);
				return null;
			}
		}
		
	public void allowAPPPermission()
	{
		
		try {
			commonFunction.clickIfElementPresent(getPageElement(AppForgotUsernamePageObjects.btn_AppAllowPermission),AppForgotUsernamePageObjects.btn_AppAllowPermission.getObjectname());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("App Permission was already enabled");
		}
		
	}
	
    @SuppressWarnings("rawtypes")
	public void enterdetailsonAccountInfoPage() throws InterruptedException, IOException
    {
    	
    	String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String date = dataTable.getData("General_Data","DOB");
			String dateParts[] = date.split("/");
			String month  = dateParts[0];
			String day  = dateParts[1];
			String year = dateParts[2];
    			
		commonFunction.scrollDown();
		WebDriverWait wait = new WebDriverWait(driver, 30);
		    	
    	commonFunction.clickIfElementPresent(getPageElement(AppForgotUsernamePageObjects.lnk_GrizzlyAPPLoginForgotUsername), AppForgotUsernamePageObjects.lnk_GrizzlyAPPLoginForgotUsername.getObjectname());
    	Thread.sleep(2000);
    	commonFunction.selectValueMobileDropDown(getPageElement(AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthMonth),month, AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthMonth.getObjectname());
    	commonFunction.selectValueMobileDropDown(getPageElement(AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthDay),day,AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthDay.getObjectname());
    	commonFunction.selectValueMobileDropDown(getPageElement(AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthYear),year,AppForgotUsernamePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
    	((AndroidDriver)driver).hideKeyboard();
    	
    	commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameFirstName),FirstName,AppForgotUsernamePageObjects.txt_ForgotUsernameFirstName.getObjectname());
    	commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameLastName),LastName,AppForgotUsernamePageObjects.txt_ForgotUsernameLastName.getObjectname());
    	commonFunction.scrollDown();
    	commonFunction.clearAndEnterText(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameAddressLine),Address,AppForgotUsernamePageObjects.txt_ForgotUsernameAddressLine.getObjectname());
    	commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameZipcode),Zipcode,AppForgotUsernamePageObjects.txt_ForgotUsernameZipcode.getObjectname());
    	((AndroidDriver)driver).hideKeyboard();
    	commonFunction.scrollDown();
    	commonFunction.clickIfElementPresent(getPageElement(AppForgotUsernamePageObjects.btn_ForgotUsernameAcctInfoConitnue),AppForgotUsernamePageObjects.btn_ForgotUsernameAcctInfoConitnue.getObjectname());
    	
    }
    
    
    public void verifyIdentityPage() throws IOException
    {
    	String ChallengeAnswer = dataTable.getData("General_Data", "ChallengeAnswer");
    	
    	commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameVerifyIdentityChallengeAnswer), ChallengeAnswer, AppForgotUsernamePageObjects.txt_ForgotUsernameVerifyIdentityChallengeAnswer.getObjectname());
    	commonFunction.clickIfElementPresent(getPageElement(AppForgotUsernamePageObjects.btn_ForgotUsernameVerifyIdentityContinue),AppForgotUsernamePageObjects.btn_ForgotUsernameVerifyIdentityContinue.getObjectname());
    	
    }
    
    
    @SuppressWarnings("unused")
	public void navigatebackfromWelcomeBackPage() throws IOException
    {
    	
    	String UserId = commonFunction.getTextFromElement(getPageElement(AppForgotUsernamePageObjects.txt_ForgotUsernameUserIdDetails));
    	
    	commonFunction.clickIfElementPresent(getPageElement(AppForgotUsernamePageObjects.btn_ForgotUsernameReturntoLogin),AppForgotUsernamePageObjects.btn_ForgotUsernameReturntoLogin.getObjectname());
    }
	
}

