package testscripts.cts.TheOasisNativeApp;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.MobileApp_Login_OtherbrandUserwithLoginResetN;

@Listeners(ExtentITestListenerClassAdapter.class)
public class Login_OtherBrandSUserandResetN_OasisNativeApp extends BaseClass{

	MobileApp_Login_OtherbrandUserwithLoginResetN mobileApp_Login_OtherbrandUserwithLoginResetN;
	
	public Login_OtherBrandSUserandResetN_OasisNativeApp() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion", "AppPackageName", "AppMainActivityName" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("CE071827327A2026037E")String deviceName, @Optional("")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion, @Optional("com.rjrt.TheOasis")String appPackageName, @Optional("com.rjrt.TheOasis.Oasis")String appMainActivityName) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion, appPackageName, appMainActivityName); 
		
		mobileApp_Login_OtherbrandUserwithLoginResetN = new MobileApp_Login_OtherbrandUserwithLoginResetN(this.getClass().getSimpleName());
		gl= new GenericLib(this.getClass().getSimpleName());
		gl.start_report(this.getClass().getSimpleName(), "Verify ContactUs Page when user try to login other brand H User with Reset N", properties.getProperty("ApplicationUrl"));
	}
	
	@Test
	public void forgotPasswordPage_OtherbrandSUserwithResetN() throws Exception {
		
		mobileApp_Login_OtherbrandUserwithLoginResetN.login_EnterValidData();
		mobileApp_Login_OtherbrandUserwithLoginResetN.forgotPasswordPage_OtherBrandSUserwithResetN();;
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		gl.endReport();
		
	}

}
