package testscripts.cts.PallMallNativeApp;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.MobileApp_LoginPageValidationsandAccountLock;


@Listeners(ExtentITestListenerClassAdapter.class)
public class Loginwith128Characters_PallMallNativeApp extends BaseClass{


	MobileApp_LoginPageValidationsandAccountLock mobileApp_LoginPageValidationsandAccountLock;
	
	public Loginwith128Characters_PallMallNativeApp() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion", "AppPackageName", "AppMainActivityName" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("CE071827327A2026037E")String deviceName, @Optional("")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion, @Optional("com.rjrt.Pallmall")String appPackageName, @Optional("com.rjrt.Pallmall.Pallmall")String appMainActivityName) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion, appPackageName, appMainActivityName); 
		
		mobileApp_LoginPageValidationsandAccountLock = new MobileApp_LoginPageValidationsandAccountLock(this.getClass().getSimpleName());
		gl= new GenericLib(this.getClass().getSimpleName());
		gl.start_report(this.getClass().getSimpleName(), "Verify if user can login with max.128 characters", properties.getProperty("ApplicationUrl"));
	}
	
	@Test
	public void verifyLoginwith128Characters() throws Exception {
				
		mobileApp_LoginPageValidationsandAccountLock.loginPage_Loginwith128characters();
		
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		gl.endReport();
		
	}

}
