package testscripts.cts.PallMallNativeApp;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.MobileApp_ValidationsForgotPassword;

@Listeners(ExtentITestListenerClassAdapter.class)
public class ForgotPasswordNegativeValidations_PallMallNativeApp extends BaseClass {
	MobileApp_ValidationsForgotPassword grizzlyAppValidationsForgotPassword;
	public ForgotPasswordNegativeValidations_PallMallNativeApp() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion", "AppPackageName", "AppMainActivityName" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("CE071827327A2026037E")String deviceName, @Optional("")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion, @Optional("com.rjrt.Pallmall")String appPackageName, @Optional("com.rjrt.Pallmall.Pallmall")String appMainActivityName) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion, appPackageName, appMainActivityName); 
			grizzlyAppValidationsForgotPassword = new MobileApp_ValidationsForgotPassword(this.getClass().getSimpleName());
		gl= new GenericLib(this.getClass().getSimpleName());
		gl.start_report(this.getClass().getSimpleName(), "Verify the validations in ForgotPassword flow", properties.getProperty("ApplicationUrl"));
	}
	
	@Test
	public void verifyForgotPasswordFlowNegativeValidations_PallMallApp() throws Exception {
		grizzlyAppValidationsForgotPassword.navigateToForgotPasswordPage();
		grizzlyAppValidationsForgotPassword.forgotPassword_NegativeValidationsUsernamePage();
		grizzlyAppValidationsForgotPassword.forgotPassword_EnterValidUsername();
		grizzlyAppValidationsForgotPassword.forgotPassword_NegativeValidationsGeneralInfoPage();
		grizzlyAppValidationsForgotPassword.forgotPassword_ValidDataOnGeneralInformationPage();
		grizzlyAppValidationsForgotPassword.forgotPassword_NegativeValidationsVerifyIdentity();
		grizzlyAppValidationsForgotPassword.forgotPassword_ValidDataVerifyIdentity();
		grizzlyAppValidationsForgotPassword.forgotPassword_NegativeValidationsResetPassword();
		
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		//gl.endReport();
		
	}
}
