package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.AppForgotPasswordPageObjects;
import com.rai.pageObjects.AppLoginPageObjects;

import io.appium.java_client.android.AndroidDriver;

import com.rai.pageObjects.AppForgotPasswordPageObjects;

public class MobileApp_ValidationsForgotPassword extends BaseClass {

	String testcaseName;

	public MobileApp_ValidationsForgotPassword(String testcaseName) {
		this.testcaseName = testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper The {@link ScriptHelper} object passed from the
	 *                     {@link DriverScript}
	 */

	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	private WebElement getPageElement(AppForgotPasswordPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("ForgotPassword Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}


	public void navigateToForgotPasswordPage() throws IOException, InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		Thread.sleep(4000);
		commonFunction.scrollDown();
		commonFunction.clickIfElementPresent(getPageElement(AppForgotPasswordPageObjects.lnk_GrizzlyAPPLoginForgotPassword),AppForgotPasswordPageObjects.lnk_GrizzlyAPPLoginForgotPassword.getObjectname());
	}
	public void forgotPassword_NegativeValidationsUsernamePage() throws Exception {
		String InvalidUserIdformat = dataTable.getData("General_Data", "InvalidUserIDformat");
		String InvalidUserId = dataTable.getData("General_Data", "NonExistUserId");

		String Errormsg_NoUserId = "Please enter your Username / Email Address.";
		String Errormsg_NoData = "Please fix the errors above";
		String Errormsg_UserIdInvalidformat = "Username must be a combination of 8-30 letters and numbers.";
		String Errormsg_InvalidUserId = "We could not locate your Login ID, please try again.";

		// Clicking on Continue without UserId data
		commonFunction.clickIfElementPresent(getPageElement(AppForgotPasswordPageObjects.btn_ForgotPasswordEnterEmailContinue),
				AppForgotPasswordPageObjects.btn_ForgotPasswordEnterEmailContinue.getObjectname());
		commonFunction.isElementPresentContainsText(
				getPageElement(AppForgotPasswordPageObjects.errormsg_ForgotPasswordEmailfieldvalidation),
				AppForgotPasswordPageObjects.errormsg_ForgotPasswordEmailfieldvalidation.getObjectname(), Errormsg_NoUserId);
		commonFunction.isElementPresentContainsText(
				getPageElement(AppForgotPasswordPageObjects.errormsg_ForgotPasswordEmailpagewithoutanyData),
				AppForgotPasswordPageObjects.errormsg_ForgotPasswordEmailpagewithoutanyData.getObjectname(), Errormsg_NoData);

		// User entered Invalid UserID format
				commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordEnterEmail),
						InvalidUserIdformat, AppForgotPasswordPageObjects.btn_ForgotPasswordEnterEmailContinue.getObjectname());
				// Thread.sleep(2000);
				commonFunction.clickIfElementPresent(getPageElement(AppForgotPasswordPageObjects.btn_ForgotPasswordEnterEmailContinue),
						AppForgotPasswordPageObjects.btn_ForgotPasswordEnterEmailContinue.getObjectname());
				commonFunction.isElementPresentContainsText(
						getPageElement(AppForgotPasswordPageObjects.errormsg_ForgotPasswordInvalidUserIdformat),
						AppForgotPasswordPageObjects.errormsg_ForgotPasswordInvalidUserIdformat.getObjectname(),
						Errormsg_UserIdInvalidformat);

				// User enters Invalid/Inactive UserId
				commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordEnterEmail),
						InvalidUserId, AppForgotPasswordPageObjects.txt_ForgotPasswordEnterEmail.getObjectname());
				commonFunction.clickIfElementPresent(getPageElement(AppForgotPasswordPageObjects.btn_ForgotPasswordEnterEmailContinue),
						AppForgotPasswordPageObjects.btn_ForgotPasswordEnterEmailContinue.getObjectname());
				commonFunction.isElementPresentContainsText(
						getPageElement(AppForgotPasswordPageObjects.errormsg_ForgotPasswordInvalidUserId),
						AppForgotPasswordPageObjects.errormsg_ForgotPasswordInvalidUserId.getObjectname(), Errormsg_InvalidUserId);

			}

			public void forgotPassword_EnterValidUsername() throws IOException, InterruptedException {
				String Email = dataTable.getData("General_Data", "Email");
				commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordEnterEmail),
						Email, AppForgotPasswordPageObjects.txt_ForgotPasswordEnterEmail.getObjectname());
				Thread.sleep(4000);
				commonFunction.clickIfElementPresent(
						getPageElement(AppForgotPasswordPageObjects.btn_ForgotPasswordEnterEmailContinue),
						AppForgotPasswordPageObjects.btn_ForgotPasswordEnterEmailContinue.getObjectname());
				// commonFunction.sendKeyENTER(getPageElement(AppForgotPasswordPageObjects.btn_ForgotPasswordUsernameContinue),AppForgotPasswordPageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
			}

			public void forgotPassword_NegativeValidationsGeneralInfoPage() throws InterruptedException, IOException {
				String FirstName = dataTable.getData("General_Data", "FirstName");
				String InvalidLastName = dataTable.getData("General_Data", "InvalidLastName");
				String InvalidAddress = dataTable.getData("General_Data", "InvalidAddress");
				String InvalidZipcode = dataTable.getData("General_Data", "InvalidZipcode");
				String City = dataTable.getData("General_Data", "City");
				String State = dataTable.getData("General_Data", "State");

				String date = dataTable.getData("General_Data", "DOB");
				String dateParts[] = date.split("/");
				String month = dateParts[0];
				String day = dateParts[1];
				String year = dateParts[2];

				String Errormessage_ForgotPasswordNoDOB = "Please provide a Date Of Birth";
				String Errormessage_ForgotPasswordNoDataonGeneralInfo = "Please fix the errors above";
				String Errormessage_ForgotPasswordNoLegalName = "Please enter your legal name";
				String Errormessage_ForgotPasswordNoAddress = "Please provide a street address";
				String Errormessage_ForgotPasswordNoZipcode = "Please provide a ZIP Code";
				String Errormessage_ForgotPasswordNoCity = "Please Provide City";
				String Errormessage_ForgotPasswordNoState = "Please Provide State";
				String Errormessage_ForgotPasswordInvalidUserInfo = "We were not able to find your information. Please check and try again.";

				// Clicking on Continue without any data on GeneralInfo page
				Thread.sleep(4000);
				commonFunction.scrollDown();
				commonFunction.clickIfElementPresent(
						getPageElement(AppForgotPasswordPageObjects.btn_ForgotPasswordGeneralInfoConitnue),
						AppForgotPasswordPageObjects.btn_ForgotPasswordGeneralInfoConitnue.getObjectname());
				commonFunction.scrollUp();

				commonFunction.isElementPresentContainsText(
						getPageElement(AppForgotPasswordPageObjects.errormsg_ForgotPasswordGeneralInfowihtoutDOB),
						AppForgotPasswordPageObjects.errormsg_ForgotPasswordGeneralInfowihtoutDOB.getObjectname(), Errormessage_ForgotPasswordNoDOB);
				commonFunction.isElementPresentContainsText(
						getPageElement(AppForgotPasswordPageObjects.errormsg_ForgotPasswordGeneralInfowihtoutLegalName),
						AppForgotPasswordPageObjects.errormsg_ForgotPasswordGeneralInfowihtoutLegalName.getObjectname(),
						Errormessage_ForgotPasswordNoLegalName);
				//commonFunction.scrollToMobileElement("Address");
				commonFunction.scrollDown();
				commonFunction.isElementPresentContainsText(
						getPageElement(AppForgotPasswordPageObjects.errormsg_ForgotPasswordGeneralInfowithoutAddress),
						AppForgotPasswordPageObjects.errormsg_ForgotPasswordGeneralInfowithoutAddress.getObjectname(),
						Errormessage_ForgotPasswordNoAddress);
				commonFunction.isElementPresentContainsText(
						getPageElement(AppForgotPasswordPageObjects.errormsg_ForgotPasswordGeneralInfowithoutZipcode),
						AppForgotPasswordPageObjects.errormsg_ForgotPasswordGeneralInfowithoutZipcode.getObjectname(),
						Errormessage_ForgotPasswordNoZipcode);
				commonFunction.isElementPresentContainsText(
						getPageElement(AppForgotPasswordPageObjects.errormsg_ForgotPasswordGeneralInfowithoutCity),
						AppForgotPasswordPageObjects.errormsg_ForgotPasswordGeneralInfowithoutCity.getObjectname(),
						Errormessage_ForgotPasswordNoCity);
				commonFunction.isElementPresentContainsText(
						getPageElement(AppForgotPasswordPageObjects.errormsg_ForgotPasswordGeneralInforwithoutState),
						AppForgotPasswordPageObjects.errormsg_ForgotPasswordGeneralInforwithoutState.getObjectname(),
						Errormessage_ForgotPasswordNoState);
				commonFunction.isElementPresentContainsText(
						getPageElement(AppForgotPasswordPageObjects.errormsg_ForgotPasswordGeneralInfowithoutanydata),
						AppForgotPasswordPageObjects.errormsg_ForgotPasswordGeneralInfowithoutanydata.getObjectname(),
						Errormessage_ForgotPasswordNoDataonGeneralInfo);
				commonFunction.scrollUp();
				// User entered Invalid user info on GeneralInfo page
				commonFunction.selectValueMobileDropDown(getPageElement(AppForgotPasswordPageObjects.drpDownBirthMonth), month,
						AppForgotPasswordPageObjects.drpDownBirthMonth.getObjectname());
				//Thread.sleep(3000);
				commonFunction.selectValueMobileDropDown(getPageElement(AppForgotPasswordPageObjects.drpdwn_ForgotPasswordGeneralInforBirthDay),
						day, AppForgotPasswordPageObjects.drpdwn_ForgotPasswordGeneralInforBirthDay.getObjectname());
				commonFunction.selectValueMobileDropDown(getPageElement(AppForgotPasswordPageObjects.drpdwn_ForgotPasswordGeneralInforBirthYear),
						year, AppForgotPasswordPageObjects.drpdwn_ForgotPasswordGeneralInforBirthYear.getObjectname());
				commonFunction.clearAndEnterText(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInforFirstName), FirstName,
						AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInforFirstName.getObjectname());
				commonFunction.clearAndEnterText(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoLastName),
						InvalidLastName, AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoLastName.getObjectname());
				commonFunction.scrollDown();
				commonFunction.clearAndEnterText(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoAddressLine),
						InvalidAddress, AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoAddressLine.getObjectname());
				commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoZipcode),
						InvalidZipcode, AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoZipcode.getObjectname());
				Thread.sleep(3000);
				if (getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoCity).getText().contains("")) {
					commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoCity), City,
							AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoCity.getObjectname());
					commonFunction.selectValueMobileDropDown(getPageElement(AppForgotPasswordPageObjects.Drpdwn_ForgotPasswordGenralInfoState),
							State, AppForgotPasswordPageObjects.Drpdwn_ForgotPasswordGenralInfoState.getObjectname());
				}

				commonFunction.clickIfElementPresent(
						getPageElement(AppForgotPasswordPageObjects.btn_ForgotPasswordGeneralInfoConitnue),
						AppForgotPasswordPageObjects.btn_ForgotPasswordGeneralInfoConitnue.getObjectname());
				commonFunction.isElementPresentContainsText(
						getPageElement(AppForgotPasswordPageObjects.errormsg_ForgotPasswordUsernotfound),
						AppForgotPasswordPageObjects.errormsg_ForgotPasswordUsernotfound.getObjectname(),
						Errormessage_ForgotPasswordInvalidUserInfo);

			}

			public void forgotPassword_ValidDataOnGeneralInformationPage() throws InterruptedException, IOException {
				String FirstName = dataTable.getData("General_Data", "FirstName");
				String LastName = dataTable.getData("General_Data", "LastName");
				String Address = dataTable.getData("General_Data", "Address");
				String Zipcode = dataTable.getData("General_Data", "Zipcode");
				String City = dataTable.getData("General_Data", "City");
				String State = dataTable.getData("General_Data", "State");
				String DOB = dataTable.getData("General_Data", "DOB");

				String date = DOB;
				String dateParts[] = date.split("/");
				String month = dateParts[0];
				String day = dateParts[1];
				String year = dateParts[2];
				
				commonFunction.scrollUp();
				commonFunction.selectValueMobileDropDown(getPageElement(AppForgotPasswordPageObjects.drpDownBirthMonth), month, AppForgotPasswordPageObjects.drpDownBirthMonth.getObjectname());
				commonFunction.selectValueMobileDropDown(getPageElement(AppForgotPasswordPageObjects.drpdwn_ForgotPasswordGeneralInforBirthDay), day, AppForgotPasswordPageObjects.drpdwn_ForgotPasswordGeneralInforBirthDay.getObjectname());
				commonFunction.selectValueMobileDropDown(getPageElement(AppForgotPasswordPageObjects.drpdwn_ForgotPasswordGeneralInforBirthYear), year,AppForgotPasswordPageObjects.drpdwn_ForgotPasswordGeneralInforBirthYear.getObjectname());
				commonFunction.clearAndEnterText(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInforFirstName), FirstName,
						AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInforFirstName.getObjectname());
				commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoLastName), LastName,
						AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoLastName.getObjectname());
				((AndroidDriver)driver).hideKeyboard();
				commonFunction.scrollDown();
				//commonFunction.scrollToMobileElement("Address");
				commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoAddressLine), Address,
						AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoAddressLine.getObjectname());
				commonFunction.scrollDown();
				commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoZipcode),
						Zipcode, AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoZipcode.getObjectname());
				//Thread.sleep(2000);
				if (getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoCity).getText().contains("")) {
					commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoCity), City,
							AppForgotPasswordPageObjects.txt_ForgotPasswordGeneralInfoCity.getObjectname());
					commonFunction.selectValueMobileDropDown(getPageElement(AppForgotPasswordPageObjects.Drpdwn_ForgotPasswordGenralInfoState),
							State, AppForgotPasswordPageObjects.Drpdwn_ForgotPasswordGenralInfoState.getObjectname());
				}
				commonFunction.clickIfElementPresent(
						getPageElement(AppForgotPasswordPageObjects.btn_ForgotPasswordGeneralInfoConitnue),
						AppForgotPasswordPageObjects.btn_ForgotPasswordGeneralInfoConitnue.getObjectname());

			}

			public void forgotPassword_NegativeValidationsVerifyIdentity() throws InterruptedException, IOException {
				String InvalidChallengeAnswer = dataTable.getData("General_Data", "InvalidChallengeAnswer");

				String Errormessage_ForgotPasswordNoChallengeAnswer = "Please provide an answer to account recovery question";
				String Errormessage_ForgotPasswordIncorrectChallengeAnswer = "The answer does not match our records. Please re-enter your answer to the challenge question";

				// ChallengeAnswer not entered on VerifyIdentity Page
				//Thread.sleep(4000);
				commonFunction.clickIfElementPresent(getPageElement(AppForgotPasswordPageObjects.btn_ForgotPasswordVerifyIdentityContinue),
						AppForgotPasswordPageObjects.btn_ForgotPasswordVerifyIdentityContinue.getObjectname());
				//Thread.sleep(5000);
				commonFunction.isElementPresentContainsText(
						getPageElement(AppForgotPasswordPageObjects.errormsg_VerifyIdenityChallengeAnswer),
						AppForgotPasswordPageObjects.errormsg_VerifyIdenityChallengeAnswer.getObjectname(),
						Errormessage_ForgotPasswordNoChallengeAnswer);

				// User entered Incorrect ChallengeAnswer on VerifyIdentity page
				commonFunction.clearAndEnterTextTabOut(
						getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordVerifyIdentityChallengeAnswer), InvalidChallengeAnswer,
						AppForgotPasswordPageObjects.txt_ForgotPasswordVerifyIdentityChallengeAnswer.getObjectname());
				//Thread.sleep(2000);
				commonFunction.clickIfElementPresent(getPageElement(AppForgotPasswordPageObjects.btn_ForgotPasswordVerifyIdentityContinue),
						AppForgotPasswordPageObjects.btn_ForgotPasswordVerifyIdentityContinue.getObjectname());
				commonFunction.isElementPresentContainsText(
						getPageElement(AppForgotPasswordPageObjects.errormsg_ForgotPasswordInvalidChallengeAnswer),
						AppForgotPasswordPageObjects.errormsg_ForgotPasswordInvalidChallengeAnswer.getObjectname(),
						Errormessage_ForgotPasswordIncorrectChallengeAnswer);

			}

			public void forgotPassword_ValidDataVerifyIdentity() throws InterruptedException, IOException {
				String ChallengeAnswer = dataTable.getData("General_Data", "ChallengeAnswer");

				commonFunction.clearAndEnterTextTabOut(
						getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordVerifyIdentityChallengeAnswer), ChallengeAnswer,
						AppForgotPasswordPageObjects.txt_ForgotPasswordVerifyIdentityChallengeAnswer.getObjectname());
				//Thread.sleep(2000);
				commonFunction.clickIfElementPresent(getPageElement(AppForgotPasswordPageObjects.btn_ForgotPasswordVerifyIdentityContinue),
						AppForgotPasswordPageObjects.btn_ForgotPasswordVerifyIdentityContinue.getObjectname());
				//Thread.sleep(4000);

			}

			public void forgotPassword_NegativeValidationsResetPassword() throws InterruptedException, IOException {
				String InvalidPasswordformat = dataTable.getData("General_Data", "InvalidPasswordformat");
				String DifferntPassword = dataTable.getData("General_Data", "InvalidPassword");
				String Password = dataTable.getData("General_Data", "Password");

				String Errormessage_ForgotPasswordNoPassword = "Please provide a password";
				String Errormessage_ForgotPasswordInvalidPasswordformat = "Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.";
				String Errormessage_ForgotPasswordDiffPassword = "Passwords did not match";

				// User clicked Continue without entering Password on ResetPassword page
				commonFunction.clickIfElementPresent(getPageElement(AppForgotPasswordPageObjects.btn_ForgotPasswordResetPasswordNext),
						AppForgotPasswordPageObjects.btn_ForgotPasswordResetPasswordNext.getObjectname());
				commonFunction.isElementPresentContainsText(
						getPageElement(AppForgotPasswordPageObjects.errormsg_ForgotPasswordPagefieldvalidation),
						AppForgotPasswordPageObjects.errormsg_ForgotPasswordPagefieldvalidation.getObjectname(),
						Errormessage_ForgotPasswordNoPassword);

				// User entered Invalid format in Password field
				commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordResetPasswordPasswordfield),
						InvalidPasswordformat, AppForgotPasswordPageObjects.txt_ForgotPasswordResetPasswordPasswordfield.getObjectname());
				commonFunction.isElementPresentContainsText(
						getPageElement(AppForgotPasswordPageObjects.errormsg_ForgotPasswordInvalidPasswordformatentered),
						AppForgotPasswordPageObjects.errormsg_ForgotPasswordInvalidPasswordformatentered.getObjectname(),
						Errormessage_ForgotPasswordInvalidPasswordformat);

				// User entered different data in Password & ConfirmPassword fields
				commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordResetPasswordPasswordfield),
						Password, AppForgotPasswordPageObjects.txt_ForgotPasswordResetPasswordPasswordfield.getObjectname());
				commonFunction.clearAndEnterTextTabOut(
						getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordResetPasswordConfirmPasswordfield), DifferntPassword,
						AppForgotPasswordPageObjects.txt_ForgotPasswordResetPasswordConfirmPasswordfield.getObjectname());
				commonFunction.clickIfElementPresent(getPageElement(AppForgotPasswordPageObjects.btn_ForgotPasswordResetPasswordNext),
						AppForgotPasswordPageObjects.btn_ForgotPasswordResetPasswordNext.getObjectname());
				//Thread.sleep(4000);
				commonFunction.isElementPresentContainsText(
						getPageElement(AppForgotPasswordPageObjects.errormsg_ForgotPasswordDifferentPasswordentered),
						AppForgotPasswordPageObjects.errormsg_ForgotPasswordDifferentPasswordentered.getObjectname(),
						Errormessage_ForgotPasswordDiffPassword);

			}

			public void forgotPassword_ValidDataResetPassword() throws InterruptedException, IOException {
				String Password = dataTable.getData("General_Data", "Password");
				String ConfirmPassword = dataTable.getData("General_Data", "Password");

				commonFunction.clearAndEnterTextTabOut(getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordResetPasswordPasswordfield),
						Password, AppForgotPasswordPageObjects.txt_ForgotPasswordResetPasswordPasswordfield.getObjectname());
				commonFunction.clearAndEnterTextTabOut(
						getPageElement(AppForgotPasswordPageObjects.txt_ForgotPasswordResetPasswordConfirmPasswordfield), ConfirmPassword,
						AppForgotPasswordPageObjects.txt_ForgotPasswordResetPasswordConfirmPasswordfield.getObjectname());
				commonFunction.clickIfElementPresent(getPageElement(AppForgotPasswordPageObjects.btn_ForgotPasswordResetPasswordNext),
						AppForgotPasswordPageObjects.btn_ForgotPasswordResetPasswordNext.getObjectname());
				//Thread.sleep(4000);
			}	

		}
