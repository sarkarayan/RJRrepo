package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.rai.framework.Status;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.componentgroups.*;
import com.rai.pageObjects.AppLoginPageObjects;
import com.rai.pageObjects.AppRegistrationPageObjects;

import io.appium.java_client.android.AndroidDriver;

public class MobileApp_AlreadyRegisteredPage extends BaseClass {

	String testcaseName;

	public MobileApp_AlreadyRegisteredPage(String testcaseName) {
		this.testcaseName = testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper The {@link ScriptHelper} object passed from the
	 *                     {@link DriverScript}
	 */

	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	private WebElement getPageElement(AppRegistrationPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}

	private WebElement getPageElement(AppLoginPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Login Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	public void invokeApplication_brandwebsite() {
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	}

	@SuppressWarnings("rawtypes")
	public void registration_ValidDetailsonStep1Page() throws Exception {

		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String Email = dataTable.getData("General_Data", "Email");
		String City = dataTable.getData("General_Data", "City");
		String State = dataTable.getData("General_Data", "State");
		String DOB = dataTable.getData("General_Data", "DOB");

		String date = DOB;
		String dateParts[] = date.split("/");
		String month = dateParts[0];
		String day = dateParts[1];
		String year = dateParts[2];
		WebDriverWait wait = new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.visibilityOf(getPageElement(AppLoginPageObjects.txt_GrizzlyAPPLoginUsername)));
		commonFunction.scrollDown();
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_GrizzlyAPPRegister),
				AppRegistrationPageObjects.btn_GrizzlyAPPRegister.getObjectname());

		commonFunction.selectValueMobileDropDown(
				getPageElement(AppRegistrationPageObjects.drpdwn_RegistrationStep1BirthMonth), month,
				AppRegistrationPageObjects.drpdwn_RegistrationStep1BirthMonth.getObjectname());
		commonFunction.selectValueMobileDropDown(
				getPageElement(AppRegistrationPageObjects.drpdwn_RegistrationStep1BirthDay), day,
				AppRegistrationPageObjects.drpdwn_RegistrationStep1BirthDay.getObjectname());
		commonFunction.selectValueMobileDropDown(
				getPageElement(AppRegistrationPageObjects.drpdwn_RegistrationStep1BirthYear), year,
				AppRegistrationPageObjects.drpdwn_RegistrationStep1BirthYear.getObjectname());
		((AndroidDriver) driver).hideKeyboard();

		commonFunction.clearAndEnterText(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep1FirstName),
				FirstName, AppRegistrationPageObjects.txt_RegistrationStep1FirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep1LastName),
				LastName, AppRegistrationPageObjects.txt_RegistrationStep1LastName.getObjectname());
		// commonFunction.scrollIntoView(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep1Address1));
		commonFunction.clearAndEnterText(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep1Address1),
				Address, AppRegistrationPageObjects.txt_RegistrationStep1Address1.getObjectname());

		((AndroidDriver) driver).hideKeyboard();
		// commonFunction.scrollDown();

		commonFunction.clearAndEnterTextTabOut(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep1Zipcode),
				Zipcode, AppRegistrationPageObjects.txt_RegistrationStep1Zipcode.getObjectname());
		((AndroidDriver) driver).hideKeyboard();
		commonFunction.clearAndEnterTextTabOut(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep1City),
				City, AppRegistrationPageObjects.txt_RegistrationStep1City.getObjectname());
		((AndroidDriver) driver).hideKeyboard();
		commonFunction.selectValueMobileDropDown(
				getPageElement(AppRegistrationPageObjects.drpdwn_RegistrationStep1State), State,
				AppRegistrationPageObjects.drpdwn_RegistrationStep1State.getObjectname());

		((AndroidDriver) driver).hideKeyboard();
		commonFunction.scrollDown();

		commonFunction.clearAndEnterTextTabOut(getPageElement(AppRegistrationPageObjects.txt_RegistrationStep1Email),
				Email, AppRegistrationPageObjects.txt_RegistrationStep1Email.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.chkbox_RegistrationStep1),
				AppRegistrationPageObjects.chkbox_RegistrationStep1.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_RegistrationStep1Next),
				AppRegistrationPageObjects.btn_RegistrationStep1Next.getObjectname());

	}

	public void registration_sameBrandAlreadyRegisteredPage() throws IOException {

		String ExpectedErrormsg_AlreadyRegistered1 = "IT LOOKS LIKE YOU'RE ALREADY REGISTERED WITH US!!";
		String expectedErrorMsg_AlreadyRegistered2 = "Our records show that you already have an account with us. Please log in with your Username and password.";
		commonFunction.isElementPresentContainsText(
				getPageElement(AppRegistrationPageObjects.errmsg_AlreadyRegisteredSame),
				AppRegistrationPageObjects.errmsg_AlreadyRegisteredSame.getObjectname(),
				ExpectedErrormsg_AlreadyRegistered1);
		commonFunction.isElementPresentContainsText(
				getPageElement(AppRegistrationPageObjects.errmsg_AlredyRegisteredSame2),
				AppRegistrationPageObjects.errmsg_AlredyRegisteredSame2.getObjectname(),
				expectedErrorMsg_AlreadyRegistered2);

	}

	public void registration_anotherBrandAlreadyRegisteredPage() throws Exception {

		String ExpectedErrormsg_diffBrandAlreadyRegistered = "It looks like you are already registered with another Reynolds American operating company�s brand website.";

		commonFunction.isElementPresentContainsText(getPageElement(AppRegistrationPageObjects.errmsg_AlreadyRegistered),
				AppRegistrationPageObjects.errmsg_AlreadyRegistered.getObjectname(),
				ExpectedErrormsg_diffBrandAlreadyRegistered);
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_AlreadyRegisteredLogin),
				AppRegistrationPageObjects.btn_AlreadyRegisteredLogin.getObjectname());
	}

	public void registration_anotherBrandAlreadyRegisteredPageOasis() throws Exception {

		String ExpectedErrormsg_diffBrandAlreadyRegistered = "It looks like you are already registered with another Reynolds American operating company�s brand website.";

		commonFunction.isElementPresentContainsText(getPageElement(AppRegistrationPageObjects.errmsg_AlreadyRegistered),
				AppRegistrationPageObjects.errmsg_AlreadyRegistered.getObjectname(),
				ExpectedErrormsg_diffBrandAlreadyRegistered);
		commonFunction.clickIfElementPresent(getPageElement(AppRegistrationPageObjects.btn_AlreadyRegisteredLogin),
				AppRegistrationPageObjects.btn_AlreadyRegisteredLogin.getObjectname());
	}

}
