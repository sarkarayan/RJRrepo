package com.rai.pageObjects;

import static com.rai.pageObjects.ObjectLocator.*;



public enum AppRegistrationPageObjects implements PageObjects {
	
	//AllowPermission
	btn_AppAllowPermission("//android.widget.Switch[@resource-id='android:id/switch_widget']",XPATH,"APP Permission Allow"),

	//Registration - Step 1
	btn_GrizzlyAPPRegister("//android.widget.Button[@text='REGISTER']",XPATH,"Button - Register"),
	lnk_RegistrationStep1BacktoLogin("//android.widget.TextView[@text='Back to Login']",XPATH,"Link - Registration Step1 BacktoLogin text"),
	drpdwn_RegistrationStep1BirthMonth("//android.widget.Spinner[@resource-id='UserInformation_BirthMonth']",XPATH,"Dropdown - RegistrationStep1BirthMonth"),
	drpdwn_RegistrationStep1BirthDay("//android.widget.Spinner[@resource-id='UserInformation_BirthDay']",XPATH,"Dropdown - RegistrationStep1BirthDay"),
	drpdwn_RegistrationStep1BirthYear("//android.widget.Spinner[@resource-id='UserInformation_BirthYear']",XPATH,"Dropdown - RegistrationStep1BirthYear"),
	txt_RegistrationStep1FirstName("//android.widget.EditText[@resource-id='UserInformation_FirstName']",XPATH,"Input - RegistrationStep1FirstName"),
	txt_RegistrationStep1LastName("//android.widget.EditText[@resource-id='UserInformation_LastName']",XPATH,"Input - RegistrationStep1LastName"),
	txt_RegistrationStep1Address1("//android.widget.EditText[@resource-id='UserInformation_AddressLine1']",XPATH,"Input - RegistrationStep1Address"),
	txt_RegistrationStep1Zipcode("//android.widget.EditText[@resource-id='UserInformation_ZipCode']",XPATH,"Input - RegistrationStep1Zipcode"),
	txt_RegistrationStep1City("//android.widget.EditText[@resource-id='UserInformation_City']",XPATH,"Input - RegistrationStep1City"),
	drpdwn_RegistrationStep1State("//android.widget.Spinner[@resource-id='UserInformation_State']",XPATH,"Dropdown - RegistrationStep1State"),
	txt_RegistrationStep1Email("//android.widget.EditText[@resource-id='UserInformation_EmailAddress']",XPATH,"Input - Email"),
	chkbox_RegistrationStep1("//android.widget.CheckBox[@resource-id='UserInformation_IsCertified']",XPATH,"Checkbox - RegistrationStep1Certified"),
	btn_RegistrationStep1Next("//android.widget.Button[@resource-id='next-intro']",XPATH,"Button - RegistrationStep1 Next"),
	
	erromsg_RegistrationStep1("//android.view.View[@text='Please acknowledge.']",XPATH,"ErrorMessage - Please acknowledge."),
	errmsg_Step1("//android.view.View[@text='Please fix the errors above']",XPATH,"ErrorMessage - Please fix the errors above"),
	errormsg_RegistrationNoEmail("//android.view.View[@text='Please enter a valid email address']",XPATH,"ErrorMessage - email address"),
	errormsg_RegistrationNoState("//android.view.View[@text='Please Provide State']",XPATH,"ErrorMessage - State"),
	errormsg_RegistrationNoCity("//android.view.View[@text='Please Provide City']",XPATH,"ErrorMessage - City"),
	errormsg_RegistrationNoDOB("//android.view.View[@text='Please provide your full date of birth']",XPATH,"ErrorMessage - DOB"),
	errormsg_RegistrationNoLegalName("//android.view.View[@text='Please enter your legal name']",XPATH,"ErrorMessage - name"),
	errormsg_RegistrationNoAddress("//android.view.View[@text='Please provide a street address']",XPATH,"ErrorMessage - address"),
	errormsg_RegistrationNoZipcode("//android.view.View[@text='Please provide a ZIP Code']",XPATH,"ErrorMessage - ZIP"),
	
	
	errmsg_AlreadyRegistered("//*[@resource-id=\"regStepFail\"]/android.view.View[@index=0]",XPATH,"Already Registered Page -Error Mesage"),
	errmsg_AlreadyRegisteredOasis("//android.view.View[@text='Our records show that you already have an account with us. Please log in with your Username and password.']",XPATH,"Already Registered Page"),
	errmsg_AlreadyRegisteredSame("//*[@resource-id=\"regStep1\"]/android.view.View[@index=0]",XPATH,"Already Registered Page"),
	errmsg_AlredyRegisteredSame2("//*[@resource-id=\"regStep1\"]/android.view.View[@index=1]", XPATH,"Already Registered Page - Same Brand Error Message"),
	
	btn_AlreadyRegisteredLogin("//android.widget.Button[@text='RETURN TO LOGIN']",XPATH,"Login - AlreadyRegistered"),

	//Registration - Step2
	lnk_RegistrationStep2BacktoLogin("//android.widget.TextView[@text='Back to Login']",XPATH,"Link - Registration Step2 BacktoLogin text"),
	txt_RegistrationStep2UserName("//android.widget.EditText[@resource-id='UserInformation_UserNameConfirm']",XPATH,"Read - RegistrationStep2UserName"),
	txt_RegistrationStep2Password("//android.widget.EditText[@resource-id='UserInformation_Password']",XPATH,"Read - RegistrationStep2Password"),
	txt_RegistrationStep2NewPassword("//android.widget.EditText[@resource-id='UserInformation_ConfirmPassword']",XPATH,"Read - RegistrationStep2NewPassword"),
	tooltip_RegistrationStep2("//android.view.View[@text='i']",XPATH,"ToolTip - RegistrationStep2"),
	drpdwn_RegistrationStep2ChallengeQuestion("//android.widget.Spinner[@resource-id='UserInformation_ChallengeQuestionId']",XPATH,"Dropdown - RegistrationStep2ChallengeQuestion"),
	txt_RegistrationStep2ChallengeAnswer("//android.widget.EditText[@resource-id='UserInformation_ChallengeAnswer']",XPATH,"Input - RegistrationStep2ChallengeAnswer"),
	btn_RegistrationStep2Next("//android.widget.Button[@resource-id='continue-verification']",XPATH,"Button - RegistrationStep2 Next"),
	
	errormsg_RegistrationNoDataonStep2Page("//android.view.View[@text='Please fix the errors above']",XPATH,"ErrorMessage - Step2"),
	errormsg_RegistrationNoPassword("//android.view.View[@text='Please provide a password']",XPATH,"ErrorMessage - password"),
	errormsg_RegistrationNoChallengeQuestion("//android.view.View[@text='Please select a account recovery question']",XPATH,"ErrorMessage - question"),
	errormsg_RegistrationNoChallengeAnswer("//android.view.View[@text='Please provide an answer to account recovery question']",XPATH,"ErrorMessage - answer"),
	errormsg_RegistrationIncorrectPasswordformat("//android.view.View[@text='Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.']",XPATH,"ErrorMessage - IncorrectPasswordformat"),
	errormsg_RegistrationDifferentPasswordsentered("//android.view.View[@text='Passwords did not match']",XPATH,"ErrorMessage - Passwords did not match"),
		
	
	//Registration - Step3
	lnk_RegistrationStep3BacktoLogin("//android.widget.TextView[@text='Back to Login']",XPATH,"Link - Registration Step3 BacktoLogin text"),
	radbtn_RegistrationStep3KBA("//android.widget.RadioButton[@resource-id='verify_identity_01']",XPATH,"Radiobutton - Step3 KBA"),
	tooltip_RegistrationStep3("//android.view.View[@text='i']",XPATH,"Tooltip - Step3KBA"),
	radbtn_RegistrationStep3SSN("//android.widget.RadioButton[@resource-id='verify_identity_02']",XPATH,"Radiobutton - Step3 SSN"),
	txt_RegistrationStep3SSN("//android.widget.EditText[@resource-id='UserInformation_SSN']",XPATH,"Input - RegistrationStep3 SSN"),
	txt_onlySSNvisible("//android.widget.EditText[@resource-id='UserInformation_NoKBASSN']",XPATH,"Input - RegistrationStep3 SSN"),
	btn_RegistrationStep3Submit("//android.widget.Button[@resource-id='ssnbutton']",XPATH,"Button - RegistrationStep3 Submit"),
	btn_SubmitwhenonlySSNVisible("//android.widget.Button[@resource-id='ssnnokbabutton']",XPATH,"Button - RegistrationStep3 Submit"),
	erroMsg_RegistrationInvaliSSNNoKBA("//android.view.View[@text='Your Social Security Number does not match your name and date of birth. Please try again.']",XPATH,"ErrorMessage - Invalid SSN"),
	
	
	//CreatePIN
	lnk_CreatePINLogout("//android.widget.TextView[@text='Log Out']",XPATH,"Link - CreatePIN Logout"),
	lnk_CreatePINSkip("//android.widget.TextView[@text='Skip']",XPATH,"Link - CreatePIN Skip"),
	btn_CreatePINOK ("//android.widget.Button[@text='OK']",XPATH,"Button - CreatePIN OK"),
	btn_CreatePINNotNow ("//android.widget.Button[@text='NOT NOW']",XPATH,"Button - CreatePIN NotNow"),
	btn_CreatePINNumber1 ("//android.widget.Button[@text='1']",XPATH,"Button - CreatePIN Number1"),
	btn_CreatePINNumber2 ("//android.widget.Button[@text='2']",XPATH,"Button - CreatePIN Number2"),
	btn_CreatePINNumber3 ("//android.widget.Button[@text='3']",XPATH,"Button - CreatePIN Number3"),
	btn_CreatePINNumber4 ("//android.widget.Button[@text='4']",XPATH,"Button - CreatePIN Number4"),
	btn_CreatePINNumber5 ("//android.widget.Button[@text='5']",XPATH,"Button - CreatePIN Number5"),
	btn_CreatePINNumber6 ("//android.widget.Button[@text='6']",XPATH,"Button - CreatePIN Number6"),
	btn_CreatePINNumber7 ("//android.widget.Button[@text='7']",XPATH,"Button - CreatePIN Number7"),
	btn_CreatePINNumber8 ("//android.widget.Button[@text='8']",XPATH,"Button - CreatePIN Number8"),
	btn_CreatePINNumber9 ("//android.widget.Button[@text='9']",XPATH,"Button - CreatePIN Number9"),
	btn_CreatePINNumber0 ("//android.widget.Button[@text='0']",XPATH,"Button - CreatePIN Number0"),
	
	
	//VerifyPIN
	lnk_VerifyPINLogout("//android.widget.TextView[@text='Log Out']",XPATH,"Link - VerifyPIN Logout"),
	lnk_VerifyPINSkip("//android.widget.TextView[@text='Skip']",XPATH,"Link - VerifyPIN Skip"),
	btn_VerifyPINNumber1 ("//android.widget.Button[@text='1']",XPATH,"Button - VerifyPIN Number1"),
	btn_VerifyPINNumber2 ("//android.widget.Button[@text='2']",XPATH,"Button - VerifyPIN Number2"),
	btn_VerifyPINNumber3 ("//android.widget.Button[@text='3']",XPATH,"Button - VerifyPIN Number3"),
	btn_VerifyPINNumber4 ("//android.widget.Button[@text='4']",XPATH,"Button - VerifyPIN Number4"),
	btn_VerifyPINNumber5 ("//android.widget.Button[@text='5']",XPATH,"Button - VerifyPIN Number5"),
	btn_VerifyPINNumber6 ("//android.widget.Button[@text='6']",XPATH,"Button - VerifyPIN Number6"),
	btn_VerifyPINNumber7 ("//android.widget.Button[@text='7']",XPATH,"Button - VerifyPIN Number7"),
	btn_VerifyPINNumber8 ("//android.widget.Button[@text='8']",XPATH,"Button - VerifyPIN Number8"),
	btn_VerifyPINNumber9 ("//android.widget.Button[@text='9']",XPATH,"Button - VerifyPIN Number9"),
	btn_VerifyPINNumber0 ("//android.widget.Button[@text='0']",XPATH,"Button - VerifyPIN Number0"),
	
	//APP Tutorial
	btn_AppTutorialStep1TurnON ("//android.widget.Button[@text='TURN ON']",XPATH,"Button - AppTutorial Step1 TurnON"),
	btn_AppTutorialStep1NotNow ("//android.widget.Button[@text='NOT NOW']",XPATH,"Button - AppTutorial Step1 NotNow"),
	
	btn_AppTutorialStep2Allow ("//android.widget.Button[@text='ALLOW']",XPATH,"Button - AppTutorial Step2 Allow"),
	btn_AppTutorialStep2NotNow ("//android.widget.Button[@text='NOT NOW']",XPATH,"Button - AppTutorial Step2 NotNow"),
	
	btn_AppTutorialStep3GotIt ("//android.widget.Button[@text='GOT IT']",XPATH,"Button - AppTutorial Step3 GotIt"),
	
	btn_AppTutorialStep4GotIt ("//android.widget.Button[@text='GOT IT']",XPATH,"Button - AppTutorial Step4 GotIt"),
	
	btn_AppTutorialStep5GotIt ("//android.widget.Button[@text='GOT IT']",XPATH,"Button - AppTutorial Step5 GotIt"),
	
	btn_DeviceLocationDeny ("//android.widget.Button[@resource-id='com.android.packageinstaller:id/permission_deny_button' or @text='DENY']",XPATH,"Button - DeviceLocation Deny"),
	btn_DeviceLocationAllow ("//android.widget.Button[@resource-id='com.android.packageinstaller:id/permission_allow_button' or @text='ALLOW']",XPATH,"Button - DeviceLocation Allow"),
	;
	
	
	
	
	String strProperty = "";
   	ObjectLocator locatorType = null;
   	String strObjName = "";
   	
	@Override
	public String getProperty() {
		// TODO Auto-generated method stub
		return strProperty;
	}

	@Override
	public ObjectLocator getLocatorType() {
		// TODO Auto-generated method stub
		return locatorType;
	}

	@Override
	public String getObjectname() {
		// TODO Auto-generated method stub
		return strObjName;
	}
	
	private AppRegistrationPageObjects (String strPropertyValue, ObjectLocator locatorType, String strObjName) {
		// TODO Auto-generated method stub
		this.strProperty = strPropertyValue;
   		this.locatorType = locatorType;
   		this.strObjName = strObjName;
		
	}
}
