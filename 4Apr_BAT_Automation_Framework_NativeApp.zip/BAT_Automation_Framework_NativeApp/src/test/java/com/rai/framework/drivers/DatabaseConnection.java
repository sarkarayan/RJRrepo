package com.rai.framework.drivers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.rai.framework.BaseClass;

public class DatabaseConnection extends BaseClass {

	public static ResultSet getResultSet(String query) {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

			String userName = properties.getProperty("DBUsername");
			String password = properties.getProperty("DBPassword");
			String databaseName = properties.getProperty("DatabaseName");
			String serverName = properties.getProperty("ServerName");
			String url = "jdbc:sqlserver://"+serverName+":1433" + ";databaseName="+databaseName;
			Connection con = DriverManager.getConnection(url, userName, password);
			Statement s1 = con.createStatement();
			ResultSet rs = s1.executeQuery(query);
			return rs;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public static String getDBColumnValue(ResultSet rs, String columnName) {
		String value = null;
		try {
			if (rs != null) {
				while (rs.next()) {
					value= rs.getString(columnName);
				}
			}
			return value;
		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}
		
	}

}
