package testscripts.cts.RevelMobileSiteAndSPA;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.MobileSite_FogotUsername;
import com.rai.pages.Mobilesite_SGWImageandTextValidation;

@Listeners(ExtentITestListenerClassAdapter.class)
public class ForgotUsername_ValidatingSGWText_RevelMobilesite extends BaseClass 
{
	MobileSite_FogotUsername mobileSiteForgotusername;
	Mobilesite_SGWImageandTextValidation mobilesitesiteForgotUsernameSGWText;
	
	public ForgotUsername_ValidatingSGWText_RevelMobilesite() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("WEB_ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("ZY224ZZNBC")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		mobileSiteForgotusername = new MobileSite_FogotUsername(this.getClass().getSimpleName());
		mobilesitesiteForgotUsernameSGWText = new Mobilesite_SGWImageandTextValidation(this.getClass().getSimpleName());
		gl= new GenericLib(this.getClass().getSimpleName());
		//gl.start_report(this.getClass().getSimpleName(), "Verify the forgot username flow", properties.getProperty("ApplicationUrl"));
	}
	
	@Test
	public void verifySGWTextinForgotUserNameFlow_RevelWebsite() throws Exception 
	{
		mobilesitesiteForgotUsernameSGWText.invokeApplication_brandMobilesite();
		mobileSiteForgotusername.navigateToRevelVeloForgotUsernamePage();
		mobilesitesiteForgotUsernameSGWText.ecommercesites_ValidatingSGWtext();
		mobileSiteForgotusername.forgotUsername_ValidDataAccountInformation();
		mobilesitesiteForgotUsernameSGWText.ecommercesites_ValidatingSGWtext();
		mobileSiteForgotusername.forgotUsername_ValidDataVerifyIdentity();
		mobilesitesiteForgotUsernameSGWText.ecommercesites_ValidatingSGWtext();
		mobileSiteForgotusername.forgotUsername_NegativeValidationsWelcomeback();
		mobileSiteForgotusername.forgotUsername_ValidDataWelcomeback();
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		//gl.endReport();
		
	}
}
