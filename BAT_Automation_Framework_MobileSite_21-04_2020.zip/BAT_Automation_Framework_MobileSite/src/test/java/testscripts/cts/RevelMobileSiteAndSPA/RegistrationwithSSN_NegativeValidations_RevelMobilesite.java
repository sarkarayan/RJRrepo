package testscripts.cts.RevelMobileSiteAndSPA;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.MobileSiteHomePageComponents;
import com.rai.pages.MobileSite_Newuser_RegistrationSSN;


@Listeners(ExtentITestListenerClassAdapter.class)
public class RegistrationwithSSN_NegativeValidations_RevelMobilesite extends BaseClass{


	MobileSite_Newuser_RegistrationSSN mobileSiteSSNRegesterCamel;
	MobileSiteHomePageComponents mobileSiteHomePageComponents;
	
	public RegistrationwithSSN_NegativeValidations_RevelMobilesite() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("WEB_ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("98892A4144365A334C")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		mobileSiteSSNRegesterCamel = new MobileSite_Newuser_RegistrationSSN(this.getClass().getSimpleName());
		mobileSiteHomePageComponents = new MobileSiteHomePageComponents(this.getClass().getSimpleName());
		//gl= new GenericLib(this.getClass().getSimpleName());
		//gl.start_report(this.getClass().getSimpleName(), "Verify the forgot username flow", properties.getProperty("ApplicationUrl"));
	}
	
	@Test
	public void verifyRegistrationwithSSN_NegativeValidations() throws Exception {
		
		mobileSiteSSNRegesterCamel.invokeApplication_brandMobilesite();
		mobileSiteSSNRegesterCamel.navigateToRevelRegistrationPage();
		mobileSiteSSNRegesterCamel.registration_ValidateErrormessagesonStep1();
		mobileSiteSSNRegesterCamel.registration_RevelValidDetailsonStep1Page();
		mobileSiteSSNRegesterCamel.registration_ValidateErrormessageonStep2();
		mobileSiteSSNRegesterCamel.registration_EnterValidDataonStep2();
		mobileSiteSSNRegesterCamel.registration_ValidateErrormessageonStep3();
		
		
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		//gl.endReport();
		
	}

}
