package testscripts.cts.AmericanSpiritMobileSite;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.MobileSiteHomePageComponents;
import com.rai.pages.MobileSite_ForgotPassword;
import com.rai.pages.MobileSite_MyprofileUpdate;

@Listeners(ExtentITestListenerClassAdapter.class)
public class Forgot_Password_Flow_Validations_Americanspirit_Mobile_Site extends BaseClass {
	MobileSite_ForgotPassword mobileSiteForgotPasswordCamel;
	MobileSite_MyprofileUpdate mobileSiteHomePageComponents;
	public Forgot_Password_Flow_Validations_Americanspirit_Mobile_Site() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("WEB_ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("ZY224ZZNBC")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		mobileSiteForgotPasswordCamel = new MobileSite_ForgotPassword(this.getClass().getSimpleName());
		mobileSiteHomePageComponents = new MobileSite_MyprofileUpdate(this.getClass().getSimpleName());
		gl= new GenericLib(this.getClass().getSimpleName());
		//gl.start_report(this.getClass().getSimpleName(), "Verify the forgot username flow", properties.getProperty("ApplicationUrl"));
	}
	
	@Test
	public void verifyForgotpasswordflowValidations_AmericanSpiritMobilesite() throws Exception {
		mobileSiteForgotPasswordCamel.invokeApplication_MobileSite();
		mobileSiteForgotPasswordCamel.navigateToForgotPasswordPage();
		mobileSiteForgotPasswordCamel.forgotPassword_EnterValidUsername();
		mobileSiteForgotPasswordCamel.forgotPassword_ValidDataOnGeneralInformationPage();
		mobileSiteForgotPasswordCamel.forgotPassword_ValidDataVerifyIdentity();
		mobileSiteForgotPasswordCamel.forgotPassword_ValidDataResetPassword();
		mobileSiteForgotPasswordCamel.forgotPassword_CongratsPage();
		mobileSiteHomePageComponents.americanSpiritHomePage_Logout();
		
	}
	

	@AfterMethod
	public void tearDown() {
		driver.close();
		driver.quit();
		//gl.endReport();
		
	}
}
