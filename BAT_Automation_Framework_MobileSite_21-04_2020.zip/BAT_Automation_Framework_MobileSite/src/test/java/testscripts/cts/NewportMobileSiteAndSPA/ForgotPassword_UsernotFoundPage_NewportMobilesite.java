package testscripts.cts.NewportMobileSiteAndSPA;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.Mobilesite_ForgotPassword_UsernotfoundPage;

@Listeners(ExtentITestListenerClassAdapter.class)
public class ForgotPassword_UsernotFoundPage_NewportMobilesite extends BaseClass 
{
	Mobilesite_ForgotPassword_UsernotfoundPage MobilesiteForgotPasswordUsernotFound;
	
	public ForgotPassword_UsernotFoundPage_NewportMobilesite() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("WEB_IOS")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("92EDC2E6F8D62ED24E9E6BA54CBCF80DF47CCA04")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		MobilesiteForgotPasswordUsernotFound = new Mobilesite_ForgotPassword_UsernotfoundPage(this.getClass().getSimpleName());
		//mobileSiteHomePageComponents = new MobileSiteHomePageComponents(this.getClass().getSimpleName());
		//gl= new GenericLib(this.getClass().getSimpleName());
		//gl.start_report(this.getClass().getSimpleName(), "Verify the forgot username flow", properties.getProperty("ApplicationUrl"));
	}
	
	@Test
	public void verifyUsernotfoundPage_NewportMobilesite() throws Exception {
		MobilesiteForgotPasswordUsernotFound.invokeApplication_brandMobilesite();
		MobilesiteForgotPasswordUsernotFound.navigateToForgotPasswordPage();
		MobilesiteForgotPasswordUsernotFound.forgotPassword_EnterValidUsername();
		MobilesiteForgotPasswordUsernotFound.forgotPassword_ValidDataOnGeneralInformationPage();
		MobilesiteForgotPasswordUsernotFound.forgotPassword_InvalidAnsweronVerifyIdentity();
		MobilesiteForgotPasswordUsernotFound.forgotPassword_UsernotfoundPage();
		
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		//gl.endReport();
		
	}
}
