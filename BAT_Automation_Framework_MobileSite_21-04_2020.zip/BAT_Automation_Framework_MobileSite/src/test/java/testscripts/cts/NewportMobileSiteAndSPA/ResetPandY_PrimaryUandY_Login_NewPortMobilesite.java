package testscripts.cts.NewportMobileSiteAndSPA;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.MobileSiteHomePageComponents;
import com.rai.pages.Mobilesite_LoginFlow_LoginResetPandY_PrimaryUandY;

@Listeners(ExtentITestListenerClassAdapter.class)
public class ResetPandY_PrimaryUandY_Login_NewPortMobilesite extends BaseClass {

	Mobilesite_LoginFlow_LoginResetPandY_PrimaryUandY RegistrationLoginResetUY;
	MobileSiteHomePageComponents mobileSiteHomePageComponents;
	public ResetPandY_PrimaryUandY_Login_NewPortMobilesite() {
		super();
	}

	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("WEB_ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("98892A4144365A334C")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		RegistrationLoginResetUY = new Mobilesite_LoginFlow_LoginResetPandY_PrimaryUandY(this.getClass().getSimpleName());
		mobileSiteHomePageComponents = new MobileSiteHomePageComponents(this.getClass().getSimpleName());
		gl= new GenericLib(this.getClass().getSimpleName());
		//gl.start_report(this.getClass().getSimpleName(), "Verify the forgot username flow", properties.getProperty("ApplicationUrl"));
	}
	

	@Test
	public void verifyLoginResetFlow_PandY_PrimaryUandY_NewPortMobilesite() throws Exception {
		RegistrationLoginResetUY.invokeApplication_brandMobilesite();
		RegistrationLoginResetUY.login_EnterValidDataPandY();
		RegistrationLoginResetUY.resetflow_GeneralInfoPageviaLogin();
		RegistrationLoginResetUY.resetflow_NegativeValidationsAccountInfoPage();
		RegistrationLoginResetUY.resetflow_AccountInfoPage();
		RegistrationLoginResetUY.resetflow_CongratsPage();
	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
		//gl.endReport();

	}

}
