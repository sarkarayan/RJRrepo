package testscripts.cts.VeloMobileSiteAndSPA;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.MobileSiteHomePageComponents;
import com.rai.pages.Mobilesite_Accountlocked;


@Listeners(ExtentITestListenerClassAdapter.class)
public class Loginwith128Characters_VeloMobilesite extends BaseClass{


	Mobilesite_Accountlocked accountlocked;
	
	public Loginwith128Characters_VeloMobilesite() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("WEB_ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("ZY224ZZNBC")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		accountlocked = new Mobilesite_Accountlocked(this.getClass().getSimpleName());
		//mobileSiteHomePageComponents = new MobileSiteHomePageComponents(this.getClass().getSimpleName());
		gl= new GenericLib(this.getClass().getSimpleName());
	}
	
	@Test
	public void verifyLoginwith128Characters() throws Exception {
		
		
		accountlocked.invokeApplication_mobilesite();
		accountlocked.loginPage_Loginwith128characters();
		
		
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		//gl.endReport();
		
	}

}
