package testscripts.cts.VeloMobileSiteAndSPA;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.MobileSite_MyprofileUpdate;
import com.rai.pages.Mobilesite_LoginPage_RememberMeFunctionality;

@Listeners(ExtentITestListenerClassAdapter.class)
public class Login_RememberMeFunctionality_VeloMobilesite extends BaseClass{

Mobilesite_LoginPage_RememberMeFunctionality mobilesiteRememberMe;
	
	MobileSite_MyprofileUpdate mobilesitesiteLogout;
	
	public Login_RememberMeFunctionality_VeloMobilesite() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("WEB_ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("520041CF4833954B")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		mobilesiteRememberMe = new Mobilesite_LoginPage_RememberMeFunctionality(this.getClass().getSimpleName());
		mobilesitesiteLogout = new MobileSite_MyprofileUpdate(this.getClass().getSimpleName());
		//gl= new GenericLib(this.getClass().getSimpleName());
		//gl.start_report(this.getClass().getSimpleName(), "Verify the forgot username flow", properties.getProperty("ApplicationUrl"));
	}
	
	@Test
	public void verifyRememberMeFunctionality() throws Exception {
		
		mobilesiteRememberMe.invokeApplication_brandMobilesite();
		mobilesiteRememberMe.revelVelologinPage_RememberMeValidation();
		//brandwebsiteLogout.veloHomePage_Logout();
		//brandwebsiteRememberMe.loginPage_ValidatedisplayedUserId();
		//brandwebsiteRememberMe.revelVelologout_RememberMeValidation();
		
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		//gl.endReport();
		
	}

}
