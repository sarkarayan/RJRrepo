package testscripts.cts.CamelMobileSiteAndSPA;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.MobileSite_ForgotPassword;
import com.rai.pages.MobileSite_MyprofileUpdate;
import com.rai.pages.Mobilesite_PrePostLoginFooterLinksValidation;
import com.rai.pages.Mobilesite_SGWImageandTextValidation;

@Listeners(ExtentITestListenerClassAdapter.class)
public class PostLogin_ValidatingSGWText_CamelMobilesite extends BaseClass{

	Mobilesite_SGWImageandTextValidation LoginPageSGWText;
	MobileSite_MyprofileUpdate mobileprofileupdate;
	Mobilesite_PrePostLoginFooterLinksValidation  logout;
	MobileSite_ForgotPassword mobileSiteForgotPasswordCamel;
	
	public PostLogin_ValidatingSGWText_CamelMobilesite() {
		super();
	}
	
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("WEB_ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("ZY224ZZNBC")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		mobileprofileupdate = new MobileSite_MyprofileUpdate(this.getClass().getSimpleName());
		LoginPageSGWText = new Mobilesite_SGWImageandTextValidation(this.getClass().getSimpleName());
		logout = new Mobilesite_PrePostLoginFooterLinksValidation (this.getClass().getSimpleName());
		mobileSiteForgotPasswordCamel = new MobileSite_ForgotPassword(this.getClass().getSimpleName());
		gl= new GenericLib(this.getClass().getSimpleName());
		//gl.start_report(this.getClass().getSimpleName(), "Verify the forgot username flow", properties.getProperty("ApplicationUrl"));
	}

	
	@Test
	public void verifySGWTextonPostLoginPage_CamelMobilesite() throws Exception {
		
		LoginPageSGWText.invokeApplication_brandMobilesite();
		mobileprofileupdate.loginPage_AppToWebsiteLogin();
		mobileSiteForgotPasswordCamel.closeSavePasswordPopUp();
		LoginPageSGWText.camelPostLogin_ValidatingSGWtext();
		logout.camelHomePage_Logout();
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		//gl.endReport();
		
	}

}
