package testscripts.cts.CamelMobileSiteAndSPA;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pages.Mobilesite_Login_OtherbrandUserwithLoginResetY;

@Listeners(ExtentITestListenerClassAdapter.class)
public class Login_OtherBrandHUserandResetY_CamelMobilesite extends BaseClass{

	Mobilesite_Login_OtherbrandUserwithLoginResetY MobilesiteresetuserY;
	
	
	public Login_OtherBrandHUserandResetY_CamelMobilesite() {
		super();
	}
	@BeforeMethod
	@Parameters({"executionMode", "toolName", "mobileExecutionPlatform", "mobileOsVersion", "deviceName", "browser", "browserVersion", "platform", "platformVersion" })
	public void setUp(@Optional("PERFECTO")String executionMode  , @Optional("APPIUM")String toolName, @Optional("WEB_ANDROID")String mobileExecutionPlatform, @Optional("")String mobileOsVersion, @Optional("520041CF4833954B")String deviceName, @Optional("CHROME")String browser, @Optional("")String browserVersion, @Optional("")String platform, @Optional("")String platformVersion) {
		initializeWebDriver(executionMode,  toolName,  mobileExecutionPlatform, mobileOsVersion,  deviceName,  browser,  browserVersion,  platform, platformVersion); 
		MobilesiteresetuserY = new Mobilesite_Login_OtherbrandUserwithLoginResetY(this.getClass().getSimpleName());
		//gl= new GenericLib(this.getClass().getSimpleName());
		//gl.start_report(this.getClass().getSimpleName(), "Verify the forgot username flow", properties.getProperty("ApplicationUrl"));
	}
	
	
	@Test
	public void usernameNotExists_OtherbrandHUserwithResetY_CamelMobilesite() throws Exception {
		
		MobilesiteresetuserY.invokeApplication_brandMobilesite();
		MobilesiteresetuserY.login_EnterValidData();
		MobilesiteresetuserY.loginPage_OtherBrandHandSUserwithResetY();
	}
	

	@AfterMethod
	public void tearDown() {
		driver.quit();
		//gl.endReport();
		
	}

}
