package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.MobilesitePageObjects;
import com.rai.pageObjects.MobilesitePageObjects;

public class Mobilesite_VUSEPrePostLoginFooterLinksValidation extends BaseClass {

	String testcaseName;
	public Mobilesite_VUSEPrePostLoginFooterLinksValidation(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(MobilesitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("FooterLinks Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	public void invokeApplication_brandMobilesite()
	{
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
		
	public void loginPage_AppToVUSEWebsiteLogin() throws InterruptedException, IOException
	{
		
		String Username = dataTable.getData("General_Data", "Username");
		String Password = dataTable.getData("General_Data", "Password");
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.loginLnk_VUSECertifyAgePage), MobilesitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		
		//commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.header_VUSELogin), MobilesitePageObjects.header_VUSELogin.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginUsername),Username,MobilesitePageObjects.txt_VUSELoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginPassword),Password, MobilesitePageObjects.txt_VUSELoginPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_VUSELogin), MobilesitePageObjects.btn_VUSELogin.getObjectname());
		Thread.sleep(5000);
	}
	
	
	public void homePage_VUSEPostLoginFooterLinksValidation() throws Exception
	{
		
		//PostLogin - StoreLocator footerlink
		String CurrentUrl = driver.getCurrentUrl();
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_StoreLocator));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_StoreLocator),MobilesitePageObjects.PostLoginVUSEfooterlnk_StoreLocator.getObjectname());
		String ActualPostLoginStoreLocatorTitle = driver.getTitle();
		String ExpectedPostLoginStoreLocatorTitle = "Retail Locator";
		commonFunction.compareStrings(ExpectedPostLoginStoreLocatorTitle, ActualPostLoginStoreLocatorTitle);
		driver.navigate().to(CurrentUrl);
		//PostLogin - ContactUs footer link
		//commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_ContactUs));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_ContactUs),MobilesitePageObjects.PostLoginVUSEfooterlnk_ContactUs.getObjectname());
		String ActualPostLoginContactUsTitle = driver.getTitle();
		String ExpectedPostLoginContactUsTitle = "Contact us";
		commonFunction.compareStrings(ExpectedPostLoginContactUsTitle, ActualPostLoginContactUsTitle);
		driver.navigate().to(CurrentUrl);
		//PostLogin - FAQs footerlink
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_FAQs));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_FAQs),MobilesitePageObjects.PostLoginVUSEfooterlnk_FAQs.getObjectname());
		commonFunction.SwitchControlToChildTab();
		String ActualPostLoginFAQsTitle = driver.getTitle();
		String ExpectedPostLoginFAQsTitle = "FAQs";
		commonFunction.compareStrings(ExpectedPostLoginFAQsTitle, ActualPostLoginFAQsTitle);
		driver.navigate().to(CurrentUrl);
		//PostLogin - Patents footer link
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_Patents));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_Patents),MobilesitePageObjects.PostLoginVUSEfooterlnk_Patents.getObjectname());
		String ActualPostLoginPatentsTitle = driver.getTitle();
		String ExpectedPostLoginPatentsTitle = "VUSE Patents";
		commonFunction.compareStrings(ExpectedPostLoginPatentsTitle, ActualPostLoginPatentsTitle );
		driver.navigate().to(CurrentUrl);
		//PostLogin - TobaccoRights
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_TobaccoRights));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_TobaccoRights),MobilesitePageObjects.PostLoginVUSEfooterlnk_TobaccoRights.getObjectname());
		String ActualPostLoginTobaccoRightsTitle = driver.getTitle();
		String ExpectedPostLoginTobaccoRightsTitle = "Own It Voice It";
		commonFunction.compareStrings(ExpectedPostLoginTobaccoRightsTitle, ActualPostLoginTobaccoRightsTitle );
		driver.navigate().to(CurrentUrl);
		//PostLogin - AgeFiltering
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_AgeFiltering));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_AgeFiltering),MobilesitePageObjects.PostLoginVUSEfooterlnk_AgeFiltering.getObjectname());
		String ActualPostLoginAgeFilteringTitle = driver.getTitle();
		String ExpectedPostLoginAgeFilteringTitle = "Age Filtering Software:";
		commonFunction.compareStrings(ExpectedPostLoginAgeFilteringTitle, ActualPostLoginAgeFilteringTitle );
		driver.navigate().to(CurrentUrl);
		//PostLogin - SiteMap
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_SiteMap));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_SiteMap),MobilesitePageObjects.PostLoginVUSEfooterlnk_SiteMap.getObjectname());
		String ActualPostLoginSiteMapTitle = driver.getTitle();
		String ExpectedPostLoginSiteMapTitle = "SiteMap";
		commonFunction.compareStrings(ExpectedPostLoginSiteMapTitle, ActualPostLoginSiteMapTitle );
		driver.navigate().to(CurrentUrl);
		//PostLogin - TermsOfUse
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_TermsOfUse));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_TermsOfUse),MobilesitePageObjects.PostLoginVUSEfooterlnk_TermsOfUse.getObjectname());
		String ActualPostLoginTermsOfUseTitle = driver.getTitle();
		String ExpectedPostLoginTermsOfUseTitle = "Terms of use";
		commonFunction.compareStrings(ExpectedPostLoginTermsOfUseTitle, ActualPostLoginTermsOfUseTitle );
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff), MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff_backtoTop), MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ChoiceOfLaw), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ChoiceOfLaw.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_ChoiceOfLaw_backtoTop), MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_ChoiceOfLaw_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous_backtoTop.getObjectname());
		driver.navigate().to(CurrentUrl);
		
		
		
		//PostLogin - TermsOfSale
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_TermsOfSale));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_TermsOfSale),MobilesitePageObjects.PostLoginVUSEfooterlnk_TermsOfSale.getObjectname());
		
		String ActualPostLoginTermsOfSaleTitle = driver.getTitle();
		String ExpectedPostLoginTermsOfSaleTitle = "Terms of Sale";
		commonFunction.compareStrings(ExpectedPostLoginTermsOfSaleTitle, ActualPostLoginTermsOfSaleTitle );
		driver.navigate().to(CurrentUrl);
		//PostLogin - SiteRequirements
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_SiteRequirements));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_SiteRequirements),MobilesitePageObjects.PostLoginVUSEfooterlnk_SiteRequirements.getObjectname());
		
		String ActualPostLoginSiteRequirementsTitle = driver.getTitle();
		String ExpectedPostLoginSiteRequirementsTitle = "Site Requirements";
		commonFunction.compareStrings(ExpectedPostLoginSiteRequirementsTitle, ActualPostLoginSiteRequirementsTitle );
		driver.navigate().to(CurrentUrl);
		
		
		//PostLogin - PrivacyPolicy
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy),MobilesitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy.getObjectname());
		String ActualPostLoginPrivacyPolicyTitle = driver.getTitle();
		String ExpectedPostLoginPrivacyPolicyTitle = "Privacy Policy";
		commonFunction.compareStrings(ExpectedPostLoginPrivacyPolicyTitle, ActualPostLoginPrivacyPolicyTitle );
		driver.navigate().to(CurrentUrl);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_Whatwecollect), MobilesitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_Whatwecollect.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_Whatwecollect_backtoTop), MobilesitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_Whatwecollect_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_LinktoWebsites), MobilesitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_LinktoWebsites.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_LinktoWebsites_backtoTop), MobilesitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_LinktoWebsites_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_CaliforniaRights), MobilesitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_CaliforniaRights.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_CaliforniaRights_backtoTop), MobilesitePageObjects.PostLoginVUSEfooterlnk_PrivacyPolicy_CaliforniaRights_backtoTop.getObjectname());
		
		
				
	}
	
	public void vuseHomePage_Logout() throws IOException
	{
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSE_MyAccount), MobilesitePageObjects.PostLoginVUSE_MyAccount.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVUSE_LogOut), MobilesitePageObjects.PostLoginVUSE_LogOut.getObjectname());
		
	}
		
	
}
