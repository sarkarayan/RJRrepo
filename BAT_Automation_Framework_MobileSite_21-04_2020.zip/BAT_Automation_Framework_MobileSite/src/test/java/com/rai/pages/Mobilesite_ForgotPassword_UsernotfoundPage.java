package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.MobileSiteLoginPageObjects;
import com.rai.pageObjects.MobilesitePageObjects;
import com.rai.pageObjects.MobilesitePageObjects;

public class Mobilesite_ForgotPassword_UsernotfoundPage extends BaseClass {

	String testcaseName;

	public Mobilesite_ForgotPassword_UsernotfoundPage(String testcaseName) {
		this.testcaseName = testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper The {@link ScriptHelper} object passed from the
	 *                     {@link DriverScript}
	 */

	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	private WebElement getPageElement(MobilesitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("ForgotPassword Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}

	public void invokeApplication_brandMobilesite() {
		System.out.println("Invoking application");
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

	}

	public void navigateToForgotPasswordPage() throws IOException {
		 commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btnSignInTab), MobilesitePageObjects.btnSignInTab.getObjectname());
		  commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.lnktxt_Forgotpassword),MobilesitePageObjects.lnktxt_Forgotpassword.getObjectname());
	}
	
	public void navigateToRevelVeloForgotPasswordPage() throws IOException 
	{
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.lnktxt_RevelVeloForgotPassword), MobilesitePageObjects.lnktxt_RevelVeloForgotPassword.getObjectname());
	}
	
	public void navigateToVUSEForgotPasswordPage() throws IOException 
	{
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.loginLnk_VUSECertifyAgePage), MobilesitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.lnk_VUSELoginForgotPassword), MobilesitePageObjects.lnk_VUSELoginForgotPassword.getObjectname());
	}

	public void forgotPassword_EnterValidUsername() throws IOException {
		String Email = dataTable.getData("General_Data", "Email");
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_ForgotPasswordUsername),Email, MobilesitePageObjects.txt_ForgotPasswordUsername.getObjectname());
		// Thread.sleep(2000);
		commonFunction.clickIfElementPresentJavaScript(getPageElement(MobilesitePageObjects.btn_ForgotPasswordUsernameContinue),MobilesitePageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
		// commonFunction.sendKeyENTER(getPageElement(MobilesitePageObjects.btn_ForgotPasswordUsernameContinue),MobilesitePageObjects.btn_ForgotPasswordUsernameContinue.getObjectname());
	}

	public void forgotPassword_ValidDataOnGeneralInformationPage() throws InterruptedException, IOException {
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data", "City");
		String State = dataTable.getData("General_Data", "State");
		String DOB = dataTable.getData("General_Data", "DOB");

		String date = DOB;
		String dateParts[] = date.split("/");
		String month = dateParts[0];
		String day = dateParts[1];
		String year = dateParts[2];

		commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.drpdwn_ForgotPasswordBirthMonth), month, MobilesitePageObjects.drpdwn_ForgotPasswordBirthMonth.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobilesitePageObjects.drpdwn_ForgotPasswordBirthDay), day, MobilesitePageObjects.drpdwn_ForgotPasswordBirthDay.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobilesitePageObjects.drpdwn_ForgotPasswordBirthYear), year,MobilesitePageObjects.drpdwn_ForgotPasswordBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobilesitePageObjects.txt_ForgotPasswordFirstName), FirstName,MobilesitePageObjects.txt_ForgotPasswordFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobilesitePageObjects.txt_ForgotPasswordLastName), LastName,MobilesitePageObjects.txt_ForgotPasswordLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobilesitePageObjects.txt_ForgotPasswordAddress), Address,MobilesitePageObjects.txt_ForgotPasswordAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_ForgotPasswordZipcode),Zipcode, MobilesitePageObjects.txt_ForgotPasswordZipcode.getObjectname());
		//Thread.sleep(2000);
		if (getPageElement(MobilesitePageObjects.txt_ForgotPasswordCity).getText().contains("")) {
			commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_ForgotPasswordCity), City,MobilesitePageObjects.txt_ForgotPasswordCity.getObjectname());
			commonFunction.selectAnyElementByValue(getPageElement(MobilesitePageObjects.drpdwn_ForgotPasswordState),State, MobilesitePageObjects.drpdwn_ForgotPasswordState.getObjectname());
		}
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_ForgotPasswordGeneralInformation),MobilesitePageObjects.btn_ForgotPasswordGeneralInformation.getObjectname());

	}

	public void forgotPassword_InvalidAnsweronVerifyIdentity() throws InterruptedException, IOException
	{
		String InvalidChallengeAnswer = dataTable.getData("General_Data", "InvalidChallengeAnswer");
		String Errormessage_ForgotPasswordIncorrectChallengeAnswer = "The answer does not match our records. Please re-enter your answer to the challenge question";

		// User entered Incorrect ChallengeAnswer on VerifyIdentity page - 1st time
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_ForgotPasswordChallengeAnswer), InvalidChallengeAnswer,MobilesitePageObjects.txt_ForgotPasswordChallengeAnswer.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_ForgotPasswordVerifyIdentity),MobilesitePageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(MobilesitePageObjects.errormsg_ForgotPasswordInvalidChallengeAnswer),MobilesitePageObjects.errormsg_ForgotPasswordInvalidChallengeAnswer.getObjectname(),Errormessage_ForgotPasswordIncorrectChallengeAnswer);

		// User entered Incorrect ChallengeAnswer on VerifyIdentity page - 2nd time

		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_ForgotPasswordVerifyIdentity),MobilesitePageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(MobilesitePageObjects.errormsg_ForgotPasswordInvalidChallengeAnswer),MobilesitePageObjects.errormsg_ForgotPasswordInvalidChallengeAnswer.getObjectname(),Errormessage_ForgotPasswordIncorrectChallengeAnswer);
		Thread.sleep(3000);
		// User entered Incorrect ChallengeAnswer on VerifyIdentity page - 3rd time
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_ForgotPasswordVerifyIdentity),MobilesitePageObjects.btn_ForgotPasswordVerifyIdentity.getObjectname());
	}

	
	public void forgotPassword_UsernotfoundPage() throws Exception
	{
		
		commonFunction.verifyIfElementIsPresent(getPageElement(MobilesitePageObjects.forgotPassword_UsernotfoundPage), MobilesitePageObjects.forgotPassword_UsernotfoundPage.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.forgotPassword_UsernotfoundPage_gotoRegistration), MobilesitePageObjects.forgotPassword_UsernotfoundPage_gotoRegistration.getObjectname());
	}
}
