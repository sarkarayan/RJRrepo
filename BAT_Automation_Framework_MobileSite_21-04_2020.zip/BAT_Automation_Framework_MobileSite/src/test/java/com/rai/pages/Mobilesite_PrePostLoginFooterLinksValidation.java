package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.MobileSiteLoginPageObjects;
import com.rai.pageObjects.MobileSite_MyprofilePageObjects;

public class Mobilesite_PrePostLoginFooterLinksValidation extends BaseClass {

	String testcaseName;
	public Mobilesite_PrePostLoginFooterLinksValidation(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(MobileSite_MyprofilePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("FooterLinks Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	private WebElement getPageElement(MobileSiteLoginPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("FooterLinks Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	
	public void invokeApplication_brandMobilesite()
	{
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
	
	public void loginPage_CamelPreLoginFooterLinksValidation() throws Exception
	{ 
		//PreLogin - FAQs footerlink
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btnSignInTab),MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
		String currenturl = driver.getCurrentUrl();
		Thread.sleep(3000);
		//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.PreLoginfooterlnk_FAQs));		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PreLoginfooterlnk_FAQs),MobileSite_MyprofilePageObjects.PreLoginfooterlnk_FAQs.getObjectname());
		Thread.sleep(7000);
		String ActualFAQsTitle = driver.getTitle();
		String ExpectedFAQsTitle = "Frequently Asked Questions";
		commonFunction.compareStringsContains(ExpectedFAQsTitle, ActualFAQsTitle);
		driver.navigate().to(currenturl);
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btnSignInTab),MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btn_Login),MobileSiteLoginPageObjects.btn_Login.getObjectname());
		Thread.sleep(3000);
		//PreLogin - ContactUs
		//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.PreLoginfooterlnk_ContactUs));		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PreLoginfooterlnk_ContactUs),MobileSite_MyprofilePageObjects.PreLoginfooterlnk_ContactUs.getObjectname());
		Thread.sleep(3000);
		String ActualContactUsTitle = driver.getTitle();
		String ExpectedContactUsTitle = "Contact us";
		commonFunction.compareStringsContains(ExpectedContactUsTitle, ActualContactUsTitle);
		driver.navigate().to(currenturl);
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btnSignInTab),MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btn_Login),MobileSiteLoginPageObjects.btn_Login.getObjectname());
		Thread.sleep(3000);
		//PreLogin - TobaccoRights
		//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.PreLoginfooterlnk_TobaccoRights));		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PreLoginfooterlnk_TobaccoRights),MobileSite_MyprofilePageObjects.PreLoginfooterlnk_TobaccoRights.getObjectname());
		Thread.sleep(3000);
		String ActualTobaccoRightsTitle = driver.getTitle();
		String ExpectedTobaccoRightsTitle = "Own It Voice It - Make Your Voice Heard";
		commonFunction.compareStringsContains(ExpectedTobaccoRightsTitle, ActualTobaccoRightsTitle);
		driver.navigate().to(currenturl);
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btnSignInTab),MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btn_Login),MobileSiteLoginPageObjects.btn_Login.getObjectname());
		Thread.sleep(3000);
		//PreLogin - SiteRequirements
		//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.PreLoginfooterlnk_SiteRequrmnts));		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PreLoginfooterlnk_SiteRequrmnts),MobileSite_MyprofilePageObjects.PreLoginfooterlnk_SiteRequrmnts.getObjectname());
		Thread.sleep(3000);
		String ActualSiteRequrmntsTitle = driver.getTitle();
		String ExpectedSiteRequrmntsTitle = "Site Requirements";
		commonFunction.compareStringsContains(ExpectedSiteRequrmntsTitle, ActualSiteRequrmntsTitle);
		driver.navigate().to(currenturl);
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btnSignInTab),MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btn_Login),MobileSiteLoginPageObjects.btn_Login.getObjectname());
		Thread.sleep(3000);
		//PreLogin - AgeFiltering
		//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.PreLoginfooterlnk_AgeFiltering));		
		//commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PreLoginfooterlnk_AgeFiltering),MobileSite_MyprofilePageObjects.PreLoginfooterlnk_AgeFiltering.getObjectname());
		//Thread.sleep(3000);
		//String ActualAgeFilteringTitle = driver.getTitle();
		//String ExpectedAgeFilteringTitle = "Age Filtering Software:";
		//commonFunction.compareStringsContains(ExpectedAgeFilteringTitle, ActualAgeFilteringTitle);
		//driver.navigate().to(currenturl);
		//commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btnSignInTab),MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
		//commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btn_Login),MobileSiteLoginPageObjects.btn_Login.getObjectname());
		
		//PreLogin - TermsOfUse
		//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.PreLoginfooterlnk_TermsOfUse));		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PreLoginfooterlnk_TermsOfUse),MobileSite_MyprofilePageObjects.PreLoginfooterlnk_TermsOfUse.getObjectname());
		Thread.sleep(4000);
		String ActualTermsofUseTitle = driver.getTitle();
		String ExpectedTermsofUseTitle = "Terms of use";
		commonFunction.compareStringsContains(ExpectedTermsofUseTitle, ActualTermsofUseTitle );
		driver.navigate().to(currenturl);
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btnSignInTab),MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btn_Login),MobileSiteLoginPageObjects.btn_Login.getObjectname());
		Thread.sleep(3000);
		//PreLogin - PrivacyPolicy
		//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.PreLoginfooterlnk_PrivacyPolicy));		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PreLoginfooterlnk_PrivacyPolicy),MobileSite_MyprofilePageObjects.PreLoginfooterlnk_PrivacyPolicy.getObjectname());
		//commonFunction.SwitchControlToChildTab();
		Thread.sleep(5000);
		String ActualPrivacyPolicyTitle = driver.getTitle();
		String ExpectedPrivacyPolicyTitle = "Privacy Policy and Your California Privacy Rights";
		commonFunction.compareStringsContains(ExpectedPrivacyPolicyTitle, ActualPrivacyPolicyTitle );
		driver.navigate().to(currenturl);
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btnSignInTab),MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btn_Login),MobileSiteLoginPageObjects.btn_Login.getObjectname());
	}
	
	
	public void loginPage_AppToWebsiteLogin() throws InterruptedException, IOException
	{
		
		String Username = dataTable.getData("General_Data", "Username");
		String Password = dataTable.getData("General_Data", "Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteLoginPageObjects.txt_LoginUsername),Username,MobileSiteLoginPageObjects.txt_LoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteLoginPageObjects.txt_LoginPassword),Password, MobileSiteLoginPageObjects.txt_LoginPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btn_Login), MobileSiteLoginPageObjects.btn_Login.getObjectname());
		Thread.sleep(6000);
	}
	
	
	public void homePage_CamelPostLoginFooterLinksValidation() throws Exception
	{
		
		//PostLogin - FAQs footerlink
		Thread.sleep(6000);
		String Postcurrenturl = driver.getCurrentUrl();
		//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.PostLoginfooterlnk_FAQs));		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginfooterlnk_FAQs),MobileSite_MyprofilePageObjects.PostLoginfooterlnk_FAQs.getObjectname());
		//commonFunction.SwitchControlToChildTab();
		Thread.sleep(7000);
		String ActualPostLoginFAQsTitle = driver.getTitle();
		String ExpectedPostLoginFAQsTitle = "Frequently Asked Questions";
		commonFunction.compareStringsContains(ExpectedPostLoginFAQsTitle, ActualPostLoginFAQsTitle );
		//Thread.sleep(5000);
		driver.navigate().to(Postcurrenturl);
	
		
		//PostLogin - ContactUs footer link
		//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.PostLoginfooterlnk_ContactUs));		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginfooterlnk_ContactUs),MobileSite_MyprofilePageObjects.PostLoginfooterlnk_ContactUs.getObjectname());
		Thread.sleep(5000);
		String ActualPostLoginContactUsTitle = driver.getTitle();
		String ExpectedPostLoginContactUsTitle = "Contact us";
		commonFunction.compareStringsContains(ExpectedPostLoginContactUsTitle, ActualPostLoginContactUsTitle);
		//Thread.sleep(5000);
		//commonFunction.selectAnyElement(getPageElement(MobileSite_MyprofilePageObjects.PostLoginfooterlnk_ContactUsQuestion),2 ,MobileSite_MyprofilePageObjects.PostLoginfooterlnk_ContactUsQuestion.getObjectname());
		//commonFunction.clearAndEnterText(getPageElement(MobileSite_MyprofilePageObjects.PostLoginfooterlnk_ContactUsAnswer),"Validate",MobileSite_MyprofilePageObjects.PostLoginfooterlnk_ContactUsAnswer.getObjectname());
		//commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginfooterlnk_ContactUsSubmit),MobileSite_MyprofilePageObjects.PostLoginfooterlnk_ContactUsSubmit.getObjectname());
		driver.navigate().to(Postcurrenturl);
		//PostLogin - TobaccoRights
		//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.PostLoginfooterlnk_TobaccoRights));		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginfooterlnk_TobaccoRights),MobileSite_MyprofilePageObjects.PostLoginfooterlnk_TobaccoRights.getObjectname());
		Thread.sleep(5000);
		String ActualPostLoginTobaccoRightsTitle = driver.getTitle();
		String ExpectedPostLoginTobaccoRightsTitle = "Own It Voice It - Make Your Voice Heard";
		commonFunction.compareStringsContains(ExpectedPostLoginTobaccoRightsTitle, ActualPostLoginTobaccoRightsTitle);
		driver.navigate().to(Postcurrenturl);
		//PostLogin - SiteRequirements
		//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.PostLoginfooterlnk_SiteRequirements));		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginfooterlnk_SiteRequirements),MobileSite_MyprofilePageObjects.PostLoginfooterlnk_SiteRequirements.getObjectname());
		Thread.sleep(5000);
		String ActualPostLoginSiteRequirementsTitle = driver.getTitle();
		String ExpectedPostLoginSiteRequirementsTitle = "Site Requirements";
		commonFunction.compareStringsContains(ExpectedPostLoginSiteRequirementsTitle, ActualPostLoginSiteRequirementsTitle);
		driver.navigate().to(Postcurrenturl);
		//PostLogin - AgeFiltering
		//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.PostLoginfooterlnk_AgeFiltering));		
		//commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginfooterlnk_AgeFiltering),MobileSite_MyprofilePageObjects.PostLoginfooterlnk_AgeFiltering.getObjectname());
		//Thread.sleep(5000);
		//String ActualPostLoginAgeFilteringTitle = driver.getTitle();
		//String ExpectedPostLoginAgeFilteringTitle = "Age Filtering Software:";
		//commonFunction.compareStringsContains(ExpectedPostLoginAgeFilteringTitle, ActualPostLoginAgeFilteringTitle );
		//driver.navigate().to(Postcurrenturl);
		//Thread.sleep(5000);
		
		//PostLogin - TermsOfUse
		//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.PostLoginfooterlnk_TermsOfUse));		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginfooterlnk_TermsOfUse),MobileSite_MyprofilePageObjects.PostLoginfooterlnk_TermsOfUse.getObjectname());
		Thread.sleep(7000);
		String ActualPostLoginTermsOfUseTitle = driver.getTitle();
		String ExpectedPostLoginTermsOfUseTitle = "Terms of use";
		commonFunction.compareStringsContains(ExpectedPostLoginTermsOfUseTitle, ActualPostLoginTermsOfUseTitle );
		driver.navigate().to(Postcurrenturl);
		//Thread.sleep(5000);
		
		
		//PostLogin - PrivacyPolicy
		//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.PostLoginfooterlnk_PrivacyPolicy));		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginfooterlnk_PrivacyPolicy),MobileSite_MyprofilePageObjects.PostLoginfooterlnk_PrivacyPolicy.getObjectname());
		Thread.sleep(5000);
		String ActualPostLoginPrivacyPolicyTitle = driver.getTitle();
		String ExpectedPostLoginPrivacyPolicyTitle = "Privacy Policy and Your California Privacy Rights";
		commonFunction.compareStringsContains(ExpectedPostLoginPrivacyPolicyTitle, ActualPostLoginPrivacyPolicyTitle );
		driver.navigate().to(Postcurrenturl);
		
		
	}
	
	public void homePage_pallmallPostLoginFooterLinksValidation() throws Exception
	{
		Thread.sleep(5000);
		//PostLogin - FAQs footerlink
		String Postcurrenturl = driver.getCurrentUrl();
		//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.PostLoginPallmallfooterlnk_FAQs));		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginPallmallfooterlnk_FAQs),MobileSite_MyprofilePageObjects.PostLoginPallmallfooterlnk_FAQs.getObjectname());
		//commonFunction.SwitchControlToChildTab();
		Thread.sleep(6000);
		String ActualPostLoginFAQsTitle = driver.getTitle();
		String ExpectedPostLoginFAQsTitle = "Frequently Asked Questions";
		commonFunction.compareStringsContains(ExpectedPostLoginFAQsTitle, ActualPostLoginFAQsTitle );
		//Thread.sleep(5000);
		driver.navigate().to(Postcurrenturl);
	
		
		//PostLogin - ContactUs footer link
		//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.PostLoginfooterlnk_ContactUs));		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginPallmallfooterlnk_ContactUs),MobileSite_MyprofilePageObjects.PostLoginPallmallfooterlnk_ContactUs.getObjectname());
		Thread.sleep(4000);
		String ActualPostLoginContactUsTitle = driver.getTitle();
		String ExpectedPostLoginContactUsTitle = "Contact us";
		commonFunction.compareStringsContains(ExpectedPostLoginContactUsTitle, ActualPostLoginContactUsTitle);
		//Thread.sleep(5000);
		commonFunction.selectAnyElement(getPageElement(MobileSite_MyprofilePageObjects.PostLoginfooterlnk_ContactUsQuestion),2 ,MobileSite_MyprofilePageObjects.PostLoginfooterlnk_ContactUsQuestion.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSite_MyprofilePageObjects.PostLoginfooterlnk_ContactUsAnswer),"Validate",MobileSite_MyprofilePageObjects.PostLoginfooterlnk_ContactUsAnswer.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginfooterlnk_ContactUsSubmit),MobileSite_MyprofilePageObjects.PostLoginfooterlnk_ContactUsSubmit.getObjectname());
		driver.navigate().to(Postcurrenturl);
		//PostLogin - TobaccoRights
		//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.PostLoginPallmallfooterlnk_TobaccoRights));		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginPallmallfooterlnk_TobaccoRights),MobileSite_MyprofilePageObjects.PostLoginPallmallfooterlnk_TobaccoRights.getObjectname());
		Thread.sleep(4000);
		String ActualPostLoginTobaccoRightsTitle = driver.getTitle();
		String ExpectedPostLoginTobaccoRightsTitle = "Own It Voice It - Make Your Voice Heard";
		commonFunction.compareStringsContains(ExpectedPostLoginTobaccoRightsTitle, ActualPostLoginTobaccoRightsTitle);
		driver.navigate().to(Postcurrenturl);
		//PostLogin - SiteRequirements
		//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.PostLoginPallmallfooterlnk_SiteRequirements));		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginPallmallfooterlnk_SiteRequirements),MobileSite_MyprofilePageObjects.PostLoginPallmallfooterlnk_SiteRequirements.getObjectname());
		Thread.sleep(4000);
		String ActualPostLoginSiteRequirementsTitle = driver.getTitle();
		String ExpectedPostLoginSiteRequirementsTitle = "Site Requirements";
		commonFunction.compareStringsContains(ExpectedPostLoginSiteRequirementsTitle, ActualPostLoginSiteRequirementsTitle);
		driver.navigate().to(Postcurrenturl);
		//PostLogin - AgeFiltering
		//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.PostLoginPallmallfooterlnk_AgeFiltering));		
		//commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginPallmallfooterlnk_AgeFiltering),MobileSite_MyprofilePageObjects.PostLoginPallmallfooterlnk_AgeFiltering.getObjectname());
		//String ActualPostLoginAgeFilteringTitle = driver.getTitle();
		//String ExpectedPostLoginAgeFilteringTitle = "Age Filtering Software:";
		//commonFunction.compareStringsContains(ExpectedPostLoginAgeFilteringTitle, ActualPostLoginAgeFilteringTitle );
		//driver.navigate().to(Postcurrenturl);
		//Thread.sleep(5000);
		
		//PostLogin - TermsOfUse
		//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.PostLoginPallmallfooterlnk_TermsOfUse));		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginPallmallfooterlnk_TermsOfUse),MobileSite_MyprofilePageObjects.PostLoginPallmallfooterlnk_TermsOfUse.getObjectname());
		Thread.sleep(4000);
		String ActualPostLoginTermsOfUseTitle = driver.getTitle();
		String ExpectedPostLoginTermsOfUseTitle = "Terms of use";
		commonFunction.compareStringsContains(ExpectedPostLoginTermsOfUseTitle, ActualPostLoginTermsOfUseTitle );
		driver.navigate().to(Postcurrenturl);
		//Thread.sleep(5000);
		//PostLogin - PrivacyPolicy
		//commonFunction.scrollIntoView(getPageElement(MobileSite_MyprofilePageObjects.PostLoginPallmallfooterlnk_PrivacyPolicy));		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginPallmallfooterlnk_PrivacyPolicy),MobileSite_MyprofilePageObjects.PostLoginPallmallfooterlnk_PrivacyPolicy.getObjectname());
		Thread.sleep(4000);
		String ActualPostLoginPrivacyPolicyTitle = driver.getTitle();
		String ExpectedPostLoginPrivacyPolicyTitle = "Privacy Policy and Your California Privacy Rights";
		commonFunction.compareStringsContains(ExpectedPostLoginPrivacyPolicyTitle, ActualPostLoginPrivacyPolicyTitle );
		driver.navigate().to(Postcurrenturl);
		
		
	}
	
	public void camelHomePage_Logout() throws IOException
	{
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSite_MyprofilePageObjects.PostLoginCamelfooterlnk_Logout), MobileSite_MyprofilePageObjects.PostLoginCamelfooterlnk_Logout.getObjectname());
		
	}
		
	
}
