package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.MobilesitePageObjects;
import com.rai.pageObjects.MobilesitePageObjects;

public class Mobilesite_VeloPrePostLoginFooterLinksValidation extends BaseClass {

	String testcaseName;
	public Mobilesite_VeloPrePostLoginFooterLinksValidation(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(MobilesitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("FooterLinks Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	public void invokeApplication_brandwebsite()
	{
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
	
	public void loginPage_VeloPreLoginFooterLinksValidation() throws Exception
	{ 
		//PreLogin - FAQs footerlink
		String CurrentUrl= driver.getCurrentUrl();
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginVelofooterlnk_FAQs));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginVelofooterlnk_FAQs),MobilesitePageObjects.PreLoginVelofooterlnk_FAQs.getObjectname());
		String ActualFAQsTitle = driver.getTitle();
		String ExpectedFAQsTitle = "Frequently Asked Questions";
		commonFunction.compareStrings(ExpectedFAQsTitle, ActualFAQsTitle);
		//Thread.sleep(5000);
		driver.navigate().to(CurrentUrl);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
	
		//PreLogin - ContactUs
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginVelofooterlnk_ContactUs));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginVelofooterlnk_ContactUs),MobilesitePageObjects.PreLoginVelofooterlnk_ContactUs.getObjectname());
		
		String ActualContactUsTitle = driver.getTitle();
		String ExpectedContactUsTitle = "Contact Us";
		commonFunction.compareStrings(ExpectedContactUsTitle, ActualContactUsTitle);
		//Thread.sleep(5000);
		driver.navigate().to(CurrentUrl);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - TobaccoRights
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginVelofooterlnk_TobaccoRights));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginVelofooterlnk_TobaccoRights),MobilesitePageObjects.PreLoginVelofooterlnk_TobaccoRights.getObjectname());
		
		String ActualTobaccoRightsTitle = driver.getTitle();
		String ExpectedTobaccoRightsTitle = "Own It Voice It";
		commonFunction.compareStrings(ExpectedTobaccoRightsTitle, ActualTobaccoRightsTitle);
		driver.navigate().to(CurrentUrl);
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - SiteRequirements
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginVelofooterlnk_SiteRequirements));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginVelofooterlnk_SiteRequirements),MobilesitePageObjects.PreLoginVelofooterlnk_SiteRequirements.getObjectname());
		
		String ActualSiteRequrmntsTitle = driver.getTitle();
		String ExpectedSiteRequrmntsTitle = "Site Requirements";
		commonFunction.compareStrings(ExpectedSiteRequrmntsTitle, ActualSiteRequrmntsTitle);
		driver.navigate().to(CurrentUrl);
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - AgeFiltering
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginVelofooterlnk_AgeFiltering));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginVelofooterlnk_AgeFiltering),MobilesitePageObjects.PreLoginVelofooterlnk_AgeFiltering.getObjectname());
		
		String ActualAgeFilteringTitle = driver.getTitle();
		String ExpectedAgeFilteringTitle = "Age Filtering Software:";
		commonFunction.compareStrings(ExpectedAgeFilteringTitle, ActualAgeFilteringTitle);
		//Thread.sleep(5000);
		driver.navigate().to(CurrentUrl);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - TermsOfUse
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginVelofooterlnk_TermsOfUse));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginVelofooterlnk_TermsOfUse),MobilesitePageObjects.PreLoginVelofooterlnk_TermsOfUse.getObjectname());
		
		String ActualTermsofUseTitle = driver.getTitle();
		String ExpectedTermsofUseTitle = "Terms of use";
		commonFunction.compareStrings(ExpectedTermsofUseTitle, ActualTermsofUseTitle);
	
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff), MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff_backtoTop), MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ChoiceOfLaw), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ChoiceOfLaw.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_ChoiceOfLaw_backtoTop), MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_ChoiceOfLaw_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous_backtoTop.getObjectname());
		
		driver.navigate().to(CurrentUrl);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
		
		//PreLogin - PrivacyPolicy
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PreLoginVelofooterlnk_PrivacyPolicy));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginVelofooterlnk_PrivacyPolicy),MobilesitePageObjects.PreLoginVelofooterlnk_PrivacyPolicy.getObjectname());
		
		String ActualPrivacyPolicyTitle = driver.getTitle();
		String ExpectedPrivacyPolicyTitle = "Privacy Policy and Your California Privacy Rights";
		commonFunction.compareStrings(ExpectedPrivacyPolicyTitle, ActualPrivacyPolicyTitle);
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_WhatwecollectandHow), MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_WhatwecollectandHow.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_WhatwecollectandHow_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_WhatwecollectandHow_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_LinktoWebsites), MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_LinktoWebsites.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_LinktoWebsites_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_LinktoWebsites_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_CaliforniaCCPARights), MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_CaliforniaCCPARights.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_CaliforniaCCPARights_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_CaliforniaCCPARights_backtoTop.getObjectname());
		
		driver.navigate().to(CurrentUrl);
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
		
	}
	
	
	public void loginPage_AppToWebsiteLogin() throws InterruptedException, IOException
	{
		
		String Username = dataTable.getData("General_Data", "Username");
		String Password = dataTable.getData("General_Data", "Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_LoginUsername),Username,MobilesitePageObjects.txt_LoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_LoginPassword),Password, MobilesitePageObjects.txt_LoginPassword.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login), MobilesitePageObjects.btn_Login.getObjectname());
		Thread.sleep(5000);
	}
	
	
	public void homePage_VeloPostLoginFooterLinksValidation() throws Exception
	{
		
		//PostLogin - FAQs footerlink
		String CurrentUrl= driver.getCurrentUrl();
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVelofooterlnk_FAQs));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVelofooterlnk_FAQs),MobilesitePageObjects.PostLoginVelofooterlnk_FAQs.getObjectname());
		
		String ActualPostLoginFAQsTitle = driver.getTitle();
		String ExpectedPostLoginFAQsTitle = "Frequently Asked Questions";
		commonFunction.compareStrings(ExpectedPostLoginFAQsTitle, ActualPostLoginFAQsTitle);
		//Thread.sleep(5000);
		driver.navigate().to(CurrentUrl);
	
		
		//PostLogin - ContactUs footer link
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVelofooterlnk_ContactUs));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVelofooterlnk_ContactUs),MobilesitePageObjects.PostLoginVelofooterlnk_ContactUs.getObjectname());
		
		String ActualPostLoginContactUsTitle = driver.getTitle();
		String ExpectedPostLoginContactUsTitle = "Contact us";
		commonFunction.compareStrings(ExpectedPostLoginContactUsTitle, ActualPostLoginContactUsTitle);
		//Thread.sleep(5000);
		commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_ContactUsQuestion),2 ,MobilesitePageObjects.PostLoginfooterlnk_ContactUsQuestion.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_ContactUsAnswer),"Validate",MobilesitePageObjects.PostLoginfooterlnk_ContactUsAnswer.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginfooterlnk_ContactUsSubmit),MobilesitePageObjects.PostLoginfooterlnk_ContactUsSubmit.getObjectname());
		driver.navigate().to(CurrentUrl);
		
		
		//PostLogin - TobaccoRights
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVelofooterlnk_TobaccoRights));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVelofooterlnk_TobaccoRights),MobilesitePageObjects.PostLoginVelofooterlnk_TobaccoRights.getObjectname());
		
		String ActualPostLoginTobaccoRightsTitle = driver.getTitle();
		String ExpectedPostLoginTobaccoRightsTitle = "Own It Voice It";
		commonFunction.compareStrings(ExpectedPostLoginTobaccoRightsTitle, ActualPostLoginTobaccoRightsTitle);
		//Thread.sleep(5000);
		driver.navigate().to(CurrentUrl);
		
		
		//PostLogin - SiteRequirements
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVelofooterlnk_SiteRequirements));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVelofooterlnk_SiteRequirements),MobilesitePageObjects.PostLoginVelofooterlnk_SiteRequirements.getObjectname());
		String ActualPostLoginSiteRequirementsTitle = driver.getTitle();
		String ExpectedPostLoginSiteRequirementsTitle = "Site Requirements";
		commonFunction.compareStrings(ExpectedPostLoginSiteRequirementsTitle, ActualPostLoginSiteRequirementsTitle);
		//Thread.sleep(5000);
		driver.navigate().to(CurrentUrl);
		
		//PostLogin - AgeFiltering
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVelofooterlnk_AgeFiltering));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVelofooterlnk_AgeFiltering),MobilesitePageObjects.PostLoginVelofooterlnk_AgeFiltering.getObjectname());
		
		String ActualPostLoginAgeFilteringTitle = driver.getTitle();
		String ExpectedPostLoginAgeFilteringTitle = "Age Filtering Software:";
		commonFunction.compareStrings(ExpectedPostLoginAgeFilteringTitle, ActualPostLoginAgeFilteringTitle );
		//Thread.sleep(5000);
		driver.navigate().to(CurrentUrl);
		
		//PostLogin - TermsOfUse
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVelofooterlnk_TermsOfUse));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVelofooterlnk_TermsOfUse),MobilesitePageObjects.PostLoginVelofooterlnk_TermsOfUse.getObjectname());
		
		String ActualPostLoginTermsOfUseTitle = driver.getTitle();
		String ExpectedPostLoginTermsOfUseTitle = "Terms of use";
		commonFunction.compareStrings(ExpectedPostLoginTermsOfUseTitle, ActualPostLoginTermsOfUseTitle);
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Restrictions_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff), MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff_backtoTop), MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_YourStuff_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ChoiceOfLaw), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ChoiceOfLaw.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_ChoiceOfLaw_backtoTop), MobilesitePageObjects.Preloginfooterlnk_TermsOfUse_ChoiceOfLaw_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_ResolvingDisputes_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_TermsOfUse_Miscellaneous_backtoTop.getObjectname());
		
		driver.navigate().to(CurrentUrl);
		
		//PostLogin - PrivacyPolicy
		commonFunction.scrollIntoView(getPageElement(MobilesitePageObjects.PostLoginVelofooterlnk_PrivacyPolicy));		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVelofooterlnk_PrivacyPolicy),MobilesitePageObjects.PostLoginVelofooterlnk_PrivacyPolicy.getObjectname());
		
		String ActualPostLoginPrivacyPolicyTitle = driver.getTitle();
		String ExpectedPostLoginPrivacyPolicyTitle = "Privacy Policy";
		commonFunction.compareStrings(ExpectedPostLoginPrivacyPolicyTitle, ActualPostLoginPrivacyPolicyTitle);
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_WhatwecollectandHow), MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_WhatwecollectandHow.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_WhatwecollectandHow_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_WhatwecollectandHow_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_LinktoWebsites), MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_LinktoWebsites.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_LinktoWebsites_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_LinktoWebsites_backtoTop.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_CaliforniaCCPARights), MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_CaliforniaCCPARights.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_CaliforniaCCPARights_backtoTop), MobilesitePageObjects.PreLoginfooterlnk_PrivacyPolicy_CaliforniaCCPARights_backtoTop.getObjectname());
		
		driver.navigate().to(CurrentUrl);
				
	}
	
	public void veloHomePage_Logout() throws IOException
	{
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVelo_AccountMenu), MobilesitePageObjects.PostLoginVelo_AccountMenu.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.PostLoginVelo_LogOut), MobilesitePageObjects.PostLoginVelo_LogOut.getObjectname());
		
	}
		
	
}
