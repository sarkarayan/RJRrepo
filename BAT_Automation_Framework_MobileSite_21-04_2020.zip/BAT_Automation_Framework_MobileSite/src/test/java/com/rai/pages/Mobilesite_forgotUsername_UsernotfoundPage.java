package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.MobilesitePageObjects;


public class Mobilesite_forgotUsername_UsernotfoundPage extends BaseClass {

	String testcaseName;
	public Mobilesite_forgotUsername_UsernotfoundPage(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(MobilesitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("ForgotUsername Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	public void invokeApplication_brandMobilesite()
	{
		String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);	
		
		
	}
	public void navigateToForgotUsernamePage() throws IOException {
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btnSignInTab), MobilesitePageObjects.btnSignInTab.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.lnktxt_Forgetusername), MobilesitePageObjects.lnktxt_Forgetusername.getObjectname());
	}
	
	public void navigateToRevelVeloForgotUsernamePage() throws IOException {
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.lnktxt_RevelVeloForgotUsername), MobilesitePageObjects.lnktxt_RevelVeloForgotUsername.getObjectname());	
	}
	
    public void navigateToVUSEForgotUsernamePage() throws IOException
    {
    	commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.loginLnk_VUSECertifyAgePage), MobilesitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.lnk_VUSELoginForgotUsername), MobilesitePageObjects.lnk_VUSELoginForgotUsername.getObjectname());	
	}
	
	public void forgotUsername_InvalidUserInfoonAccountInformationPage() throws InterruptedException, IOException
	{
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String DOB = dataTable.getData("General_Data","DOB");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
		
		//UserInformation not found - valid data but Invalid UserInfo - click Continue for the 1st time
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
		
		String Errormessage_UserInfonotfound = "We were not able to find your information. Please check and try again.";
	
		commonFunction.selectAnyElement(getPageElement(MobilesitePageObjects.drpdwn_ForgotUsernameBirthMonth), month, MobilesitePageObjects.drpdwn_ForgotUsernameBirthMonth.getObjectname());
		Thread.sleep(2000);
		commonFunction.selectAnyElementByValue(getPageElement(MobilesitePageObjects.drpdwn_ForgotUsernameBirthDay),day,MobilesitePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobilesitePageObjects.drpdwn_ForgotUsernameBirthYear),year, MobilesitePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobilesitePageObjects.txt_ForgotUsernameFirstName), FirstName, MobilesitePageObjects.txt_ForgotUsernameFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobilesitePageObjects.txt_ForgotUsernameLastName), LastName, MobilesitePageObjects.txt_ForgotUsernameLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobilesitePageObjects.txt_ForgotUsernameAddress), Address, MobilesitePageObjects.txt_ForgotUsernameAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_ForgotUsernameZipcode), Zipcode,MobilesitePageObjects.txt_ForgotUsernameZipcode.getObjectname());
		Thread.sleep(3000);
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_ForgotUsernameCity), City, MobilesitePageObjects.txt_ForgotUsernameCity.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobilesitePageObjects.drpdwn_ForgotUsernameState),State, MobilesitePageObjects.drpdwn_ForgotUsernameState.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_ForgotUsernameAccountInformation),MobilesitePageObjects.btn_ForgotUsernameAccountInformation.getObjectname());
		
		commonFunction.isElementPresentContainsText(getPageElement(MobilesitePageObjects.errormsg_ForgotUsernameUsernotfound), MobilesitePageObjects.errormsg_ForgotUsernameUsernotfound.getObjectname(), Errormessage_UserInfonotfound);
		
		
		//UserInformation not found - valid data but invalid UserInfo - Click Continue for the 2nd time
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_ForgotUsernameAccountInformation),MobilesitePageObjects.btn_ForgotUsernameAccountInformation.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(MobilesitePageObjects.errormsg_ForgotUsernameUsernotfound), MobilesitePageObjects.errormsg_ForgotUsernameUsernotfound.getObjectname(), Errormessage_UserInfonotfound);
		
		//UserInformation not found - valid data but Invalid UserInfo - Click Continue for the 3rd time
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_ForgotUsernameAccountInformation),MobilesitePageObjects.btn_ForgotUsernameAccountInformation.getObjectname());
	
	}
	
	
	
	public void forgotUsername_UsernotFoundPage() throws Exception
	{
		
		commonFunction.verifyIfElementIsPresent(getPageElement(MobilesitePageObjects.forgotUsername_usernotfoundPage), MobilesitePageObjects.forgotUsername_usernotfoundPage.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.gotoRegistration_UsernotfoundPage), MobilesitePageObjects.gotoRegistration_UsernotfoundPage.getObjectname());
						
	}
	
	

}

