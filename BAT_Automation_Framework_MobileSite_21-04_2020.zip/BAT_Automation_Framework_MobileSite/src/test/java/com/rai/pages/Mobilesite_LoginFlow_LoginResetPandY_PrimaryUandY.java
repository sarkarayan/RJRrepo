package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.MobileSiteForgotusernamePageObjects;
import com.rai.pageObjects.MobileSiteLoginPageObjects;
import com.rai.pageObjects.MobileSiteResetPageObjects;
import com.rai.pageObjects.MobilesitePageObjects;

public class Mobilesite_LoginFlow_LoginResetPandY_PrimaryUandY extends BaseClass {

	String testcaseName;
	public Mobilesite_LoginFlow_LoginResetPandY_PrimaryUandY(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(MobilesitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	private WebElement getPageElement(MobileSiteForgotusernamePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	private WebElement getPageElement(MobileSiteLoginPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	private WebElement getPageElement(MobileSiteResetPageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Registration Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	public void invokeApplication_brandMobilesite()
	{
		String WebsiteURL = dataTable.getData("General_Data","URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
	public void login_EnterValidDataPandY() throws IOException
	{
		
		String Email = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data","Password");
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btnSignInTab),MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteLoginPageObjects.txt_LoginUsername),Email,MobilesitePageObjects.txt_LoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteLoginPageObjects.txt_LoginPassword),Password,MobilesitePageObjects.txt_LoginPassword.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteLoginPageObjects.btn_Login),MobilesitePageObjects.btn_Login.getObjectname());
	}
	
		
	public void resetflow_GeneralInfoPageviaLogin() throws InterruptedException, IOException
	{
		String FirstName = dataTable.getData("General_Data", "FirstName");
		String LastName = dataTable.getData("General_Data", "LastName");
		String Address = dataTable.getData("General_Data", "Address");
		String Zipcode = dataTable.getData("General_Data", "Zipcode");
		String City = dataTable.getData("General_Data","City");
		String State = dataTable.getData("General_Data", "State");
		String DOB = dataTable.getData("General_Data","DOB");
		
		String date = DOB;
		String dateParts[] = date.split("/");
		String month  = dateParts[0];
		String day  = dateParts[1];
		String year = dateParts[2];
				
		commonFunction.selectAnyElement(getPageElement(MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameBirthMonth), month, MobilesitePageObjects.drpdwn_ForgotUsernameBirthMonth.getObjectname());
		Thread.sleep(5000);
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameBirthDay),day,MobilesitePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameBirthYear), year, MobilesitePageObjects.drpdwn_ForgotUsernameBirthYear.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameFirstName), FirstName, MobilesitePageObjects.txt_ForgotUsernameFirstName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameLastName), LastName, MobilesitePageObjects.txt_ForgotUsernameLastName.getObjectname());
		commonFunction.clearAndEnterText(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameAddress), Address, MobilesitePageObjects.txt_ForgotUsernameAddress.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameZipcode), Zipcode,MobilesitePageObjects.txt_ForgotUsernameZipcode.getObjectname());
		Thread.sleep(4000);
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteForgotusernamePageObjects.txt_ForgotUsernameCity), City, MobilesitePageObjects.txt_ForgotUsernameCity.getObjectname());
		commonFunction.selectAnyElementByValue(getPageElement(MobileSiteForgotusernamePageObjects.drpdwn_ForgotUsernameState),State, MobilesitePageObjects.drpdwn_ForgotUsernameState.getObjectname());
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.Continuebtn_LoginResetviaLoginonGeneralInfo),MobilesitePageObjects.Continuebtn_LoginResetviaLoginonGeneralInfo.getObjectname());
				
	}
	
	public void resetflow_NegativeValidationsAccountInfoPage() throws IOException, InterruptedException
	{
		
		String InActiveEmail = dataTable.getData("General_Data","NonExistUserId");
		String ExistingEmail = dataTable.getData("General_Data","ExistingUserId");
		String InvalidEmail = dataTable.getData("General_Data","InvalidUserIDformat");
		String Password = dataTable.getData("General_Data","Password");
		String InvalidPasswordformat = dataTable.getData("General_Data","InvalidPasswordformat");
		String DifferentPassword = dataTable.getData("General_Data","InvalidPassword");
		
		
		String Errormsg_NoDataEntered = "Please fix the errors above";
		String Errormsg_NoEmailEntered = "Please enter a valid email address";
		String Errormsg_InvalidEmailEntered = "Please enter a valid email address";
		String Errormsg_InActiveEmailEntered = "This is not an active email address. Please provide an active email address.";
		String Errormsg_ExistingEmailEntered = "Username already taken. Please try a different one.";
		String Errormsg_NoPasswordEntered = "Please provide a password";
		String Errormsg_InvalidPasswordformatEntered = "Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.";
		String Errormsg_DifferentPasswordEntered = "Passwords did not match";
		String Errormsg_NoChallengeQuestion = "Please select a account recovery question";
		String Errormsg_NoChallengeAnswerEntered = "Please provide an answer to account recovery question";
		
		
		//User clicked on Save without any data
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.btn_LoginResetAccntInfoSave), MobilesitePageObjects.btn_LoginResetAccntInfoSave.getObjectname());
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoNoDataEntered), MobilesitePageObjects.errormsg_LoginResetAccntInfoNoDataEntered.getObjectname(), Errormsg_NoDataEntered);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAcctInfoNoEmailEntered), MobilesitePageObjects.errormsg_LoginResetAcctInfoNoEmailEntered.getObjectname(), Errormsg_NoEmailEntered);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoNoPassword), MobilesitePageObjects.errormsg_LoginResetAccntInfoNoPassword.getObjectname(), Errormsg_NoPasswordEntered);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoNoChallengeQuestion), MobilesitePageObjects.errormsg_LoginResetAccntInfoNoChallengeQuestion.getObjectname(), Errormsg_NoChallengeQuestion);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoNoChallengeAnswer), MobilesitePageObjects.errormsg_LoginResetAccntInfoNoChallengeAnswer.getObjectname(), Errormsg_NoChallengeAnswerEntered);
		
		//User entered InvalidEmail
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoEmail),InvalidEmail, MobilesitePageObjects.txt_LoginResetAccntInfoEmail.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoInvalidEmail), MobilesitePageObjects.errormsg_LoginResetAccntInfoInvalidEmail.getObjectname(), Errormsg_InvalidEmailEntered);
		
		//User entered InactiveEmail
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoEmail),InActiveEmail, MobilesitePageObjects.txt_LoginResetAccntInfoEmail.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoInactiveEmail), MobilesitePageObjects.errormsg_LoginResetAccntInfoInactiveEmail.getObjectname(), Errormsg_InActiveEmailEntered);
		
		//User entered ExistingEmail
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoEmail),ExistingEmail, MobilesitePageObjects.txt_LoginResetAccntInfoEmail.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoExistingEmail), MobilesitePageObjects.errormsg_LoginResetAccntInfoExistingEmail.getObjectname(), Errormsg_ExistingEmailEntered);
		
		
		//User entered InvalidPassword format
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoPassword),InvalidPasswordformat, MobilesitePageObjects.txt_LoginResetAccntInfoPassword.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoInvalidPasswordFormat), MobilesitePageObjects.errormsg_LoginResetAccntInfoInvalidPasswordFormat.getObjectname(), Errormsg_InvalidPasswordformatEntered);
		
		//User entered Differntdata in password & Confirm password fields
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoPassword),Password, MobilesitePageObjects.txt_LoginResetAccntInfoPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoConfirmPassword),DifferentPassword, MobilesitePageObjects.txt_LoginResetAccntInfoConfirmPassword.getObjectname());
		Thread.sleep(3000);
		commonFunction.isElementPresentContainsText(getPageElement(MobileSiteResetPageObjects.errormsg_LoginResetAccntInfoDifferentPasswordEntered), MobilesitePageObjects.errormsg_LoginResetAccntInfoDifferentPasswordEntered.getObjectname(), Errormsg_DifferentPasswordEntered);
	}
	
	
	public void resetflow_AccountInfoPage() throws Exception
	{
		String Email = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data","Password");
		String ConfirmPassword = dataTable.getData("General_Data","Password");
		String Question = dataTable.getData("General_Data","ChallengeQuestion");
		String Answer = dataTable.getData("General_Data","ChallengeAnswer");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoEmail),Email, MobilesitePageObjects.txt_LoginResetAccntInfoEmail.getObjectname());
		Thread.sleep(5000);
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoPassword),Password,MobilesitePageObjects.txt_LoginResetAccntInfoPassword.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoConfirmPassword),ConfirmPassword,MobilesitePageObjects.txt_LoginResetAccntInfoConfirmPassword.getObjectname());
		
		commonFunction.selectAnyElement(getPageElement(MobileSiteResetPageObjects.drpdnw_LoginResetAccntInfoChallengeQuestion), Question,MobilesitePageObjects.drpdnw_LoginResetAccntInfoChallengeQuestion.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetAccntInfoChallengeAnswer), Answer, MobilesitePageObjects.txt_LoginResetAccntInfoChallengeAnswer.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.btn_LoginResetAccntInfoSave), MobilesitePageObjects.btn_LoginResetAccntInfoSave.getObjectname());
	}
	
	public void login_VUSEEnterValidDataPandY() throws IOException
	{
		
		String Email = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data","Password");
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.loginLnk_VUSECertifyAgePage),MobilesitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		
		//commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.header_VUSELogin),MobilesitePageObjects.header_VUSELogin.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginUsername),Email,MobilesitePageObjects.txt_VUSELoginUsername.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginPassword),Password,MobilesitePageObjects.txt_VUSELoginPassword.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_VUSELogin),MobilesitePageObjects.btn_VUSELogin.getObjectname());
	}
	
	public void resetflow_CongratsPage() throws IOException
	{
		
		String Email = dataTable.getData("General_Data","Email");
		String Password = dataTable.getData("General_Data", "Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetCongratsPageEmail), Email,MobilesitePageObjects.txt_LoginResetCongratsPageEmail.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobileSiteResetPageObjects.txt_LoginResetCongratsPagePassword),Password,MobilesitePageObjects.txt_LoginResetCongratsPagePassword.getObjectname());
		
		commonFunction.clickIfElementPresent(getPageElement(MobileSiteResetPageObjects.btn_LoginResetCongratsPageLogin), MobilesitePageObjects.btn_LoginResetCongratsPageLogin.getObjectname());
	}
	
	
	

	
	
	
}

