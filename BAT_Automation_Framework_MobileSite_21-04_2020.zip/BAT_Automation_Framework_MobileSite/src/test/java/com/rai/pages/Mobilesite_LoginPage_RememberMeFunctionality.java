package com.rai.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.rai.framework.Status;
import com.rai.componentgroups.CommonFunctions;
import com.rai.framework.BaseClass;
import com.rai.framework.GenericLib;
import com.rai.pageObjects.MobileSiteLoginPageObjects;
import com.rai.pageObjects.MobilesitePageObjects;

public class Mobilesite_LoginPage_RememberMeFunctionality extends BaseClass {

	String testcaseName;
	public Mobilesite_LoginPage_RememberMeFunctionality(String testcaseName) {
		this.testcaseName=testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}

	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	CommonFunctions commonFunction = new CommonFunctions(testcaseName);

	
	private WebElement getPageElement(MobilesitePageObjects pageEnum) throws IOException {
		WebElement element;
		try {
			element = commonFunction.getElementByProperty(pageEnum.getProperty(), pageEnum.getLocatorType().toString(),
					true);
			if (element != null)
				System.out.println("Found the element: " + pageEnum.getObjectname());
			else
				System.out.println("Element Not Found: " + pageEnum.getObjectname());
			return element;
		} catch (Exception e) {
			GenericLib.updateExtentStatus("Login Page - get page element",
					pageEnum.toString() + " object is not defined or found.", Status.FAIL);
			return null;
		}
	}
	
	
	public void invokeApplication_brandMobilesite()
	{
	    String WebsiteURL = dataTable.getData("General_Data", "URL");
		driver.manage().window().maximize();
		driver.get(WebsiteURL);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);		
	}
	
	
   public void loginfields_ValidateInlinetext() throws Exception
   {
	   
	   String Expected_UsernameInlinetext = "Username / Email Address";
	   String Expected_PasswordInlinetext = "Password";
	   
	   commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btnSignInTab),MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
	   String Actual_UsernameInlintext = commonFunction.getValueFromAttribute(getPageElement(MobilesitePageObjects.txt_LoginUsername), MobilesitePageObjects.txt_LoginUsername.getObjectname(), "placeholder");
	   String Actual_PasswordInlinetext = commonFunction.getValueFromAttribute(getPageElement(MobilesitePageObjects.txt_LoginPassword), MobilesitePageObjects.txt_LoginPassword.getObjectname(), "placeholder");
	   
	   commonFunction.compareStrings(Expected_UsernameInlinetext, Actual_UsernameInlintext);
	   commonFunction.compareStrings(Expected_PasswordInlinetext, Actual_PasswordInlinetext);	   
	   
   }	
	
	public void loginPage_RememberMeValidation() throws IOException, InterruptedException
	{
		String ValidUserId = dataTable.getData("General_Data","Username");
		String ValidPassword = dataTable.getData("General_Data","Password");
		//commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btnSignInTab),MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_LoginUsername),ValidUserId,MobilesitePageObjects.txt_LoginUsername.getObjectname());
        commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_LoginPassword),ValidPassword,MobilesitePageObjects.txt_LoginPassword.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.chkbx_RememberMe), MobilesitePageObjects.chkbx_RememberMe.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login), MobilesitePageObjects.btn_Login.getObjectname());

	}
	
	public void revelVelologinPage_RememberMeValidation() throws IOException, InterruptedException
	{
		String ValidUserId = dataTable.getData("General_Data","Username");
		String ValidPassword = dataTable.getData("General_Data","Password");
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_LoginUsername),ValidUserId,MobilesitePageObjects.txt_LoginUsername.getObjectname());
        commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_LoginPassword),ValidPassword,MobilesitePageObjects.txt_LoginPassword.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.chkbx_RevelVelo_RememberMe), MobilesitePageObjects.chkbx_RevelVelo_RememberMe.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_Login), MobilesitePageObjects.btn_Login.getObjectname());

	}
	
	public void loginPage_ValidatedisplayedUserId() throws Exception
	{
		String Expected_UserId = dataTable.getData("General_Data", "Username");
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btnSignInTab),MobileSiteLoginPageObjects.btnSignInTab.getObjectname());
		Thread.sleep(3000);
		String Actual_UserId = commonFunction.getValueFromAttribute(getPageElement(MobilesitePageObjects.txt_LoginUsername), MobilesitePageObjects.txt_LoginUsername.getObjectname(), "value");
		
		commonFunction.compareStrings(Expected_UserId, Actual_UserId);
		
	}
	
	public void logout_RememberMeValidation() throws Exception
	{
		
		if((getPageElement(MobilesitePageObjects.chkbx_RememberMe)).isSelected())
		{
			GenericLib.updateExtentStatus("Verify Remember me Checkbox Checked", "Remember me Checkbox is Checked", Status.PASS);
		}
		else
		{
			GenericLib.updateExtentStatus("Verify Remember me Checkbox Checked", "Remember me Checkbox is NOT Checked", Status.FAIL);
		}
		
	}
	
	public void vuseloginPage_RememberMeValidation() throws IOException, InterruptedException
	{
		String ValidUserId = dataTable.getData("General_Data","Username");
		String ValidPassword = dataTable.getData("General_Data","Password");
		
		commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.loginLnk_VUSECertifyAgePage), MobilesitePageObjects.loginLnk_VUSECertifyAgePage.getObjectname());
		
		commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginUsername),ValidUserId,MobilesitePageObjects.txt_VUSELoginUsername.getObjectname());
        commonFunction.clearAndEnterTextTabOut(getPageElement(MobilesitePageObjects.txt_VUSELoginPassword),ValidPassword,MobilesitePageObjects.txt_VUSELoginPassword.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.chkbox_VUSELoginRememberMe), MobilesitePageObjects.chkbox_VUSELoginRememberMe.getObjectname());
        commonFunction.clickIfElementPresent(getPageElement(MobilesitePageObjects.btn_VUSELogin), MobilesitePageObjects.btn_VUSELogin.getObjectname());

	}
	
	public void vuseloginPage_ValidatedisplayedUserId() throws Exception
	{
		String Expected_UserId = dataTable.getData("General_Data", "Username");
		
		String Actual_UserId = commonFunction.getTextFromTextBox(getPageElement(MobilesitePageObjects.txt_VUSELoginUsername), MobilesitePageObjects.txt_VUSELoginUsername.getObjectname());
		
		commonFunction.compareStrings(Expected_UserId, Actual_UserId);
		
	}
	
	public void vuselogout_RememberMeValidation() throws Exception
	{
		
		if((getPageElement(MobilesitePageObjects.chkbox_VUSELoginRememberMe)).isSelected())
		{
			GenericLib.updateExtentStatus("Verify Remember me Checkbox Checked", "Remember me Checkbox is Checked", Status.PASS);
		}
		else
		{
			GenericLib.updateExtentStatus("Verify Remember me Checkbox Checked", "Remember me Checkbox is NOT Checked", Status.FAIL);
		}
	}
	
	public void revelVelologout_RememberMeValidation() throws Exception
	{
		
		if((getPageElement(MobilesitePageObjects.chkbx_RevelVelo_RememberMe)).isSelected())
		{
			GenericLib.updateExtentStatus("Verify Remember me Checkbox Checked", "Remember me Checkbox is Checked", Status.PASS);
		}
		else
		{
			GenericLib.updateExtentStatus("Verify Remember me Checkbox Checked", "Remember me Checkbox is NOT Checked", Status.FAIL);
		}
	}
	
	
	

		
	
	
}

