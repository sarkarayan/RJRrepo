package com.rai.pages;

import java.sql.ResultSet;

import org.openqa.selenium.support.PageFactory;

import com.rai.framework.drivers.DatabaseConnection;;


public class Mobilesite_DatabaseValidations extends DatabaseConnection {
	
	String testcaseName;
	

	public Mobilesite_DatabaseValidations(String testcaseName)
	{
		this.testcaseName = testcaseName;
		PageFactory.initElements(driver, this);
		dataTable.setCurrentRow(testcaseName, 1, 1);
	}


	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 * @return 
	 * @return 
	 */
	
	public ResultSet results_ConsumerAcctNo() 
	{
		// TODO Auto-generated constructor stub
		String AcctNo = dataTable.getData("Database_Data", "AccountNo");
				
		ResultSet AcctnoResults = DatabaseConnection.getResultSet("Select * from [RAI_BASE].[dbo].[CONSUMER_ACCTNO] where ACCTNO='"+AcctNo+"'");
		return AcctnoResults;
				
	}
	
	
	public void results_ConsumerAcctNo_SourceSystemValidation(ResultSet AcctnoResults, String SOURCESYSTEM)
	{
		
	 String SourceValue = DatabaseConnection.getDBColumnValue(AcctnoResults, SOURCESYSTEM);
	 String ExpectedValue = dataTable.getData("Database_Data", "SourceSystem");
	 
	 try
	 {
		if(SourceValue.contentEquals(ExpectedValue))
		 {
			 System.out.println("Expected SourceSystem value was updated in RAI_BASE DB");
		 }
	 }
	 catch (Exception e) 
	 {
		// TODO Auto-generated catch block
	 
		    System.out.println("Expected SourceSystem value was not updated in RAI_BASE DB");
	 
	 } 	
	}
	

	public void results_ConsumerAcctNo_ConsumerSourceValidation(ResultSet AcctnoResults, String CONSUMER_SOURCE)
	{
		
	 String SourceValue = DatabaseConnection.getDBColumnValue(AcctnoResults, CONSUMER_SOURCE);
	 String ExpectedValue = dataTable.getData("Database_Data", "ConsumerSource");
	 	
	 try
	 {
		if(SourceValue.contentEquals(ExpectedValue))
		 {
			 System.out.println("Expected ConsumerSource value was updated in RAI_BASE DB");
		 }
	 }
	 catch (Exception e) 
	 {
		// TODO Auto-generated catch block
	 
		    System.out.println("Expected ConsumerSource value was not updated in RAI_BASE DB");
	 
	 } 
	}
	 
	public ResultSet results_ConsumerSurveyResponse() 
	{
		String AcctNo = dataTable.getData("Database_Data", "AccountNo");
		
		ResultSet SurveyResults = DatabaseConnection.getResultSet("Select * from [RAI_BASE].[dbo].[SURVEY_RESPONSE] where ACCTNO='"+AcctNo+"' and FileDate=''");
		return SurveyResults;	 
		
	}
	
	public ResultSet results_SubscriptionsValidation() 
	{
			// TODO Auto-generated constructor stub
		
		String AcctNo = dataTable.getData("Database_Data", "AccountNo");
			
		ResultSet SubscriptionResults = DatabaseConnection.getResultSet("Select * from [RAI_BASE].[dbo].[CONSUMER_SUBSCRIPTIONS] where ACCTNO='"+AcctNo+"'");
		return SubscriptionResults;	 
		
	}
	
	public void validation_CamelSubscription(ResultSet SubscriptionResults, String DNE_CAMEL)
	{
		
	 String Camel_Subscription = DatabaseConnection.getDBColumnValue(SubscriptionResults, DNE_CAMEL);
	 String ExpectedSubscriptionValue = dataTable.getData("Database_Data", "DNECamel");
	 	
	 try
	 {
		if(Camel_Subscription.contentEquals(ExpectedSubscriptionValue))
		 {
			 System.out.println("Expected Subscription value was updated for Camel in RAI_BASE DB");
		 }
	 }
	 catch (Exception e) 
	 {
		// TODO Auto-generated catch block
	 
		    System.out.println("Expected Subscription value was not updated for Camel in RAI_BASE DB");
	 
	 } 
	}

	public void validation_GrizzlySubscription(ResultSet SubscriptionResults, String DNE_GRIZZLY)
	{
		
	 String Grizzly_Subscription = DatabaseConnection.getDBColumnValue(SubscriptionResults, DNE_GRIZZLY);
	 String ExpectedSubscriptionValue = dataTable.getData("Database_Data", "DNEGrizzly");
	 	
	 try
	 {
		if(Grizzly_Subscription.contentEquals(ExpectedSubscriptionValue))
		 {
			 System.out.println("Expected Subscription value was updated for Grizzly in RAI_BASE DB");
		 }
	 }
	 catch (Exception e) 
	 {
		// TODO Auto-generated catch block
	 
		    System.out.println("Expected Subscription value was not updated for Grizzly in RAI_BASE DB");
	 
	 } 
	}

	public void validation_NewportSubscription(ResultSet SubscriptionResults, String DNE_NEWPORT)
	{
		
	 String Newport_Subscription = DatabaseConnection.getDBColumnValue(SubscriptionResults, DNE_NEWPORT);
	 String ExpectedSubscriptionValue = dataTable.getData("Database_Data", "DNENewport");
	 	
	 try
	 {
		if(Newport_Subscription.contentEquals(ExpectedSubscriptionValue))
		 {
			 System.out.println("Expected Subscription value was updated for Newport in RAI_BASE DB");
		 }
	 }
	 catch (Exception e) 
	 {
		// TODO Auto-generated catch block
	 
		    System.out.println("Expected Subscription value was not updated for Newport in RAI_BASE DB");
	 
	 } 
	}

	public void validation_PallmallSubscription(ResultSet SubscriptionResults, String DNE_PALLMALL)
	{
		
	 String Pallmall_Subscription = DatabaseConnection.getDBColumnValue(SubscriptionResults, DNE_PALLMALL);
	 String ExpectedSubscriptionValue = dataTable.getData("Database_Data", "DNEPallmall");
	 	
	 try
	 {
		if(Pallmall_Subscription.contentEquals(ExpectedSubscriptionValue))
		 {
			 System.out.println("Expected Subscription value was updated for Pallmall in RAI_BASE DB");
		 }
	 }
	 catch (Exception e) 
	 {
		// TODO Auto-generated catch block
	 
		    System.out.println("Expected Subscription value was not updated for Pallmall in RAI_BASE DB");
	 
	 } 
	}
	
	public void validation_NASCIGSSubscription(ResultSet SubscriptionResults, String DNE_NAS)
	{
		
	 String Nascigs_Subscription = DatabaseConnection.getDBColumnValue(SubscriptionResults, DNE_NAS);
	 String ExpectedSubscriptionValue = dataTable.getData("Database_Data", "DNENascigs");
	 	
	 try
	 {
		if(Nascigs_Subscription.contentEquals(ExpectedSubscriptionValue))
		 {
			 System.out.println("Expected Subscription value was updated for Nascigs in RAI_BASE DB");
		 }
	 }
	 catch (Exception e) 
	 {
		// TODO Auto-generated catch block
	 
		    System.out.println("Expected Subscription value was not updated for Nascigs in RAI_BASE DB");
	 
	 } 
	}
	
	
	public void validation_VUSESubscription(ResultSet SubscriptionResults, String DNE_VUSE)
	{
		
	 String VUSE_Subscription = DatabaseConnection.getDBColumnValue(SubscriptionResults, DNE_VUSE);
	 String ExpectedSubscriptionValue = dataTable.getData("Database_Data", "DNEVUSE");
	 	
	 try
	 {
		if(VUSE_Subscription.contentEquals(ExpectedSubscriptionValue))
		 {
			 System.out.println("Expected Subscription value was updated for VUSE in RAI_BASE DB");
		 }
	 }
	 catch (Exception e) 
	 {
		// TODO Auto-generated catch block
	 
		    System.out.println("Expected Subscription value was not updated for VUSE in RAI_BASE DB");
	 
	 } 
	}
	
	public void validation_RevelSubscription(ResultSet SubscriptionResults, String DNE_REVEL)
	{
		
	 String Revel_Subscription = DatabaseConnection.getDBColumnValue(SubscriptionResults, DNE_REVEL);
	 String ExpectedSubscriptionValue = dataTable.getData("Database_Data", "DNERevel");
	 	
	 try
	 {
		if(Revel_Subscription.contentEquals(ExpectedSubscriptionValue))
		 {
			 System.out.println("Expected Subscription value was updated for Revel in RAI_BASE DB");
		 }
	 }
	 catch (Exception e) 
	 {
		// TODO Auto-generated catch block
	 
		    System.out.println("Expected Subscription value was not updated for Revel in RAI_BASE DB");
	 
	 } 
	}
	
	public void validation_VeloSubscription(ResultSet SubscriptionResults, String DNE_VELO)
	{
		
	 String Velo_Subscription = DatabaseConnection.getDBColumnValue(SubscriptionResults, DNE_VELO);
	 String ExpectedSubscriptionValue = dataTable.getData("Database_Data", "DNEVelo");
	 	
	 try
	 {
		if(Velo_Subscription.contentEquals(ExpectedSubscriptionValue))
		 {
			 System.out.println("Expected Subscription value was updated for Velo in RAI_BASE DB");
		 }
	 }
	 catch (Exception e) 
	 {
		// TODO Auto-generated catch block
	 
		    System.out.println("Expected Subscription value was not updated for Velo in RAI_BASE DB");
	 
	 } 
	}
	
	
	
}

