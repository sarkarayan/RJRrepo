package com.rai.pageObjects;

import static com.rai.pageObjects.ObjectLocator.ID;
import static com.rai.pageObjects.ObjectLocator.NAME;
import static com.rai.pageObjects.ObjectLocator.XPATH;

public enum MobileSiteResetPageObjects implements PageObjects {

	//Reset pages
	Continuebtn_LoginResetviaLoginonGeneralInfo("//div/input[@id='edit-submit']",XPATH,"ResetFlow through Login - Continue button on GeneralInfo page"),    
	   txt_LoginResetAccntInfoEmail("UserInformation_EmailAddress",ID,"ResetFlow - AccountInfo - Email"),
	   txt_LoginResetAccntInfoPassword("UserInformation_Password",ID,"ResetFlow - AccountInfo - Password "),
	   txt_LoginResetAccntInfoConfirmPassword("UserInformation_ConfirmPassword",ID,"ResetFlow - AccountInfo - ConfirmPassword"),
	   drpdnw_LoginResetAccntInfoChallengeQuestion("UserInformation_ChallengeQuestionId",ID,"ResetFlow - AccountInfo - ChallengeQuestion"),
	   txt_LoginResetAccntInfoChallengeAnswer("UserInformation_ChallengeAnswer",ID,"ResetFlow - AccountInfo - ChallengeAnswer"),
	   btn_LoginResetAccntInfoSave("edit-submit",ID,"ResetFlow - AccountInfo - Save"),
	
	   errormsg_LoginResetAcctInfoNoEmailEntered("emailError",ID,"ResetFlow - AccountInfo - No Email entered"),      //Please enter a valid email address
       errormsg_LoginResetAccntInfoExistingEmail("emailErrorAjax",ID,"ResetFlow - AccountInfo - User entered already existing email"), //Username already taken. Please try a different one.
	   errormsg_LoginResetAccntInfoInvalidEmail("emailError",ID,"ResetFlow - AccountInfo - User entered Invalid email"), //Please enter a valid email address
	   errormsg_LoginResetAccntInfoInactiveEmail("inactiveEmail",ID,"ResetFlow - AccountInfo - User entered Valid Inactive email"), //This is not an active email address. Please provide an active email address.
	   errormsg_LoginResetAccntInfoNoPassword("passwordError",ID,"ResetFlow - No Password entered"),         //Please provide a password
	   errormsg_LoginResetAccntInfoInvalidPasswordFormat("passwordFormatError",ID,"ResetFlow - Invalid Password format entered"),   //Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.
	   errormsg_LoginResetAccntInfoDifferentPasswordEntered("passwordConfirmError",ID,"ResetFlow - Different data entered in Password & ConfirmPassword fields"),    //Passwords did not match
	   errormsg_LoginResetAccntInfoNoChallengeQuestion("questionError",ID,"ResetFlow - No ChallengeQuestion selected"),     //Please select a account recovery question
	   errormsg_LoginResetAccntInfoNoChallengeAnswer("answerError",ID,"ResetFlow - No ChallengeAnswer selected"),        //Please provide an answer to account recovery question
	   errormsg_LoginResetAccntInfoNoDataEntered("//div[@class='errorText formError']",XPATH,"ResetFlow - No data entered on AccntInfo Page"),      //Please fix the errors above
	
	   
	   txt_LoginResetCongratsPageEmail("username",ID,""),
	   txt_LoginResetCongratsPagePassword("password",ID,""),
	   chckbox_LoginResetCongrtatsPageRememberMe("IsRememberUserChecked",ID,""),
	   lnk_LoginResetCongratsPageForgotUsername("//a[@href='/Security/ForgotLoginId']",XPATH,""),
	   lnk_LoginResetCongatsPageForgotPassword("//a[@href=\"/Security/GetPassword\"]",XPATH,""),
	   btn_LoginResetCongratsPageLogin("edit-submit",ID,""),
	
	
	//Already Registered Page
			txt_AlreadyRegisteredUsername("username",ID,"Input - AlreadyRegistered - Username"),
			txt_AlreadyRegisteredPassword("password",ID,"Input - AlreadyRegistered - Password"),
			chkbox_AlreadyRegisteredRememberMe("IsRememberUserChecked",ID,"Checkbox - AlreadyRegistered - RememberMe"),
			lnk_AlreadyRegisteredForgotUsername("//a[@href='/Security/ForgotLoginId']",XPATH,"ForgotUsername link - AlreadyRegistered"),
			lnk_AlreadyRegisteredForgotPassword("//a[@href='/Security/GetPassword']",XPATH,"ForgotPassword link - AlreadyRegistered"),
			btn_AlreadyRegisteredLogin("edit-submit",ID,"Login - AlreadyRegistered"),
			
			//errmsg_AlreadyRegisteredPage("//div[@class='form-header security-msg']/p",XPATH,"Already Registered Page"),
			errmsg_AlreadyRegisteredPage("//div[@class='form-header security-msg']/p",XPATH,"Already Registered Page"),
	   
	
	//Registration - Step 1
			btn_Step1Next("next-intro",ID,"Button - Step1 Next"),
			drpdwn_BirthMonth("UserInformation_BirthMonth",ID,"Dropdown - BirthMonth"),
			drpdwn_BirthDay("UserInformation.BirthDay",NAME,"Dropdown - BirthDay"),
			drpdwn_BirthYear("UserInformation_BirthYear",ID,"Dropdown - BirthYear"),
			drpdwn_BirthYearIndex("//div/select[@id='UserInformation_BirthYear']",XPATH,"Dropdown - BirthYear"),
			txt_FirstName("UserInformation.FirstName",NAME,"Input - FirstName"),
			txt_LastName("UserInformation_LastName",ID,"Input - LastName"),
			txt_Address("UserInformation.AddressLine1",NAME,"Input - Address"),
			txt_Zipcode("UserInformation_ZipCode",ID,"Input - Zipcode"),
			txt_City("UserInformation_City",ID,"Input - City"),
			drpdwn_State("UserInformation_State",ID,"State"),
			txt_Email("UserInformation_EmailAddress",ID,"Input - Email"),
			txt_PhoneRevelVelo("//input[@name='UserInformation.Phone']",XPATH,"Input - PhoneNumber"),
			radiobtn_GenderMaleRevel("//label[contains(text(),'Male')]",XPATH,"Radiobutton - Male Gender - Revel"),
			radiobtn_GenderFemaleRevel("//label[contains(text(),'Female')]",XPATH,"Radiobutton - Female Gender - Revel"),
	        chkbx_CertifyRevelVelo("//label[@class='fieldNote']",XPATH,"Checkbox Certify - Revel"),
	        
			Chkbx_Certify("//input[@class='form-checkbox']",XPATH,"Checkbox"),
			errmsg_Step1("//div[@class='errorText formError']",XPATH,"Error message - Step1"),
			
			errormsg_RegistrationNoDOB("dobError",ID,"Errormsg - No DOB data on Step1 Registrationpage"),     //Please provide your full date of birth
			errormsg_RegistrationNoLegalName("nameError",ID,"Errormsg - No LegalName data on Step1 Registrationpage"),  //Please enter your legal name
			errormsg_RegistrationNoAddress("streetAddressError",ID,"Errormsg - No Addressdata on Step1 Registrationpage"),     //Please provide a street address
			errormsg_RegistrationNoZipcode("zipCodeError",ID,"Errormsg - No Zipcode on Step1 Registrationpage"),               //Please provide a ZIP Code
			errormsg_RegistrationNoCity("cityError",ID,"Errormsg - No City data on Step1 Registrationpage"),                   //Please Provide City
			errormsg_RegistrationNoState("stateError",ID,"Errormsg - No State data on Step1 Registrationpage"),              //Please Provide State
			errormsg_RegistrationNoEmail("emailError",ID,"Errormsg - No Email data on Step1 Registrationpage"),            //Please enter a valid email address
			errormsg_RegistrationNoDataonStep1Page("//div[@id='intro']/div/div[@class='errorText formError']",XPATH,"Errormsg - No data on Step1 Registration Page"),    //Please fix the errors above
			
			errormsg_RegistrationInvalidEmail("emailError",ID,"Errormsg - User entered InvalidEmail on Registration Step1 page"),
			erromsg_RegistrationInactiveEmail("//span[@id='UserInformation_EmailAddress-error']",XPATH,"Errormsg - User entered InactiveEmail on Registration Step1 page"),     //This is not an active email address. Please provide an active email address.
			errormsg_RegistrationAlreadyExistingEmail("//span[@id='UserInformation_EmailAddress-error']",XPATH,"Errormsg - User entered AlreadyExisting email on Registration Step1 page"),     //User Name already taken. Please try a different one.
			
			//Step 2
			txt_Password("UserInformation_Password",ID,"Input-Password"),
			txt_ConfirmPassword("UserInformation.ConfirmPassword",NAME,"Input - ConfirmPassword"),
			drpdwn_ChallengeQuestion("UserInformation_ChallengeQuestionId",ID,"Input - ChallengeQuestion"),
			txt_ChallengeAnswer("UserInformation_ChallengeAnswer",ID,"Input - ChallengeAnswer"),
			btn_Step2Next("continue-verification",ID,"Button - Step2 Next"),
			
			errormsg_RegistrationNoPassword("passwordError",ID,"Errormsg - No Password data on Step2 Registrationpage"),        //Please provide a password
			errormsg_RegistrationNoChallengeQuestion("questionError",ID,"Errormsg - No ChallengeQuestion on Step2 RegistrationPage"),                //Please select a account recovery question
			errormsg_RegistrationNoChallengeAnswer("answerError",ID,"Errormsg - No ChallengeAnswer on Step2 RegistrationPage"),             //Please provide an answer to account recovery question
			errormsg_RegistrationNoDataonStep2Page("//div[@id='acctInfo']/div/div/div/div[@class='errorText formError']",XPATH,"Errormsg - No data on Step2 Registration Page"),    //Please fix the errors above
			errormsg_RegistrationIncorrectPasswordformat("passwordFormatError",ID,"Errormsg - InvalidPassword format on Step2 RegistrationPage"),      //Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.
			errormsg_RegistrationDifferentPasswordsentered("passwordConfirmError",ID,"Errormsg - Diff.data entered in Password & ConfirmPassword on Step2 RegistrationPage"),       //Passwords did not match
			
			//Step 3
			radiobtn_KBA("//div[@id='edit-kba']/div/span",XPATH,"Radiobutton - KBA"),
			radiobtn_SSN("//div[@id='edit-ssn']/div/span",XPATH,"Radiobutton - SSN"),
			txt_SSN("ssn[KbaSSN]",NAME,"Input - SSN"),
			btn_Submit("ssnbutton",ID,"Button - Step3 Submit"),		
			txt_onlySSNvisible("//div/input[@id='UserInformation_NoKBASSN']",XPATH,"Only SSN text field visible on VerifyIdentity page"),
			btn_SubmitwhenonlySSNVisible("//div/button[@id='ssnnokbabutton']",XPATH,"Submit button when only SSN is visible"),
			txt_SSNonUnabletoVerifyPage("//div/input[@id='UserInformation_prevSSN']",XPATH,"SSN text on UnabletoVerify page"),
			btn_SubmitonUnabletoVerifyPage("//div/button[@id='ssnunableverify']",XPATH,"Submit button on UnabletoVerify page"),
			btn_AgeVerificationFailedReturntoSignIn("//a[contains(text(),'Return to Sign In Page')]",XPATH,"ReturntoSignIn button - AgeVerificationFailed"),
			
			errormsg_RegistrationInvalidSSN("ssnVerifyError",ID,"Errormsg - IncorrectSSN entered on VerifyIdentity page"),       //Your Social Security Number does not match your name and date of birth. Please try again.
			erroMsg_RegistrationInvaliSSNNoKBA("ssnNoKBAVerifyError",ID,"Errormsg - IncorrectSSN entered on VerifyIdentity page"),	//(No KBA) Your Social Security Number does not match your name and date of birth. Please try again.
			//Congrats Page
			link_takemetoSite("take_me_to_site",ID,"Link - take me to site");
			
	
	
	
	
		
	String strProperty = "";
	ObjectLocator locatorType = null;
	String strObjName = "";
	
	@Override
	public String getProperty() {
		// TODO Auto-generated method stub
		return strProperty;
	}

	@Override
	public ObjectLocator getLocatorType() {
		// TODO Auto-generated method stub
		return locatorType;
	}

	@Override
	public String getObjectname() {
		// TODO Auto-generated method stub
		return strObjName;
	}
	
	private MobileSiteResetPageObjects (String strPropertyValue, ObjectLocator locatorType, String strObjName) {
		// TODO Auto-generated method stub
		this.strProperty = strPropertyValue;
   		this.locatorType = locatorType;
   		this.strObjName = strObjName;
		
	}
}
