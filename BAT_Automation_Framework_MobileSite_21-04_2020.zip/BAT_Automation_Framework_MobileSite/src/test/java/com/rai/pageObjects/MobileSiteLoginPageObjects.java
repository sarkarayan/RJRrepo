package com.rai.pageObjects;

import static com.rai.pageObjects.ObjectLocator.*;
public enum MobileSiteLoginPageObjects implements PageObjects {

	
	btnSignInTab("//div[text()='Sign In' and @class='tab']",XPATH,"SPA - Login Page - Sign In tab"),
	txt_LoginUsername("username",ID,"Input - Username"),
	btn_Registration("redirect_register",ID,"Button - Registration"),
	btn_RegistrationRevel("//div[@class='tab'][text()='Register']",XPATH,"Button - Registration Mobileste view"),
    txt_LoginPassword("password",ID,"Input - Password"),
    chkbx_RememberMe("IsRememberUserChecked",ID,"RememberMe Checkbox LoginPage"),
    btn_Login("//input[@type='submit']",XPATH,"Button - Login"),
    lnktxt_Forgetusername("//a[contains(text(),'Forgot Username?')]",XPATH,"Link - ForgotUsername"),
	lnktxt_Forgotpassword("//a[contains(text(),'Forgot Password?')]",XPATH,"Link - ForgotPassword"),
	btn_signin("",XPATH,"Link - ForgotPassword"),
	//div[@onclick="showBlock(this,'loginBlock')"]
	;
	String strProperty = "";
   	ObjectLocator locatorType = null;
   	String strObjName = "";
   	
	@Override
	public String getProperty() {
		// TODO Auto-generated method stub
		return strProperty;
	}

	@Override
	public ObjectLocator getLocatorType() {
		// TODO Auto-generated method stub
		return locatorType;
	}

	@Override
	public String getObjectname() {
		// TODO Auto-generated method stub
		return strObjName;
	}
	
	private MobileSiteLoginPageObjects (String strPropertyValue, ObjectLocator locatorType, String strObjName) {
		// TODO Auto-generated method stub
		this.strProperty = strPropertyValue;
   		this.locatorType = locatorType;
   		this.strObjName = strObjName;
		
	}
}
