package com.rai.pageObjects;

import static com.rai.pageObjects.ObjectLocator.ID;
import static com.rai.pageObjects.ObjectLocator.XPATH;

public enum MobileSiteForgotPasswordPageObjects implements PageObjects {

	//Forgot Password
    txt_ForgotPasswordUsername("userId",ID,"Input - Username"),
    btn_ForgotPasswordUsernameContinue("edit-submit",ID,"Button - Continue"),
    Lnk_ForgotPasswordForgotUsername("//a[@href='/Security/ForgotLoginId']",XPATH,"Link - ForgotUsername"),
    drpdwn_ForgotPasswordBirthMonth("BirthMonth",ID,"Dropdown - PasswordBirthMonth"),
    drpdwn_ForgotPasswordBirthDay("BirthDay",ID,"Dropdown - PasswordBirthDay"),
    drpdwn_ForgotPasswordBirthYear("BirthYear",ID,"Dropdown - PasswordBirthYear"),
    txt_ForgotPasswordFirstName("FirstName",ID,"Input - FirstName"),
    txt_ForgotPasswordLastName("LastName",ID,"Input - LastName"),
    txt_ForgotPasswordAddress("AddressLine1",ID,"Input - Address"),
    txt_ForgotPasswordZipcode("ZipCode",ID,"Input - Zipcode"),
    txt_ForgotPasswordCity("City",ID,"Input - City"),
    drpdwn_ForgotPasswordState("State",ID,"Dropdown - State"),
    btn_ForgotPasswordGeneralInformation("//div//input[@id='edit-submit']",XPATH,"Button - Continue"),
    lnk_ForgotPasswordGeneralInfoLogin("//a[contains(text(),'Go to Login')]",XPATH,"Link - Goto Login"),
    txt_ForgotPasswordChallengeAnswer("ChallengeAnswer",ID,"Input - ChallengeAnswer"),
    btn_ForgotPasswordVerifyIdentity("edit-submit",ID,"Button - verifyIdentity"),
    txt_ForgotPasswordPassword("inputPassword",ID,"Input - Password"),
    txt_ForgotPasswordConfirmPassword("inputPasswordConfirm",ID,"Input - ConfirmPassword"),
    btn_ForgotPasswordResetPassword("edit-submit",ID,"Button - Next"),
    closeSavePasswordPopUp("//*[@resource-id=\"com.android.chrome:id/infobar_close_button\"]",XPATH,"Chrome Browser - SAve Password Close button[X]"),
    never_SavePassword("//hierarchy/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.view.ViewGroup[1]/android.widget.FrameLayout[3]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.view.ViewGroup[1]/android.view.ViewGroup[2]/android.widget.Button[1]",XPATH,"SavePassword - Never"),
    close_SavePassword("com.android.chrome:id/infobar_close_button",ID,"SavePassword - Close"),
	alertOkButton("com.android.chrome:id/positive_button",ID,"Profile Page - Alert Ok Button"),
    
    txt_CongratsPageUsername("username",ID,"Input - Username"),
    txt_CongratsPagePassword("password",ID,"Input - Password"),
    chkbox_CongratspageRememberMe("IsRememberUserChecked",ID,"Checkbox - RememberMe"),
    lnk_CongratsPageForgotUsername("//a[@href='/Security/ForgotLoginId\']",XPATH,"Link - ForgotUsername"),
    lnk_CongratsPageForgotPassword("//a[@href='/Security/GetPassword\']",XPATH,"Link - ForgotPassword"),
    btn_CongratsPageLoginbutton("edit-submit",ID,"Button - Login"),
    
    errormsg_ForgotPasswordNoUsername("userIdError",ID,"Errormsg - NoUsername entered - ForgotPassword"),     //Please enter your Username / Email Address.
    errormsg_ForgotPasswordInvalidUserIdformat("formatError",ID,"Erromsg - InvalidUserId format - ForgotPassword"),     //Username must be a combination of 8-30 letters and numbers.
    errormsg_ForgotPasswordInvalidUserId("//div[@id='answerMatchError']",XPATH,"Errormsg - InvalidUserId - ForgotPassword"),    //We could not locate your Login ID, please try again.
    errormsg_ForgotPasswordNoDataonGeneralInfo("//div[@class='errorText formError']",XPATH,"Errormsg - NoProfileInfo entered - ForgotPassword"),    //Please fix the errors above
    errormsg_ForgotPasswordNoDOB("dobError",ID,"Errormsg - No DOB data on GeneralInfo page - ForgotPassword"),   //Please provide a Date Of Birth
    errormsg_ForgotPasswordNoLegalName("nameError",ID,"Errormsg - No LegalName on GeneralInfo page - ForgotPassword"),  //Please enter your legal name"
    errormsg_ForgotPasswordNoAddress("streetAddressError",ID,"Errormsg - No Address on GeneralInfo page - ForgotPassword"),   //Please provide a street address
    errormsg_ForgotPasswordNoZipcode("zipCodeError",ID,"Errormsg - No Zipcode data on GeneralInfo page - ForgotPassword"),   //Please provide a ZIP Code
    errormsg_ForgotPasswordNoCity("cityError",ID,"Errormsg - No City data on GeneralInfo page - ForgotPassword"),           //Please Provide City
    errormsg_ForgotPasswordNoState("stateError",ID,"Errormsg - No State data on GeneralInfo page - ForgotPassword"),   //Please Provide State
    errormsg_ForgotPasswordUsernotfound("userNotFoundDiv",ID,"Errormsg - Usernotfound ForgotPassword"),     //We were not able to find your information. Please check and try again.
    errormsg_ForgotPasswordNoChallengeAnswer("answerError",ID,"Errormsg - NoChallengeAnswer entered ForgotPassword"),     //Please provide an answer to account recovery question
    errormsg_ForgotPasswordInvalidChallengeAnswer("answerMatchError",ID,"Errormsg - InvalidAnswer ForgotPassword"),       //The answer does not match our records. Please re-enter your answer to the challenge question
    errormsg_ForgotPasswordNoPasswordentered("passwordError",ID,"Errormsg - NoPasswordEntered ForgotPassword"),      //Please provide a password
    errormsg_ForgotPasswordInvalidPasswordformatentered("passwordFormatError",ID,"Errormsg - InvalidPasswordformatEntered ForgotPassword"),   //Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.
    errormsg_ForgotPasswordDifferentPasswordentered("passwordConfirmError",ID,"Errormsg - DifferentPasswordEntered ForgotPassword"),     //Passwords did not match
    errormsg_ForgotPasswordCongratsPageNoDataEntered("//div[@class='errorText formError']",XPATH,"Errormsg - CongratsPage with no data - ForgotPassword"),    //Please fix the errors above
    errormsg_ForgotPasswordCongratsPagePasswordNotentered("passwordError",ID,"Errormsg - CongratsPage with NoPasswordEntered - ForgotPassword"),      //Please enter your password.
    
	;
	String strProperty = "";
   	ObjectLocator locatorType = null;
   	String strObjName = "";
   	
	@Override
	public String getProperty() {
		// TODO Auto-generated method stub
		return strProperty;
	}

	@Override
	public ObjectLocator getLocatorType() {
		// TODO Auto-generated method stub
		return locatorType;
	}

	@Override
	public String getObjectname() {
		// TODO Auto-generated method stub
		return strObjName;
	}
	
	private MobileSiteForgotPasswordPageObjects (String strPropertyValue, ObjectLocator locatorType, String strObjName) {
		// TODO Auto-generated method stub
		this.strProperty = strPropertyValue;
   		this.locatorType = locatorType;
   		this.strObjName = strObjName;
		
	}
}
