package com.rai.pageObjects;

import static com.rai.pageObjects.ObjectLocator.ID;
import static com.rai.pageObjects.ObjectLocator.NAME;
import static com.rai.pageObjects.ObjectLocator.XPATH;
import static com.rai.pageObjects.ObjectLocator.CSS;

public enum MobileSite_Accountlock_validationPageObjects implements PageObjects {

	//LoginPage
    txt_LoginUsername("username",ID,"Input - Username"),
    txt_LoginPassword("password",ID,"Input - Password"),
    chkbx_RememberMe("IsRememberUserChecked",ID,"RememberMe Checkbox LoginPage"),
    btn_Login("edit-submit",ID,"Button - Login"),
	btn_Registration("redirect_register",ID,"Button - Registration"),
	lnktxt_Forgetusername("//a[contains(text(),'Forgot Username?')]",XPATH,"Link - ForgotUsername"),
	lnktxt_Forgotpassword("//a[contains(text(),'Forgot Password?')]",XPATH,"Link - ForgotPassword"),
	lnktxt_RevelVeloForgotUsername("//a[contains(text(),'Username')]",XPATH,"Revel&Velo - ForgotUsername link on Login page"),
	lnktxt_RevelVeloForgotPassword("//a[contains(text(),'Password')]",XPATH,"Revel&Velo - ForgotPassword link on Login page"),
	
	errormsg_LoginwithoutanyData("usernameError",ID,"Login with no data"), //Please Provide a Username / Email Address.
	errormsg_LoginwithoutanyData_vuse("Email-error",ID,"Login with no data"), 
	errormsg_LoginwithNonExistingUserId("loginError",ID,"Login with non-existing UserId"),   //Username Does Not Exist.
	errormsg_Usernamefieldformaterror("formatError",ID,"UserID with unaccepted characters on LoginPage"), //Username must be a combination of 8-30 letters and numbers.
	
	//AccountLock
	errormsg_WrongPasswrd("div#loginError.errorText",CSS,"Error Message - Invalid Username or password"),    //Username and Password do not match.
	errormsg_Accountlocked("loginError",ID,"Accountlocked after entering Invliad password for 4times"),   //Username and password do not match. account now locked. Click 		
	lnk_LockedAccntResetlink("//a[@href='/Security/GetPassword']",XPATH,"Reset link for Locked Account"),
	lnk_VuseLockedAccntResetlink("//span//a[@href='https://qa-auth-vusevapor.raimktg.com/Security/GetPassword']",XPATH,"Reset link for Locked Account"),
	
	//Registration - Step 1
	btn_Step1Next("next-intro",ID,"Button - Step1 Next"),
	drpdwn_BirthMonth("UserInformation_BirthMonth",ID,"Dropdown - BirthMonth"),
	drpdwn_BirthDay("UserInformation.BirthDay",NAME,"Dropdown - BirthDay"),
	drpdwn_BirthYear("UserInformation_BirthYear",ID,"Dropdown - BirthYear"),
	drpdwn_BirthYearIndex("//div/select[@id='UserInformation_BirthYear']",XPATH,"Dropdown - BirthYear"),
	txt_FirstName("UserInformation.FirstName",NAME,"Input - FirstName"),
	txt_LastName("UserInformation_LastName",ID,"Input - LastName"),
	txt_Address("UserInformation.AddressLine1",NAME,"Input - Address"),
	txt_Zipcode("UserInformation_ZipCode",ID,"Input - Zipcode"),
	txt_City("UserInformation_City",ID,"Input - City"),
	drpdwn_State("UserInformation_State",ID,"State"),
	txt_Email("UserInformation_EmailAddress",ID,"Input - Email"),
	txt_PhoneRevelVelo("//input[@name='UserInformation.Phone']",XPATH,"Input - PhoneNumber"),
	radiobtn_GenderMaleRevel("//label[contains(text(),'Male')]",XPATH,"Radiobutton - Male Gender - Revel"),
	radiobtn_GenderFemaleRevel("//label[contains(text(),'Female')]",XPATH,"Radiobutton - Female Gender - Revel"),
    chkbx_CertifyRevelVelo("//label[@class='fieldNote']",XPATH,"Checkbox Certify - Revel"),
    
	Chkbx_Certify("//input[@class='form-checkbox']",XPATH,"Checkbox"),
	errmsg_Step1("//div[@class='errorText formError']",XPATH,"Error message - Step1"),
	
	errormsg_RegistrationNoDOB("dobError",ID,"Errormsg - No DOB data on Step1 Registrationpage"),     //Please provide your full date of birth
	errormsg_RegistrationNoLegalName("nameError",ID,"Errormsg - No LegalName data on Step1 Registrationpage"),  //Please enter your legal name
	errormsg_RegistrationNoAddress("streetAddressError",ID,"Errormsg - No Addressdata on Step1 Registrationpage"),     //Please provide a street address
	errormsg_RegistrationNoZipcode("zipCodeError",ID,"Errormsg - No Zipcode on Step1 Registrationpage"),               //Please provide a ZIP Code
	errormsg_RegistrationNoCity("cityError",ID,"Errormsg - No City data on Step1 Registrationpage"),                   //Please Provide City
	errormsg_RegistrationNoState("stateError",ID,"Errormsg - No State data on Step1 Registrationpage"),              //Please Provide State
	errormsg_RegistrationNoEmail("emailError",ID,"Errormsg - No Email data on Step1 Registrationpage"),            //Please enter a valid email address
	errormsg_RegistrationNoDataonStep1Page("//div[@id='intro']/div/div[@class='errorText formError']",XPATH,"Errormsg - No data on Step1 Registration Page"),    //Please fix the errors above
	
	errormsg_RegistrationInvalidEmail("emailError",ID,"Errormsg - User entered InvalidEmail on Registration Step1 page"),
	erromsg_RegistrationInactiveEmail("//span[@id='UserInformation_EmailAddress-error']",XPATH,"Errormsg - User entered InactiveEmail on Registration Step1 page"),     //This is not an active email address. Please provide an active email address.
	errormsg_RegistrationAlreadyExistingEmail("//span[@id='UserInformation_EmailAddress-error']",XPATH,"Errormsg - User entered AlreadyExisting email on Registration Step1 page"),     //User Name already taken. Please try a different one.
	
	//Step 2
	txt_Password("UserInformation_Password",ID,"Input-Password"),
	txt_ConfirmPassword("UserInformation.ConfirmPassword",NAME,"Input - ConfirmPassword"),
	drpdwn_ChallengeQuestion("UserInformation_ChallengeQuestionId",ID,"Input - ChallengeQuestion"),
	txt_ChallengeAnswer("UserInformation_ChallengeAnswer",ID,"Input - ChallengeAnswer"),
	btn_Step2Next("continue-verification",ID,"Button - Step2 Next"),
	
	errormsg_RegistrationNoPassword("passwordError",ID,"Errormsg - No Password data on Step2 Registrationpage"),        //Please provide a password
	errormsg_RegistrationNoChallengeQuestion("questionError",ID,"Errormsg - No ChallengeQuestion on Step2 RegistrationPage"),                //Please select a account recovery question
	errormsg_RegistrationNoChallengeAnswer("answerError",ID,"Errormsg - No ChallengeAnswer on Step2 RegistrationPage"),             //Please provide an answer to account recovery question
	errormsg_RegistrationNoDataonStep2Page("//div[@id='acctInfo']/div/div/div/div[@class='errorText formError']",XPATH,"Errormsg - No data on Step2 Registration Page"),    //Please fix the errors above
	errormsg_RegistrationIncorrectPasswordformat("passwordFormatError",ID,"Errormsg - InvalidPassword format on Step2 RegistrationPage"),      //Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.
	errormsg_RegistrationDifferentPasswordsentered("passwordConfirmError",ID,"Errormsg - Diff.data entered in Password & ConfirmPassword on Step2 RegistrationPage"),       //Passwords did not match
	
	//Step 3
	radiobtn_KBA("//div[@id='edit-kba']/div/span",XPATH,"Radiobutton - KBA"),
	radiobtn_SSN("//div[@id='edit-ssn']/div/span",XPATH,"Radiobutton - SSN"),
	txt_SSN("ssn[KbaSSN]",NAME,"Input - SSN"),
	btn_Submit("ssnbutton",ID,"Button - Step3 Submit"),		
	txt_onlySSNvisible("//div/input[@id='UserInformation_NoKBASSN']",XPATH,"Only SSN text field visible on VerifyIdentity page"),
	btn_SubmitwhenonlySSNVisible("//div/button[@id='ssnnokbabutton']",XPATH,"Submit button when only SSN is visible"),
	txt_SSNonUnabletoVerifyPage("//div/input[@id='UserInformation_prevSSN']",XPATH,"SSN text on UnabletoVerify page"),
	btn_SubmitonUnabletoVerifyPage("//div/button[@id='ssnunableverify']",XPATH,"Submit button on UnabletoVerify page"),
	btn_AgeVerificationFailedReturntoSignIn("//a[contains(text(),'Return to Sign In Page')]",XPATH,"ReturntoSignIn button - AgeVerificationFailed"),
	
	errormsg_RegistrationInvalidSSN("ssnVerifyError",ID,"Errormsg - IncorrectSSN entered on VerifyIdentity page"),       //Your Social Security Number does not match your name and date of birth. Please try again.
	erroMsg_RegistrationInvaliSSNNoKBA("ssnNoKBAVerifyError",ID,"Errormsg - IncorrectSSN entered on VerifyIdentity page"),	//(No KBA) Your Social Security Number does not match your name and date of birth. Please try again.
	//Congrats Page
	link_takemetoSite("take_me_to_site",ID,"Link - take me to site"),
	
	//Already Registered Page
	txt_AlreadyRegisteredUsername("username",ID,"Input - AlreadyRegistered - Username"),
	txt_AlreadyRegisteredPassword("password",ID,"Input - AlreadyRegistered - Password"),
	chkbox_AlreadyRegisteredRememberMe("IsRememberUserChecked",ID,"Checkbox - AlreadyRegistered - RememberMe"),
	lnk_AlreadyRegisteredForgotUsername("//a[@href='/Security/ForgotLoginId']",XPATH,"ForgotUsername link - AlreadyRegistered"),
	lnk_AlreadyRegisteredForgotPassword("//a[@href='/Security/GetPassword']",XPATH,"ForgotPassword link - AlreadyRegistered"),
	btn_AlreadyRegisteredLogin("edit-submit",ID,"Login - AlreadyRegistered"),
	
	errmsg_AlreadyRegisteredPage("//div[@class='form-header security-msg']/p",XPATH,"Already Registered Page"),
	

    //Forgot Username
    drpdwn_ForgotUsernameBirthMonth("BirthMonth",ID,"Dropdown - UsernameBirthMonth"),
    drpdwn_ForgotUsernameBirthDay("BirthDay",ID,"Dropdown - UsernameBirthDay"),
    drpdwn_ForgotUsernameBirthYear("BirthYear",ID,"Dropdown - UsernameBirthYear"),
    txt_ForgotUsernameFirstName("FirstName",ID,"Input - FirstName"),
    txt_ForgotUsernameLastName("LastName",ID,"Input - LastName"),
    txt_ForgotUsernameAddress("AddressLine1",ID,"Input - Address"),
    txt_ForgotUsernameZipcode("ZipCode",ID,"Input - Zipcode"),
    txt_ForgotUsernameCity("City",ID,"Input - City"),
    drpdwn_ForgotUsernameState("State",ID,"Dropdown - State"),
    btn_ForgotUsernameAccountInformation("next_UserInformation",ID,"Button - ContinueStep1"),
    txt_ForgotUsernameChallengeAnswer("ChallengeAnswer",ID,"Input - ChallengeAnswer"),
    btn_ForgotUsernameVerifyIdentity("next_AnswerChallengeQuestion",ID,"Button - VerifyIdentity"),
    txt_WelcomeBackPassword("password",ID,"Input - PasswordonWelcomeBack"),
    chkbox_WelcomeBackRememberMe("IsRememberUserChecked",ID,"Checkbox - RememberMe"),
    lnk_WelcomeBackResetPassword("//a[@href='/Security/GetPassword']",XPATH,"Link - ResetYourPassword"),
    btn_WelcomBackLogin("edit-submit",ID,"Button - Login"),
    
    errormsg_ForgotUsernameUsernotfound("userNotFoundDiv",ID,"Errormsg - Usernotfound ForgotUsername"),                //errormsg - We were not able to find your information. Please check and try again.
    errormsg_ForgotUsernameNoDataonGeneralInfo("//div[@class='errorText formError']",XPATH,"Errormsg - NoProfileInfo entered - ForgotUsername"),    //Please fix the errors above
    errormsg_ForgotUsernameNoDOB("dobError",ID,"Errormsg - No DOB data on GeneralInfo page - ForgotUsername"),   //Please provide a Date Of Birth
    errormsg_ForgotUsernameNoLegalName("nameError",ID,"Errormsg - No LegalName on GeneralInfo page - ForgotUsername"),  //Please enter your legal name"
    errormsg_ForgotUsernameNoAddress("streetAddressError",ID,"Errormsg - No Address on GeneralInfo page - ForgotUsername"),   //Please provide a street address
    errormsg_ForgotUsernameNoZipcode("zipCodeError",ID,"Errormsg - No Zipcode data on GeneralInfo page - ForgotUsername"),   //Please provide a ZIP Code
    errormsg_ForgotUsernameNoCity("cityError",ID,"Errormsg - No City data on GeneralInfo page - ForgotUsername"),           //Please Provide City
    errormsg_ForgotUsernameNoState("stateError",ID,"Errormsg - No State data on GeneralInfo page - ForgotUsername"),   //Please Provide State
    errormsg_ForgotUsernamenoChallengeAnswer("answerError",ID,"Errormsg - NoChallengeAnswer entered ForgotUsername"),  //Please provide an answer to account recovery question
    errormsg_ForgotUsernameInvalidAnswer("answerMatchError",ID,"Errormsg - InvalidAnswer ForgotUsername"),             //The answer does not match our records. Please re-enter your answer to the account recovery question
    errormsg_WelcomeBackNoPassword("passwordError",ID,"Errormsg - WelcomeBackPage with no Password - ForgotUsername"), //Please enter your password.
    errormsg_WelcomeBackInvalidPassword("loginError",ID,"Errormsg - WelcomeBackPage with Invalid Password - ForgotUsername"), //Username and password do not match.
    

    //Forgot Password
    txt_ForgotPasswordUsername("userId",ID,"Input - Username"),
    btn_ForgotPasswordUsernameContinue("edit-submit",ID,"Button - Continue"),
    Lnk_ForgotPasswordForgotUsername("//a[@href='/Security/ForgotLoginId']",XPATH,"Link - ForgotUsername"),
    drpdwn_ForgotPasswordBirthMonth("BirthMonth",ID,"Dropdown - PasswordBirthMonth"),
    drpdwn_ForgotPasswordBirthDay("BirthDay",ID,"Dropdown - PasswordBirthDay"),
    drpdwn_ForgotPasswordBirthYear("BirthYear",ID,"Dropdown - PasswordBirthYear"),
    txt_ForgotPasswordFirstName("FirstName",ID,"Input - FirstName"),
    txt_ForgotPasswordLastName("LastName",ID,"Input - LastName"),
    txt_ForgotPasswordAddress("AddressLine1",ID,"Input - Address"),
    txt_ForgotPasswordZipcode("ZipCode",ID,"Input - Zipcode"),
    txt_ForgotPasswordCity("City",ID,"Input - City"),
    drpdwn_ForgotPasswordState("State",ID,"Dropdown - State"),
    btn_ForgotPasswordGeneralInformation("//div//input[@id='edit-submit']",XPATH,"Button - Continue"),
    lnk_ForgotPasswordGeneralInfoLogin("//a[contains(text(),'Go to Login')]",XPATH,"Link - Goto Login"),
    txt_ForgotPasswordChallengeAnswer("ChallengeAnswer",ID,"Input - ChallengeAnswer"),
    btn_ForgotPasswordVerifyIdentity("edit-submit",ID,"Button - verifyIdentity"),
    txt_ForgotPasswordPassword("inputPassword",ID,"Input - Password"),
    txt_ForgotPasswordConfirmPassword("inputPasswordConfirm",ID,"Input - ConfirmPassword"),
    btn_ForgotPasswordResetPassword("edit-submit",ID,"Button - Next"),
    txt_CongratsPageUsername("username",ID,"Input - Username"),
    txt_CongratsPagePassword("password",ID,"Input - Password"),
    chkbox_CongratspageRememberMe("IsRememberUserChecked",ID,"Checkbox - RememberMe"),
    lnk_CongratsPageForgotUsername("//a[@href='/Security/ForgotLoginId\']",XPATH,"Link - ForgotUsername"),
    lnk_CongratsPageForgotPassword("//a[@href='/Security/GetPassword\']",XPATH,"Link - ForgotPassword"),
    btn_CongratsPageLoginbutton("edit-submit",ID,"Button - Login"),
    
    errormsg_ForgotPasswordNoUsername("userIdError",ID,"Errormsg - NoUsername entered - ForgotPassword"),     //Please enter your Username / Email Address.
    errormsg_ForgotPasswordInvalidUserIdformat("formatError",ID,"Erromsg - InvalidUserId format - ForgotPassword"),     //Username must be a combination of 8-30 letters and numbers.
    errormsg_ForgotPasswordInvalidUserId("//div[@id='answerMatchError']",XPATH,"Errormsg - InvalidUserId - ForgotPassword"),    //We could not locate your Login ID, please try again.
    errormsg_ForgotPasswordNoDataonGeneralInfo("//div[@class='errorText formError']",XPATH,"Errormsg - NoProfileInfo entered - ForgotPassword"),    //Please fix the errors above
    errormsg_ForgotPasswordNoDOB("dobError",ID,"Errormsg - No DOB data on GeneralInfo page - ForgotPassword"),   //Please provide a Date Of Birth
    errormsg_ForgotPasswordNoLegalName("nameError",ID,"Errormsg - No LegalName on GeneralInfo page - ForgotPassword"),  //Please enter your legal name"
    errormsg_ForgotPasswordNoAddress("streetAddressError",ID,"Errormsg - No Address on GeneralInfo page - ForgotPassword"),   //Please provide a street address
    errormsg_ForgotPasswordNoZipcode("zipCodeError",ID,"Errormsg - No Zipcode data on GeneralInfo page - ForgotPassword"),   //Please provide a ZIP Code
    errormsg_ForgotPasswordNoCity("cityError",ID,"Errormsg - No City data on GeneralInfo page - ForgotPassword"),           //Please Provide City
    errormsg_ForgotPasswordNoState("stateError",ID,"Errormsg - No State data on GeneralInfo page - ForgotPassword"),   //Please Provide State
    errormsg_ForgotPasswordUsernotfound("userNotFoundDiv",ID,"Errormsg - Usernotfound ForgotPassword"),     //We were not able to find your information. Please check and try again.
    errormsg_ForgotPasswordNoChallengeAnswer("answerError",ID,"Errormsg - NoChallengeAnswer entered ForgotPassword"),     //Please provide an answer to account recovery question
    errormsg_ForgotPasswordInvalidChallengeAnswer("answerMatchError",ID,"Errormsg - InvalidAnswer ForgotPassword"),       //The answer does not match our records. Please re-enter your answer to the challenge question
    errormsg_ForgotPasswordNoPasswordentered("passwordError",ID,"Errormsg - NoPasswordEntered ForgotPassword"),      //Please provide a password
    errormsg_ForgotPasswordInvalidPasswordformatentered("passwordFormatError",ID,"Errormsg - InvalidPasswordformatEntered ForgotPassword"),   //Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.
    errormsg_ForgotPasswordDifferentPasswordentered("passwordConfirmError",ID,"Errormsg - DifferentPasswordEntered ForgotPassword"),     //Passwords did not match
    errormsg_ForgotPasswordCongratsPageNoDataEntered("//div[@class='errorText formError']",XPATH,"Errormsg - CongratsPage with no data - ForgotPassword"),    //Please fix the errors above
    errormsg_ForgotPasswordCongratsPagePasswordNotentered("passwordError",ID,"Errormsg - CongratsPage with NoPasswordEntered - ForgotPassword"),      //Please enter your password.
    
    	
    //Profile 
    //lnk_MyAccount("//*[@id='main']/header/nav/a[6]",XPATH,"MyAccount Link - Homepage"),
    lnk_CamelMyAccount("//nav/a[@href='/profile/linkout']",XPATH,"MyAccount Link - Camel Homepage"),
    lnk_GrizzlyMyAccount("//span/a[contains(text(),'Profile')]",XPATH,"MyAccount Link - Grizzly Homepage"),
    btn_GrizzlyUpdateInfo("//a/button[contains(text(),'Update Your Contact Information')]",XPATH,"UpdateInformation button - Profile HomePage"),
    lnk_NewportMyAccount("//li/a[contains(text(),'Profile')]",XPATH,"MyAccount Link - Newport Homepage"),
    lnk_NASCIGSProfile("//nav/a[contains(text(),'Profile')]",XPATH,"PostLogin - NASCIGS Profile footerlink"),
    lnk_PallmallProfile("//div/a[@href='/myprofile']",XPATH,"MyAccount Link - Pallmall Homepage"),
    
    btn_ProfileUserInfo("tabUserInformation",ID,"Button - ProfileUserInformation"),
    btn_ProfileTobaccoPreferences("tabMySmokes",ID,"Button - ProfileTobaccoPreferences"),
    btn_ProfileContentPreferences("tabMyCp",ID,"Button - ProfileContentPreferences"),
    txt_ProfileAddressLine1("UserInformation_AddressLine1",ID,"Input - ProfileAddressLine1"),
    txt_ProfileCity("UserInformation_City",ID,"Input - ProfileCity"),
    txt_ProfileZipcode("UserInformation_ZipCode",ID,"Input - ProfileZipcode"),
    txt_ProfileNewEmail("NewEmailAddress",ID,"Input - NewEmail"),
    txt_ProfileConfirmEmail("ConfirmNewEmailAddress",ID,"Input - ConfirmEmail"),
    btn_ProfileUpdateInfo("btnUpdateUserInfo",ID,"Button - UpdateEmail&Permission"),
    txt_ProfileCurrentPassword("CurrentPassword",ID,"Input - CurrentPassword"),
    txt_ProfileNewPassword("NewPassword",ID,"Input - NewPassword"),
    txt_ProfileConfirmNewPassword("ConfirmNewPassword",ID,"Input - ConfirmNewPassword"),
    btn_ProfileUpdatePassword("btnUpdatePassword",ID,"Button - UpdatePassword"),
    drpdwn_ProfileChallengeQuestion("ChallengeQuestion",ID,"Dropdown - ChallengeQuestion"),
    txt_ProfileChallengeAnswer("ChallengeAnswer",ID,"Input - ChallengeAnswer"),
    btn_ProfileUpdateChallengeQuestion("//input[@id='btnUpdateChallengeQA']",XPATH,"Button - ChallengeQuestion"),
    btn_ProfileBacktoSite("//img[@src='/themes/custom/rjr_theme/images/Btn_BackToSite.jpg']",XPATH,"Button - Backtosite"),
    
    chckbox_TobaccoPreferencesCombustible("//input[@value='10001|aPROD CATEGORY|1000001|10001']",XPATH,"MyProfile - TobaccoPreferences - Combustible"),
    chckbox_TobaccoPreferencesMoistSnuff("//input[@value='10001|aPROD CATEGORY|1000001|10002']",XPATH,"MyProfile - TobaccoPreferences - MoistSnuff"),
    chckbox_TobaccoPreferencesVapor("//input[@value='10001|aPROD CATEGORY|1000001|10003']",XPATH,"MyProfile - TobaccoPreferences - Vapor"),
    chckbox_TobaccoPreferencesSNUS("//input[@value='10001|aPROD CATEGORY|1000001|10004']",XPATH,"MyProfile - TobaccoPreferences - SNUS"),
    chckbox_TobaccoPreferencesDissolvableTobacco("//input[@value='10001|aPROD CATEGORY|1000001|10005']",XPATH,"MyProfile - TobaccoPreferences - DissolvableTobacco"),
    drpdwn_TobaccoPreferencesDissolvable1("TobaccoPreferencesSurvey.ScreenerSections[0].1000010UB",NAME,"MyProfile - TobaccoPreferences - DissolvableTobacco - 1"),
    drpdwn_TobaccoPreferencesDissolvable2("TobaccoPreferencesSurvey_ScreenerSections__0_1000011SOR",ID,"MyProfile - TobaccoPreferences - DissolvableTobacco - 2"),
    chckbox_TobaccoPreferencesDissolvable3("//input[@value='10001|DISSOLVABLE|1000015|10161']",XPATH,"MyProfile - TobaccoPreferences - last30daysPurchased"),
    btn_TobaccoPreferencesUpdateText("//span/span[contains(text(),'Answering the question above is required to continue')]",XPATH,"MyProfile - TobaccoPreferences - Update"),
    btn_TobaccoPreferencesUpdate("btnUpdateMySmokes",ID,"My Profile Page - Tobacco Preferences Section - Update Button"),
    errormsg_ProfileNoAddress("//li/span/span[contains(text(),'The Address Line 1 field is required.')]",XPATH,"MyProfile - No Address1"),
    errormsg_ProfileNoCity("//li/span/span[contains(text(),'The City field is required.')]",XPATH,"MyProfile - No City"),
    errormsg_ProfileNoZipcode("//li/span/span[contains(text(),'The Zip Code field is required.')]",XPATH,"MyProfile - No Zipcode"),
    errormsg_ProfileNoTobaccoPreferencesUpdate("//span/span[contains(text(),'Answering the question above is required to continue')]",XPATH,"MyProfile - No TobaccoPreferences"),
    
    errormsg_ProfileNoChallengeAnswer("//li/span/span[contains(text(),'The Challenge Answer field is required.')]",XPATH,"MyProfile - ChallengeAnswer not entered"),
    errormsg_ProfileNoCurrentPassword("//li/span/span[contains(text(),'The Current Password field is required.')]",XPATH,"MyProfile - CurrentPassword not entered"),
    errormsg_ProfileInvalidPasswordformatinNewPassword("//li/span/span[contains(text(),'Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.')]",XPATH,"Invalid Password format in NewPassword field"),
    errormsg_ProfileNoNewPassword("//li/span/span[contains(text(),'The New Password field is required.')]",XPATH,"MyProfile - NewPassword not entered"),
    errormsg_ProfileDifferentPassword("//li/span/span[contains(text(),'The New Password and Confirm New Password fields do not match.')]",XPATH,"MyProfile - Password doesnt match in NewPassword & ConfirmPassword fields"),
    errormsg_ProfileInactiveEmail("//li/span/span[contains(text(),'This is not an active email address. Please provide an active email address.')]",XPATH,"MyProfile - User entered Inactive email"),
    errormsg_ProfileInValidEmail("//li/span/span[contains(text(),'Please enter a valid email address')]",XPATH,"MyProfile - User entered InValid email"),
    errormsg_ProfileEnteredExistingEmail("//li/span/span[contains(text(),'User Name already taken. Please try a different one.')]",XPATH,"MyProfile - User entered Existing email"),


	
	
	
	
	
   
    
	;
	String strProperty = "";
   	ObjectLocator locatorType = null;
   	String strObjName = "";
   	
	@Override
	public String getProperty() {
		// TODO Auto-generated method stub
		return strProperty;
	}

	@Override
	public ObjectLocator getLocatorType() {
		// TODO Auto-generated method stub
		return locatorType;
	}

	@Override
	public String getObjectname() {
		// TODO Auto-generated method stub
		return strObjName;
	}
	
	private MobileSite_Accountlock_validationPageObjects (String strPropertyValue, ObjectLocator locatorType, String strObjName) {
		// TODO Auto-generated method stub
		this.strProperty = strPropertyValue;
   		this.locatorType = locatorType;
   		this.strObjName = strObjName;
		
	}
}
