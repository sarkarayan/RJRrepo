package com.rai.pageObjects;

import static com.rai.pageObjects.ObjectLocator.*;
public enum MobileSite_SPAPageObjects  implements PageObjects {

	spa_CouponPage_SGW("//img[@id='frmCouponsHome_imgseal']",XPATH,"SPA Coupon HomePage - SGW Image"),
	spa_CouponPage_Offer1("(//div[@id='flxOfferTile_flxOffer'])[1]",XPATH,"SPA Coupon HomePage - Offer1 section"),
	spa_CouponPage_Offer2("(//div[@id='flxOfferTile_flxOffer'])[2]",XPATH,"SPA Coupon HomePage - Offer2 section"),
	spa_CouponPage_ChooseaStore("//input[@id='flxOfferTile_btnchooseastore']",XPATH,"SPA Coupon HomePage - Choose a Store"),
	
	spa_StorelistPage_loadmore("//input[@id='frmStoreList_btnloadmore']",XPATH,"SPA StoreList Page - Loadmore button"),
	spa_StorelistPage_SGW("//img[@id='flxmaster_imgseal']",XPATH,"SPA Storelist Page - SGW Image"),
	spa_StorelistPage_ListView_MapIt1("(//div[@id='flxsegstoreitem_lblmapit'])[1]",XPATH,"SPA Storelist Page - ListView - MapIt 1st link"),
	spa_StorelistPage_ListView_MapIt2("(//div[@id='flxsegstoreitem_lblmapit'])[2]",XPATH,"SPA Storelist Page - ListView - MapIt 2nd link"),
	spa_StorelistPage_ListView_MapIt3("(//div[@id='flxsegstoreitem_lblmapit'])[3]",XPATH,"SPA Storelist Page - ListView - MapIt 3rd link"),
	spa_StorelistPage_ListView_MapIt4("(//div[@id='flxsegstoreitem_lblmapit'])[4]",XPATH,"SPA Storelist Page - ListView - MapIt 4th link"),
	spa_StorelistPage_Listview_Store1("(//div[@id='flxsegstoreitem_flxstoreinfo'])[1]",XPATH,"SPA Storelist Page - ListView - Store1"),
	spa_StorelistPage_Listview_Store2("(//div[@id='flxsegstoreitem_flxstoreinfo'])[2]",XPATH,"SPA Storelist Page - ListView - Store2"),
	spa_StorelistPage_Listview_Store3("(//div[@id='flxsegstoreitem_flxstoreinfo'])[3]",XPATH,"SPA Storelist Page - ListView - Store3"),
	spa_StorelistPage_Listview_Store4("(//div[@id='flxsegstoreitem_flxstoreinfo'])[4]",XPATH,"SPA Storelist Page - ListView - Store4"),
	spa_StorelistPage_MapView("//img[@id='frmStoreList_imgmap']",XPATH,"SPA - MapView"),
	spa_StorelistPage_ListView("//img[@id='frmStoreList_imglist']",XPATH,"SPA - ListView"),
	spa_StorelistPage_Searchbox("//input[@id='frmStoreList_txtzipcode']",XPATH,"SPA Storelist Page - Searchbox"),
	spa_StorelistPage_SearchIcon("//img[@id='frmStoreList_imgsearchlogo']",XPATH,"SPA Storelist Page - SearchIcon"),
	spa_StorelistPage_MapIt_MapPage_SGW("//img[@id='flxmaster_imgseal']",XPATH,"SPA Storelist Page - MapIt - MapPage"),
	spa_StorelistPage_MapIt_DirectionsPage_SGW("//img[@id='flxmaster_imgseal']",XPATH,"SPA Storelist Page - MapIt - DirectionsPage - SGWImage"),
	spa_StorelistPage_MapIt_DirectionsPage("///input[@id='frmMapPath_btnShowDirectionDetails']",XPATH,"SPA Storelist Page - MapIt - DirectionsPage"),
	spa_StorelistPage_MapIt_DirectionsPage_Back("//div[@id='frmDirectionDetails_lblBack']",XPATH,"SPA Storelist Page - MapIt - DirectionsPage - Back Icon"),
	
	
	spa_StoreDetailsPage_SGW("//img[@id='frmSelectStore_imgseal']",XPATH,"SPA StoreDetails Page - SGWImage"),
	spa_StoreDetailsPage_SearchIcon("//img[@id='frmSelectStore_imgsearchlogo']",XPATH,"SPA StoreDetails Page - SearchIcon"),
	spa_StoreDetailsPage_Searchbox("//input[@id='frmSelectStore_txtzipcode']",XPATH,"SPA StoreDetails Page - Searchbox"),
	spa_StoreDetailsPage_MapView("//input[@id='frmSelectStore_btnmapvieiwcon']",XPATH,"SPA StoreDetails Page - MapView"),
	spa_StoreDetailsPage_ListView("//img[@id='frmSelectStore_imglist']",XPATH,"SPA StoreDetails Page - ListView"),
	spa_StoreDetailsPage_MapIt("//div[@id='frmSelectStore_lblmapit']",XPATH,"SPA StoreDetails Page - MapIt"),
	spa_StoreDetailsPage_RedeemNow("//input[@id='frmSelectStore_btnredeemnow']",XPATH,"SPA StoreDetails Page - RedeemNow"),
	spa_StoreDetailsPage_NotNow("//input[@id='frmSelectStore_btnnotnow']",XPATH,"SPA StoreDetails Page - NotNow"),
	spa_StoreDetailsPage_MapIt_MapPage_SGW("//img[@id='flxmaster_imgseal']",XPATH,"SPA StoreDetails Page - MapIt - MapPage"),
	spa_StoreDetailsPage_MapIt_DirectionsPage_SGW("//img[@id='flxmaster_imgseal']",XPATH,"SPA StoreDetails Page - MapIt - DirectionsPage - SGWImage"),
	spa_StoreDetailsPage_MapIt_DirectionsPage("///input[@id='frmMapPath_btnShowDirectionDetails']",XPATH,"SPA StoreDetails Page - MapIt - DirectionsPage"),
	spa_StoreDetailSPage_MapIt_DirectionsPage_Back("//div[@id='frmDirectionDetails_lblBack']",XPATH,"SPA StoreDetails Page - MapIt - DirectionsPage - Back Icon"),
	
	;
	String strProperty = "";
   	ObjectLocator locatorType = null;
   	String strObjName = "";
   	
	@Override
	public String getProperty() {
		// TODO Auto-generated method stub
		return strProperty;
	}

	@Override
	public ObjectLocator getLocatorType() {
		// TODO Auto-generated method stub
		return locatorType;
	}

	@Override
	public String getObjectname() {
		// TODO Auto-generated method stub
		return strObjName;
	}
	
	private MobileSite_SPAPageObjects (String strPropertyValue, ObjectLocator locatorType, String strObjName) {
		// TODO Auto-generated method stub
		this.strProperty = strPropertyValue;
   		this.locatorType = locatorType;
   		this.strObjName = strObjName;
		
	}
}
