package com.rai.pageObjects;

import static com.rai.pageObjects.ObjectLocator.*;

public enum MobilesitePageObjects implements PageObjects {
	
		//LoginPage
	    btnSignInTab("//div[text()='Sign In' and @class='tab']",XPATH,"SPA - Login Page - Sign In tab"),
        txt_LoginUsername("//input[@name='Email']",XPATH,"Input - Username"),
        txt_LoginPassword("password",ID,"Input - Password"),
        chkbx_RememberMe("IsRememberUserChecked",ID,"RememberMe Checkbox LoginPage"),
        btn_Login("edit-submit",ID,"Button - Login"),
        btn_RegistrationRevel("//div[@class='tab'][text()='Register']",XPATH,"Button - Registration Mobileste view"),
        //btn_signupRevel("//div[@class='tab'][text()='Register']",XPATH,"Button - Registration Mobileste view"),
		btn_Registration("redirect_register",ID,"Button - Registration"),
		lnktxt_Forgetusername("//a[contains(text(),'Forgot Username?')]",XPATH,"Link - ForgotUsername"),
		lnktxt_Forgotpassword("//a[contains(text(),'Forgot Password?')]",XPATH,"Link - ForgotPassword"),
		lnktxt_RevelVeloForgotUsername("//a[contains(text(),'Username')]",XPATH,"Revel&Velo - ForgotUsername link on Login page"),
		lnktxt_RevelVeloForgotPassword("//a[contains(text(),'Password')]",XPATH,"Revel&Velo - ForgotPassword link on Login page"),
		chkbx_RevelVelo_RememberMe("//label[contains(text(),'Remember Me')]",XPATH,"Revel&Velo - RememberMe checkbox"),
		
		
		errormsg_LoginwithoutanyData("usernameError",ID,"Login with no data"),   //Please Provide a Username / Email Address.
		errormsg_LoginwithNonExistingUserId("loginError",ID,"Login with non-existing UserId"),   //Username Does Not Exist.
		errormsg_Usernamefieldformaterror("formatError",ID,"UserID with unaccepted characters on LoginPage"), //Username must be a combination of 8-30 letters and numbers.
		
		//AccountLock
		errormsg_WrongPasswrd("loginError",ID,"Entered wrong password"),    //Username and Password do not match.
		errormsg_Accountlocked("loginError",ID,"Accountlocked after entering Invliad password for 4times"),   //Username and password do not match. account now locked. Click 		
		lnk_LockedAccntResetlink("//a[@href='/Security/GetPassword']",XPATH,"Reset link for Locked Account"),
		errormsg_AlreadylockedAccount("loginError",ID,"Already Account Locked message"),
		
		forgotUsername_usernotfoundPage("userNotFoundError",ID,"ForgotUsername - Usernotfound page"),
	    gotoRegistration_UsernotfoundPage("(//a[@class='button registerLink'])[2]",XPATH,"Usernotfound page - GotoRegistration button"),
		
	    loginLnk_VUSECertifyAgePage("//a[contains(text(),'Login')]",XPATH,"VUSE - Login link on Age Certify Page"),
		txt_VUSELoginUsername("email",ID,"VUSE - Login - Username"),
		txt_VUSELoginPassword("pass",ID,"VUSE - Login - Password"),
		
		chkbox_VUSELoginRememberMe("rememberEmail",ID,"VUSE Login - RememeberMe"),
		btn_VUSELogin("//button[@name='send']",XPATH,"VUSE - Login button"),
		lnk_VUSELoginForgotUsername("//p/a[contains(text(),'Username')]",XPATH,"VUSE - Input Username"),
		lnk_VUSELoginForgotPassword("//p/a[contains(text(),'Password')]",XPATH,"VUSE - Input Password"),
		header_VUSECreateAccount("//h2/a[contains(text(),'create an account')]",XPATH,"VUSE LoginPage - CreateAccount header"),
		header_VUSELogin("//div/h2[contains(text(),'login')]",XPATH,"VUSE LoginPage - Login header"),
		
		errormsg_VUSELoginwithoutanyDataUsername("email-error",ID,"Login with no data"),   //Please enter your username
		errormsg_VUSELoginwithoutanyDataPassword("pass-error",ID,"Login with no data"),    //Please enter your password
		errormsg_VUSELoginwithNonExistingUserId("//div/span[contains(text(),'Username does not exist.')]",XPATH,"Login with non-existing UserId"),   //Username does not exist.
		errormsg_VUSEUsernamefieldformaterror("//div/span[contains(text(),'Username does not exist.')]",XPATH,"UserID with unaccepted characters on LoginPage"), //Username does not exist.
		
		errormsg_VUSELoginWrongPassword("//div/span[contains(text(),'Login or Password incorrect')]",XPATH,"VUSELogin - user entered InvalidPassword"),   //Login or Password incorrect
		errormsg_VUSEAccountLocked("//div/span[contains(text(),'Username or password incorrect, account now locked.')]",XPATH,"VUSELogin - AccountLocked"),   //Username or password incorrect, account now locked. Click
		lnk_VUSEAccntResetlink("//span/a[contains(text(),'here')]",XPATH,"VUSELogin - Reset link for locked Account"),
		
		
		
		
		//Registration - Step 1
		btn_Step1Next("next-intro",ID,"Button - Step1 Next"),
		drpdwn_BirthMonth("UserInformation_BirthMonth",ID,"Dropdown - BirthMonth"),
		drpdwn_BirthDay("UserInformation.BirthDay",NAME,"Dropdown - BirthDay"),
		drpdwn_BirthYear("UserInformation_BirthYear",ID,"Dropdown - BirthYear"),
		drpdwn_BirthYearIndex("//div/select[@id='UserInformation_BirthYear']",XPATH,"Dropdown - BirthYear"),
		txt_FirstName("UserInformation.FirstName",NAME,"Input - FirstName"),
		txt_LastName("UserInformation_LastName",ID,"Input - LastName"),
		txt_Address("UserInformation.AddressLine1",NAME,"Input - Address"),
		txt_Zipcode("UserInformation_ZipCode",ID,"Input - Zipcode"),
		txt_City("UserInformation_City",ID,"Input - City"),
		drpdwn_State("UserInformation_State",ID,"State"),
		txt_Email("UserInformation_EmailAddress",ID,"Input - Email"),
		txt_PhoneRevelVelo("//input[@name='UserInformation.Phone']",XPATH,"Input - PhoneNumber"),
		radiobtn_GenderMaleRevel("//label[contains(text(),'Male')]",XPATH,"Radiobutton - Male Gender - Revel"),
		radiobtn_GenderFemaleRevel("//label[contains(text(),'Female')]",XPATH,"Radiobutton - Female Gender - Revel"),
        chkbx_CertifyRevelVelo("//label[@class='fieldNote']",XPATH,"Checkbox Certify - Revel"),
        
		Chkbx_Certify("//input[@class='form-checkbox']",XPATH,"Checkbox"),
		errmsg_Step1("//div[@class='errorText formError']",XPATH,"Error message - Step1"),
		
		errormsg_RegistrationNoDOB("dobError",ID,"Errormsg - No DOB data on Step1 Registrationpage"),     //Please provide your full date of birth
		errormsg_RegistrationNoLegalName("nameError",ID,"Errormsg - No LegalName data on Step1 Registrationpage"),  //Please enter your legal name
		errormsg_RegistrationNoAddress("streetAddressError",ID,"Errormsg - No Addressdata on Step1 Registrationpage"),     //Please provide a street address
		errormsg_RegistrationNoZipcode("zipCodeError",ID,"Errormsg - No Zipcode on Step1 Registrationpage"),               //Please provide a ZIP Code
		errormsg_RegistrationNoCity("cityError",ID,"Errormsg - No City data on Step1 Registrationpage"),                   //Please Provide City
		errormsg_RegistrationNoState("stateError",ID,"Errormsg - No State data on Step1 Registrationpage"),              //Please Provide State
		errormsg_RegistrationNoEmail("emailError",ID,"Errormsg - No Email data on Step1 Registrationpage"),            //Please enter a valid email address
		errormsg_RegistrationNoDataonStep1Page("//div[@id='intro']/div/div[@class='errorText formError']",XPATH,"Errormsg - No data on Step1 Registration Page"),    //Please fix the errors above
		
		errormsg_RegistrationInvalidEmail("emailError",ID,"Errormsg - User entered InvalidEmail on Registration Step1 page"),
		erromsg_RegistrationInactiveEmail("//span[@id='UserInformation_EmailAddress-error']",XPATH,"Errormsg - User entered InactiveEmail on Registration Step1 page"),     //This is not an active email address. Please provide an active email address.
		errormsg_RegistrationAlreadyExistingEmail("//span[@id='UserInformation_EmailAddress-error']",XPATH,"Errormsg - User entered AlreadyExisting email on Registration Step1 page"),     //User Name already taken. Please try a different one.
		
		//Step 2
		txt_Password("UserInformation_Password",ID,"Input-Password"),
		txt_ConfirmPassword("UserInformation.ConfirmPassword",NAME,"Input - ConfirmPassword"),
		drpdwn_ChallengeQuestion("UserInformation_ChallengeQuestionId",ID,"Input - ChallengeQuestion"),
		txt_ChallengeAnswer("UserInformation_ChallengeAnswer",ID,"Input - ChallengeAnswer"),
		btn_Step2Next("continue-verification",ID,"Button - Step2 Next"),
		
		errormsg_RegistrationNoPassword("passwordError",ID,"Errormsg - No Password data on Step2 Registrationpage"),        //Please provide a password
		errormsg_RegistrationNoChallengeQuestion("questionError",ID,"Errormsg - No ChallengeQuestion on Step2 RegistrationPage"),                //Please select a account recovery question
		errormsg_RegistrationNoChallengeAnswer("answerError",ID,"Errormsg - No ChallengeAnswer on Step2 RegistrationPage"),             //Please provide an answer to account recovery question
		errormsg_RegistrationNoDataonStep2Page("//div[@id='acctInfo']/div/div/div/div[@class='errorText formError']",XPATH,"Errormsg - No data on Step2 Registration Page"),    //Please fix the errors above
		errormsg_RegistrationIncorrectPasswordformat("passwordFormatError",ID,"Errormsg - InvalidPassword format on Step2 RegistrationPage"),      //Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.
		errormsg_RegistrationDifferentPasswordsentered("passwordConfirmError",ID,"Errormsg - Diff.data entered in Password & ConfirmPassword on Step2 RegistrationPage"),       //Passwords did not match
		
		//Step 3
		radiobtn_KBA("//div[@id='edit-kba']/div/span",XPATH,"Radiobutton - KBA"),
		radiobtn_SSN("//div[@id='edit-ssn']/div/span",XPATH,"Radiobutton - SSN"),
		txt_SSN("ssn[KbaSSN]",NAME,"Input - SSN"),
		btn_Submit("ssnbutton",ID,"Button - Step3 Submit"),		
		txt_onlySSNvisible("//div/input[@id='UserInformation_NoKBASSN']",XPATH,"Only SSN text field visible on VerifyIdentity page"),
		btn_SubmitwhenonlySSNVisible("//div/button[@id='ssnnokbabutton']",XPATH,"Submit button when only SSN is visible"),
		txt_SSNonUnabletoVerifyPage("//div/input[@id='UserInformation_prevSSN']",XPATH,"SSN text on UnabletoVerify page"),
		btn_SubmitonUnabletoVerifyPage("//div/button[@id='ssnunableverify']",XPATH,"Submit button on UnabletoVerify page"),
		btn_AgeVerificationFailedReturntoSignIn("//a[contains(text(),'Return to Sign In Page')]",XPATH,"ReturntoSignIn button - AgeVerificationFailed"),
		
		errormsg_RegistrationInvalidSSN("ssnVerifyError",ID,"Errormsg - IncorrectSSN entered on VerifyIdentity page"),       //Your Social Security Number does not match your name and date of birth. Please try again.
		erroMsg_RegistrationInvaliSSNNoKBA("ssnNoKBAVerifyError",ID,"Errormsg - IncorrectSSN entered on VerifyIdentity page"),	//(No KBA) Your Social Security Number does not match your name and date of birth. Please try again.
		//Congrats Page
		link_takemetoSite("take_me_to_site",ID,"Link - take me to site"),
		
		//Already Registered Page
		txt_AlreadyRegisteredUsername("username",ID,"Input - AlreadyRegistered - Username"),
		txt_AlreadyRegisteredPassword("password",ID,"Input - AlreadyRegistered - Password"),
		chkbox_AlreadyRegisteredRememberMe("IsRememberUserChecked",ID,"Checkbox - AlreadyRegistered - RememberMe"),
		lnk_AlreadyRegisteredForgotUsername("//a[@href='/Security/ForgotLoginId']",XPATH,"ForgotUsername link - AlreadyRegistered"),
		lnk_AlreadyRegisteredForgotPassword("//a[@href='/Security/GetPassword']",XPATH,"ForgotPassword link - AlreadyRegistered"),
		btn_AlreadyRegisteredLogin("edit-submit",ID,"Login - AlreadyRegistered"),
		
		errmsg_AlreadyRegisteredPage("//div[@class='form-header security-msg']/p",XPATH,"Already Registered Page"),
		
		
		
		 //VUSE Profile
	     
	     //PostLoginVUSE_MyAccount("//ul/li/div/a[@class='my-account link']",XPATH,"PostLogin - VUSE - AccountIcon"),
	    //PostLoginVUSE_MyAccountlink("//div/ul/li/a[contains(text(),'My Account')]",XPATH,"VUSE PostLogin - MyAccountLink"),
	    //PostLoginVUSE_LogOut("//div/ul/li/a[contains(text(),'Log Out')]",XPATH,"PostLogin - VUSE - LogOut"),
	    PostLoginVUSE_AddressBook("//nav/ul/li/a[contains(text(),'Address Book')]",XPATH,"PostLogin - Menu - AddressBook"),
	    btnEdit_ProfileVUSE_BillingAddress("(//span[@class='icon icon--edit'])[1]",XPATH,"VUSEProfile - Edit - BillingAddress"),
	    btnEdit_ProfileVUSE_ShippingAddress("(//span[@class='icon icon--edit'])[2]",XPATH,"VUSEProfile - Edit - ShippingAddress"),
	    btn_ProfileVUSE_AddNewAddress("//div/button/span[contains(text(),'Add New Address')]",XPATH,"VUSEProfile - AddressBook - Add New Address"),
	    txt_VUSEProfile_BillingAddress_FirstName("//div/input[@id='firstname']",XPATH,"VUSE Profile - BillingAddress - FirstName"),
	    txt_VUSEProfile_BillingAddress_LastName("//div/input[@id='lastname']",XPATH,"VUSE Profile - BillingAddress - LastName"),
	    txt_VUSEProfile_BillingAddress_Telephone("//input[@id='telephone']",XPATH,"VUSE Profile - BillingAddress - Telephone"),
	    txt_VUSEProfile_BillingAddress_Address("//input[@title='Street Address']",XPATH,"VUSE Profile - BillingAddress - Address"),
	    txt_VUSEProfile_BillingAddress_Zipcode("//div/input[@id='postcode']",XPATH,"VUSE Profile - BillingAddress - Zipcode"),
	    btn_VUSEProfile_BillingAddress_Save("//div/button[contains(text(),'Save Address')]",XPATH,"VUSEProfile - BillingAddress - SaveAddress"),
	    btn_VUSEProfile_BillingAddress_Cancel("//div/a[contains(text(),'Cancel')]",XPATH,"VUSEProfile - BillingAddress - Cancel"),
	    
	    errormsg_VUSE_BillingAddress_NoTelephone("//div[@id='telephone-error']",XPATH,"VUSEProfile - BillingAddress - No Telephone"),
	    errormsg_VUSE_BillingAddress_NoAddress1("//div[@id='street_1-error']",XPATH,"VUSEProfile - BillingAddress - No Address"),
	    errormsg_VUSE_BillingAddress_NoZipcode("//div[@id='postcode-error']",XPATH,"VUSEProfile - BillingAddress - No Zipcode"),
	    errormsg_VUSE_BillingAddress_NoCity("//div[@id='city-error']",XPATH,"VUSEProfile - BillingAddress - No City"),
	    
		
	
	    //Forgot Username
	    drpdwn_ForgotUsernameBirthMonth("BirthMonth",ID,"Dropdown - UsernameBirthMonth"),
	    drpdwn_ForgotUsernameBirthDay("BirthDay",ID,"Dropdown - UsernameBirthDay"),
	    drpdwn_ForgotUsernameBirthYear("BirthYear",ID,"Dropdown - UsernameBirthYear"),
	    txt_ForgotUsernameFirstName("FirstName",ID,"Input - FirstName"),
	    txt_ForgotUsernameLastName("LastName",ID,"Input - LastName"),
	    txt_ForgotUsernameAddress("AddressLine1",ID,"Input - Address"),
	    txt_ForgotUsernameZipcode("ZipCode",ID,"Input - Zipcode"),
	    txt_ForgotUsernameCity("City",ID,"Input - City"),
	    drpdwn_ForgotUsernameState("State",ID,"Dropdown - State"),
	    btn_ForgotUsernameAccountInformation("next_UserInformation",ID,"Button - ContinueStep1"),
	    txt_ForgotUsernameChallengeAnswer("ChallengeAnswer",ID,"Input - ChallengeAnswer"),
	    btn_ForgotUsernameVerifyIdentity("next_AnswerChallengeQuestion",ID,"Button - VerifyIdentity"),
	    txt_WelcomeBackPassword("password",ID,"Input - PasswordonWelcomeBack"),
	    chkbox_WelcomeBackRememberMe("IsRememberUserChecked",ID,"Checkbox - RememberMe"),
	    lnk_WelcomeBackResetPassword("//a[@href='/Security/GetPassword']",XPATH,"Link - ResetYourPassword"),
	    btn_WelcomBackLogin("edit-submit",ID,"Button - Login"),
	    
	    errormsg_ForgotUsernameUsernotfound("userNotFoundDiv",ID,"Errormsg - Usernotfound ForgotUsername"),                //errormsg - We were not able to find your information. Please check and try again.
	    errormsg_ForgotUsernameNoDataonGeneralInfo("//div[@class='errorText formError']",XPATH,"Errormsg - NoProfileInfo entered - ForgotUsername"),    //Please fix the errors above
	    errormsg_ForgotUsernameNoDOB("dobError",ID,"Errormsg - No DOB data on GeneralInfo page - ForgotUsername"),   //Please provide a Date Of Birth
        errormsg_ForgotUsernameNoLegalName("nameError",ID,"Errormsg - No LegalName on GeneralInfo page - ForgotUsername"),  //Please enter your legal name"
        errormsg_ForgotUsernameNoAddress("streetAddressError",ID,"Errormsg - No Address on GeneralInfo page - ForgotUsername"),   //Please provide a street address
        errormsg_ForgotUsernameNoZipcode("zipCodeError",ID,"Errormsg - No Zipcode data on GeneralInfo page - ForgotUsername"),   //Please provide a ZIP Code
        errormsg_ForgotUsernameNoCity("cityError",ID,"Errormsg - No City data on GeneralInfo page - ForgotUsername"),           //Please Provide City
        errormsg_ForgotUsernameNoState("stateError",ID,"Errormsg - No State data on GeneralInfo page - ForgotUsername"),   //Please Provide State
	    errormsg_ForgotUsernamenoChallengeAnswer("answerError",ID,"Errormsg - NoChallengeAnswer entered ForgotUsername"),  //Please provide an answer to account recovery question
	    errormsg_ForgotUsernameInvalidAnswer("answerMatchError",ID,"Errormsg - InvalidAnswer ForgotUsername"),             //The answer does not match our records. Please re-enter your answer to the account recovery question
	    errormsg_WelcomeBackNoPassword("passwordError",ID,"Errormsg - WelcomeBackPage with no Password - ForgotUsername"), //Please enter your password.
	    errormsg_WelcomeBackInvalidPassword("loginError",ID,"Errormsg - WelcomeBackPage with Invalid Password - ForgotUsername"), //Username and password do not match.
	    
	
	    //Forgot Password
	    txt_ForgotPasswordUsername("userId",ID,"Input - Username"),
	    btn_ForgotPasswordUsernameContinue("edit-submit",ID,"Button - Continue"),
	    Lnk_ForgotPasswordForgotUsername("//a[@href='/Security/ForgotLoginId']",XPATH,"Link - ForgotUsername"),
	    drpdwn_ForgotPasswordBirthMonth("BirthMonth",ID,"Dropdown - PasswordBirthMonth"),
	    drpdwn_ForgotPasswordBirthDay("BirthDay",ID,"Dropdown - PasswordBirthDay"),
	    drpdwn_ForgotPasswordBirthYear("BirthYear",ID,"Dropdown - PasswordBirthYear"),
	    txt_ForgotPasswordFirstName("FirstName",ID,"Input - FirstName"),
	    txt_ForgotPasswordLastName("LastName",ID,"Input - LastName"),
	    txt_ForgotPasswordAddress("AddressLine1",ID,"Input - Address"),
	    txt_ForgotPasswordZipcode("ZipCode",ID,"Input - Zipcode"),
	    txt_ForgotPasswordCity("City",ID,"Input - City"),
	    drpdwn_ForgotPasswordState("State",ID,"Dropdown - State"),
	    btn_ForgotPasswordGeneralInformation("//div//input[@id='edit-submit']",XPATH,"Button - Continue"),
	    lnk_ForgotPasswordGeneralInfoLogin("//a[contains(text(),'Go to Login')]",XPATH,"Link - Goto Login"),
	    txt_ForgotPasswordChallengeAnswer("ChallengeAnswer",ID,"Input - ChallengeAnswer"),
	    btn_ForgotPasswordVerifyIdentity("edit-submit",ID,"Button - verifyIdentity"),
	    txt_ForgotPasswordPassword("inputPassword",ID,"Input - Password"),
	    txt_ForgotPasswordConfirmPassword("inputPasswordConfirm",ID,"Input - ConfirmPassword"),
	    btn_ForgotPasswordResetPassword("edit-submit",ID,"Button - Next"),
	    txt_CongratsPageUsername("username",ID,"Input - Username"),
	    txt_CongratsPagePassword("password",ID,"Input - Password"),
	    chkbox_CongratspageRememberMe("IsRememberUserChecked",ID,"Checkbox - RememberMe"),
	    lnk_CongratsPageForgotUsername("//a[@href='/Security/ForgotLoginId\']",XPATH,"Link - ForgotUsername"),
	    lnk_CongratsPageForgotPassword("//a[@href='/Security/GetPassword\']",XPATH,"Link - ForgotPassword"),
	    btn_CongratsPageLoginbutton("edit-submit",ID,"Button - Login"),
	    
	    errormsg_ForgotPasswordNoUsername("userIdError",ID,"Errormsg - NoUsername entered - ForgotPassword"),     //Please enter your Username / Email Address.
	    errormsg_ForgotPasswordInvalidUserIdformat("formatError",ID,"Erromsg - InvalidUserId format - ForgotPassword"),     //Username must be a combination of 8-30 letters and numbers.
	    errormsg_ForgotPasswordInvalidUserId("//div[@id='answerMatchError']",XPATH,"Errormsg - InvalidUserId - ForgotPassword"),    //We could not locate your Login ID, please try again.
	    errormsg_ForgotPasswordNoDataonGeneralInfo("//div[@class='errorText formError']",XPATH,"Errormsg - NoProfileInfo entered - ForgotPassword"),    //Please fix the errors above
	    errormsg_ForgotPasswordNoDOB("dobError",ID,"Errormsg - No DOB data on GeneralInfo page - ForgotPassword"),   //Please provide a Date Of Birth
        errormsg_ForgotPasswordNoLegalName("nameError",ID,"Errormsg - No LegalName on GeneralInfo page - ForgotPassword"),  //Please enter your legal name"
        errormsg_ForgotPasswordNoAddress("streetAddressError",ID,"Errormsg - No Address on GeneralInfo page - ForgotPassword"),   //Please provide a street address
        errormsg_ForgotPasswordNoZipcode("zipCodeError",ID,"Errormsg - No Zipcode data on GeneralInfo page - ForgotPassword"),   //Please provide a ZIP Code
        errormsg_ForgotPasswordNoCity("cityError",ID,"Errormsg - No City data on GeneralInfo page - ForgotPassword"),           //Please Provide City
        errormsg_ForgotPasswordNoState("stateError",ID,"Errormsg - No State data on GeneralInfo page - ForgotPassword"),   //Please Provide State
        errormsg_ForgotPasswordUsernotfound("userNotFoundDiv",ID,"Errormsg - Usernotfound ForgotPassword"),     //We were not able to find your information. Please check and try again.
	    errormsg_ForgotPasswordNoChallengeAnswer("answerError",ID,"Errormsg - NoChallengeAnswer entered ForgotPassword"),     //Please provide an answer to account recovery question
	    errormsg_ForgotPasswordInvalidChallengeAnswer("answerMatchError",ID,"Errormsg - InvalidAnswer ForgotPassword"),       //The answer does not match our records. Please re-enter your answer to the challenge question
	    errormsg_ForgotPasswordNoPasswordentered("passwordError",ID,"Errormsg - NoPasswordEntered ForgotPassword"),      //Please provide a password
	    errormsg_ForgotPasswordInvalidPasswordformatentered("passwordFormatError",ID,"Errormsg - InvalidPasswordformatEntered ForgotPassword"),   //Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.
	    errormsg_ForgotPasswordDifferentPasswordentered("passwordConfirmError",ID,"Errormsg - DifferentPasswordEntered ForgotPassword"),     //Passwords did not match
	    errormsg_ForgotPasswordCongratsPageNoDataEntered("//div[@class='errorText formError']",XPATH,"Errormsg - CongratsPage with no data - ForgotPassword"),    //Please fix the errors above
	    errormsg_ForgotPasswordCongratsPagePasswordNotentered("passwordError",ID,"Errormsg - CongratsPage with NoPasswordEntered - ForgotPassword"),      //Please enter your password.
	    forgotPassword_UsernotfoundPage("//div[contains(text(),'USER NOT FOUND/VERIFIED')]",XPATH,"ForgotPassword - Usernotfound Page"),   //clss='headline'
	    forgotPassword_UsernotfoundPage_gotoRegistration("//a[@class='button registerLink']",XPATH,"Usernotfound page - GotoRegistration button"),
	    
	    	
	    //Profile 
	    //lnk_MyAccount("//*[@id='main']/header/nav/a[6]",XPATH,"MyAccount Link - Homepage"),
	    lnk_CamelMyAccount("//nav/a[@href='/profile/linkout']",XPATH,"MyAccount Link - Camel Homepage"),
	    lnk_GrizzlyMyAccount("//span/a[contains(text(),'Profile')]",XPATH,"MyAccount Link - Grizzly Homepage"),
	    btn_GrizzlyUpdateInfo("//a/button[contains(text(),'Update Your Contact Information')]",XPATH,"UpdateInformation button - Profile HomePage"),
	    lnk_NewportMyAccount("//li/a[contains(text(),'Profile')]",XPATH,"MyAccount Link - Newport Homepage"),
	    lnk_NASCIGSProfile("//nav/a[contains(text(),'Profile')]",XPATH,"PostLogin - NASCIGS Profile footerlink"),
	    lnk_PallmallProfile("//div/a[@href='/myprofile']",XPATH,"MyAccount Link - Pallmall Homepage"),
	    Btn_Revelmenu("//div[@class='hamburger-box']",XPATH,"Menu Button - Revel Menu Button"),
	    
	    btn_ProfileUserInfo("tabUserInformation",ID,"Button - ProfileUserInformation"),
	    btn_ProfileTobaccoPreferences("tabMySmokes",ID,"Button - ProfileTobaccoPreferences"),
	    btn_ProfileContentPreferences("tabMyCp",ID,"Button - ProfileContentPreferences"),
	    txt_ProfileAddressLine1("UserInformation_AddressLine1",ID,"Input - ProfileAddressLine1"),
	    txt_ProfileCity("UserInformation_City",ID,"Input - ProfileCity"),
	    txt_ProfileZipcode("UserInformation_ZipCode",ID,"Input - ProfileZipcode"),
	    txt_ProfileNewEmail("NewEmailAddress",ID,"Input - NewEmail"),
	    txt_ProfileConfirmEmail("ConfirmNewEmailAddress",ID,"Input - ConfirmEmail"),
	    btn_ProfileUpdateInfo("btnUpdateUserInfo",ID,"Button - UpdateEmail&Permission"),
	    txt_ProfileCurrentPassword("CurrentPassword",ID,"Input - CurrentPassword"),
	    txt_ProfileNewPassword("NewPassword",ID,"Input - NewPassword"),
	    txt_ProfileConfirmNewPassword("ConfirmNewPassword",ID,"Input - ConfirmNewPassword"),
	    btn_ProfileUpdatePassword("btnUpdatePassword",ID,"Button - UpdatePassword"),
	    drpdwn_ProfileChallengeQuestion("ChallengeQuestion",ID,"Dropdown - ChallengeQuestion"),
	    txt_ProfileChallengeAnswer("ChallengeAnswer",ID,"Input - ChallengeAnswer"),
	    btn_ProfileUpdateChallengeQuestion("//input[@id='btnUpdateChallengeQA']",XPATH,"Button - ChallengeQuestion"),
	    btn_ProfileBacktoSite("//img[@src='/themes/custom/rjr_theme/images/Btn_BackToSite.jpg']",XPATH,"Button - Backtosite"),
	    
	    chckbox_TobaccoPreferencesCombustible("//input[@value='10001|aPROD CATEGORY|1000001|10001']",XPATH,"MyProfile - TobaccoPreferences - Combustible"),
	    chckbox_TobaccoPreferencesMoistSnuff("//input[@value='10001|aPROD CATEGORY|1000001|10002']",XPATH,"MyProfile - TobaccoPreferences - MoistSnuff"),
	    chckbox_TobaccoPreferencesVapor("//input[@value='10001|aPROD CATEGORY|1000001|10003']",XPATH,"MyProfile - TobaccoPreferences - Vapor"),
	    chckbox_TobaccoPreferencesSNUS("//input[@value='10001|aPROD CATEGORY|1000001|10004']",XPATH,"MyProfile - TobaccoPreferences - SNUS"),
	    chckbox_TobaccoPreferencesDissolvableTobacco("//input[@value='10001|aPROD CATEGORY|1000001|10005']",XPATH,"MyProfile - TobaccoPreferences - DissolvableTobacco"),
	    drpdwn_TobaccoPreferencesDissolvable1("TobaccoPreferencesSurvey.ScreenerSections[0].1000010UB",NAME,"MyProfile - TobaccoPreferences - DissolvableTobacco - 1"),
	    drpdwn_TobaccoPreferencesDissolvable2("TobaccoPreferencesSurvey_ScreenerSections__0_1000011SOR",ID,"MyProfile - TobaccoPreferences - DissolvableTobacco - 2"),
	    chckbox_TobaccoPreferencesDissolvable3("//input[@value='10001|DISSOLVABLE|1000015|10161']",XPATH,"MyProfile - TobaccoPreferences - last30daysPurchased"),
	    btn_TobaccoPreferencesUpdateText("//span/span[contains(text(),'Answering the question above is required to continue')]",XPATH,"MyProfile - TobaccoPreferences - Update"),
	    btn_TobaccoPreferencesUpdate("btnUpdateMySmokes",ID,"My Profile Page - Tobacco Preferences Section - Update Button"),
	    errormsg_ProfileNoAddress("//li/span/span[contains(text(),'The Address Line 1 field is required.')]",XPATH,"MyProfile - No Address1"),
	    errormsg_ProfileNoCity("//li/span/span[contains(text(),'The City field is required.')]",XPATH,"MyProfile - No City"),
	    errormsg_ProfileNoZipcode("//li/span/span[contains(text(),'The Zip Code field is required.')]",XPATH,"MyProfile - No Zipcode"),
	    errormsg_ProfileNoTobaccoPreferencesUpdate("//span/span[contains(text(),'Answering the question above is required to continue')]",XPATH,"MyProfile - No TobaccoPreferences"),
	    
	    errormsg_ProfileNoChallengeAnswer("//li/span/span[contains(text(),'The Challenge Answer field is required.')]",XPATH,"MyProfile - ChallengeAnswer not entered"),
	    errormsg_ProfileNoCurrentPassword("//li/span/span[contains(text(),'The Current Password field is required.')]",XPATH,"MyProfile - CurrentPassword not entered"),
	    errormsg_ProfileInvalidPasswordformatinNewPassword("//li/span/span[contains(text(),'Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.')]",XPATH,"Invalid Password format in NewPassword field"),
	    errormsg_ProfileNoNewPassword("//li/span/span[contains(text(),'The New Password field is required.')]",XPATH,"MyProfile - NewPassword not entered"),
	    errormsg_ProfileDifferentPassword("//li/span/span[contains(text(),'The New Password and Confirm New Password fields do not match.')]",XPATH,"MyProfile - Password doesnt match in NewPassword & ConfirmPassword fields"),
	    errormsg_ProfileInactiveEmail("//li/span/span[contains(text(),'This is not an active email address. Please provide an active email address.')]",XPATH,"MyProfile - User entered Inactive email"),
	    errormsg_ProfileInValidEmail("//li/span/span[contains(text(),'Please enter a valid email address')]",XPATH,"MyProfile - User entered InValid email"),
	    errormsg_ProfileEnteredExistingEmail("//li/span/span[contains(text(),'User Name already taken. Please try a different one.')]",XPATH,"MyProfile - User entered Existing email"),
	
	
	     //PreLogin - Camel,Pallmall and Newport Footerlinks
			PreLoginfooterlnk_FAQs("//div[@class='footer reg']/div[@class='footer-fullsize']/div/nav/div/a[@href='/FooterLinks/Faqs']",XPATH,"PreLogin - FAQs footerlink"),
			PreLoginfooterlnk_ContactUs("//div[@class='footer reg']/div[@class='footer-fullsize']/div/nav/div/a[@href='/FooterLinks/ContactUs']",XPATH,"PreLogin - ContactUs footerlink"),
			PreLoginfooterlnk_TobaccoRights("//div[@class='footer reg']/div[@class='footer-fullsize']/div/nav/div/a[@href='https://ownitvoiceit.com/']",XPATH,"PreLogin - TobaccoRights"),
			PreLoginfooterlnk_SiteRequrmnts("//div[@class='footer-fullsize']/div/nav/div/a[@href='/FooterLinks/SiteRequirements']",XPATH,"PreLogin - SiteRequirements"),
			PreLoginfooterlnk_AgeFiltering("//div[@class='footer-fullsize']/div/nav/div/a[@href='/FooterLinks/AgeFilteringSoftware']",XPATH,"PreLogin - AgeFiltering"),
			PreLoginfooterlnk_TermsOfUse("//div[@class='footer-fullsize']/div/nav/div/a[@href='/FooterLinks/TermsOfUse']",XPATH,"PreLogin - TermsOfUse"),
			PreLoginfooterlnk_PrivacyPolicy("//div[@class='footer-fullsize']/div/nav/div/a[@href='/FooterLinks/PrivacyPolicy']",XPATH,"PreLogin - PrivacyPolicy"),
			PreLoginfooterlnk_TermsOfUse_Restrictions("(//h2[@id='restrictions_mobile']/div/span/a[contains(text(),'restrictions on access and use')])",XPATH,"PreLogin - TermsOfUse - Restrictions Content"),
			PreLoginfooterlnk_TermsOfUse_Restrictions_backtoTop("(//div[@id='restrictions']/span[@class='mobile']/a[contains(text(),'Back to Top')])",XPATH,"PreLogin - TermsOfUse - RestrictionsContent - BacktoTop"),
			Preloginfooterlnk_TermsOfUse_YourStuff("(//h2/div/span/a[contains(text(),'your stuff')])",XPATH,"PreLogin - TermsOfUse - YourStuff Content"),
			Preloginfooterlnk_TermsOfUse_YourStuff_backtoTop("//div[@id='your_stuff']/span[@class='mobile']/a[contains(text(),'Back to Top')]",XPATH,"PreLogin - TermsOfUse - YourStuff Content - BacktoTop"),
			PreLoginfooterlnk_TermsOfUse_ChoiceOfLaw("(//h2//span/a[contains(text(),'choice of law')])",XPATH,"PreLogin - TermsOfUse - ChoiceOfLaw"),
			Preloginfooterlnk_TermsOfUse_ChoiceOfLaw_backtoTop("(//div[@id='Choice of law']/span[@class='mobile']/a[contains(text(),'Back to Top')])",XPATH,"PreLogin - TermsOfUse - ChoiceOfLaw Content - BacktoTop"),
			PreLoginfooterlnk_TermsOfUse_ResolvingDisputes("//h2//span/a[contains(text(),'resolving disputes')]",XPATH,"PreLogin - TermsOfUse - ResolvingDisputes"),
			PreLoginfooterlnk_TermsOfUse_ResolvingDisputes_backtoTop("(//div[@id='resolving_disputes']/span[@class='mobile']/a[contains(text(),'Back to Top')])",XPATH,"PreLogin - TermsOfUse - ResolvingDisputes Content - BacktoTop"),
			PreLoginfooterlnk_TermsOfUse_Miscellaneous("(//h2//span/a[contains(text(),'miscellaneous')])",XPATH,"PreLogin - TermsOfUse - Miscellaneous"),
			PreLoginfooterlnk_TermsOfUse_Miscellaneous_backtoTop("(//div[@id='miscellaneous']/span[@class='mobile']/a[contains(text(),'Back to Top')])",XPATH,"PreLogin - TermsOfUse - Miscellaneous Content - BacktoTop"),
			
			PreLoginfooterlnk_PrivacyPolicy_WhatwecollectandHow("//h2/a[contains(text(),'What We Collect and How')]",XPATH,"PreLogin - PrivacyPolicy - WhatWeCollect&How content"),
			PreLoginfooterlnk_PrivacyPolicy_WhatwecollectandHow_backtoTop("//div[@id='What_We_Collect']/span[@class='mobile']/a[contains(text(),'Back to Top')]",XPATH,"PreLogin - PrivacyPolicy - Linkto3rdPartyWebsites content - backtoTop"),
			PreLoginfooterlnk_PrivacyPolicy_LinktoWebsites("//h2/a[contains(text(),'Links to Third-Party Websites')]",XPATH,"PreLogin - PrivacyPolicy - LinktoWebsites"),
			PreLoginfooterlnk_PrivacyPolicy_LinktoWebsites_backtoTop("//div[@id='third_party_websites']/span[@class='mobile']/a[contains(text(),'Back to Top')]",XPATH,"PreLogin - PrivacyPolicy - Linkto3rdPartyWebsites content - backtoTop"),
			PreLoginfooterlnk_PrivacyPolicy_CaliforniaCCPARights("//h2/a[contains(text(),'Notice to California Residents � Your CCPA Rights')]",XPATH,"PreLogin - PrivacyPolicy - CaliforniaCCPARights"),
			PreLoginfooterlnk_PrivacyPolicy_CaliforniaCCPARights_backtoTop("//div[@id='notice_to_california_ccpa_rights']/span[@class='mobile']/a[contains(text(),'Back to Top')]",XPATH,"PreLogin - PrivacyPolicy - CaliforniaCCPARights content - backtoTop"),
			
			//Newport
			PreLoginfooterlnkNewport_FAQs("//div[@class='footer-mobile']//div/a[@href='/FooterLinks/Faqs']",XPATH,"PreLogin - FAQs footerlink"),
			PreLoginfooterlnkNewport_ContactUs("//div[@class='footer-mobile']//div/a[@href='/FooterLinks/ContactUs']",XPATH,"PreLogin - ContactUs footerlink"),
			PreLoginfooterlnkNewport_TobaccoRights("//div[@class='footer-mobile']//div/a[@href='https://ownitvoiceit.com/']",XPATH,"PreLogin - TobaccoRights"),
			PreLoginfooterlnkNewport_SiteRequrmnts("//div[@class='footer-mobile']//div/a[@href='/FooterLinks/SiteRequirements']",XPATH,"PreLogin - SiteRequirements"),
			PreLoginfooterlnkNewport_AgeFiltering("//div[@class='footer-mobile']//div/a[@href='/FooterLinks/AgeFilteringSoftware']",XPATH,"PreLogin - AgeFiltering"),
			PreLoginfooterlnkNewport_TermsOfUse("//div[@class='footer-mobile']//div/a[@href='/FooterLinks/TermsOfUse']",XPATH,"PreLogin - TermsOfUse"),
			PreLoginfooterlnkNewport_PrivacyPolicy("//div[@class='footer-mobile']//div/a[@href='/FooterLinks/PrivacyPolicy']",XPATH,"PreLogin - PrivacyPolicy"),
			
			
			
			//PostLogin - Revel Footerlinks
		    PostLoginRevelfooterlnk_FAQs("//div/ul/li/a[contains(text(),'FAQs')]",XPATH,"PostLogin - Revel FAQs footerlink"),
		    PostLoginRevelfooterlnk_ContactUs("//div/ul/li/a[contains(text(),'Contact Us')]",XPATH,"PostLogin - Revel ContactUs footerlink"),
		    PostLoginRevelfooterlnk_TobaccoRights("//div/ul/li/a[contains(text(),'Tobacco Rights')]",XPATH,"PostLogin - Revel TobaccoRights footerlink"),
		    PostLoginRevelfooterlnk_SiteRequirements("//div/ul/li/a[contains(text(),'Site Requirements')]",XPATH,"PostLogin - Revel SiteRequirements footerlink"),
		    PostLoginRevelfooterlnk_AgeFiltering("//div/ul/li/a[contains(text(),'Age Filtering')]",XPATH,"PostLogin - Revel AgeFiltering footerlink"),
		    PostLoginRevelfooterlnk_TermsOfUse("//div/ul/li/a[contains(text(),'Terms of Use')]",XPATH,"PostLogin - Revel TermsOfUse footerlink"),
		    PostLoginRevelfooterlnk_PrivacyPolicy("//div/ul/li/a[contains(text(),'Privacy Policy')]",XPATH,"PostLogin - Revel PrivacyPolicy footerlink"),
		    PostLoginRevelfooterlnk_TermsOfSale("//div/ul/li/a[contains(text(),'Terms Of Sale')]",XPATH,"PostLogin - Revel TermsOfSale footerlink"),
		    
		    PostLoginRevelfooterlnk_TermsOfUse_Restrictions("(//span/a[contains(text(),'Restrictions On Access And Use')])[1]",XPATH,"PreLogin - TermsOfUse - Restrictions Content"),  
		    
		    PostLoginRevelfooterlnk_PrivacyPolicy_Whatwecollect("//h2/a[contains(text(),'What We Collect')]",XPATH,"PreLogin - PrivacyPolicy - WhatWeCollect&How content"),
			PostLoginRevelfooterlnk_PrivacyPolicy_Whatwecollect_backtoTop("//div[@id='What_We_Collect']/span[@class='mobile']/a[contains(text(),'Back to Top')]",XPATH,"PostLogin - PrivacyPolicy - Linkto3rdPartyWebsites content - backtoTop"),
			PostLoginRevelfooterlnk_PrivacyPolicy_LinktoWebsites("//h2/a[contains(text(),'Links to Third-Party Websites')]",XPATH,"PostLogin - PrivacyPolicy - LinktoWebsites"),
			PostLoginRevelfooterlnk_PrivacyPolicy_LinktoWebsites_backtoTop("//div[@id='third_party_websites']/span[@class='mobile']/a[contains(text(),'Back to Top')]",XPATH,"PostLogin - PrivacyPolicy - Linkto3rdPartyWebsites content - backtoTop"),
			PostLoginRevelfooterlnk_PrivacyPolicy_CaliforniaRights("//h2/a[contains(text(),'Notice to California Residents — Your California Privacy Rights')]",XPATH,"PostLogin - PrivacyPolicy - CaliforniaRights"),
			PostLoginRevelfooterlnk_PrivacyPolicy_CaliforniaRights_backtoTop("//div[@id='notice_to_california']/span[@class='mobile']/a[contains(text(),'Back to Top')]",XPATH,"PreLogin - PrivacyPolicy - CaliforniaRights content - backtoTop"),
		     
		  
		    
			
			//PostLogin - VUSE Footerlinks
		       PostLoginVUSEfooterlnk_StoreLocator("//nav/ul/li/a[contains(text(),'Store Locator')]",XPATH,"PostLogin - VUSE - StoreLocator"),
		       PostLoginVUSEfooterlnk_ContactUs("//nav/ul/li/a[contains(text(),'Contact Us')]')]",XPATH,"PostLogin - VUSE - ContactUs"),
		       PostLoginVUSEfooterlnk_FAQs("//nav/ul/li/a[contains(text(),'Faq')]",XPATH,"PostLogin - VUSE - FAQs"),
		       PostLoginVUSEfooterlnk_Patents("//nav/ul/li/a[contains(text(),'Patents')]",XPATH,"PostLogin - VUSE - Patents"),
		       PostLoginVUSEfooterlnk_TobaccoRights("//nav/ul/li/a[contains(text(),'Tobacco Rights')]",XPATH,"PostLogin - VUSE - TobaccoRights"),
		       PostLoginVUSEfooterlnk_AgeFiltering("//nav/ul/li/a[contains(text(),'Age Filtering')]",XPATH,"PostLogin - VUSE - AgeFiltering"),
		       PostLoginVUSEfooterlnk_SiteMap("//nav/ul/li/a[contains(text(),'Site Map')]",XPATH,"PostLogin - VUSE - SiteMap"),
		       PostLoginVUSEfooterlnk_TermsOfUse("//nav/ul/li/a[contains(text(),'Terms of Use')]",XPATH,"PostLogin - VUSE - TermsOfUse"),
		       PostLoginVUSEfooterlnk_TermsOfSale("//nav/ul/li/a[contains(text(),'Terms Of Sale')]",XPATH,"PostLogin - VUSE - TermsOfSale"),
		       PostLoginVUSEfooterlnk_SiteRequirements("//nav/ul/li/a[contains(text(),'Site Requirements')]",XPATH,"PostLogin - VUSE - SiteRequirements"),
		       PostLoginVUSEfooterlnk_PrivacyPolicy("//nav/ul/li/a[contains(text(),'Privacy Policy')]",XPATH,"PostLogin - VUSE - PrivacyPolicy"),
		       PostLoginVUSE_Menu("//button[@class='nav-toggle display--tablet-down display--small-only']",XPATH,"PostLogin - VUSE - AccountIcon"),
		       PostLoginVUSE_MyAccount("//ul[@class='nav__menu']/li/a[@href='https://qa1-vusevapor.raimktg.com/customer/account/']",XPATH,"PostLogin - VUSE - AccountIcon"),
		       PostLoginVUSE_MyAccountlink("//div/ul/li/a[contains(text(),'My Account')]",XPATH,"VUSE PostLogin - MyAccountLink"),
		       PostLoginVUSE_LogOut("//div/ul/li/a[contains(text(),'Log Out')]",XPATH,"PostLogin - VUSE - LogOut"),
		       PostLoginRevel_LogOut("//nav/ul/li/a[contains(text(),'Log Out')]",XPATH,"PostLogin - Logout"),
		       PostLoginVuse_LogOutlink("//div[@class='account-nav__title']",XPATH,"PostLogin - Logout"),
		       MobilesiteVuse_LogOut("//ul[@class='nav items']/li/a[contains(text(),'Log Out')]",XPATH,"PostLogin - Logout"),
		       
		     //div[@class='account-nav__title']
		     //button[@class='nav-toggle display--tablet-down display--small-only']
		//PostLogin - Camel and Newport Footerlinks
			PostLoginfooterlnk_FAQs("//div/a[contains(text(),'FAQs')]",XPATH,"PostLogin - FAQs footerlink"),
			PostLoginfooterlnk_ContactUs("//div/a[contains(text(),'Contact Us')]",XPATH,"PostLogin - ContactUs footerlink"),
			PostLoginfooterlnk_ContactUsQuestion("email-topic",NAME,"PostLogin - ContactUs Question dropdown"),
			PostLoginfooterlnk_ContactUsAnswer("email-content",ID,"PostLogin - ContactUs Answer textbox"),
			PostLoginfooterlnk_ContactUsSubmit("edit-submit",ID,"PostLogin - ContactUs Submit"),
			PostLoginfooterlnk_TobaccoRights("//div/a[contains(text(),'Tobacco Rights')]",XPATH,"PostLogin - TobaccoRights footerlink"),
			PostLoginfooterlnk_SiteRequirements("//div/a[contains(text(),'Site Requirements')]",XPATH,"PostLogin - SiteRequirements footerlink"),
			PostLoginfooterlnk_AgeFiltering("//div/a[contains(text(),'Age')]",XPATH,"PostLogin - AgeFiltering footerlink"),
			PostLoginfooterlnk_TermsOfUse("//div/a[contains(text(),'Terms')]",XPATH,"PostLogin - TermsOfUse footerlink"),
			PostLoginfooterlnk_PrivacyPolicy("//div/a[contains(text(),'Privacy Policy')]",XPATH,"PostLogin - PrivacyPolicy footerlink"),
			
			PostLoginCamelfooterlnk_Logout("//div/a[@href='/logout']",XPATH,"PostLogin - Logout footerlink"),
			PostLoginNewportfooterlnk_Logout("//li/a[contains(text(),'Log Out')]",XPATH,"PostLogin - Logout footerlink"),
			
		//PostLogin - Pallmall Footerlinks
			PostLoginPallmallfooterlnk_FAQs("//footer[@id='site-footer']//div//div//nav[@class='footer-nav-primary']/a[@href='https://qa-pallmall.raimktg.com/FooterLinks/Faqs']",XPATH,"PostLogin - Pallmall FAQs footerlink"),
			PostLoginPallmallfooterlnk_ContactUs("//footer[@id='site-footer']//div//div//nav[@class='footer-nav-primary']/a[@href='https://qa-pallmall.raimktg.com/FooterLinks/ContactUs']",XPATH,"PostLogin - Pallmall ContactUs footerlink"),
			PostLoginPallmallfooterlnk_TobaccoRights("//footer[@id='site-footer']//div//div//nav[@class='footer-nav-secondary']/a[contains(text(),'Tobacco Rights')]",XPATH,"PostLogin - Pallmall TobaccoRights footerlink"),
			PostLoginPallmallfooterlnk_SiteRequirements("//footer[@id='site-footer']//div//div//nav[@class='footer-nav-secondary']/a[contains(text(),'Site Requirements')]",XPATH,"PostLogin - Pallmall SiteRequirements footerlink"),
			PostLoginPallmallfooterlnk_AgeFiltering("//footer[@id='site-footer']//div//div//nav[@class='footer-nav-secondary']/a[contains(text(),'Site Requirements')]",XPATH,"PostLogin - Pallmall AgeFiltering footerlink"),
			PostLoginPallmallfooterlnk_TermsOfUse("//footer[@id='site-footer']//div//div//nav[@class='footer-nav-secondary']/a[contains(text(),'Terms of Use')]",XPATH,"PostLogin - Pallmall TermsOfUse footerlink"),
			PostLoginPallmallfooterlnk_PrivacyPolicy("//footer[@id='site-footer']//div//div//nav[@class='footer-nav-secondary']/a[contains(text(),'Privacy Policy and Your California Privacy Rights')]",XPATH,"PostLogin - Pallmall PrivacyPolicy footerlink"),
			
			PostLoginPallmallfooterlnk_Logout("//nav/a[contains(text(),'Logout')]",XPATH,"PostLogin - Pallmall Logout footerlink"),
			
		//PreLogin - Grizzly Footerlinks
			PreLoginfooterlnk_GrizzlyContactUs("//span/a[contains(text(),'Contact Us')]",XPATH,"PreLogin - Grizzly ContactUs footerlink"),
			PreLoginfooterlnk_GrizzlyFAQs("//span/a[contains(text(),'FAQs')]",XPATH,"PreLogin - Grizzly FAQs footerlink"),
			PreLoginfooterlnk_GrizzlyTobaccoRights("//div/a[contains(text(),'Tobacco Rights')]",XPATH,"PreLogin - Grizzly TobaccoRights footerlink"),
			PreLoginfooterlnk_GrizzlySiteRequirements("//div/a[contains(text(),'Site Requirements')]",XPATH,"PreLogin - Grizzly SiteRequirements footerlink"),
			PreLoginfooterlnk_GrizzlyAgeFiltering("//div/a[contains(text(),'Age Filtering')]",XPATH,"PreLogin - Grizzly AgeFiltering footerlink"),
			PreLoginfooterlnk_GrizzlyTermsOfUse("//div/a[contains(text(),'Terms of Use')]",XPATH,"PreLogin - Grizzly TermsOfUse footerlink"),
			PreLoginfooterlnk_GrizzlyPrivacyPolicy("//div/a[contains(text(),'Privacy Policy')]",XPATH,"PreLogin - Grizzly PrivacyPolicy footerlink"),
			
		//PostLogin - Grizzly Footerlinks
			PostLoginfooterlnk_GrizzlyContactUs("//span/a[contains(text(),'Contact Us')]",XPATH,"PostLogin - Grizzly ContactUs footerlink"),
			PostLoginfooterlnk_GrizzlyFAQs("//span/a[contains(text(),'FAQs')]",XPATH,"PostLogin - Grizzly FAQs footerlink"),
			PostLoginfooterlnk_GrizzlyTobaccoRights("//span/a[contains(text(),'Tobacco Rights')]",XPATH,"PostLogin - Grizzly TobaccoRights footerlink"),
			PostLoginfooterlnk_GrizzlySiteRequirements("//span/a[contains(text(),'Site Requirements')]",XPATH,"PostLogin - Grizzly SiteRequirements footerlink"),
			PostLoginfooterlnk_GrizzlyAgeFiltering("//span/a[contains(text(),'Age Filtering')]",XPATH,"PostLogin - Grizzly AgeFiltering footerlink"),
			PostLoginfooterlnk_GrizzlyTermsOfUse("//span/a[contains(text(),'Terms of Use')]",XPATH,"PostLogin - Grizzly TermsOfUse footerlink"),
			PostLoginfooterlnk_GrizzlyPrivacyPolicy("//span/a[contains(text(),'Privacy Policy')]",XPATH,"PostLogin - Grizzly PrivacyPolicy footerlink"),
			
			PostLogin_Menu("//div/a/span[contains(text(),'Menu')]",XPATH,"PostLogin - Menu icon"),
			PostLogin_Menu_Logout("//div/a[contains(text(),'Log Out')]",XPATH,"PostLogin - Logout icon"),
			
		//PreLogin - AmericanSpirit Footerlinks
	        PreLoginNASfooterlnk_FAQs("//nav/nav/div/a[contains(text(),'FAQs')]",XPATH,"PreLogin - NASCIGS FAQs footerlink"),
	        PreLoginNASfooterlnk_ContactUs("//nav/nav/div/a[contains(text(),'Contact Us')]",XPATH,"PreLogin - NASCIGS Contact Us footerlink"),
	        PreLoginNASfooterlnk_TobaccoRights("//nav/nav/div/a[contains(text(),'Tobacco Rights')]",XPATH,"PreLogin - NASCIGS TobaccoRights footerlink"),
	        PreLoginNASfooterlnk_SiteRequirements("//nav/nav/div/a[contains(text(),'Site Requirements')]",XPATH,"PreLogin - NASCIGS SiteRequirements footerlink"),
	        PreLoginNASfooterlnk_AgeFiltering("//nav/nav/div/a[contains(text(),'Age Filtering')]",XPATH,"PreLogin - NASCIGS AgeFiltering footerlink"),
	        PreLoginNASfooterlnk_TermsOfUse("//nav/nav/div/a[contains(text(),'Terms of Use')]",XPATH,"PreLogin - NASCIGS TermsOfUse footerlink"),
	        PreLoginNASfooterlnk_PrivacyPolicy("//nav/nav/div/a[contains(text(),'Privacy Policy')]",XPATH,"PreLogin - NASCIGS PrivacyPolicy footerlink"),
	
	  //PostLogin - AmericanSpirit Footerlinks
	       PostLoginNASfooterlnk_SFNTC("//footer[@class='Footer Footer-primary']//div//nav/a[contains(text(),'FAQS')]",XPATH,"PostLogin - NASCIGS SFNTC footerlink"),
	       PostLoginNASfooterlnk_ResponsibleMarketing("//footer[@class='Footer Footer-primary']//div//nav/a[contains(text(),'Responsible Marketing')]",XPATH,"PostLogin - NASCIGS ResponsibleMarketing footerlink"),
	       PostLoginNASfooterlnk_ContactUs("//footer[@class='Footer Footer-primary']//div//nav/a[contains(text(),'Contact Us')]",XPATH,"PostLogin - NASCIGS ContactUs footerlink"), 
	       PostLoginNASfooterlnk_TobaccoRights("//footer[@class='Footer Footer-primary']//div//nav/a[contains(text(),'Tobacco Rights')]",XPATH,"PostLogin - NASCIGS TobaccoRights footerlink"),
	       PostLoginNASfooterlnk_SiteRequirements("//footer[@class='Footer Footer-primary']//div//nav/a[contains(text(),'Site Requirements')]",XPATH,"PostLogin - NASCIGS SiteRequirements footerlink"),
	       PostLoginNASfooterlnk_AgeFiltering("//footer[@class='Footer Footer-primary']//div//nav/a[contains(text(),'Age Filtering')]",XPATH,"PostLogin - NASCIGS AgeFiltering footerlink"),
	       PostLoginNASfooterlnk_TermsOfUse("//footer[@class='Footer Footer-primary']//div//nav/a[contains(text(),'Terms Of Use')]",XPATH,"PostLogin - NASCIGS TermsOfUse footerlink"),
	       PostLoginNASfooterlnk_PrivacyPolicy("//footer[@class='Footer Footer-primary']//div//nav/a[contains(text(),'Privacy Policy')]",XPATH,"PostLogin - NASCIGS PrivacyPolicy footerlink"),
	       
	       PostLoginNASfooterlnk_LogOut("//footer[@class='Footer Footer-primary']//div//nav/a[contains(text(),'Logout')]",XPATH,"PostLogin - NASCIGS LogOut footerlink"),
	       
	  //PreLogin - Revel Footerlinks
	       PreLoginRevelfooterlnk_FAQs("//div/nav/div/a[contains(text(),'FAQs')]",XPATH,"PreLogin - Revel FAQs footerlink"),
	       PreLoginRevelfooterlnk_ContactUs("//div/nav/div/a[contains(text(),'Contact Us')]",XPATH,"PreLogin - Revel ContactUs footerlink"),
	       PreLoginRevelfooterlnk_TobaccoRights("//div/nav/div/a[contains(text(),'Tobacco Rights')]",XPATH,"PreLogin - Revel TobaccoRights footerlink"),
	       PreLoginRevelfooterlnk_SiteRequirements("//div/nav/div/a[contains(text(),'Site Requirements')]",XPATH,"PreLogin - Revel SiteRequirements footerlink"),
	       PreLoginRevelfooterlnk_AgeFiltering("//div/nav/div/a[contains(text(),'Age Filtering')]",XPATH,"PreLogin - Revel AgeFiltering footerlink"),
	       PreLoginRevelfooterlnk_TermsOfUse("//div/nav/div/a[contains(text(),'Terms of Use')]",XPATH,"PreLogin - Revel TermsOfUse footerlink"),
	       PreLoginRevelfooterlnk_PrivacyPolicy("//div/nav/div/a[contains(text(),'Privacy Policy')]",XPATH,"PreLogin - Revel PrivacyPolicy footerlink"),
	       PreLoginRevelfooterlnk_TermsOfSale("//div/nav/div/a[contains(text(),'Terms Of Sale')]",XPATH,"PreLogin - Revel TermsOfSale footerlink"),
	       
	  //PostLogin - Revel Footerlinks
	       
	       
	       
	       
	       
	  //PreLogin - Velo Footerlinks
	       PreLoginVelofooterlnk_FAQs("//nav/div/div/a[contains(text(),'FAQs')]",XPATH,"PreLogin - Velo FAQs footerlink"),
	       PreLoginVelofooterlnk_ContactUs("//nav/div/div/a[contains(text(),'Contact Us')]",XPATH,"PreLogin - Velo ContactUs footerlink"),
	       PreLoginVelofooterlnk_TobaccoRights("//nav/div/div/a[contains(text(),'Tobacco Rights')]",XPATH,"PreLogin - Velo TobaccoRights footerlink"),
	       PreLoginVelofooterlnk_SiteRequirements("//nav/div/div/a[contains(text(),'Site Requirements')]",XPATH,"PreLogin - Velo SiteRequirements footerlink"),
	       PreLoginVelofooterlnk_AgeFiltering("//nav/div/div/a[contains(text(),'Age Filtering')]",XPATH,"PreLogin - Revel AgeFiltering footerlink"),
	       PreLoginVelofooterlnk_TermsOfUse("//nav/div/div/a[contains(text(),'Terms of Use')]",XPATH,"PreLogin - Velo TermsOfUse footerlink"),
	       PreLoginVelofooterlnk_PrivacyPolicy("//nav/div/div/a[contains(text(),'Privacy Policy')]",XPATH,"PreLogin - Velo PrivacyPolicy footerlink"),
	       
	  //PostLogin - Velo Footerlinks
	       
	       
	
	  //ResetPages
	
	   Continuebtn_LoginResetviaLoginonGeneralInfo("//div/input[@id='edit-submit']",XPATH,"ResetFlow through Login - Continue button on GeneralInfo page"),    
	   txt_LoginResetAccntInfoEmail("UserInformation_EmailAddress",ID,"ResetFlow - AccountInfo - Email"),
	   txt_LoginResetAccntInfoPassword("UserInformation_Password",ID,"ResetFlow - AccountInfo - Password "),
	   txt_LoginResetAccntInfoConfirmPassword("UserInformation_ConfirmPassword",ID,"ResetFlow - AccountInfo - ConfirmPassword"),
	   drpdnw_LoginResetAccntInfoChallengeQuestion("UserInformation_ChallengeQuestionId",ID,"ResetFlow - AccountInfo - ChallengeQuestion"),
	   txt_LoginResetAccntInfoChallengeAnswer("UserInformation_ChallengeAnswer",ID,"ResetFlow - AccountInfo - ChallengeAnswer"),
	   btn_LoginResetAccntInfoSave("edit-submit",ID,"ResetFlow - AccountInfo - Save"),
	
	   errormsg_LoginResetAcctInfoNoEmailEntered("emailError",ID,"ResetFlow - AccountInfo - No Email entered"),      //Please enter a valid email address
       errormsg_LoginResetAccntInfoExistingEmail("emailErrorAjax",ID,"ResetFlow - AccountInfo - User entered already existing email"), //Username already taken. Please try a different one.
	   errormsg_LoginResetAccntInfoInvalidEmail("emailError",ID,"ResetFlow - AccountInfo - User entered Invalid email"), //Please enter a valid email address
	   errormsg_LoginResetAccntInfoInactiveEmail("inactiveEmail",ID,"ResetFlow - AccountInfo - User entered Valid Inactive email"), //This is not an active email address. Please provide an active email address.
	   errormsg_LoginResetAccntInfoNoPassword("passwordError",ID,"ResetFlow - No Password entered"),         //Please provide a password
	   errormsg_LoginResetAccntInfoInvalidPasswordFormat("passwordFormatError",ID,"ResetFlow - Invalid Password format entered"),   //Password must be a combination of 8-12 letters and numbers with at least one capital letter and at least one number.
	   errormsg_LoginResetAccntInfoDifferentPasswordEntered("passwordConfirmError",ID,"ResetFlow - Different data entered in Password & ConfirmPassword fields"),    //Passwords did not match
	   errormsg_LoginResetAccntInfoNoChallengeQuestion("questionError",ID,"ResetFlow - No ChallengeQuestion selected"),     //Please select a account recovery question
	   errormsg_LoginResetAccntInfoNoChallengeAnswer("answerError",ID,"ResetFlow - No ChallengeAnswer selected"),        //Please provide an answer to account recovery question
	   errormsg_LoginResetAccntInfoNoDataEntered("//div[@class='errorText formError']",XPATH,"ResetFlow - No data entered on AccntInfo Page"),      //Please fix the errors above
	 //Revel Profile
	    PostLoginRevel_AccountMenu("//div/ul/li/a[contains(text(),'Account')]",XPATH,"PostLogin - Revel AccountMenu"),
	    PostLoginRevel_AddressBook("//nav/ul/li/a[contains(text(),'Address Book')]",XPATH,"PostLogin - Menu - AddressBook"),
	    btnEdit_ProfileRevel_BillingAddress("(//div/div/a/span[contains(text(),'Edit')])[1]",XPATH,"RevelProfile - Edit - BillingAddress"),
	    btnEdit_ProfileRevel_ShippingAddress("(//div/div/a/span[contains(text(),'Edit')])[2]",XPATH,"RevelProfile - Edit - ShippingAddress"),
	    btn_ProfileRevel_AddNewAddress("//div/button/span[contains(text(),'Add New Address')]",XPATH,"RevelProfile - AddressBook - Add New Address"),
	    txt_Profile_BillingAddress_FirstName("//div/input[@id='firstname']",XPATH,"RevelProfile - BillingAddress - FirstName"),
	    txt_Profile_BillingAddress_LastName("//div/input[@id='lastname']",XPATH,"RevelProfile - BillingAddress - LastName"),
	    txt_Profile_BillingAddress_Telephone("//input[@id='telephone']",XPATH,"Revel Profile - BillingAddress - Telephone"),
	    txt_Profile_BillingAddress_Address("//div/input[@id='street_1']",XPATH,"Revel Profile - BillingAddress - Address"),
	    txt_Profile_BillingAddress_Zipcode("//div/input[@id='postcode']",XPATH,"Revel Profile - BillingAddress - Zipcode"),
	    btn_Profile_BillingAddress_Save("//div/button[contains(text(),'Save Address')]",XPATH,"RevelProfile - BillingAddress - SaveAddress"),
	    btn_Profile_BillingAddress_Cancel("//div/a[contains(text(),'Cancel')]",XPATH,"RevelProfile - BillingAddress - Cancel"),
	    btn_Navigation("//div[@class='account-nav-title']",XPATH,"Button"),
	    errormsg_BillingAddress_NoFirstName("//div[@id='firstname-error']",XPATH,"RevelProfile - BillingAddress - No FirstName"),    //This is a required field.
	    errormsg_BillingAddress_NoLastName("//div[@id='lastname-error']",XPATH,"RevelProfile - BillingAddress - No LastName"),
	    errormsg_BillingAddress_NoTelephone("//div[@id='telephone-error']",XPATH,"RevelProfile - BillingAddress - No Telephone"),
	    errormsg_BillingAddress_NoAddress1("//div[@id='street_1-error']",XPATH,"RevelProfile - BillingAddress - No Address"),
	    errormsg_BillingAddress_NoZipcode("//div[@id='postcode-error']",XPATH,"RevelProfile - BillingAddress - No Zipcode"),
	    
	    
	  //PostLogin - Velo Footerlinks
	       PostLoginVelofooterlnk_FAQs("//div/ul/li/a[contains(text(),'FAQs')]",XPATH,"PostLogin - Velo FAQs footerlink"),
	       PostLoginVelofooterlnk_ContactUs("//div/ul/li/a[contains(text(),'Contact Us')]",XPATH,"PostLogin - Velo ContactUs footerlink"),
	       PostLoginVelofooterlnk_TobaccoRights("//div/ul/li/a[contains(text(),'Tobacco Rights')]",XPATH,"PostLogin - Velo TobaccoRights footerlink"),
	       PostLoginVelofooterlnk_SiteRequirements("//div/ul/li/a[contains(text(),'Site')]",XPATH,"PostLogin - Velo SiteRequirements footerlink"),
	       PostLoginVelofooterlnk_AgeFiltering("//div/ul/li/a[contains(text(),'Age')]",XPATH,"PostLogin - Revel AgeFiltering footerlink"),
	       PostLoginVelofooterlnk_TermsOfUse("//div/ul/li/a[contains(text(),'Terms of Use')]",XPATH,"PostLogin - Velo TermsOfUse footerlink"),
	       PostLoginVelofooterlnk_PrivacyPolicy("//div/ul/li/a[contains(text(),'Privacy Policy')]",XPATH,"PostLogin - Velo PrivacyPolicy footerlink"),
	       
	       PostLoginVelo_AccountMenu("//ul[@class='nav-menu mobile']/li/img[@class='img-fluid loggedIn']",XPATH,"PostLogin - Velo AccountMenu"),
		   PostLoginVelo_LogOut("//ul[@class='nav-menu mobile']//div/ul[@class='account-nav']/li[contains(text(),'Log out')]",XPATH,"PostLogin - Velo Logout"),
		   PostLoginVelo_Profile("//ul[@class='nav-menu mobile']//div/ul[@class='account-nav']/li[contains(text(),'My Account')]",XPATH,"PostLogin - Profile"),
	    
	       
		   PostLoginVUSEfooterlnk_PrivacyPolicy_Whatwecollect("(//h2/a[contains(text(),'What We Collect')])",XPATH,"PreLogin - PrivacyPolicy - WhatWeCollect&How content"),
		   PostLoginVUSEfooterlnk_PrivacyPolicy_Whatwecollect_backtoTop("//div[@id='What_We_Collect']/span[@class='mobile']/a[contains(text(),'Back to Top')]",XPATH,"PostLogin - PrivacyPolicy - Linkto3rdPartyWebsites content - backtoTop"),
		   PostLoginVUSEfooterlnk_PrivacyPolicy_LinktoWebsites("//h2/a[contains(text(),'Links to Third-Party Websites')]",XPATH,"PostLogin - PrivacyPolicy - LinktoWebsites"),
		   PostLoginVUSEfooterlnk_PrivacyPolicy_LinktoWebsites_backtoTop("//div[@id='third_party_websites']/span[@class='mobile']/a[contains(text(),'Back to Top')]",XPATH,"PostLogin - PrivacyPolicy - Linkto3rdPartyWebsites content - backtoTop"),
		   PostLoginVUSEfooterlnk_PrivacyPolicy_CaliforniaRights("//h2/a[contains(text(),'Notice to California Residents — Your California Privacy Rights')]",XPATH,"PostLogin - PrivacyPolicy - CaliforniaRights"),
		   PostLoginVUSEfooterlnk_PrivacyPolicy_CaliforniaRights_backtoTop("//div[@id='notice_to_california']/span[@class='mobile']/a[contains(text(),'Back to Top')]",XPATH,"PreLogin - PrivacyPolicy - CaliforniaRights content - backtoTop"),
			
	       
	 
	   
	   
	   //SGW Images
		  
	   sgwText_PreLoginfooterlink("//div[@id='sgw']/ul/li[2]/img[1]",XPATH,"footerlink section - SGW Image text"),
	   
	   sgwText_PreLoginfooterlink_ecommercesites("//div[@id='page-warning']",XPATH,"Ecommerce footerlink section - SGW Image text"),
	   sgwText_PreLoginfooterlink_Nascigs("(//img[@class='sgw-desktop sgw-img'])[1]",XPATH,"NASCIGS footerlink section - SGW Image text"),
	   sgwText_PreLoginfooterlink_americanspirit("//div[@id='sgw']/img[@class='sgw-desktop sgw-img']",XPATH,"NASCIGS footerlink section - SGW Image text"),
	   sgwText_PostLoginfooterlink_Camel("(//img[@class='styles__Image-psdd8o-1 kFWAtR'])[1]",XPATH,"Camel PostLogin footerlink section - SGWImage text"),   
	   sgwText_PostLoginfooterlink_Grizzly("//div[@id='warning__label']/p[@id='warning__text']",XPATH,"Grizzly PostLogin footerlink section - SGWImage text"),  
	   sgwText_PostLoginfooterlink_Newport("//img[@class='sgw-mobile sgw-img']",XPATH,"Newport PostLogin footerlink section - SGW Image text"),      
	   sgwText_PostLoginfooterlink_Nascigs("(//img[@class='Warnings-sgw'])[1]",XPATH,"NASCIGS footerlink section - SGW Image text"),
	   sgwText_PostLoginfooterlink_Pallmall("//footer[@id='site-footer']//div[@class='footer-content pm-container']//div//div//img[@id='sgw-footer-img']",XPATH,"Pallmall PostLogin footerlink section - SGW Image"),
	 //sgwText_PreLoginfooterlink("//img[@class='sgw-desktop sgw-img']",XPATH,"footerlink section - SGW Image text"),      
	    //sgwText_PreLoginfooterlink_ecommercesites("//div[@id='page-warning']",XPATH,"Ecommerce footerlink section - SGW Image text"),
	    sgwText_PreLoginfooterlink1_Nascigs("(//img[@class='sgw-desktop sgw-img'])[1]",XPATH,"NASCIGS footerlink section - 1st SGW Image text"),
	    sgwText_PreLoginfooterlink2_Nascigs("(//img[@class='sgw-desktop sgw-img'])[2]",XPATH,"NASCIGS footerlink section - 2nd SGW Image text"),
	    sgwText_PreLoginfooterlink3_Nascigs("(//img[@class='sgw-desktop sgw-img'])[3]",XPATH,"NASCIGS footerlink section - 3rd SGW Image text"),
	    //sgwText_PostLoginfooterlink_Camel("//*[@id=\"main\"]/footer/div/img",XPATH,"Camel PostLogin footerlink section - SGWImage text"),   
	    //sgwText_PostLoginfooterlink_Grizzly("//div[@id='warning__label']/p[@id='warning__text']",XPATH,"Grizzly PostLogin footerlink section - SGWImage text"),  
	    //sgwText_PostLoginfooterlink_Newport("//img[@class='sg-warning-img']",XPATH,"Newport PostLogin footerlink section - SGW Image text"),      
	    sgwText_PostLoginfooterlink1_Nascigs("//*[@id='root']/div/footer/div/div/img",XPATH,"NASCIGS footerlink section - 1st SGW Image text"),
	    sgwText_PostLoginfooterlink2_Nascigs("//footer[@class='Footer Footer-primary']//div[@class='Warnings-nonsgw']//img[1]",XPATH,"NASCIGS footerlink section - 2nd SGW Image text"),
	    sgwText_PostLoginfooterlink3_Nascigs("//footer[@class='Footer Footer-primary']//div[@class='Warnings-nonsgw']//img[2]",XPATH,"NASCIGS footerlink section - 3rd SGW Image text"),
	    //sgwText_PostLoginfooterlink_Pallmall("(//div[@class='sgw-img']/img)[2]",XPATH,"Pallmall PostLogin footerlink section - SGW Image"),   
	    sgwText_PreLoginfooterlink_Grizzly1200("//li[@class='warnings']/img[@class='warning1200 sgw-img']",XPATH,"Grizzly PostLogin footerlink section - SGWImage text"),
	    sgwText_PreLoginfooterlink_Grizzly320("//li[@class='warnings']/img[@class='warning320 sgw-img']",XPATH,"Grizzly PostLogin footerlink section - SGWImage text"),
	    sgwText_PreLoginfooterlink_Grizzly480("//li[@class='warnings']/img[@class='warning480 sgw-img']",XPATH,"Grizzly PostLogin footerlink section - SGWImage text"),
	    sgwText_PreLoginfooterlink_Grizzly720("//li[@class='warnings']/img[@class='warning720 sgw-img']",XPATH,"Grizzly PostLogin footerlink section - SGWImage text"),
	    sgwText_PreLoginfooterlink_Grizzly960("//li[@class='warnings']/img[@class='warning960 sgw-img']",XPATH,"Grizzly PostLogin footerlink section - SGWImage text"),

	   
	   
	   txt_LoginResetCongratsPageEmail("username",ID,""),
	   txt_LoginResetCongratsPagePassword("password",ID,""),
	   chckbox_LoginResetCongrtatsPageRememberMe("IsRememberUserChecked",ID,""),
	   lnk_LoginResetCongratsPageForgotUsername("//a[@href='/Security/ForgotLoginId']",XPATH,""),
	   lnk_LoginResetCongatsPageForgotPassword("//a[@href=\"/Security/GetPassword\"]",XPATH,""),
	   btn_LoginResetCongratsPageLogin("edit-submit",ID,"");
	   
		
	String strProperty = "";
   	ObjectLocator locatorType = null;
   	String strObjName = "";
   	
	@Override
	public String getProperty() {
		// TODO Auto-generated method stub
		return strProperty;
	}

	@Override
	public ObjectLocator getLocatorType() {
		// TODO Auto-generated method stub
		return locatorType;
	}

	@Override
	public String getObjectname() {
		// TODO Auto-generated method stub
		return strObjName;
	}
	
	private MobilesitePageObjects (String strPropertyValue, ObjectLocator locatorType, String strObjName) {
		// TODO Auto-generated method stub
		this.strProperty = strPropertyValue;
   		this.locatorType = locatorType;
   		this.strObjName = strObjName;
		
	}

}
