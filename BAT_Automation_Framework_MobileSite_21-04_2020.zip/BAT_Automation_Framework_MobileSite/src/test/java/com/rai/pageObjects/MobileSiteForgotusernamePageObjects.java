package com.rai.pageObjects;

import static com.rai.pageObjects.ObjectLocator.ID;
import static com.rai.pageObjects.ObjectLocator.XPATH;

public enum MobileSiteForgotusernamePageObjects implements PageObjects {

	//Forgot Username
    drpdwn_ForgotUsernameBirthMonth("BirthMonth",ID,"Dropdown - UsernameBirthMonth"),
    drpdwn_ForgotUsernameBirthDay("BirthDay",ID,"Dropdown - UsernameBirthDay"),
    drpdwn_ForgotUsernameBirthYear("BirthYear",ID,"Dropdown - UsernameBirthYear"),
    txt_ForgotUsernameFirstName("FirstName",ID,"Input - FirstName"),
    txt_ForgotUsernameLastName("LastName",ID,"Input - LastName"),
    txt_ForgotUsernameAddress("AddressLine1",ID,"Input - Address"),
    txt_ForgotUsernameZipcode("ZipCode",ID,"Input - Zipcode"),
    txt_ForgotUsernameCity("City",ID,"Input - City"),
    drpdwn_ForgotUsernameState("State",ID,"Dropdown - State"),
    btn_ForgotUsernameAccountInformation("next_UserInformation",ID,"Button - ContinueStep1"),
    txt_ForgotUsernameChallengeAnswer("ChallengeAnswer",ID,"Input - ChallengeAnswer"),
    btn_ForgotUsernameVerifyIdentity("next_AnswerChallengeQuestion",ID,"Button - VerifyIdentity"),
    txt_WelcomeBackPassword("//input[@data-drupal-selector='edit-password']",XPATH,"Input - PasswordonWelcomeBack"),
    chkbox_WelcomeBackRememberMe("IsRememberUserChecked",ID,"Checkbox - RememberMe"),
    lnk_WelcomeBackResetPassword("//a[@href='/Security/GetPassword']",XPATH,"Link - ResetYourPassword"),
    btn_WelcomBackLogin("//input[@type='submit']",XPATH,"Button - Login"),
    
    errormsg_ForgotUsernameUsernotfound("userNotFoundDiv",ID,"Errormsg - Usernotfound ForgotUsername"),                //errormsg - We were not able to find your information. Please check and try again.
    errormsg_ForgotUsernameNoDataonGeneralInfo("//div[@class='errorText formError']",XPATH,"Errormsg - NoProfileInfo entered - ForgotUsername"),    //Please fix the errors above
    errormsg_ForgotUsernameNoDOB("dobError",ID,"Errormsg - No DOB data on GeneralInfo page - ForgotUsername"),   //Please provide a Date Of Birth
    errormsg_ForgotUsernameNoLegalName("nameError",ID,"Errormsg - No LegalName on GeneralInfo page - ForgotUsername"),  //Please enter your legal name"
    errormsg_ForgotUsernameNoAddress("streetAddressError",ID,"Errormsg - No Address on GeneralInfo page - ForgotUsername"),   //Please provide a street address
    errormsg_ForgotUsernameNoZipcode("zipCodeError",ID,"Errormsg - No Zipcode data on GeneralInfo page - ForgotUsername"),   //Please provide a ZIP Code
    errormsg_ForgotUsernameNoCity("cityError",ID,"Errormsg - No City data on GeneralInfo page - ForgotUsername"),           //Please Provide City
    errormsg_ForgotUsernameNoState("stateError",ID,"Errormsg - No State data on GeneralInfo page - ForgotUsername"),   //Please Provide State
    errormsg_ForgotUsernamenoChallengeAnswer("answerError",ID,"Errormsg - NoChallengeAnswer entered ForgotUsername"),  //Please provide an answer to account recovery question
    errormsg_ForgotUsernameInvalidAnswer("answerMatchError",ID,"Errormsg - InvalidAnswer ForgotUsername"),             //The answer does not match our records. Please re-enter your answer to the account recovery question
    errormsg_WelcomeBackNoPassword("passwordError",ID,"Errormsg - WelcomeBackPage with no Password - ForgotUsername"), //Please enter your password.
    errormsg_WelcomeBackInvalidPassword("loginError",ID,"Errormsg - WelcomeBackPage with Invalid Password - ForgotUsername"), //Username and password do not match.
    
	;
	String strProperty = "";
   	ObjectLocator locatorType = null;
   	String strObjName = "";
   	
	@Override
	public String getProperty() {
		// TODO Auto-generated method stub
		return strProperty;
	}

	@Override
	public ObjectLocator getLocatorType() {
		// TODO Auto-generated method stub
		return locatorType;
	}

	@Override
	public String getObjectname() {
		// TODO Auto-generated method stub
		return strObjName;
	}
	
	private MobileSiteForgotusernamePageObjects (String strPropertyValue, ObjectLocator locatorType, String strObjName) {
		// TODO Auto-generated method stub
		this.strProperty = strPropertyValue;
   		this.locatorType = locatorType;
   		this.strObjName = strObjName;
		
	}
}
