package com.rai.framework;

import java.net.URL;
import org.openqa.selenium.remote.http.HttpClient;
import org.openqa.selenium.remote.http.HttpClient.Builder;
import org.openqa.selenium.remote.internal.OkHttpClient;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.util.*;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.html5.*;
import org.openqa.selenium.logging.*;
import org.openqa.selenium.remote.*;
import org.openqa.selenium.remote.http.HttpClient.Factory;
import org.openqa.selenium.NoSuchElementException;

import io.appium.java_client.*;
import io.appium.java_client.android.*;
import io.appium.java_client.ios.*;
import okhttp3.*;
import okhttp3.Response;

public class MyHttpClientFactory extends BaseClass implements org.openqa.selenium.remote.http.HttpClient.Factory {

	final OkHttpClient okHttpClient;

	public MyHttpClientFactory(OkHttpClient okHttpClient) {
		this.okHttpClient = okHttpClient;
	}

	@Override
	public org.openqa.selenium.remote.http.HttpClient createClient(URL url) {
// TODO Auto-generated method stub
		return (HttpClient) okHttpClient;
	}

	@Override
	public void cleanupIdleClients() {
// TODO Auto-generated method stub

	}

	@Override
	public Builder builder() {
		return null;
	}

	public static RemoteWebDriver connectWebViaProxy(DesiredCapabilities caps) {
		String proxyHost = mobileProperties.getProperty("ProxyHost");
		int proxyPort = Integer.parseInt(mobileProperties.getProperty("ProxyPort"));
		String host = mobileProperties.getProperty("PerfectoHostDefault");
		final String username = mobileProperties.getProperty("ProxyUsername");
		final String password = mobileProperties.getProperty("ProxyPassword");

		URL url;
		try {
			url = new URL(mobileProperties.getProperty("PerfectoHost"));
		} catch (MalformedURLException e) {
			throw new RuntimeException(e.getMessage(), e);
		}

		Authenticator proxyAuthenticator = new Authenticator() {
			@Override
			public Request authenticate(Route route, Response response) throws IOException {
				String credential = Credentials.basic(username, password);
				return response.request().newBuilder().header("Proxy-Authorization", credential).build();
			}
		};

		okhttp3.OkHttpClient.Builder client = new okhttp3.OkHttpClient.Builder().connectTimeout(60, TimeUnit.SECONDS)
				.writeTimeout(60, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS)
				.proxy(new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, proxyPort)))
				.proxyAuthenticator(proxyAuthenticator);

		Factory factory = new MyHttpClientFactory(new OkHttpClient(client.build(), url));
		HttpCommandExecutor executor = new HttpCommandExecutor(new HashMap<String, CommandInfo>(), url, factory);
		return new RemoteWebDriver(executor, caps);
	}

	public static AndroidDriver<MobileElement> connectAndroidViaProxy(DesiredCapabilities caps) {
		String proxyHost = mobileProperties.getProperty("ProxyHost");
		int proxyPort = Integer.parseInt(mobileProperties.getProperty("ProxyPort"));
		String host = mobileProperties.getProperty("PerfectoHostDefault");
		final String username = mobileProperties.getProperty("ProxyUsername");
		final String password = mobileProperties.getProperty("ProxyPassword");

		URL url;
		try {
			url = new URL(mobileProperties.getProperty("PerfectoMobileHost"));
		} catch (MalformedURLException e) {
			throw new RuntimeException(e.getMessage(), e);
		}

		Authenticator proxyAuthenticator = new Authenticator() {
			@Override
			public Request authenticate(Route route, Response response) throws IOException {
				String credential = Credentials.basic(username, password);
				return response.request().newBuilder().header("Proxy-Authorization", credential).build();
			}
		};

		okhttp3.OkHttpClient.Builder client = new okhttp3.OkHttpClient.Builder().connectTimeout(60, TimeUnit.SECONDS)
				.writeTimeout(60, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS)
				.proxy(new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, proxyPort)))
				.proxyAuthenticator(proxyAuthenticator);

		Factory factory = new MyHttpClientFactory(new OkHttpClient(client.build(), url));
		HttpCommandExecutor executor = new HttpCommandExecutor(MobileCommand.commandRepository, url, factory);
		return new AndroidDriver<>(executor, caps);
	}
}